package org.zalando.problem.spring.web.advice.io;

import org.apiguardian.api.API;

import static org.apiguardian.api.API.Status.DEPRECATED;

@API(status = DEPRECATED)
@Deprecated
@SuppressWarnings("SpellCheckingInspection")
public interface TypeMistmatchAdviceTrait extends TypeMismatchAdviceTrait {
}
