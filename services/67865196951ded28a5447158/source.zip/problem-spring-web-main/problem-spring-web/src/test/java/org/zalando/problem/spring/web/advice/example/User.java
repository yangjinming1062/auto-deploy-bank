package org.zalando.problem.spring.web.advice.example;

import lombok.Value;

@Value
public class User {

    String name;

}
