We acknowledge that every line of code that we write may potentially contain security issues.

We are trying to deal with it responsibly and provide patches as quickly as  possible. If you have anything to report to
us please use any of the following channels:

- open an [issue](../../issues)
- use our [security form](https://corporate.zalando.com/en/services-and-contact#security-form)
