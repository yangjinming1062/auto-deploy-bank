package org.zalando.problem.spring.webflux.advice.example;

import lombok.Value;

@Value
public class User {

    String name;

}
