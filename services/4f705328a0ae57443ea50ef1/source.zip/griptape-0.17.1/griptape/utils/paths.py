import os


def abs_path(path: str) -> str:
    return os.path.abspath(
        os.path.join(
            os.path.dirname(os.path.abspath(__file__)),
            os.pardir,
            path
        )
    )
