from griptape.events import BaseEvent


class MockEvent(BaseEvent):
    ...
