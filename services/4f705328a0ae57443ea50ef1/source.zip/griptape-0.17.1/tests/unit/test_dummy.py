class TestDummy:
    """
    Used to automatically pickup tests/unit as a test directory in some editors.
    """
    def test_dummy(self):
        assert True
