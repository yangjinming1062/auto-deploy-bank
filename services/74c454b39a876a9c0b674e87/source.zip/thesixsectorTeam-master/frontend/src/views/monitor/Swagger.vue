<template>
  <div style="width: 100%;height: 100%;">
    <iframe src="http://localhost:9696/swagger-ui.html" frameborder="no" style="width: 100%; height: 522px;" scrolling="auto"></iframe>
  </div>
</template>
<script>

</script>
<style>

</style>
