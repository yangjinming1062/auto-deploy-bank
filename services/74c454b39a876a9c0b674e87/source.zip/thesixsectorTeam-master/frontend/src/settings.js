module.exports = {
  swaggerUrl: 'http://localhost:5432/system/swagger-ui.html'
}
