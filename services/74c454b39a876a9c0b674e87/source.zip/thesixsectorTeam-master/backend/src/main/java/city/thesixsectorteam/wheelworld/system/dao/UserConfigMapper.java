package city.thesixsectorteam.wheelworld.system.dao;

import city.thesixsectorteam.wheelworld.system.domain.UserConfig;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

public interface UserConfigMapper extends BaseMapper<UserConfig> {
}