package city.thesixsectorteam.wheelworld.job.dao;


import city.thesixsectorteam.wheelworld.job.domain.JobLog;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

public interface JobLogMapper extends BaseMapper<JobLog> {
}