package city.thesixsectorteam.wheelworld.system.dao;

import city.thesixsectorteam.wheelworld.system.domain.Dept;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

public interface DeptMapper extends BaseMapper<Dept> {

}