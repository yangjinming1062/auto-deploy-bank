package city.thesixsectorteam.wheelworld.system.dao;

import city.thesixsectorteam.wheelworld.system.domain.Test;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

public interface TestMapper extends BaseMapper<Test> {
}