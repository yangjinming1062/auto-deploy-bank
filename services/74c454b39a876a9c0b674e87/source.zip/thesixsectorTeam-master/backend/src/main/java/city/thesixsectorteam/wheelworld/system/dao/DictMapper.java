package city.thesixsectorteam.wheelworld.system.dao;

import city.thesixsectorteam.wheelworld.system.domain.Dict;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

public interface DictMapper extends BaseMapper<Dict> {
}