package city.thesixsectorteam.wheelworld.reincarnation.dao;

import org.springframework.stereotype.Repository;

/**
 * 类/方法名称：ReincarnationDao
 * 类/方法描述：
 * 创建人：zhangmf
 * 创建时间： 2019/12/19
 * 修改备注：
 */
@Repository
public interface ReincarnationDao {
}
