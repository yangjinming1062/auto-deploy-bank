package dev.langchain4j.example.mcp;

public interface Bot {

    String chat(String prompt);
}
