package dev.langchain4j.example.booking;

public record Customer(String name, String surname) {
}