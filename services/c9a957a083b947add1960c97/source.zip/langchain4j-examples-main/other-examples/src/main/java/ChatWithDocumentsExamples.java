/**
 * 1. See examples in "rag-examples" module.
 * 2. See CustomerSupportAgentApplication and CustomerSupportAgentApplicationTest
 * from "customer-support-agent-example" module.
 */
public class ChatWithDocumentsExamples {
}
