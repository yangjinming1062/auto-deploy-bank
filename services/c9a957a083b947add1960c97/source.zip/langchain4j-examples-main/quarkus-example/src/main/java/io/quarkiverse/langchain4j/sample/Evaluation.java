package io.quarkiverse.langchain4j.sample;

public enum Evaluation {

    POSITIVE,
    NEGATIVE
}
