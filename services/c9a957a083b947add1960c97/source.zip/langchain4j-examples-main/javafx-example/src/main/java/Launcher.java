public class Launcher {
    public static void main(String[] args) {
        ChatApp.main(args);
    }
}
