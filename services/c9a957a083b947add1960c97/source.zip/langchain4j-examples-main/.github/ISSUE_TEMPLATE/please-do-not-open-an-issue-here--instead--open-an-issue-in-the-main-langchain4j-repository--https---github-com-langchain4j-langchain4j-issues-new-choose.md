---
name: 'Please do not open an issue here. Instead, open an issue in the main LangChain4j
  repository: https://github.com/langchain4j/langchain4j/issues/new/choose'
about: Issue
title: ''
labels: ''
assignees: ''

---

Please do not open an issue here.
Instead, open an issue in the main LangChain4j repository: https://github.com/langchain4j/langchain4j/issues/new/choose
