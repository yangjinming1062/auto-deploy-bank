package io.helidon.examples.integrations.langchain4j.mp.coffee.shop.assistant.ai;
