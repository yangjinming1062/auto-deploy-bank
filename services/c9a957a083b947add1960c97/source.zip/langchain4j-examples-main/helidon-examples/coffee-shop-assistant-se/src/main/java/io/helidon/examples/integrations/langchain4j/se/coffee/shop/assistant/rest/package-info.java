package io.helidon.examples.integrations.langchain4j.se.coffee.shop.assistant.rest;
