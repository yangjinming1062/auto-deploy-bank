package util.log;

public enum LogLevels {
    NONE,
    PRETTY,
    DEBUG,
    INFO
}