-- Basic v0.8.7p1 tarball --

This tarball is the result of a couple of runs from a single
incarnation of a master that was running Buildbot-0.8.7p1.  Both
builds were successful.
