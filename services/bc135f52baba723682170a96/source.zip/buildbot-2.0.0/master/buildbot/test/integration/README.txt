"Integration" tests are tests that exercise a significant chunk of the
Buildbot code, and thus do not really count as unit tests.

When debugging, get the unit tests working first, *then* work on the
integration tests.
