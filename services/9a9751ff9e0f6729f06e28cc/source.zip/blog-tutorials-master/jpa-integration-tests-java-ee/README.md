# Codebase for the blog post [#HOWTO: JPA integration tests with Java EE](https://rieckpil.de/howto-jpa-integration-tests-with-java-ee/)

Steps to run this project:

1. Clone this Git repository
2. Navigate to the folder `jpa-integration-tests-java-ee`
3. Test the application with `mvn test`
4. Have a look at the logs to see the output of the integration test
