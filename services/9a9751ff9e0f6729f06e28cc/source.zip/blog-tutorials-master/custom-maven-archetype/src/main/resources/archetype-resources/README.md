# Project ${groupId}/${artifactId}

Default documentation.
