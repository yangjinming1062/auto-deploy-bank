# Codebase for the JSF + PrimeFaces article in Java Magazin

Steps to run this project:

1. Clone this Git repository
2. Navigate to the folder `java-magazin-jsf-primefaces`
3. Run `buildAndRun.bat` for Windows and `./buildAndRun.sh` for Mac/Linux (if needed, add missing rights to execute with: `chmod +x buildAndRun.sh`)
4. Wait until Payara is up and running and visit http://localhost:8080/index.xhtml in your browser and try it!
