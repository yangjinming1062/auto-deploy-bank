INSERT INTO hogwarts_houses (name)
VALUES
  ('Gryffindor'),
  ('Hufflepuff'),
  ('Slytherin'),
  ('RavenClaw');