# Codebase for the blog post [5 Java 9 Features you might not know yet](https://rieckpil.de/review-5-java-9-features-you-might-not-know-yet/)

Steps to run this project:

1. Clone this Git repository
2. Navigate to the folder `five-java-9-features`
3. Execute the different files in `src/main/java/de/rieckpil/blog` in a IDE of your choice or with Java 11's Single File Source Code: `java StreamsUpdate.java`
