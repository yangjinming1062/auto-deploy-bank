---
name: General questions
about: Issue template to ask related questions for the presented examples
title: ''
labels: ''
assignees: ''

---

## Blog post you are referring to
<!--- Please add the name of the blog post or the folder name of the source code -->

## Your Question
<!--- Ask the question here and add as much information (code examples) as possible -->

## Context (Environment, Dependency Versions, Framework)
<!--- What Java version are you using? Which framework? Which application server? Which operating system? -->
<!--- Providing context helps answer your question -->
