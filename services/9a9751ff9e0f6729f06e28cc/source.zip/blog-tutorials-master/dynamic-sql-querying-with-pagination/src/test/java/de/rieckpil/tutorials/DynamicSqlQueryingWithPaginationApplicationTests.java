package de.rieckpil.tutorials;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DynamicSqlQueryingWithPaginationApplicationTests {

  @Test
  void contextLoads() {}
}
