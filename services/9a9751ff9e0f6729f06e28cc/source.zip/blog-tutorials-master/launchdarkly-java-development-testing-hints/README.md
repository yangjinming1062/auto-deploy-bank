# Codebase for the blog post [LaunchDarkly Java Testing and Local Development Hints](https://rieckpil.de/launchdarkly-java-testing-and-local-development-hints/)

Steps to run this project:

1. Clone this Git repository
2. Navigate to the folder `launchdarkly-java-development-testing-hints`
3. Run all tests with `./mvnw verify`

