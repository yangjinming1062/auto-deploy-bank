# Codebase for the blog post CRUD Applications with Spring Boot

Steps to run this project:

1. Clone this Git repository
2. Navigate to the folder `demo-crud-application`
3. Run the application with `mvn spring-boot:run`
4. You can now access the HTTP endpoints as demonstrated in the course at http://localhost:8080
