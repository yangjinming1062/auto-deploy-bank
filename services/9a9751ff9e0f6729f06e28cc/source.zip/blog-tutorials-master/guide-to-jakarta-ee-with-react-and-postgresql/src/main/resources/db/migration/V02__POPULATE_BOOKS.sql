INSERT INTO book VALUES (1, 'Jakarta EE 8', 'All you need to know about Jakarta EE 8', 'Duke', '123-3-42-133713-1', 'Java', '2019-09-10 12:00:00-00');
INSERT INTO book VALUES (2, 'React 16', 'Effective Frontend Development with React', 'Duke', '123-3-42-133713-2', 'React', '2019-08-08 12:00:00-00');
INSERT INTO book VALUES (3, 'MicroProfile 3', 'All you need to know about Jakarta EE 8', 'Duke', '123-3-42-133713-3', 'Java', '2019-06-11 12:00:00-00');
INSERT INTO book VALUES (4, 'Jakarta EE 9', 'All you need to know about Jakarta EE 8', 'Duke', '123-3-42-133713-4', 'Java', null);