package de.rieckpil.blog;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class DeploySpringBootToGkeApplicationTests {

  @Test
  public void contextLoads() {}
}
