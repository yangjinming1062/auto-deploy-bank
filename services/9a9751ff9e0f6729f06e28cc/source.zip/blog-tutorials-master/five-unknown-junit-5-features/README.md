# Codebase for the blog post [Five JUnit 5 features you might not know yet](https://rieckpil.de/five-junit-5-features-you-might-not-know-yet/)

Steps to run this project:

1. Clone this Git repository
2. Navigate to the folder `five-unkown-junit-5-features`
3. Execute the tests with `mvn test`
