# Codebase for the blog post [#HOWTO: Writing JavaScript code with Kotlin using Gradle](https://rieckpil.de/writing-javascript-code-with-kotlin-using-gradle/)

Steps to run this project:

1. Clone this Git repository
2. Navigate to the folder `kotlin-javascript-transpiling-gradle`
3. Run `gradle --continuous browserRun`
4. Visit http://localhost:8080 to see the output