# Codebase for the blog post [#HOWTO: GitHub Actions for Java - automate your Maven workflows](https://rieckpil.de/github-actions-for-java-automate-your-maven-workflows/)

Steps to run this project:

1. Check the GitHub Actions [workflow definition](https://github.com/rieckpil/blog-tutorials/blob/master/.github/workflows/sampleJavaMavenProject.yml) for this project
2. Visit the [Actions tab](https://github.com/rieckpil/blog-tutorials/actions?query=workflow%3A%22Build+sample+Java+Maven+project%22) to see the log output of the different `jobs`
