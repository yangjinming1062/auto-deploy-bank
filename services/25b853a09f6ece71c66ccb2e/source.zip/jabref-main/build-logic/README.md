# JabRef build logic

This directory contains gradle instructions for the build.
Initially, it was created by `gradle init` using gradle 8.13.
