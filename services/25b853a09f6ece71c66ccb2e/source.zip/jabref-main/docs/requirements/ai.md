---
parent: Requirements
---
# AI

## User Interface

### Chatting with AI
`req~ai.chat.new-message-based-on-previous~1`

To enable simple editing and resending of previous messages, <kbd>Cursor Up</kbd> should show last message.
This should only happen if the current text field is empty.

Needs: impl

<!-- markdownlint-disable-file MD022 -->
