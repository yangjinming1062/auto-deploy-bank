---
parent: Requirements
---
# Entry Editor

## Entry Editor should show the last entry
`req~entry-editor.keep-showing~1`

The Entry Editor should "always" show a valid entry.

When users search or select a group not containing the entry shown in the Entry Editor, the Entry Editor should keep showing until user select a new entry explicitly.

Needs: impl

<!-- markdownlint-disable-file MD022 -->
