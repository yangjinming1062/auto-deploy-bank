---
nav_order: 4
has_children: true
---
# Decision Records

Below, all "architectural decision records" for JabRef are listed.
This list uses the TOC functionality of the [Just the Docs Jekyll template](https://just-the-docs.github.io/just-the-docs/).

For new ADRs, please use [adr-template.md](adr-template.md) as basis.
More information on MADR is available at <https://adr.github.io/madr/>.
General information about architectural decision records is available at <https://adr.github.io/>.
