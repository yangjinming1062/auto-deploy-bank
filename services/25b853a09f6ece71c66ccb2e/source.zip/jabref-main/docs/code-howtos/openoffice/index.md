---
parent: Code Howtos
nav_order: 12
has_children: true
---
# The LibreOffice Panel
