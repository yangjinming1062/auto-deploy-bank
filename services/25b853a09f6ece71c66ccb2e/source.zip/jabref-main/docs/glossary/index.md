---
nav_order: 100
has_children: true
---
# Glossary

This section collects important terms in the domain of JabRef.
