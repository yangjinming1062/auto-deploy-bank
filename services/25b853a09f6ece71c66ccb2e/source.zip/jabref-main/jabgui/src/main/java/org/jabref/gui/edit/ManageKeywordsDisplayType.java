package org.jabref.gui.edit;

public enum ManageKeywordsDisplayType {
    CONTAINED_IN_ALL_ENTRIES,
    CONTAINED_IN_ANY_ENTRY,
}
