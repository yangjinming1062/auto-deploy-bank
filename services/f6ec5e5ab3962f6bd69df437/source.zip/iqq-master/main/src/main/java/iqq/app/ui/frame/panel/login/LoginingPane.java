package iqq.app.ui.frame.panel.login;

import iqq.app.ui.IMContentPane;

/**
 * Project  : iqq-projects
 * Author   : 承∮诺 < 6208317@qq.com >
 * Created  : 14-6-17
 * License  : Apache License 2.0
 */
public class LoginingPane extends IMContentPane {

    public LoginingPane() {

    }

}
