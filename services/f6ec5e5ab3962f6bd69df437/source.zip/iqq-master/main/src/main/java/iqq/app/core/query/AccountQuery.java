package iqq.app.core.query;

import iqq.api.bean.IMAccount;

/**
 * Created by Tony on 4/7/15.
 */
public interface AccountQuery {

    public IMAccount getOwner();

}
