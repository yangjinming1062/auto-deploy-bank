package iqq.api.bean;

/**
 * Created with IntelliJ IDEA.
 * User: solosky
 * Date: 4/19/14
 * Time: 8:01 PM
 * To change this template use File | Settings | File Templates.
 */
public enum IMStatus {
    ONLINE, OFFLINE, AWAY, SILENT, MEETING, CALLME, HIDDEN
}
