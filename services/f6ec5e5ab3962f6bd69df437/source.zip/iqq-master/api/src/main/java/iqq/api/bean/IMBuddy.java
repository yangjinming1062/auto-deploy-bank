package iqq.api.bean;

/**
 * Created with IntelliJ IDEA.
 * User: solosky
 * Date: 4/19/14
 * Time: 8:05 PM
 * To change this template use File | Settings | File Templates.
 */
public class IMBuddy extends IMUser {
    private String remark;

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }
}
