package iqq.api.bean.content;

/**
 * Project  : iqq-projects
 * Author   : 承∮诺 < 6208317@qq.com >
 * Created  : 14-5-15
 * License  : Apache License 2.0
 */
public enum IMContentType {
    TEXT, FACE, PIC
}
