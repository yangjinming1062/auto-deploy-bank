package iqq.api.bean;

/**
 * Created with IntelliJ IDEA.
 * User: solosky
 * Date: 4/19/14
 * Time: 8:02 PM
 * To change this template use File | Settings | File Templates.
 */
public enum IMDevice {
    PC, WEB, IPAD, IPHONE, ANDROID, OTHER
}
