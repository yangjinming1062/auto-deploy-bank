((window.gitter = {}).chat = {}).options = {
  room: 'encode/community'
};
