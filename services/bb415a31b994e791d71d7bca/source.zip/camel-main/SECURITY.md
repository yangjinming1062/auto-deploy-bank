# Security Policy

## Supported Versions

To see which versions of Apache Camel are supported please refer to this [page](https://camel.apache.org/download/).

## Reporting a Vulnerability

For information on how to report a new security problem please see [here](https://camel.apache.org/security/).
