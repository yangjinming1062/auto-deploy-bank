Camel Component Project
=======================

This project is a template of a Camel component.

To build this project use

    mvn install

For more help see the Apache Camel documentation:

    http://camel.apache.org/writing-components.html
    
