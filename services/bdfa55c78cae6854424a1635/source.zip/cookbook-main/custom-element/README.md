####

This tutorial shows an minimalist example of how to create a CustomElement in front-end 
and links it to python backend's callback.

Reference: https://docs.chainlit.io/api-reference/elements/custom