# Your own Claude by Anthropic 👋🔥

An example app using the Anthropic API!

# Welcome to Chainlit! 🚀🤖

- **Documentation:** Get started with our comprehensive [Chainlit Documentation](https://docs.chainlit.io) 📚
- **Discord Community:** Join our friendly [Chainlit Discord](https://discord.gg/ZThrUxbAYw) to ask questions, share your projects, and connect with other developers! 💬
