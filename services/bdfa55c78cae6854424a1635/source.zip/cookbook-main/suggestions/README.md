Title: Follow up suggestions

# Follow Up Suggestions

This cookbook demonstrates how to send suggestions to follow up to the user through a custom element.

<img width="1636" alt="Xnapper-2025-03-08-17 20 41" src="https://github.com/user-attachments/assets/e213fd66-421c-4e69-b617-30798e935476" />
