---
title: 'Chainlit Canvas'
tags: ['canvas']
---

# Chainlit Canvas

This folder shows how to use the element side bar as a canvas

https://github.com/user-attachments/assets/2acf8b46-8cf3-4908-a9e2-5e0780e0c38c
