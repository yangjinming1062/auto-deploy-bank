# change the import alias and uuid

copy by https://github.com/Chainlit/chainlit/tree/1.1.306/libs/react-client