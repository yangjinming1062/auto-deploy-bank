export interface IFeedback {
  id?: string;
  forId?: string;
  threadId?: string;
  comment?: string;
  value: number;
}
