# Welcome to HumanLayer x Chainlit! 🚀🤖

Get started with an example of an OpenAI agent that can call a human for confirmation.
