package com.apress.prospring5.ch5;

public class Agent {
    public void speak() {
        System.out.print("Bond");
    }
}
