package com.apress.prospring5.ch3;

public interface ContentHolder {

}
