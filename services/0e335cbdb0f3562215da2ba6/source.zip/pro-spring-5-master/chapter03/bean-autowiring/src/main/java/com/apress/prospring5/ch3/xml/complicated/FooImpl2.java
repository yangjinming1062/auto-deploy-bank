package com.apress.prospring5.ch3.xml.complicated;

import org.springframework.stereotype.Component;

/**
 * Created by iuliana.cosmina on 2/24/17.
 */
public class FooImpl2  implements Foo {

}
