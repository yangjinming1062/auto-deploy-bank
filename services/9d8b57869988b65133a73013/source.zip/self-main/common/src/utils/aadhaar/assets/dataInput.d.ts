export declare const testQRData: {
  testQRData: string;
};
