export type {
  CertificateData,
  PublicKeyDetailsECDSA,
  PublicKeyDetailsRSA,
} from '../utils/certificate_parsing/dataStructure.js';
