export type { EndpointType, SelfApp, SelfAppDisclosureConfig } from '../utils/appType.js';
