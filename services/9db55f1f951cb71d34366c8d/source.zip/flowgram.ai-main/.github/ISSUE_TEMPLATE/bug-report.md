---
name: Bug Report
about: Report Bug
title: "[Bug] "
labels: [bug]
---

## 🙋 SDK Version
Please input version of SDK.

## 📌 Layout
Free layout or Fixed layout?

## 💻 Environment
- Operation System: (e.g. Windows 11 / macOs 14.3)
- Node.js:
- Other:

## 📝 Question Description
