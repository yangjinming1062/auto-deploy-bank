/**
 * Copyright (c) 2025 Bytedance Ltd. and/or its affiliates
 * SPDX-License-Identifier: MIT
 */

export { CustomService } from './custom-service';
export { ValidateService } from './validate-service';
