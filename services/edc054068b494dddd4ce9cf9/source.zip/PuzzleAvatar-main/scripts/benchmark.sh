#!/bin/bash
source ./scripts/env.sh

python multi_concepts/benchmark.py