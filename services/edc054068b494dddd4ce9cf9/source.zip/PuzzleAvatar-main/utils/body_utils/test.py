import lib.common

print(lib.common.__path__)
