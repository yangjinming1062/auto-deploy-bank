import torch
import torch.nn as nn

from .network_utils import HashDecoder


class ColorNetwork(nn.Module):
    def __init__(
        self,
        cfg,
        num_layers=1,
        hidden_dim=32,
        hash_max_res=2048,
        hash_num_levels=16,
        use_eikonal=False
    ):
        super().__init__()
        self.num_layers = num_layers
        self.hidden_dim = hidden_dim

        self.net = HashDecoder(
            3,
            self.hidden_dim,
            3,
            self.num_layers,
            max_res=hash_max_res,
            num_levels=hash_num_levels,
            use_eikonal=use_eikonal,
        )

    def forward(self, x):
        albedo = torch.sigmoid(self.net(x)[0])
        return albedo
