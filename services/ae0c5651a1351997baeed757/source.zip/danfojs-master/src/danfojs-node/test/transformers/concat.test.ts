import { assert } from "chai";
import { describe, it } from "mocha";
import { DataFrame, concat , Series } from "../../dist/danfojs-node/src";

describe("Concat", ()=>{
  it("Check the axis 0 concatenation", function () {
    let data = [ [ 1, 2, 3 ], [ 4, 5, 6 ], [ 20, 30, 40 ], [ 39, 89, 78 ] ];
    let cols = [ "A", "B", "C" ];
    let df = new DataFrame(data, { columns: cols });

    let data1 = [ [ 1, 2, 3 ], [ 4, 5, 6 ], [ 20, 30, 40 ], [ 39, 89, 78 ] ];
    let cols1 = [ "A", "B", "C" ];
    let df1 = new DataFrame(data1, { columns: cols1 });

    let data2 = [ [ 1, 2, 3, 5 ], [ 4, 5, 6, 8 ], [ 20, 30, 40, 10 ] ];
    let cols2 = [ "A", "B", "C", "D" ];
    let df2 = new DataFrame(data2, { columns: cols2 });

    let new_df = concat({ dfList: [ df, df1, df2 ], axis: 0 });

    let data_values = [ [ 1, 2, 3, NaN ], [ 4, 5, 6, NaN ], [ 20, 30, 40, NaN ], [ 39, 89, 78, NaN ],
      [ 1, 2, 3, NaN ], [ 4, 5, 6, NaN ], [ 20, 30, 40, NaN ], [ 39, 89, 78, NaN ],
      [ 1, 2, 3, 5 ], [ 4, 5, 6, 8 ], [ 20, 30, 40, 10 ] ];

    assert.deepEqual(new_df.values, data_values);
  });

  it("Check the axis 1 concatenation", function () {
    let data = [ [ 1, 2, 3 ], [ 4, 5, 6 ], [ 20, 30, 40 ], [ 39, 89, 78 ] ];
    let cols = [ "A", "B", "C" ];
    let df = new DataFrame(data, { columns: cols });

    let data1 = [ [ 1, 2, 3 ], [ 4, 5, 6 ], [ 20, 30, 40 ], [ 39, 89, 78 ] ];
    let cols1 = [ "A", "B", "C" ];
    let df1 = new DataFrame(data1, { columns: cols1 });

    let data2 = [ [ 1, 2, 3, 5 ], [ 4, 5, 6, 8 ], [ 20, 30, 40, 10 ] ];
    let cols2 = [ "A", "B", "C", "D" ];
    let df2 = new DataFrame(data2, { columns: cols2 });

    let new_df = concat({ dfList: [ df, df1, df2 ], axis: 1 });

    let data_values = [ [ 1, 2, 3, 1, 2, 3, 1, 2, 3, 5 ], [ 4, 5, 6, 4, 5, 6, 4, 5, 6, 8 ],
      [ 20, 30, 40, 20, 30, 40, 20, 30, 40, 10 ], [ 39, 89, 78, 39, 89, 78, NaN,
        NaN, NaN, NaN ] ];
    assert.deepEqual(new_df.values, data_values);
  });

  it("concatenate dataframe and series along 0 axis", function(){

    let data1 = [ 1, 2, 3, 4 ];
    let data2 = [ 3, 4, 5, 6 ];

    let data = [ [ 1, 2, 3 ], [ 4, 5, 6 ], [ 20, 30, 40 ], [ 39, 89, 78 ] ];
    let cols = [ "A", "B", "C" ];
    let df = new DataFrame(data, { columns: cols });

    let s1 = new Series(data1);
    let rslt = [
      [ NaN, 1, 2, 3 ],
      [ NaN, 4, 5, 6 ],
      [ NaN, 20, 30, 40],
      [ NaN, 39, 89, 78 ],
      [ 1, NaN, NaN, NaN ],
      [ 2, NaN, NaN, NaN ],
      [ 3, NaN, NaN, NaN],
      [ 4, NaN, NaN, NaN ]
    ];

    let con = concat({ dfList: [ df, s1 ], axis: 0 });

    assert.deepEqual(con.values, rslt);

  });

  it("concatenate dataframe and series along axis 1", function(){

    let data = [ [ 1, 2, 3 ], [ 4, 5, 6 ], [ 20, 30, 40 ], [ 39, 89, 78 ] ];
    let cols = [ "A", "B", "C" ];
    let df = new DataFrame(data, { columns: cols });

    let data1 = [ 1, 2, 3, 4 ];
    let s1 = new Series(data1);
    let rslt = [
      [ 1, 1, 2, 3 ],
      [ 2, 4, 5, 6 ],
      [ 3, 20, 30, 40 ],
      [ 4, 39, 89, 78]
    ];


    let con = concat({ dfList: [ df, s1 ], axis: 1 });

    assert.deepEqual(con.values, rslt);

  });
  it("concatenate series along axis 1", function(){

    let data1 = [ 1, 2, 3, 4 ];
    let data2 = [ 3, 4, 5, 6 ];

    let s1 = new Series(data1);
    let s2 = new Series(data2);
    let rslt = [ [ 1, 3 ], [ 2, 4 ], [ 3, 5 ], [ 4, 6 ] ];


    let con = concat({ dfList: [ s1, s2 ], axis: 1 });

    assert.deepEqual(con.values, rslt);

  });
  it("concatenate series along axis 0", function(){

    let data1 = [ 1, 2, 3, 4 ];
    let data2 = [ 3, 4, 5, 6 ];

    let s1 = new Series(data1);
    let s2 = new Series(data2);
    let rslt = [
      1, 2, 3, 4,
      3, 4, 5, 6
    ];

    let con = concat({ dfList: [ s1, s2 ], axis: 0 });

    assert.deepEqual(con.values, rslt);

  });

})