# Network In Network

Implementation in 100 lines of code of the paper [Network In Network](https://arxiv.org/abs/1312.4400).

## Usage

```commandline
$ pip3 install -r requirements.txt
$ python3 nin.py
```

## Results

#### Test error
![](Imgs/nin.png)

