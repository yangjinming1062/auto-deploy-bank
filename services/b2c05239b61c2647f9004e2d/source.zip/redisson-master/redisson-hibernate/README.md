## The documentation has been moved to [https://redisson.org/docs/cache-api-implementations/#hibernate-cache](https://redisson.org/docs/cache-api-implementations/#hibernate-cache)
