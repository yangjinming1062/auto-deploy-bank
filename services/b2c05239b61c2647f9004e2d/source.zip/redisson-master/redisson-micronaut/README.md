## The documentation has been moved to [https://redisson.org/docs/microservices-integration/#micronaut](https://redisson.org/docs/microservices-integration/#micronaut)
