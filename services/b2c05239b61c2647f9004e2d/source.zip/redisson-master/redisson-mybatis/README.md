## The documentation has been moved to [https://redisson.org/docs/cache-api-implementations/#mybatis-cache](https://redisson.org/docs/cache-api-implementations/#mybatis-cache)
