## The documentation has been moved to [https://redisson.org/docs/integration-with-spring/#spring-data-redis](https://redisson.org/docs/integration-with-spring/#spring-data-redis)
