---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: ''
assignees: ''

---

<!--
Upgrade to Redisson PRO https://redisson.pro with advanced features.
-->

**Is your feature request related to a problem? Please describe.**

**Describe the solution you'd like**

**Describe alternatives you've considered**
