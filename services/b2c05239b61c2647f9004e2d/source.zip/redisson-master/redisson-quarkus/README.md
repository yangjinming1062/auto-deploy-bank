## The documentation has been moved to [https://redisson.org/docs/microservices-integration/#quarkus](https://redisson.org/docs/microservices-integration/#quarkus)
