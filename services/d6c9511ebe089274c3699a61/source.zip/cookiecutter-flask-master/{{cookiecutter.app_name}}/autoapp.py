# -*- coding: utf-8 -*-
"""Create an application instance."""
from {{cookiecutter.app_name}}.app import create_app

app = create_app()
