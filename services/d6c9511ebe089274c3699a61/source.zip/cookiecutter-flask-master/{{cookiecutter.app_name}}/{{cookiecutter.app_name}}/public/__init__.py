# -*- coding: utf-8 -*-
"""The public module, including the homepage and user auth."""
from . import views  # noqa
