If you believe you have found a security vulnerability in this project please contact a [maintainer](https://github.com/jamescurtin).
