---
name: "\U0001F680 Feature request"
about: Suggest an idea for the Cookiecutter template
title: ""
labels: enhancement
assignees: ""
---

<!-- Please search existing and closed issues to avoid creating duplicates. -->

<!-- Describe the feature you'd like and add any relevant labels. -->

<!-- Please feel welcome to contribute a Pull Request! -->
