# Installation

Run one of the following commands to add `asn1js` to your project:

```bash npm2yarn
npm install asn1js
```
