"use strict";(function(){return 42});
