b.foo;
