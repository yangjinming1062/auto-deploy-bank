"use strict";

(function () {
  return 42;
});
"use strict";

arr.map(function (x) {
  return x * MULTIPLIER;
});
