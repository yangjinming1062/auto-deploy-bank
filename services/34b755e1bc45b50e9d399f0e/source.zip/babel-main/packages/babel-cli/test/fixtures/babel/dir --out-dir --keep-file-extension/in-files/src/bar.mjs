arr.map(x => x / DIVIDER);
