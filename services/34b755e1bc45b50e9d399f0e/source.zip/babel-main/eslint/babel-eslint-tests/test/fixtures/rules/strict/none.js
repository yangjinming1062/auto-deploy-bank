"no use strict anywhere";
