export default function foo() {
  return "bar";
}
