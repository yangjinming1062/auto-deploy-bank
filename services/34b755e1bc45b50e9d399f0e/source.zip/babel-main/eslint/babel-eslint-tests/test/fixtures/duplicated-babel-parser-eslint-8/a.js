import { func1 } from "./index.js";

export function five() {
  return { five: `number(${5})` };
}
