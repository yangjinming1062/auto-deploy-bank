export default function foo() { }
