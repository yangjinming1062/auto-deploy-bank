export default {
  presets: ["@babel/preset-react"],
};
