// @flow
type Foo = {};

const FlowTypeButton = ({ }: Foo) => { };

console.log(FlowTypeButton);