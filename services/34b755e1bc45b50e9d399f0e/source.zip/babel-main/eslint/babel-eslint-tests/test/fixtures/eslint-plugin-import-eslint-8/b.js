import foo from './a.js';

console.log(foo);