"use strict";

function x () {}
