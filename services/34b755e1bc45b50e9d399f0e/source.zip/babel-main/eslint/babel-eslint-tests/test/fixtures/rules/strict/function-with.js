function x () {
  "use strict";
}
