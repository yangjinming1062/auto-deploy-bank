"use strict";

function x () {
  "use strict";
}
