"use strict";
/*
The empty statement is intentional. As of now, ESLint won't enforce
string: [2, "global"] on a program with an empty body. A test for that without
massaging the AST to ESlint's input format should fail.
*/
