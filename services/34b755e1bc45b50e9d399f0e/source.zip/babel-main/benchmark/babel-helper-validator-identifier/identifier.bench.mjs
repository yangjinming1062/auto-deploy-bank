import "./isIdentifierChar.bench.mjs";
import "./isIdentifierStart.bench.mjs";
import "./isIdentifierName.bench.mjs";
