The [AST specification](https://github.com/babel/babel/blob/main/packages/babel-parser/ast/spec.md) has been moved to the babel parser package, `packages/babel-parser`.
