try {
  throw 0;
} catch ([message]) {
  console.log(message);
}
