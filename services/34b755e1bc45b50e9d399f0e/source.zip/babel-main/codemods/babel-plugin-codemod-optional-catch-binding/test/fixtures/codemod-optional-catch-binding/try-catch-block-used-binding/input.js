try {
  throw 0;
} catch (err) {
  console.log(err, "it failed, but this code executes");
}
