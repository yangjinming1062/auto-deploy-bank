try {
  throw 0;
} catch (err) {
  console.log("it failed, but this code executes");
}
