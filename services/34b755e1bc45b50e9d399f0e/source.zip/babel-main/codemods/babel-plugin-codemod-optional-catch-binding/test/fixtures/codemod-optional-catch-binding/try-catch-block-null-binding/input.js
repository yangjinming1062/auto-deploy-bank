try {
  throw 0;
} catch {
  console.log("it failed, but this code executes");
}
