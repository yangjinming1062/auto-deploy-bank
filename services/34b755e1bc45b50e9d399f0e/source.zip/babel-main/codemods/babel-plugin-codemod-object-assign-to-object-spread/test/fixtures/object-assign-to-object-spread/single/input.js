Object.assign({test: 1});
