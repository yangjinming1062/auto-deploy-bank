Object.assign({test: 1}, test2, {test: 2}, test3);
