Object.assign({test: 1}, {test: 2});
