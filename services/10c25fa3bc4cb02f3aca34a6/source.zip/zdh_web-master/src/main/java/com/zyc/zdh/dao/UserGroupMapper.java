package com.zyc.zdh.dao;

import com.zyc.notscan.base.BaseUserGroupMapper;
import com.zyc.zdh.entity.UserGroupInfo;

/**
 * ClassName: NoticeMapper
 * @author zyc-admin
 * @date 2021年09月19日
 * @Description: TODO  
 */
public interface UserGroupMapper extends BaseUserGroupMapper<UserGroupInfo> {

}
