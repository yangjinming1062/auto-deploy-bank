package com.zyc.zdh.datax_generator;

public class Content{
    private DataxReader reader;

    private DataxWriter writer;

    public DataxReader getReader() {
        return reader;
    }

    public void setReader(DataxReader reader) {
        this.reader = reader;
    }

    public DataxWriter getWriter() {
        return writer;
    }

    public void setWriter(DataxWriter writer) {
        this.writer = writer;
    }
}