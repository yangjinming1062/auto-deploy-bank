package com.zyc.notscan.base;

import com.zyc.notscan.BaseMapper;


/**
 * ClassName: BasePermissionMapper
 * @author zyc-admin
 * @date 2018年2月6日  
 * @Description: TODO  
 */
public interface BasePermissionMapper<T> extends BaseMapper<T> {
    @Override
    default String getTable(){
        return "permission_user_info";
    }
}
