package com.zyc.zdh.dao;

import com.zyc.notscan.base.BasePluginMapper;
import com.zyc.zdh.entity.PluginInfo;

/**
 *
 */
public interface PluginMapper extends BasePluginMapper<PluginInfo> {

}
