package com.zyc.zdh.dao;

import com.zyc.notscan.base.BaseTaskInfoMapper;
import com.zyc.zdh.entity.TaskInfo;


public interface TaskInfoMapper extends BaseTaskInfoMapper<TaskInfo> {
}