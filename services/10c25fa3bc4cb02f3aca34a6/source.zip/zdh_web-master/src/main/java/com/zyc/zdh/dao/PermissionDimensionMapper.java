package com.zyc.zdh.dao;

import com.zyc.notscan.base.BasePermissionDimensionMapper;
import com.zyc.zdh.entity.PermissionDimensionInfo;

public interface PermissionDimensionMapper extends BasePermissionDimensionMapper<PermissionDimensionInfo> {

}