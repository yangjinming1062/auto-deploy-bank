package com.zyc.zdh.dao;

import com.zyc.notscan.base.BasePermissionDimensionValueMapper;
import com.zyc.zdh.entity.PermissionDimensionValueInfo;

public interface PermissionDimensionValueMapper extends BasePermissionDimensionValueMapper<PermissionDimensionValueInfo> {

}