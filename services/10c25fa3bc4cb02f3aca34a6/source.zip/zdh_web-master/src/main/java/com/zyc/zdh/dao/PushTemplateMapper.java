package com.zyc.zdh.dao;

import com.zyc.notscan.base.BasePushTemplateMapper;
import com.zyc.zdh.entity.PushTemplateInfo;

public interface PushTemplateMapper extends BasePushTemplateMapper<PushTemplateInfo> {

}