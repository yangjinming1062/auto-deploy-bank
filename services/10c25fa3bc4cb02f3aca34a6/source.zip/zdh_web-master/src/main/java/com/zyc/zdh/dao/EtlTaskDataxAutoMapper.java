package com.zyc.zdh.dao;

import com.zyc.notscan.base.BaseEtlTaskDataxAutoMapper;
import com.zyc.zdh.entity.EtlTaskDataxAutoInfo;

public interface EtlTaskDataxAutoMapper extends BaseEtlTaskDataxAutoMapper<EtlTaskDataxAutoInfo> {
}