package com.zyc.zdh.dao;

import com.zyc.notscan.base.BaseProductTagMapper;
import com.zyc.zdh.entity.ProductTagInfo;

public interface ProductTagMapper extends BaseProductTagMapper<ProductTagInfo> {

}