package com.zyc.zdh.dao;

import com.zyc.notscan.base.BaseProjectMapper;
import com.zyc.zdh.entity.ProjectInfo;

public interface ProjectMapper extends BaseProjectMapper<ProjectInfo> {

}