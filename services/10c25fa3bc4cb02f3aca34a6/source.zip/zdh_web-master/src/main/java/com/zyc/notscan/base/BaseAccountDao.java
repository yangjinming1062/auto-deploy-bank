package com.zyc.notscan.base;

/**
 * ClassName: BaseAccountDao
 * @author zyc-admin
 * @date 2018年2月6日  
 * @Description: TODO  
 */
public interface BaseAccountDao {

}
