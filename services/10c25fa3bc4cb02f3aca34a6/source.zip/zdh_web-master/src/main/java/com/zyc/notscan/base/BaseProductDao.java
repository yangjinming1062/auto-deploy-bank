package com.zyc.notscan.base;

/**
 * ClassName: ProductDao   
 * @author zyc-admin
 * @date 2018年2月28日  
 * @Description: TODO  
 */
public interface BaseProductDao {

}
