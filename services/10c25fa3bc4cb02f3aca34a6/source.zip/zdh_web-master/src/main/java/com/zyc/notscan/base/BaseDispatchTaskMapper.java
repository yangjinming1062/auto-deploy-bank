package com.zyc.notscan.base;

import com.zyc.notscan.BaseMapper;

/**
 * ClassName: BaseDispatchTaskMapper
 * @author zyc-admin
 * @date 2017年12月26日  
 * @Description: TODO  
 */
public interface BaseDispatchTaskMapper<T> extends BaseMapper<T> {
    @Override
    default String getTable(){
        return "dispatch_task_info";
    }
}
