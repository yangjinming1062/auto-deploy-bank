package com.zyc.zdh.dao;

import com.zyc.notscan.base.BaseApprovalConfigMapper;
import com.zyc.zdh.entity.QuartzExecutorInfo;

public interface QuartzExecutorMapper extends BaseApprovalConfigMapper<QuartzExecutorInfo> {
}