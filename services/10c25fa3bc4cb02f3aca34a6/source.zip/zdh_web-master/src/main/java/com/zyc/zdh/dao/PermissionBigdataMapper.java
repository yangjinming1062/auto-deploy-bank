package com.zyc.zdh.dao;

import com.zyc.notscan.base.BasePermissionBigdataMapper;
import com.zyc.zdh.entity.PermissionBigdataInfo;

public interface PermissionBigdataMapper extends BasePermissionBigdataMapper<PermissionBigdataInfo> {
}