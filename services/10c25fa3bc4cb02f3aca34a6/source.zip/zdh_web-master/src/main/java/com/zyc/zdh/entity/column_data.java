package com.zyc.zdh.entity;

public class column_data {
    private String column_md5;
    private String column_name;
    private String column_expr;
    private String column_type;
    private String column_length;
    private String column_is_null;
    private String column_regex;
    private String column_desc;
    private String column_alias;

    public String getColumn_md5() {
        return column_md5;
    }

    public void setColumn_md5(String column_md5) {
        this.column_md5 = column_md5;
    }

    public String getColumn_expr() {
        return column_expr;
    }

    public void setColumn_expr(String column_expr) {
        this.column_expr = column_expr;
    }

    public String getColumn_type() {
        return column_type;
    }

    public void setColumn_type(String column_type) {
        this.column_type = column_type;
    }

    public String getColumn_desc() {
        return column_desc;
    }

    public void setColumn_desc(String column_desc) {
        this.column_desc = column_desc;
    }

    public String getColumn_alias() {
        return column_alias;
    }

    public void setColumn_alias(String column_alias) {
        this.column_alias = column_alias;
    }

    public String getColumn_name() {
        return column_name;
    }

    public void setColumn_name(String column_name) {
        this.column_name = column_name;
    }

    public String getColumn_length() {
        return column_length;
    }

    public void setColumn_length(String column_length) {
        this.column_length = column_length;
    }

    public String getColumn_is_null() {
        return column_is_null;
    }

    public void setColumn_is_null(String column_is_null) {
        this.column_is_null = column_is_null;
    }

    public String getColumn_regex() {
        return column_regex;
    }

    public void setColumn_regex(String column_regex) {
        this.column_regex = column_regex;
    }
}
