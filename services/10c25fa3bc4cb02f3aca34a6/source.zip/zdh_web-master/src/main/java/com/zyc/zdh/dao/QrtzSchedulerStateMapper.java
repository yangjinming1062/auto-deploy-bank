package com.zyc.zdh.dao;

import com.zyc.notscan.base.BaseQrtzSchedulerStateMapper;
import com.zyc.zdh.entity.QrtzSchedulerState;

public interface QrtzSchedulerStateMapper extends BaseQrtzSchedulerStateMapper<QrtzSchedulerState> {
}