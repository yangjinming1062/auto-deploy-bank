package com.zyc.zdh.dao;

import com.zyc.notscan.base.BaseTouchConfigMapper;
import com.zyc.zdh.entity.TouchConfigInfo;

public interface TouchConfigMapper extends BaseTouchConfigMapper<TouchConfigInfo> {
}
