package com.zyc.zdh.dao;

import com.zyc.notscan.base.BaseAlarmSmsMapper;
import com.zyc.zdh.entity.AlarmSmsInfo;

public interface AlarmSmsMapper extends BaseAlarmSmsMapper<AlarmSmsInfo> {
}