package com.zyc.zdh.dao;

import com.zyc.notscan.base.BaseFilterMapper;
import com.zyc.zdh.entity.FilterInfo;

public interface FilterMapper extends BaseFilterMapper<FilterInfo> {
}