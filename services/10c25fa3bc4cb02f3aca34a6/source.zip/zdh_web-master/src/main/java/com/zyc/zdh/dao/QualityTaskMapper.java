package com.zyc.zdh.dao;

import com.zyc.notscan.base.BaseQualityTaskMapper;
import com.zyc.zdh.entity.QualityTaskInfo;

public interface QualityTaskMapper extends BaseQualityTaskMapper<QualityTaskInfo> {
}