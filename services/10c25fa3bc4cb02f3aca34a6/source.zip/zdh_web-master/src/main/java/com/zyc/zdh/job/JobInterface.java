package com.zyc.zdh.job;

public interface JobInterface {

}
