package com.zyc.zdh.dao;

import com.zyc.notscan.base.BaseResourceTreeMapper;
import com.zyc.zdh.entity.RoleResourceInfo;


public interface RoleResourceMapper extends BaseResourceTreeMapper<RoleResourceInfo> {

}