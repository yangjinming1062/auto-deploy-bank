package com.zyc.zdh.dao;

import com.zyc.notscan.base.BaseApprovalAuditorFlowMapper;
import com.zyc.zdh.entity.ApprovalAuditorFlowInfo;

public interface ApprovalAuditorFlowMapper extends BaseApprovalAuditorFlowMapper<ApprovalAuditorFlowInfo> {
}