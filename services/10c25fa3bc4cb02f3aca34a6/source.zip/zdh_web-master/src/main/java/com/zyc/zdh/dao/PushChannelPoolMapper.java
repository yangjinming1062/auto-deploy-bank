package com.zyc.zdh.dao;

import com.zyc.notscan.base.BasePushChannelPoolMapper;
import com.zyc.zdh.entity.PushChannelPoolInfo;

public interface PushChannelPoolMapper extends BasePushChannelPoolMapper<PushChannelPoolInfo> {

}