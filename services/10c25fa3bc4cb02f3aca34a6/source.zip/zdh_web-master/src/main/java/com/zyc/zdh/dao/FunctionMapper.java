package com.zyc.zdh.dao;

import com.zyc.notscan.base.BaseFunctionMapper;
import com.zyc.zdh.entity.FunctionInfo;

public interface FunctionMapper extends BaseFunctionMapper<FunctionInfo> {

}