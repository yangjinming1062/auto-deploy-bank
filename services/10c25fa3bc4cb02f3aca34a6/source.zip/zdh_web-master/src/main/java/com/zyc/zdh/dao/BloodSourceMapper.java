package com.zyc.zdh.dao;

import com.zyc.notscan.base.BaseBloodSourceMapper;
import com.zyc.zdh.entity.BloodSourceInfo;

public interface BloodSourceMapper extends BaseBloodSourceMapper<BloodSourceInfo> {
}