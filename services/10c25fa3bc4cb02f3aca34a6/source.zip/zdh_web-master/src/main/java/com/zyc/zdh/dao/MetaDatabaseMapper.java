package com.zyc.zdh.dao;

import com.zyc.notscan.base.BaseMetaDatabaseMapper;
import com.zyc.zdh.entity.meta_database_info;

/**
 * ClassName: MetaDatabaseMapper
 * @author zyc-admin
 * @date 2017年12月26日  
 * @Description: TODO  
 */
public interface MetaDatabaseMapper extends BaseMetaDatabaseMapper<meta_database_info> {

}
