package com.zyc.zdh.dao;

import com.zyc.notscan.base.BaseStrategyGroupMapper;
import com.zyc.zdh.entity.StrategyGroupInfo;

public interface StrategyGroupMapper extends BaseStrategyGroupMapper<StrategyGroupInfo> {
}