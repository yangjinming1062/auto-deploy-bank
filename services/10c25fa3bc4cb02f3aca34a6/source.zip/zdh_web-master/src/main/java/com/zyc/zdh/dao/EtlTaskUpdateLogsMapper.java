package com.zyc.zdh.dao;

import com.zyc.notscan.base.BaseEtlTaskUpdateLogsMapper;
import com.zyc.zdh.entity.EtlTaskUpdateLogs;

/**
 * ClassName: DataSourcesMapper
 * @author zyc-admin
 * @date 2017年12月26日  
 * @Description: TODO  
 */
public interface EtlTaskUpdateLogsMapper extends BaseEtlTaskUpdateLogsMapper<EtlTaskUpdateLogs> {

}
