package com.zyc.zdh.dao;

import com.zyc.notscan.base.BaseAccountMapper;
import com.zyc.zdh.entity.AccountInfo;

public interface AccountMapper extends BaseAccountMapper<AccountInfo> {
}