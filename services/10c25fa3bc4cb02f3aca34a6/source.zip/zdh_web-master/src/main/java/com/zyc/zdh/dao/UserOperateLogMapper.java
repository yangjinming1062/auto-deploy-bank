package com.zyc.zdh.dao;

import com.zyc.notscan.base.BaseUserOperateLogMapper;
import com.zyc.zdh.entity.UserOperateLogInfo;

public interface UserOperateLogMapper extends BaseUserOperateLogMapper<UserOperateLogInfo> {
}