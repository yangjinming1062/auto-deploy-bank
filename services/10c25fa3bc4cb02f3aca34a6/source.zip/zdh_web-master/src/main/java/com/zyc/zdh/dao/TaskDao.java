package com.zyc.zdh.dao;

import com.zyc.notscan.base.BaseTaskDao;
import com.zyc.zdh.entity.TaskInfo;


public interface TaskDao extends BaseTaskDao<TaskInfo> {
}