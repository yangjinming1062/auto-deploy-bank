package com.zyc.zdh.dao;

import com.zyc.notscan.base.BaseEtlTaskMetaMapper;
import com.zyc.zdh.entity.EtlTaskMeta;


public interface EtlTaskMetaMapper extends BaseEtlTaskMetaMapper<EtlTaskMeta> {

}