package com.zyc.zdh.dao;

import com.zyc.notscan.base.BaseRiskEventMapper;
import com.zyc.zdh.entity.RiskEventInfo;

public interface RiskEventMapper extends BaseRiskEventMapper<RiskEventInfo> {

}