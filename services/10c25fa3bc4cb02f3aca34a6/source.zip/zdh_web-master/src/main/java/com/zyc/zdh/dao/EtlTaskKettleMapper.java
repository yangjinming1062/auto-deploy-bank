package com.zyc.zdh.dao;

import com.zyc.notscan.base.BaseEtlTaskKettleMapper;
import com.zyc.zdh.entity.EtlTaskKettleInfo;

public interface EtlTaskKettleMapper extends BaseEtlTaskKettleMapper<EtlTaskKettleInfo> {

}