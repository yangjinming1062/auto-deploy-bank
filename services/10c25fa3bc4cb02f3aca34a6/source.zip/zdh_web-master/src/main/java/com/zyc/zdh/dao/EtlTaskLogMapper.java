package com.zyc.zdh.dao;

import com.zyc.notscan.base.BaseEtlTaskLogMapper;
import com.zyc.zdh.entity.EtlTaskLogInfo;

public interface EtlTaskLogMapper extends BaseEtlTaskLogMapper<EtlTaskLogInfo> {
}