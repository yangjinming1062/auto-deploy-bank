package com.zyc.zdh.dao;

import com.zyc.notscan.base.BaseBeaconFireAlarmMsgMapper;
import com.zyc.zdh.entity.BeaconFireAlarmMsgInfo;

public interface BeaconFireAlarmMsgMapper extends BaseBeaconFireAlarmMsgMapper<BeaconFireAlarmMsgInfo> {

}