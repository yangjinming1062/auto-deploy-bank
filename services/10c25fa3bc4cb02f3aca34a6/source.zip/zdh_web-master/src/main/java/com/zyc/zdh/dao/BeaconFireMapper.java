package com.zyc.zdh.dao;

import com.zyc.notscan.base.BaseBeaconFireMapper;
import com.zyc.zdh.entity.BeaconFireInfo;

public interface BeaconFireMapper extends BaseBeaconFireMapper<BeaconFireInfo> {

}