package com.zyc.zdh.dao;

import com.zyc.notscan.base.BaseHelpDocumentMapper;
import com.zyc.zdh.entity.HelpDocumentInfo;

public interface HelpDocumentMapper extends BaseHelpDocumentMapper<HelpDocumentInfo> {

}