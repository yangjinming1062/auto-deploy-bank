package com.zyc.zdh.job;

import com.zyc.zdh.entity.QuartzJobInfo;

public class FtpJob {

    public static void run(QuartzJobInfo quartzJobInfo) {

        //连接ftp
        //判断ftp 文件

    }

}
