package com.zyc.zdh.dao;

import com.zyc.notscan.base.BasePushAppMapper;
import com.zyc.zdh.entity.PushAppInfo;

public interface PushAppMapper extends BasePushAppMapper<PushAppInfo> {

}