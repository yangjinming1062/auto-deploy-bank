package com.zyc.zdh.dao;

import com.zyc.notscan.base.BasePushChannelMapper;
import com.zyc.zdh.entity.PushChannelInfo;

public interface PushChannelMapper extends BasePushChannelMapper<PushChannelInfo> {

}