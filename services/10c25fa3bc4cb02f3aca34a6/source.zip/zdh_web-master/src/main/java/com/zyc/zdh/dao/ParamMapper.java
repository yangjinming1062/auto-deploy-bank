package com.zyc.zdh.dao;

import com.zyc.notscan.base.BaseParamMapper;
import com.zyc.zdh.entity.ParamInfo;

public interface ParamMapper extends BaseParamMapper<ParamInfo> {
}