package com.zyc.zdh.dao;

import com.zyc.notscan.base.BaseDataCodeMapper;
import com.zyc.zdh.entity.DataCodeInfo;

public interface DataCodeMapper extends BaseDataCodeMapper<DataCodeInfo> {

}