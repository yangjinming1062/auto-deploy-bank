package com.zyc.zdh.dao;

import com.zyc.notscan.base.BaseQualityRuleMapper;
import com.zyc.zdh.entity.QualityRuleInfo;

public interface QualityRuleMapper extends BaseQualityRuleMapper<QualityRuleInfo> {
}