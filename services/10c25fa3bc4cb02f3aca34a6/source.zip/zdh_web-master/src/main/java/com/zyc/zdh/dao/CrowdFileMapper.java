package com.zyc.zdh.dao;

import com.zyc.notscan.base.BaseCrowdFileMapper;
import com.zyc.zdh.entity.CrowdFileInfo;

public interface CrowdFileMapper extends BaseCrowdFileMapper<CrowdFileInfo> {
}