package com.zyc.zdh.dao;

import com.zyc.notscan.base.BaseEveryDayNoticeMapper;
import com.zyc.zdh.entity.EveryDayNotice;

/**
 * ClassName: EveryDayNoticeMapper
 * @author zyc-admin
 * @date 2017年12月26日  
 * @Description: TODO  
 */
public interface EveryDayNoticeMapper extends BaseEveryDayNoticeMapper<EveryDayNotice> {

}
