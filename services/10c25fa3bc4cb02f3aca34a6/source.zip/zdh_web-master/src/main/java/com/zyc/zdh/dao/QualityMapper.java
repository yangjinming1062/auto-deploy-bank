package com.zyc.zdh.dao;

import com.zyc.notscan.base.BaseQualityMapper;
import com.zyc.zdh.entity.QualityInfo;

public interface QualityMapper extends BaseQualityMapper<QualityInfo> {
}