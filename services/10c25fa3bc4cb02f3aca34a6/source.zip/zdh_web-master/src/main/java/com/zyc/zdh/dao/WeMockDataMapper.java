package com.zyc.zdh.dao;

import com.zyc.notscan.base.BaseWeMockDataMapper;
import com.zyc.zdh.entity.WeMockDataInfo;

public interface WeMockDataMapper extends BaseWeMockDataMapper<WeMockDataInfo> {
}