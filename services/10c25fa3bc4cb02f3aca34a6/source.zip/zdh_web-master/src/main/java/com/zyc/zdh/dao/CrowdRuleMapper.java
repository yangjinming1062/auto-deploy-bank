package com.zyc.zdh.dao;

import com.zyc.notscan.base.BaseCrowdRuleMapper;
import com.zyc.zdh.entity.CrowdRuleInfo;

public interface CrowdRuleMapper extends BaseCrowdRuleMapper<CrowdRuleInfo> {

}