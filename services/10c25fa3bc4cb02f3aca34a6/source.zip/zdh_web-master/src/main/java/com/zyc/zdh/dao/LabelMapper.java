package com.zyc.zdh.dao;

import com.zyc.notscan.base.BaseLabelMapper;
import com.zyc.zdh.entity.LabelInfo;

public interface LabelMapper extends BaseLabelMapper<LabelInfo> {
}