package com.zyc.zdh.dao;

import com.zyc.notscan.base.BaseBeaconFireAlarmGroupMapper;
import com.zyc.zdh.entity.BeaconFireAlarmGroupInfo;

public interface BeaconFireAlarmGroupMapper extends BaseBeaconFireAlarmGroupMapper<BeaconFireAlarmGroupInfo> {

}