package com.zyc.notscan.base;

import com.zyc.notscan.BaseMapper;

/**
 * ClassName: BaseSshTaskMapper
 * @author zyc-admin
 * @date 2017年12月26日  
 * @Description: TODO  
 */
public interface BaseSshTaskMapper<T> extends BaseMapper<T> {
    @Override
    default String getTable(){
        return "ssh_task_info";
    }
}
