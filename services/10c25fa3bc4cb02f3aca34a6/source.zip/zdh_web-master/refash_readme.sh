npm config set registry http://registry.npm.taobao.org/
npm i doctoc -g
doctoc README.md