package edu.washington.cs.knowitall.extractor.conf.classifier;

import java.util.TreeMap;

public class DoubleFeatures extends TreeMap<String, Double> {
    private static final long serialVersionUID = 1L;
}
