gdown https://drive.google.com/uc\?id\=1U2hd6qvwKLfp7c8yGgcTqdqrP_lKJElB
gdown https://drive.google.com/uc\?id\=1jMH2-ZC0ZBgtqej5Sp-E5ebBIX7mk3Xz
gdown https://drive.google.com/uc\?id\=1kfdCDA5koYh9g3IkCCHb4XPch2CJAwek

unzip fvd.zip
unzip eval_sets.zip
unzip base_t2v_eval_sets.zip

mv eval_sets eval_folder/
mv base_t2v_eval_sets eval_folder/

rm -rf *.zip