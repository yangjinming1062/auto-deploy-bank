python tools/demo/demo_folder.py -f eval_sets -d outputs/eval_sets_gvhmr -s
python tools/eval_pose.py -f outputs/eval_sets_gvhmr_v2
