# CHANGELOG

## v2.0.0

breaking changes:

use apache-pakka instead of akka actor.

## v1.0.3

release v1.0.3
