# showcase

A sample project using Flower framework [flower.showcase](https://github.com/zhihuili/flower.showcase)

Download from github

```
git clone https://github.com/zhihuili/flower.showcase.git
```

or 

```yaml
git clone git@github.com:zhihuili/flower.showcase.git
```