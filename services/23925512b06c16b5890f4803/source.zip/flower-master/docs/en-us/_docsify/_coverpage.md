# Flower <small>1.0.3</small>

> a reactive-programming framework for micro services 

- Immediate Response 
- Resilience
- Message Driven 

[GitHub](https://github.com/zhihuili/flower)
[Get Started](/en-us/README.md)
