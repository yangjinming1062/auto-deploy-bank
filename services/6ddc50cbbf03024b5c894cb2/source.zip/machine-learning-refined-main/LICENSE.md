The material in this repository is licensed under the
**Creative Commons Attribution 4.0 International License (CC BY-NC-SA 4.0)** attributed to Jeremy Watt and Reza Borhani. 
To view a copy of this license, visit https://creativecommons.org/licenses/by-nc-sa/4.0/ and the legal code therein. 

## You are free to:
**Share** — copy and redistribute the material in any medium or format

**Adapt** — remix, transform, and build upon the material

## Under the following terms:
**Attribution** — You must give appropriate credit, provide a link to the license, and indicate if changes were made. You may do so in any reasonable manner, but not in any way that suggests the licensor endorses you or your use.

**NonCommercial** — You may not use the material for commercial purposes.

**ShareAlike** — If you remix, transform, or build upon the material, you must distribute your contributions under the same license as the original.

**No additional restrictions** — You may not apply legal terms or technological measures that legally restrict others from doing anything the license permits.

