# Exercises starter jupyter notebook wrappers and datasets

This subdirectory contains starter Jupyter notebook wrappers for the 2nd edition of Machine Learning Refined.

Many of the exercises require datasets [which can be downloaded here](https://www.dropbox.com/scl/fi/4cry0hx56bzo7mqjkuf6r/mlrefined_ed2_datasets.zip?rlkey=pg92m4i69wzdhohs0p3g27pxg&st=g9z5gpuj&dl=0).

Older exercise wrappers and datasets corresponding to the 1st edition of the text [can be found here](https://www.dropbox.com/scl/fi/wpktu7varywriqya8bhj8/mlrefined_ed1_hw_wrappers.zip?rlkey=1qpvurorth7hetnzmwy03ag7z&st=ukkrlhxk&dl=0).
