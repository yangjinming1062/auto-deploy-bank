Active Learning Icon:
Created by Wei Ding 
Using shapes from Microsoft PowerPoint
For more information, see file active_learning_icon.pptx
Please feel free to change and use it 