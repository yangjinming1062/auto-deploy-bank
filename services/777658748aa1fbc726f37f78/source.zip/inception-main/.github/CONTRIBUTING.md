INCEpTION uses the [DKPro Contribution Guidelines](https://dkpro.github.io/contributing). 
