---
name: "⚙️ Refactoring (for developers)" 
about: Refactor the application
type: "⚙️ Refactoring"
labels: []
---

**Describe the refactoring action**
A clear and concise description of what the action is.

**Expected benefit**
A clear and concise description of what you expect to improve by the refactoring.
