---
name: Custom issue template
about: Describe this issue template's purpose here.
title: ''
labels: ''
assignees: ''

---

**<u>AgentScope is an open-source project. To involve a broader community, we recommend asking your questions in English.</u>**



