# -*- coding: utf-8 -*-
"""A python file without agent classes"""


def speak() -> str:
    """A function in a separate file."""
    return "Hello world"
