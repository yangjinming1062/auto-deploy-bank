# -*- coding: utf-8 -*-
"""Some constants of rag application"""

INPUT_MAX_TOKEN = 29000
