// _static/language_switch.js

function toChinese() {
    window.location.href = "https://doc.agentscope.io/zh_CN";
}

function toEnglish() {
    window.location.href = "https://doc.agentscope.io";
}