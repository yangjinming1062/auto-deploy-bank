# -*- coding: utf-8 -*-
""" Import modules in strategy package."""
from .mixture_of_agent import MixtureOfAgents

__all__ = [
    "MixtureOfAgents",
]
