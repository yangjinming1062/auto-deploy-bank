source venvEnvLLM/bin/activate #activate virtual environment
deactivate #deactivate virtual environment