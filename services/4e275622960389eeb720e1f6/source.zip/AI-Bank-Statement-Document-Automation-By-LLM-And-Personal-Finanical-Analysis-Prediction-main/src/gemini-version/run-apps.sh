# avoid upload file issues in Local hosting
streamlit run app.py --server.enableXsrfProtection false