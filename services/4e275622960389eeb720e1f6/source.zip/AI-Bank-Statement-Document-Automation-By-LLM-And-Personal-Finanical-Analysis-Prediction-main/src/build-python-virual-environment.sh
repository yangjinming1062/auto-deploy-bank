# pre-install venv in Ubuntu sudo apt-get install python3-venv
# mkdir venvLLM 
# cd venvLLM
python3 -m venv venvEnvLLM