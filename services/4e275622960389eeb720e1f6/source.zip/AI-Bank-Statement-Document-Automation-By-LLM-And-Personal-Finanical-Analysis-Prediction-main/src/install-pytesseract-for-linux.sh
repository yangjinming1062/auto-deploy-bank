sudo apt update -y
sudo apt install -y tesseract-ocr
sudo apt install -y libtesseract-dev