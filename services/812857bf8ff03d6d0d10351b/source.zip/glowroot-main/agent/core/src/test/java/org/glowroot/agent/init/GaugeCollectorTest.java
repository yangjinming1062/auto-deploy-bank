/*
 * Copyright 2015-2018 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.glowroot.agent.init;

import java.util.List;

import javax.management.AttributeNotFoundException;
import javax.management.InstanceNotFoundException;
import javax.management.MBeanServer;
import javax.management.MalformedObjectNameException;
import javax.management.ObjectName;

import com.google.common.base.Ticker;
import com.google.common.collect.ImmutableList;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;

import org.glowroot.agent.collector.Collector;
import org.glowroot.agent.config.ConfigService;
import org.glowroot.agent.util.LazyPlatformMBeanServer;
import org.glowroot.common.config.AdvancedConfig;
import org.glowroot.common.config.GaugeConfig;
import org.glowroot.common.config.ImmutableAdvancedConfig;
import org.glowroot.common.config.ImmutableGaugeConfig;
import org.glowroot.common.config.ImmutableMBeanAttribute;
import org.glowroot.common.util.Clock;
import org.glowroot.wire.api.model.CollectorServiceOuterClass.GaugeValueMessage.GaugeValue;

import static java.util.concurrent.TimeUnit.SECONDS;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

public class GaugeCollectorTest {

    private GaugeCollector gaugeCollector;
    private LazyPlatformMBeanServer lazyPlatformMBeanServer;
    private Clock clock;
    private Ticker ticker;
    private Logger logger;

    @BeforeEach
    public void beforeEachTest() throws Exception {
        ConfigService configService = mock(ConfigService.class);
        AdvancedConfig advancedConfig =
                ImmutableAdvancedConfig.builder().mbeanGaugeNotFoundDelaySeconds(60).build();
        when(configService.getAdvancedConfig()).thenReturn(advancedConfig);

        Collector collector = mock(Collector.class);
        lazyPlatformMBeanServer = mock(LazyPlatformMBeanServer.class);
        clock = mock(Clock.class);
        ticker = mock(Ticker.class);
        logger = mock(Logger.class);
        gaugeCollector = new GaugeCollector(configService, collector, lazyPlatformMBeanServer,
                null, clock, ticker);
        gaugeCollector.setLoggerForTesting(logger);
    }

    @AfterEach
    public void afterEachTest() {
        verifyNoMoreInteractions(logger);
    }

    @Test
    public void shouldCaptureNonCounterGauge() throws Exception {
        // given
        GaugeConfig gaugeConfig = ImmutableGaugeConfig.builder()
                .mbeanObjectName("test:aaa=bbb")
                .addMbeanAttributes(ImmutableMBeanAttribute.of("ccc", false))
                .build();
        when(lazyPlatformMBeanServer.getAttribute(any(ObjectName.class), anyString(),
                anyMBeanServerList())).thenReturn(555);

        // when
        List<GaugeValue> gaugeValues =
                collectGaugeValues(gaugeConfig);

        // then
        assertThat(gaugeValues).hasSize(1);
        assertThat(gaugeValues.get(0).getValue()).isEqualTo(555);
        assertThat(gaugeValues.get(0).getWeight()).isEqualTo(1);
    }

    @Test
    public void shouldNotCaptureCounterGauge() throws Exception {
        // given
        GaugeConfig gaugeConfig = ImmutableGaugeConfig.builder()
                .mbeanObjectName("test:aaa=bbb")
                .addMbeanAttributes(ImmutableMBeanAttribute.of("ccc", true))
                .build();
        when(lazyPlatformMBeanServer.getAttribute(any(ObjectName.class), anyString(),
                anyMBeanServerList())).thenReturn(555);

        // need to execute run() once in order to initialize internal priorRawCounterValues map
        gaugeCollector.run();

        // when
        List<GaugeValue> gaugeValues =
                collectGaugeValues(gaugeConfig);

        // then
        assertThat(gaugeValues).isEmpty();
    }

    @Test
    public void shouldCaptureCounterGauge() throws Exception {
        // given
        GaugeConfig gaugeConfig = ImmutableGaugeConfig.builder()
                .mbeanObjectName("test:aaa=bbb")
                .addMbeanAttributes(ImmutableMBeanAttribute.of("ccc", true))
                .build();
        when(lazyPlatformMBeanServer.getAttribute(any(ObjectName.class), anyString(),
                anyMBeanServerList())).thenReturn(555, 565);
        when(ticker.read()).thenReturn(SECONDS.toNanos(1), SECONDS.toNanos(3));

        // need to execute run() once in order to initialize internal priorRawCounterValues map
        gaugeCollector.run();

        // when
        collectGaugeValues(gaugeConfig);
        List<GaugeValue> gaugeValues =
                collectGaugeValues(gaugeConfig);

        // then
        assertThat(gaugeValues).hasSize(1);
        assertThat(gaugeValues.get(0).getValue()).isEqualTo(5); // 5 "units" per second
        assertThat(gaugeValues.get(0).getWeight()).isEqualTo(SECONDS.toNanos(2));
    }

    @Test
    public void shouldHandleInvalidMBeanObjectName() throws Exception {
        // given
        GaugeConfig gaugeConfig = ImmutableGaugeConfig.builder()
                .mbeanObjectName("invalid mbean object name")
                .build();

        // when
        List<GaugeValue> gaugeValues =
                collectGaugeValues(gaugeConfig);

        // then
        assertThat(gaugeValues).isEmpty();
        verify(logger).debug(anyString(), any(Exception.class));
        verify(logger).warn(eq("error accessing mbean: {}"), eq("invalid mbean object name"),
                any(MalformedObjectNameException.class));
    }

    @Test
    public void shouldHandleMBeanInstanceNotFoundBeforeLoggingDelay() throws Exception {
        // given
        GaugeConfig gaugeConfig = ImmutableGaugeConfig.builder()
                .mbeanObjectName("xyz:aaa=bbb")
                .addMbeanAttributes(ImmutableMBeanAttribute.of("ccc", false))
                .addMbeanAttributes(ImmutableMBeanAttribute.of("ddd", false))
                .build();
        when(clock.currentTimeMillis()).thenReturn(59999L);
        when(lazyPlatformMBeanServer.getAttribute(any(ObjectName.class), anyString(),
                anyMBeanServerList())).thenThrow(InstanceNotFoundException.class);

        // when
        List<GaugeValue> gaugeValues =
                collectGaugeValues(gaugeConfig);

        // then
        assertThat(gaugeValues).isEmpty();
        verify(logger).debug(nullable(String.class), any(Exception.class));
    }

    @Test
    public void shouldHandleMBeanInstanceNotFoundAfterLoggingDelay() throws Exception {
        // given
        GaugeConfig gaugeConfig = ImmutableGaugeConfig.builder()
                .mbeanObjectName("xyz:aaa=bbb")
                .addMbeanAttributes(ImmutableMBeanAttribute.of("ccc", false))
                .addMbeanAttributes(ImmutableMBeanAttribute.of("ddd", false))
                .build();
        when(clock.currentTimeMillis()).thenReturn(60000L);
        when(lazyPlatformMBeanServer.getAttribute(any(ObjectName.class), anyString(),
                anyMBeanServerList())).thenThrow(InstanceNotFoundException.class);

        // when
        List<GaugeValue> gaugeValues =
                collectGaugeValues(gaugeConfig);

        // then
        assertThat(gaugeValues).isEmpty();
        verify(logger).debug(nullable(String.class), any(Exception.class));
        verify(logger).warn("mbean not {}: {}", "found", "xyz:aaa=bbb");
    }

    @Test
    public void shouldHandleMBeanInstanceNotFoundBeforeAndAfterLoggingDelay() throws Exception {
        // given
        GaugeConfig gaugeConfig = ImmutableGaugeConfig.builder()
                .mbeanObjectName("xyz:aaa=bbb")
                .addMbeanAttributes(ImmutableMBeanAttribute.of("ccc", false))
                .addMbeanAttributes(ImmutableMBeanAttribute.of("ddd", false))
                .build();
        when(clock.currentTimeMillis()).thenReturn(0L).thenReturn(30000L).thenReturn(60000L);
        when(lazyPlatformMBeanServer.getAttribute(any(ObjectName.class), anyString(),
                anyMBeanServerList())).thenThrow(InstanceNotFoundException.class);

        // when
        collectGaugeValues(gaugeConfig);
        collectGaugeValues(gaugeConfig);
        collectGaugeValues(gaugeConfig);
        collectGaugeValues(gaugeConfig);
        collectGaugeValues(gaugeConfig);

        // then
        verify(logger, times(5)).debug(nullable(String.class), any(Exception.class));
        verify(logger)
                .warn("mbean not {}: {} (waited {} seconds after jvm startup before logging this"
                        + " warning to allow time for mbean registration - this wait time can be"
                        + " changed under Configuration > Advanced)", "found", "xyz:aaa=bbb", 60);
    }

    @Test
    public void shouldHandleMBeanAttributeNotFound() throws Exception {
        // given
        GaugeConfig gaugeConfig = ImmutableGaugeConfig.builder()
                .mbeanObjectName("xyz:aaa=bbb")
                .addMbeanAttributes(ImmutableMBeanAttribute.of("ccc", false))
                .addMbeanAttributes(ImmutableMBeanAttribute.of("ddd", false))
                .build();
        when(lazyPlatformMBeanServer.getAttribute(any(ObjectName.class), anyString(),
                anyMBeanServerList())).thenThrow(AttributeNotFoundException.class);

        // when
        collectGaugeValues(gaugeConfig);
        collectGaugeValues(gaugeConfig);
        collectGaugeValues(gaugeConfig);
        collectGaugeValues(gaugeConfig);
        collectGaugeValues(gaugeConfig);

        // then
        verify(logger, times(10)).debug(nullable(String.class), any(Exception.class));
        verify(logger).warn("mbean attribute {} not found in {}", "ccc", "xyz:aaa=bbb");
        verify(logger).warn("mbean attribute {} not found in {}", "ddd", "xyz:aaa=bbb");
    }

    @Test
    public void shouldHandleMBeanAttributeOtherException() throws Exception {
        // given
        GaugeConfig gaugeConfig = ImmutableGaugeConfig.builder()
                .mbeanObjectName("xyz:aaa=bbb")
                .addMbeanAttributes(ImmutableMBeanAttribute.of("ccc", false))
                .addMbeanAttributes(ImmutableMBeanAttribute.of("ddd", false))
                .build();
        when(lazyPlatformMBeanServer.getAttribute(any(ObjectName.class), anyString(),
                anyMBeanServerList())).thenThrow(new RuntimeException("A msg"));

        // when
        collectGaugeValues(gaugeConfig);
        collectGaugeValues(gaugeConfig);
        collectGaugeValues(gaugeConfig);
        collectGaugeValues(gaugeConfig);
        collectGaugeValues(gaugeConfig);

        // then
        verify(logger, times(10)).debug(anyString(), any(Exception.class));
        verify(logger).warn(eq("error accessing mbean attribute: {} {}"), eq("xyz:aaa=bbb"),
                eq("ccc"), any(RuntimeException.class));
        verify(logger).warn(eq("error accessing mbean attribute: {} {}"), eq("xyz:aaa=bbb"),
                eq("ddd"), any(RuntimeException.class));
    }

    @Test
    public void shouldHandleMBeanAttributeNotANumber() throws Exception {
        // given
        GaugeConfig gaugeConfig = ImmutableGaugeConfig.builder()
                .mbeanObjectName("xyz:aaa=bbb")
                .addMbeanAttributes(ImmutableMBeanAttribute.of("ccc", false))
                .addMbeanAttributes(ImmutableMBeanAttribute.of("ddd", false))
                .build();
        when(lazyPlatformMBeanServer.getAttribute(any(ObjectName.class), anyString(),
                anyMBeanServerList())).thenReturn("not a number");

        // when
        collectGaugeValues(gaugeConfig);
        collectGaugeValues(gaugeConfig);
        collectGaugeValues(gaugeConfig);
        collectGaugeValues(gaugeConfig);
        collectGaugeValues(gaugeConfig);

        // then
        verify(logger).warn("error accessing mbean attribute {} {}: {}", "xyz:aaa=bbb", "ccc",
                "MBean attribute value is not a valid number: \"not a number\"");
        verify(logger).warn("error accessing mbean attribute {} {}: {}", "xyz:aaa=bbb", "ddd",
                "MBean attribute value is not a valid number: \"not a number\"");
    }

    @Test
    public void shouldHandleMBeanAttributeNotANumberOrString() throws Exception {
        // given
        GaugeConfig gaugeConfig = ImmutableGaugeConfig.builder()
                .mbeanObjectName("xyz:aaa=bbb")
                .addMbeanAttributes(ImmutableMBeanAttribute.of("ccc", false))
                .addMbeanAttributes(ImmutableMBeanAttribute.of("ddd", false))
                .build();
        when(lazyPlatformMBeanServer.getAttribute(any(ObjectName.class), anyString(),
                anyMBeanServerList())).thenReturn(new Object());

        // when
        collectGaugeValues(gaugeConfig);
        collectGaugeValues(gaugeConfig);
        collectGaugeValues(gaugeConfig);
        collectGaugeValues(gaugeConfig);
        collectGaugeValues(gaugeConfig);

        // then
        verify(logger).warn("error accessing mbean attribute {} {}: {}", "xyz:aaa=bbb", "ccc",
                "MBean attribute value is not a number or string");
        verify(logger).warn("error accessing mbean attribute {} {}: {}", "xyz:aaa=bbb", "ddd",
                "MBean attribute value is not a number or string");
    }

    private List<GaugeValue> collectGaugeValues(GaugeConfig gaugeConfig) throws Exception {
        return gaugeCollector.collectGaugeValues(gaugeConfig, ImmutableList.<MBeanServer>of());
    }

    @SuppressWarnings("deprecation")
    private static List<MBeanServer> anyMBeanServerList() {
        return anyList();
    }
}
