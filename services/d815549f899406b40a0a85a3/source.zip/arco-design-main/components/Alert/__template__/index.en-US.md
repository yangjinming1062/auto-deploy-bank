---
file: interface
---

`````
Component / Feedback

# Alert

Used to display warning information in a way that attracts attention.
`````

%%Content%%

## API

%%Props%%
