## 2.38.0

2022-07-29

### 🐛 问题修复

- 修复点击 `Alert` 组件的关闭按钮误触外部 `form` 的 `submit` 事件的 bug。([#1205](https://github.com/arco-design/arco-design/pull/1205))

## 2.20.0

2021-07-30

### 🆎 TypeScript

- 修改 `Alert` 组件 `title` 属性的 TS 定义。

## 2.11.0

2021-03-12

### 🆕 Feature

- `Alert` 组件支持 `action` 定制操作项。

