## 2.38.0

2022-07-29

### 🐛 BugFix

- Fixed a bug where clicking the close button of an `Alert` component accidentally triggered the `submit` event of an external `form`.([#1205](https://github.com/arco-design/arco-design/pull/1205))

## 2.20.0

2021-07-30

### 🆎 TypeScript

- Modify the TS definition of the `title` property of the `Alert` component.

## 2.11.0

2021-03-12

### 🆕 Feature

- The `Alert` component supports `action` custom action items.

