## 2.4.0

2020-12-11

### 🆎 TypeScript

- 修复 `Backtop` 定义缺少 `children` 的问题。

