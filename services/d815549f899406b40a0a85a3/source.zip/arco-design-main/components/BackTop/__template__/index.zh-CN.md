---
file: interface
---

`````
组件 / 其他

# 返回顶部 BackTop

可一键返回顶部的按钮。
`````

%%Content%%

## API

%%Props%%
