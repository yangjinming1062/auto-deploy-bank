---
file: interface
---

`````
Component / Other

# BackTop

`BackTop` makes it easy to go back to the top of the page.
`````

%%Content%%

## API

%%Props%%
