import '../../style/index.less';
import '../../Spin/style';
import './index.less';
