---
file: interface
---

`````
Component / Data Display

# Card

Card is generally used as a container for concise introduction or information.
`````

%%Content%%

## API

%%Props%%
