## 2.9.0 🔥

2021-02-05

### 💅 Style

- When the `Card` component is vertically oriented, the bottom border becomes transparent when the last tab is in hover state.



