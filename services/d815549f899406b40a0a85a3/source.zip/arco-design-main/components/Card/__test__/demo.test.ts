import demoTest from '../../../tests/demoTest';

demoTest('Card');
