---
file: interface
---

`````
组件 / 数据展示

# 评论 Comment

展示评论信息
`````

%%Content%%

## API

%%Props%%
