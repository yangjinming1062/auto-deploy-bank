---
file: interface
---

`````
Component / Data Display

# Comment

Display a comment.
`````

%%Content%%

## API

%%Props%%
