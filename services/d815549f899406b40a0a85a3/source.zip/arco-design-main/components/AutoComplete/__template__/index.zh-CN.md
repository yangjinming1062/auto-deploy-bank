---
file: interface
---

`````
组件 / 数据输入

# 自动补全 AutoComplete

输入框或自定义输入控件的自动补全功能。
`````

%%Content%%

## API

%%Props%%

### AutoComplete.Option

同 `Select.Option`, 参考 [Select 文档](/react/components/select) 。

### AutoComplete.OptGroup

同 `Select.OptGroup`, 参考 [Select 文档](/react/components/select) 。
