## 2.63.2

2024-08-08

### 💎 功能优化

- `Affix` 组件卸载时避免调用位置更新逻辑([#2772](https://github.com/arco-design/arco-design/pull/2772))

## 2.31.2

2022-04-01

### 🐛 问题修复

- 修复 `Affix` 子元素不合法时 `ResizeObserver`会报错的bug([#726](https://github.com/arco-design/arco-design/pull/726))

## 2.20.2

2021-08-09

### 🐛 Bugfix

- 修复 `Affix` 组件的 `onChange` 回调被频繁触发的 bug。

## 2.20.1

2021-08-06

### 🐛 Bugfix

- 修复 `Affix` 组件在 `fixed` 状态下更新内容或者修改参数位置没有更新的 bug。

## 2.18.2

2021-07-09

### 🐛 Bugfix

- 修复 `Affix` 组件在`fixed`状态时，改变元素高度时未调更新位置的 bug。
- 修复 `Affix` 组件在`fixed`状态时，改变元素高度时未调更新位置的 bug。

## 2.1.0

2020-11-06

### 🆕 Feature

- `Affix` 组件 ref 暴露 `updatePosition` 接口。



