## 2.63.2

2024-08-08

### 💎 Enhancement

- Avoid calling location update logic when `Affix` component is unmounted([#2772](https://github.com/arco-design/arco-design/pull/2772))

## 2.31.2

2022-04-01

### 🐛 BugFix

- Fix the bug that resizeObserver will report an error when the children of Affix is invalid.([#726](https://github.com/arco-design/arco-design/pull/726))

## 2.20.2

2021-08-09

### 🐛 Bugfix

- Fix the bug that the `onChange` callback of the `Affix` component is triggered frequently.



## 2.20.1

2021-08-06

### 🐛 Bugfix

- Fix the bug that the content of the `Affix` component is not updated in the `fixed` state or the position of the modified parameter is not updated.

## 2.18.2

2021-07-09

### 🐛 Bugfix

- Fix the bug that the position of the element is not updated when the height of the element is changed when the `Affix` component is in the `fixed` state.
- Fix the bug that the position of the element is not updated when the height of the element is changed when the `Affix` component is in the `fixed` state.

