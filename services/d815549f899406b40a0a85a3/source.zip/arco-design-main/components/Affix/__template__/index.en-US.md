---
file: interface
---

`````
Component / Other

# Affix

Pin the elements to the visible range. When the content area is relatively long and the page needs to scroll, the Affix can fix the element on the screen. Often used for side menu and button group.
`````

%%Content%%

## API

%%Props%%
