---
file: interface
---

`````
Component / Data Display

# Badge

Badge normally appears in the upper right corner of the icon or text to prompt important information.
`````

%%Content%%

## API

%%Props%%

## Questions

1. How to hide the red dot when `dot=true`?
   You can set `count=0`. The logo will be displayed only when `count> 0`.
