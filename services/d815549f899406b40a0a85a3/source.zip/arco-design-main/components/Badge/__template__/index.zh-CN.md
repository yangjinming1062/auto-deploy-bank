---
file: interface
---

`````
组件 / 数据展示

# 徽标数 Badge

一般出现在图标或文字的右上角。提供及时、重要的信息提示。
`````

%%Content%%

## API

%%Props%%

## 常见问题

1. 如何在 `dot=true` 时设置不显示小红点？
  可以设置`count=0`。`count > 0` 的时候才会展示徽标。
