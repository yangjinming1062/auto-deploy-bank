import mountTest from '../../../tests/mountTest';
import componentConfigTest from '../../../tests/componentConfigTest';
import Badge from '..';

mountTest(Badge);
componentConfigTest(Badge, 'Badge');
