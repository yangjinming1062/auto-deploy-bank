## 2.64.1

2024-10-28

### 🆎 类型修正

- 修复 `Badge` 组件 `count` 类型问题。([#2750](https://github.com/arco-design/arco-design/pull/2750))

## 2.45.1

2023-03-01

### 💅 样式更新

- 调整 `Badge` 组件文本大小从 `12px` 到 `14px`，对齐设计规范([#1816](https://github.com/arco-design/arco-design/pull/1816))

## 2.28.2

2022-01-21

### 🐛 问题修复

- 修复`Badge`组件里`CssTransition`传入`string`类型的`color`属性导致控制台waring的bug([#455](https://github.com/arco-design/arco-design/pull/455))

## 2.16.0

2021-05-28

### 🐛 Bugfix

- 修复 `Badge` 组件外层 `Tooltip` 不显示的问题



## 2.5.0 🎅🏽

2020-12-25 🎄

### 🐛 Bugfix

- 修复 `Badge` 组件的徽标出现的时候闪动两次的 bug。

