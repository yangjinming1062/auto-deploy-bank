## 2.64.1

2024-10-28

### 🆎 TypeScript

- Fix `count` type issue of `Badge` component.([#2750](https://github.com/arco-design/arco-design/pull/2750))

## 2.45.1

2023-03-01

### 💅 Style

- Adjust the text size of the `Badge` component from `12px` to `14px`, aligning with the design specification([#1816](https://github.com/arco-design/arco-design/pull/1816))

## 2.28.2

2022-01-21

### 🐛 BugFix

- Fixed the bug of console waring caused by passing the `color` property of `string` type to `CssTransition` in the `Badge` component([#455](https://github.com/arco-design/arco-design/pull/455))

## 2.16.0

2021-05-28

### 🐛 Bugfix

- Fix the problem that the outer layer of the `Badge` component `Tooltip` is not displayed



