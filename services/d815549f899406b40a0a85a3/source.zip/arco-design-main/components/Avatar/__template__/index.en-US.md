---
file: interface
---

`````
Component / Data Display

# Avatar

Used as an avatar, it can be displayed in the form of pictures, icons or characters.
`````

%%Content%%

## API

%%Props%%
