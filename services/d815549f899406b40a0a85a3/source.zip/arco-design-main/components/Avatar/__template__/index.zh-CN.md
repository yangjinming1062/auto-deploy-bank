---
file: interface
---

`````
组件 / 数据展示

# 头像 Avatar

用作头像显示，可以为图片、图标或字符形式展示。
`````

%%Content%%

## API

%%Props%%
