import demoTest from '../../../tests/demoTest';

demoTest('Avatar');
