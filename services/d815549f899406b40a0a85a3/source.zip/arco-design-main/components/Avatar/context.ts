import { createContext } from 'react';
import { AvatarProps } from './interface';

export default createContext<AvatarProps>({});
