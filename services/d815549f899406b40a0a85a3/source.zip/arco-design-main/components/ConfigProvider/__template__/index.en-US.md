---
file: interface
---

`````
Component / Other

# ConfigProvider

Configure in the outermost layer of the application to set global params.
`````

%%Content%%

## API

%%Props%%
