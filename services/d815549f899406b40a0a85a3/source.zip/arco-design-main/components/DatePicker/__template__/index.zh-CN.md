---
file: interface
---

`````
组件 / 数据输入

# 日期选择器 DatePicker

选择日期。支持年、月、周、日类型，支持范围选择等。
`````

%%Content%%

## API

**Picker 为所有组件共有的属性**

%%Props%%
