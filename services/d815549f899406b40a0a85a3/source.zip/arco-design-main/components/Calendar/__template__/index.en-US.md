---
file: interface
---

`````
Component / Data Display

# Calendar

Container for displaying data in calendar form.
`````

%%Content%%

## API

%%Props%%
