## 2.45.0

2023-02-17

### 🐛 BugFix

- Fix `Calendar` component `panelTodayBtn` click invalid issue.([#1789](https://github.com/arco-design/arco-design/pull/1789))

## 2.36.1

2022-07-01

### 🐛 BugFix

- Fixed `Calendar` component `defaultValue` and selected date not being highlighted.([#1073](https://github.com/arco-design/arco-design/pull/1073))

## 2.30.0

2022-03-04

### 🐛 BugFix

- Fix the style issue that the width of the month block becomes larger when the year mode of the `Calendar` component is selected([#560](https://github.com/arco-design/arco-design/pull/560))

## 2.12.0

2021-03-19

### 🐛 Bugfix

- The Chinese format in the `Calendar` component has been moved to the locale file.



