## 2.45.0

2023-02-17

### 🐛 问题修复

- 修复 `Calendar` 组件 `panelTodayBtn` 按钮点击无效的问题。([#1789](https://github.com/arco-design/arco-design/pull/1789))

## 2.36.1

2022-07-01

### 🐛 问题修复

- 修复 `Calendar` 组件 `defaultValue` 以及 selected date 没有被高亮的问题。([#1073](https://github.com/arco-design/arco-design/pull/1073))

## 2.30.0

2022-03-04

### 🐛 问题修复

- 修复 `Calendar` 组件年模式下选中当天使月块宽度变大的样式问题([#560](https://github.com/arco-design/arco-design/pull/560))

## 2.12.0

2021-03-19

### 🐛 Bugfix

- `Calendar` 组件中中文 format 移动到 locale 文件中。



