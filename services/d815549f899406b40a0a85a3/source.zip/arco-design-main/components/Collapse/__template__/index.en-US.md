---
file: interface
---

`````
Component / Data Display

# Collapse

The content area that can be collapsed/expanded.
`````

%%Content%%

## API

%%Props%%
