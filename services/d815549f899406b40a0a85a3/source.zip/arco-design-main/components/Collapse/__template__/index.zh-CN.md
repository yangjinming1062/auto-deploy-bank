---
file: interface
---

`````
组件 / 数据展示

# 折叠面板 Collapse

可以折叠 / 展开的内容区域。
`````

%%Content%%

## API

%%Props%%
