import Collapse from './collapse';

export default Collapse;

export { CollapseProps, CollapseItemProps } from './interface';
