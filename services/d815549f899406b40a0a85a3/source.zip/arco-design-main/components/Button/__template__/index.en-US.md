---
file: interface
---

`````
Component / General

# Button

A button is a command component to trigger an operation.
`````

%%Content%%

## API

%%Props%%
