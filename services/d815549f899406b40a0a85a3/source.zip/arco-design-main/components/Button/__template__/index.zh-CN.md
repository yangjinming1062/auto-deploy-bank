---
file: interface
---

`````
组件 / 通用

# 按钮 Button

按钮是一种命令组件，可发起一个即时操作。
`````

%%Content%%

## API

%%Props%%
