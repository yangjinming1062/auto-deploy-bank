---
file: interface
---

`````
组件 / 数据输入

# 颜色选择器 ColorPicker

用于选择和展示颜色
`````

%%Content%%

## API
%%Props%%
