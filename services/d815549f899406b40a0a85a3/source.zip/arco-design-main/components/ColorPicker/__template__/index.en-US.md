---
file: interface
---

`````
Component / Data Entry

# ColorPicker

Used for select and display colors
`````

%%Content%%

## API

%%Props%%
