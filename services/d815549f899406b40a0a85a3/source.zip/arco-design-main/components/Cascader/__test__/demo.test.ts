import demoTest from '../../../tests/demoTest';

demoTest('Cascader');
