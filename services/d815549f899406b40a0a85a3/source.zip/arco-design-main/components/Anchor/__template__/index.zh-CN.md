---
file: interface
---

`````
组件 / 其他

# 锚点 Anchor

通过锚点可快速找到信息内容在当前页面的位置。
`````

%%Content%%

## API

%%Props%%
