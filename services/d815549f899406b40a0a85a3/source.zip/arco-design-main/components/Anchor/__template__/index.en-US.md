---
file: interface
---

`````
Component / Other

# Anchor

By the Anchor can quickly find the information content of the current page.
`````

%%Content%%

## API

%%Props%%
