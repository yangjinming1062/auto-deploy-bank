import Anchor from './anchor';
import { AnchorProps } from './interface';

export default Anchor;

export { AnchorProps };
