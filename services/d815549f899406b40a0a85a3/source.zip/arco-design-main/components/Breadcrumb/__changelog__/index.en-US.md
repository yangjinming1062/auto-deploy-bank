## 2.58.1

2024-01-05

### 🐛 BugFix

- Fixed the bug of extra delimiters appearing when conditional rendering exists in `Breadcrumb.Item`.([#2477](https://github.com/arco-design/arco-design/pull/2477))

## 2.40.0

2022-09-16

### 🆕 Feature

- `Breadcrumb` adds `href`, `onClick` and `tagName` properties.([#1363](https://github.com/arco-design/arco-design/pull/1363))

## 2.12.0

2021-03-19

### 🐛 Bugfix

- Fix the problem that the boolean value of `Breadcrumb` package is reported incorrectly.

## 2.10.0 🏮

2020-02-26

### 💅 Style

- Optimized the experience of the `Breadcrumb` component. Only when the element is a link, the background color will be displayed in hover.

