---
file: interface
---

`````
组件 / 导航

# 面包屑 Breadcrumb

面包屑是辅助导航模式，用于识别页面在层次结构内的位置，并根据需要向上返回。
`````

%%Content%%

## API

%%Props%%
