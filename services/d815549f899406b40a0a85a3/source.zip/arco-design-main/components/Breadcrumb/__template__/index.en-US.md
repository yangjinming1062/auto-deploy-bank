---
file: interface
---

`````
Component / Navigation

# Breadcrumb

Used to display the location of the current page and quickly return to the history page.
`````

%%Content%%

## API

%%Props%%
