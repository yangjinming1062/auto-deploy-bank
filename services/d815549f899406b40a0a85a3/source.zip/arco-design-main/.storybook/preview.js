import '../dist/css/index.less';
import './index.less';

export const parameters = {
  actions: { argTypesRegex: '^on[A-Z].*' },
};
