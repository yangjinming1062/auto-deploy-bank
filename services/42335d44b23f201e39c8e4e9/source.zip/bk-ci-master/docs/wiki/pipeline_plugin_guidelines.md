# 流水线插件开发指引：

## 插件开发规范

- [插件开发规范](https://github.com/ci-plugins/ci-plugins-wiki/blob/master/specification/plugin_dev.md)
- [插件配置规范](https://github.com/ci-plugins/ci-plugins-wiki/blob/master/specification/plugin_config.md)
- [插件输出规范](https://github.com/ci-plugins/ci-plugins-wiki/blob/master/specification/plugin_output.md)

## 插件开发指引

- [插件开发指引- Java版](https://github.com/ci-plugins/ci-plugins-wiki/blob/master/guide/guide_java.md)
- [插件开发指引- Python版](https://github.com/ci-plugins/ci-plugins-wiki/blob/master/guide/guide_python.md)
- [插件开发指引- Golang版](https://github.com/ci-plugins/ci-plugins-wiki/blob/master/guide/guide_golang.md)
- [插件开发指引- Nodejs版](https://github.com/ci-plugins/ci-plugins-wiki/blob/master/guide/guide_nodejs.md)
