# Security Policy

## Reporting a Vulnerability

Please report security issues to:

irwinsun@tencent.com
zanyzhao@tencent.com
