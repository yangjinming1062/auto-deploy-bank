package com.tencent.devops.artifactory.pojo.enums

enum class PipelineOutputType {
    ARTIFACT,
    REPORT
}
