---
name: Support Request
about: Support request or question relating to bk-ci
labels: help wanted

---

<!--
STOP -- PLEASE READ!

GitHub is not the right place for support requests.

If you're looking for help, check [BlueKing Q&A Community](https://bk.tencent.com/s-mart/community/question?selectTag=%25E8%2593%259D%25E7%259B%25BE&bestType=latest).

You can also post your question on the QQ Group: 495299374.

-->