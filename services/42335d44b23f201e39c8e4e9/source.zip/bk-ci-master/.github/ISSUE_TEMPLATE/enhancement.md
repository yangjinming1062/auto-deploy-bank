---
name: Enhancement Request
about: Suggest an enhancement to the bk-ci project
labels: kind/enhancement

---
<!-- Please only use this template for submitting enhancement requests -->

**What would you like to be added**:

**Why is this needed**: