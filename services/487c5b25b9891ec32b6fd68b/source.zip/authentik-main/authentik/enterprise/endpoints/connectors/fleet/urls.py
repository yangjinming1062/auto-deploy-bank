from authentik.enterprise.endpoints.connectors.fleet.api import FleetConnectorViewSet

api_urlpatterns = [("endpoints/fleet/connectors", FleetConnectorViewSet)]
