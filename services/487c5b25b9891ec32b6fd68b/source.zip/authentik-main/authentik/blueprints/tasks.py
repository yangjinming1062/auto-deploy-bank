# Import all v1 tasks for auto task discovery
from authentik.blueprints.v1.tasks import *  # noqa: F403
