# Grails pre-release action

Performs some actions before doing a release

## Example usage

```yaml
uses: grails/grails-core/pre-release@master
with:
  token: ${{ secrets.GITHUB_TOKEN }}
```
