# Grails post-release action

Performs some actions after doing a release

## Example usage

```yaml
uses: grails/post-release@master
with:
  token: ${{ secrets.GITHUB_TOKEN }}
```
