## grails-codecs

Code related to Grails codec methods (`.encodeAsHTML)`, `.encodeAsHex()`, etc...)
