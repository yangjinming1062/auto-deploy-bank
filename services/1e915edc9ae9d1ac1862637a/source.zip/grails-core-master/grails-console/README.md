## grails-console

This subproject contains code to support the Grails console, Grails shell and Grails Swing console.
