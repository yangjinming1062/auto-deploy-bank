## grails-core

This subproject contains much of the code for the core of Grails and common code referenced from many places in the project.
