## grails-bootstrap

This subproject contains much of the core code required to bootstrap the Grails environment.
