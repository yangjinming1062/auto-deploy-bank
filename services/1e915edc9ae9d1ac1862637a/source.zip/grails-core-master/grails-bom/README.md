## grails-bom

Build support for generating the Maven bill of materials.
