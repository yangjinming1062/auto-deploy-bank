This is a custom implementation of voxel radiance field. The codebase
is adapted from TensoRF but with fairly heavy changes; we do not use tensor factorization for simplicity.
It achieves comparable performance to vanilla NeRF absent view dependencies.
