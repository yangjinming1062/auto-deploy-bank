a personal tookit for experiment management;
some of the designs patterns are inspired by detectron2
