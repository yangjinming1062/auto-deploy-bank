Selected modules from OpenAI's [guided diffusion](https://github.com/openai/guided-diffusion), retrieved at commit `22e0df8183507e13a7813f8d38d51b072ca1e67c`

It's a bare minimum set of files needed to run their pretrained models. You can download these model checkpoints following the instructions in their repository README

Some modifications are made to remove the distributed processing utilities in order to reduce code complexity.
