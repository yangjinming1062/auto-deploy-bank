public class Main {
  final static public A a = new A();
}
