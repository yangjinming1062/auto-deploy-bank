package org.myapp;

public class Main {
  @Override
  public boolean equals(Object obj) {
    return super.equals(obj);
  }
}
