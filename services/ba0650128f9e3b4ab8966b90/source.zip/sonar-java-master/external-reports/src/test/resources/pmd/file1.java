class A {

  void method(String arg1, String arg2) {
    int x = 1;
    System.out.println(arg1);
  }
}
