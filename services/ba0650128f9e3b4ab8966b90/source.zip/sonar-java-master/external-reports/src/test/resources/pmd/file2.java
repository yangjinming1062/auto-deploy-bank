import java.util.List;

class A {

  private void privateMethod() {
  }

}
