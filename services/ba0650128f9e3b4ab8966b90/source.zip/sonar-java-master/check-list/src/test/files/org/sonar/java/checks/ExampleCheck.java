import org.sonar.check.Rule;

@Rule(key = "exampleKey")
class ExampleCheck implements JavaCheck {
}
