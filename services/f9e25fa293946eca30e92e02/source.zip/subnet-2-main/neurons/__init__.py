"""
This version number is used to trigger automatic updates.
"""

__version__ = "10.3.1"
