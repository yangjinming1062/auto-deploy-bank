from enum import Enum


class Competition(Enum):
    """
    Enum for competitions.
    """

    FIRST = 1
