#!/bin/bash

# Activate your virtual environment if you have one
# source /path/to/your/venv/bin/activate

# Run your Python script
python main.py

# Deactivate the virtual environment if you activated one
# deactivate