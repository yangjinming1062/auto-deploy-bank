class IPersistenceLayer:
    def store(self, key, data):
        pass

    def retrieve(self, key):
        pass

    def update(self, key, data):
        pass

    def exists(self, key):
        pass
