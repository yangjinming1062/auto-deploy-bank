var http = require('http');

http.createServer(function (req, res) {

}).listen(9000);

http.createServer(function (req, res) {
	
}).listen(9000);
