var testsuite = require("testsuite");

module.exports = testsuite(__dirname);
