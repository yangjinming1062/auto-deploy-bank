#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
test_django-task
------------

Tests for `django-task` models module.
"""

from django.test import TestCase


class TestDjango_task(TestCase):

    def setUp(self):
        pass

    def test_something(self):
        pass

    def tearDown(self):
        pass
