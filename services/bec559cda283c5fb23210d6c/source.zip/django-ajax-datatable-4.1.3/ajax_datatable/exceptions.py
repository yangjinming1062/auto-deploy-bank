
class ColumnOrderError(Exception):
    pass
