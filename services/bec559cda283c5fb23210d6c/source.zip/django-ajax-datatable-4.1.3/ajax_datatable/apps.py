from django.apps import AppConfig


class AjaxDatatableConfig(AppConfig):
    name = 'ajax_datatable'
