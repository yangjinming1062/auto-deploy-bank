const { runAllExample } = require('./runE2eProject.js');

runAllExample();
