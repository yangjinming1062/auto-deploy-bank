declare const __DEV__: boolean;
declare const __TEST__: boolean;
declare const __VERSION__: string;
