# `@garfish/router`

[![NPM version](https://img.shields.io/npm/v/@garfish/router.svg?style=flat-square)](https://www.npmjs.com/package/@garfish/router)

## Usage

```js
import router from '@garfish/router';

// TODO: DEMONSTRATE API
```
