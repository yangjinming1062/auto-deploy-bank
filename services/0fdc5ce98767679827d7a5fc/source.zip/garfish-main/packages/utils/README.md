# `@garfish/utils`

[![NPM version](https://img.shields.io/npm/v/@garfish/utils.svg?style=flat-square)](https://www.npmjs.com/package/@garfish/utils)

## Usage

```js
import { isObject } from '@garfish/utils';

console.log(isObject({})); // true
```
