export const __LOADER_FLAG__ = Symbol.for('__LOADER_FLAG__');
export const __GARFISH_FLAG__ = Symbol.for('__GARFISH_FLAG__');
export const __MockHtml__ = '__garfishmockhtml__';
export const __MockBody__ = '__garfishmockbody__';
export const __MockHead__ = '__garfishmockhead__';
export const __REMOVE_NODE__ = '__garfishremovenode__';
