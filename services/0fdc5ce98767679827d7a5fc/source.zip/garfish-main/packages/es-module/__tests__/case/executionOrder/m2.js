expect(globalThis.orderIndex).toBe(0);
globalThis.orderIndex++;
