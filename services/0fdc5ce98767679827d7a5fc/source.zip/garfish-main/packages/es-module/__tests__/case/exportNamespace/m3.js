export const name = 'm3';
export const a = [1];
export const b = [2];
export default [3];
