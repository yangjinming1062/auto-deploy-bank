// name 不存在，会报错
import { name } from './m3.js';
