expect(globalThis.orderIndex).toBe(1);
globalThis.orderIndex++;
