export * as m3Namespace from './m3.js';
export { default } from './m3.js';
export * from './m3.js';
export * from './m4.js';
export { name } from './m3.js';
export { name as n1 } from './m3.js';
export { name as nn, name as n2 } from './m3.js';

import { name } from './m3.js';

export const _name = 'm2';

const d = 1;
export { d };

expect(name).toBe('m3');
