import { App } from './m2.js';

expect(typeof App).toBe('function');
