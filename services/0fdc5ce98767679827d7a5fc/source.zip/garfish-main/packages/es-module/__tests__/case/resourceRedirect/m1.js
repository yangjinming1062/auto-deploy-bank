import * as _ from 'https://unpkg.com/lodash-es';
import lodash from 'https://unpkg.com/lodash-es';

expect(_.default === lodash);
