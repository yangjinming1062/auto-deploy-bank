import { esmContent } from './esmB.js';
export * from './esmC.js';

window.esmContent = esmContent;
