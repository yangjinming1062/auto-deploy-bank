console.log('dynamic esm A1 content');
