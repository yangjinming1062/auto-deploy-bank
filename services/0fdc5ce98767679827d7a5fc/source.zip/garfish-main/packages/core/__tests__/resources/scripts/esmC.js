export const esmC = 'esm content c';
