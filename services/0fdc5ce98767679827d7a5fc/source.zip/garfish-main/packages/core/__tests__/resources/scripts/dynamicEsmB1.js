console.log('dynamic esm B1 content');
