export const esmContent = 'esm content';
