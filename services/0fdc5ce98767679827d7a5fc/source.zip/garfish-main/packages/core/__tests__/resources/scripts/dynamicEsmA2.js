console.log('dynamic esm A2 content');
