export type { interfaces } from './interface';
export { Garfish as default } from './garfish';
