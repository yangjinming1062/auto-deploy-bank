# `@garfish/browser-snapshot`

[![NPM version](https://img.shields.io/npm/v/@garfish/browser-snapshot.svg?style=flat-square)](https://www.npmjs.com/package/@garfish/browser-snapshot)

## Usage

```js
import spSandbox from '@garfish/browser-snapshot';

// TODO: DEMONSTRATE API
```
