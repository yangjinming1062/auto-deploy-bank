import pkg from './package.json';
import { baseTsup } from '../../tsup.config';

export const tsup = {
  ...baseTsup(pkg, true),
  format: ['esm', 'cjs', 'iife'],
};
