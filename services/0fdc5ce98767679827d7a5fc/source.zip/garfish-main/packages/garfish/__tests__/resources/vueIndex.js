const dynamicScript = document.createElement('script');
dynamicScript.src = 'dynamic.js';
document.head.appendChild(dynamicScript);
