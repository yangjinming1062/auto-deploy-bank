export { vueBridge } from './vueBridge';
