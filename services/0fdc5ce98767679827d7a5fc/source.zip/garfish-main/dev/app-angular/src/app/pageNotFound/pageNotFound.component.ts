import { Component } from '@angular/core';

@Component({
  selector: 'app-pageNotFound',
  templateUrl: './pageNotFound.component.html',
  styleUrls: ['./pageNotFound.component.css'],
})
export class PageNotFoundComponent {}
