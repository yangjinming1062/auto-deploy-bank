import { Component } from '@angular/core';

@Component({
  selector: 'app-product-detail',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'],
})
export class DashboardComponent {}
