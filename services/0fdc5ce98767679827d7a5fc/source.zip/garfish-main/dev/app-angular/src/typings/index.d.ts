export {};
declare global {
  interface Window {
    __GARFISH__: boolean;
    __GARFISH_EXPORTS__: any;
  }
}
