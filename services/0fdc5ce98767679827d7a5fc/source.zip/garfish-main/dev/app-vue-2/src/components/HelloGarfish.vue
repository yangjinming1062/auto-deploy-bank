<template>
  <div class="hello">
    <h3 data-test="title">Thank you for the vue2 applications use garfish</h3>
    <img alt="Vue logo" src="../assets/logo.png">
  </div>
</template>

<script>
  export default {
    name: 'HelloGarfish',
  }
</script>
