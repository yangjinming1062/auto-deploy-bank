window.dynamic = 1;
