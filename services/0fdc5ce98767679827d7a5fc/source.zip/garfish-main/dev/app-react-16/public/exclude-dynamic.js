window.dynamic2 = 1;
