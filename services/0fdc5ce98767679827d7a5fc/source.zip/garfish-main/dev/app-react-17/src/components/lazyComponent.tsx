console.log('react 17 -- lazy component document.currentScript: ', document.currentScript);

export default function () {
  return <h3 data-test="title">React sub App lazyComponent</h3>;
}
