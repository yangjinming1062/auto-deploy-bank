package features.test;

import org.junit.jupiter.api.Test;
import org.noear.solon.test.SolonTest;

/**
 * @author noear 2024/9/4 created
 */
@SolonTest
public class LoadTest {
  @Test
  public void load(){

  }
}
