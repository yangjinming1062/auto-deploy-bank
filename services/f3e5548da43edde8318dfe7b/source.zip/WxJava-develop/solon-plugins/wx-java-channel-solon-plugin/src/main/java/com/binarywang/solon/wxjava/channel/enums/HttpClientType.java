package com.binarywang.solon.wxjava.channel.enums;

/**
 * httpclient类型
 *
 * @author <a href="https://github.com/lixize">Zeyes</a>
 */
public enum HttpClientType {
  /**
   * HttpClient
   */
  HttpClient
}
