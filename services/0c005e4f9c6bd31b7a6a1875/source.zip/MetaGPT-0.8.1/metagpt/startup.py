#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@Time    : 2024/3/11 19:16
@Author  : alexanderwu
@File    : startup.py
"""

# DEPRECATED: This file is deprecated and will be removed in the future.
# The startup.py implementation has been moved to software_company.py
