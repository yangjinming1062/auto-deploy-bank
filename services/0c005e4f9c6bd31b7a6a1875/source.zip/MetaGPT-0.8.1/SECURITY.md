# Security Policy

## Supported Versions

| Version | Supported          |
|---------|--------------------|
 | 0.7.x   | :x:                |
 | 0.6.x   | :x:                |
| < 0.6.x | :x:                |


## Reporting a Vulnerability

If you have any vulnerability reports, please contact alexanderwu@deepwisdom.ai .