declare module 'ot-json0'
