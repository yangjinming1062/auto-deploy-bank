export default defineEventHandler(async event => {
    return { status: 'ok' }
})
