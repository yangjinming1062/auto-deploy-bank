import { embedderWorkerPlugin } from '@magickml/embedder-worker'

export default embedderWorkerPlugin
