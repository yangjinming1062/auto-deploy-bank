import { embedderAuthPlugin } from '@magickml/embedder-auth-plugin'

export default embedderAuthPlugin
