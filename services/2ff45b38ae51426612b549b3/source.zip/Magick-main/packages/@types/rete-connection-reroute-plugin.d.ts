declare module 'rete-connection-reroute-plugin'
