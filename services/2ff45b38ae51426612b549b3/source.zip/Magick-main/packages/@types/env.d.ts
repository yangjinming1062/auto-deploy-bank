/// <reference types="vite/client" />

export interface ImportMeta {
  readonly env: ImportMetaEnv
}
