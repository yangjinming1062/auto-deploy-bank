declare module 'rete-comment-plugin'
