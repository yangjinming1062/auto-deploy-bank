/**
 * This exports the MagickIDE class from './main' file.
 */
export { MagickIDE } from './main'
