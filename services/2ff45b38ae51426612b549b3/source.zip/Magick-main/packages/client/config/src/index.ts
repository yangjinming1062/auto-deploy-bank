export const DOCKVIEW_THEME = 'dockview-theme-night'
export * from './lib/client-config'
