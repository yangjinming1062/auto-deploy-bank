import { clientTypes } from './client-types'

describe('clientTypes', () => {
  it('should work', () => {
    expect(clientTypes()).toEqual('client-types')
  })
})
