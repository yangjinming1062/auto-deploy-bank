# client-types

This library was generated with [Nx](https://nx.dev).

## Building

Run `nx build client-types` to build the library.

## Running unit tests

Run `nx test client-types` to execute the unit tests via [Jest](https://jestjs.io).
