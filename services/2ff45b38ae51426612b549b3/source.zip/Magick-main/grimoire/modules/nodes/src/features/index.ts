export const nodeFeatures = {
    nodes: "nodes",
  } as const;
  
  export type NodeFeatures = typeof nodeFeatures;