## @magickml/nodes

<!-- automd:badges color="blue" license name="@magickml/nodes" codecov bundlephobia packagephobia -->

<!-- /automd -->
