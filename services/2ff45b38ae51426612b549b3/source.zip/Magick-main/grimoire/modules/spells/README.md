## @magickml/spells

<!-- automd:badges color="blue" license name="@magickml/spells" codecov bundlephobia packagephobia -->

<!-- /automd -->

Currently working on getting the folder scan for JSON.
Spell registry is mock.
