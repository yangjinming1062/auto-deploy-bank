## @magickml/portal

<!-- automd:badges color="blue" license name="@magickml/portal" codecov bundlephobia packagephobia -->

<!-- /automd -->

This ones a little different then the others. Its goal is to poll/subscribe to an external source and keep that data in the NitroApp state. I have user data/billing usage in mind.