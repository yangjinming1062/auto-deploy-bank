export const schemaFeatures = {
    schemas: "schemas",
  } as const;
  
  export type SchemaFeatures = typeof schemaFeatures;