export const toolFeatures = {
  tools: 'tools',
} as const

export type ToolFeatures = typeof toolFeatures
