## grimoire

This repo is import only from the main repo, so you won't break anything by modifying this folder.

### start playground

```bash
pnpm i
pnpm -r build
pnpm dev
```

### run cli in playground

```
pnpm --filter playground grimoire your-command-here
```