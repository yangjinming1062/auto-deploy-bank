//
// MessagePack for Java
//
//    Licensed under the Apache License, Version 2.0 (the "License");
//    you may not use this file except in compliance with the License.
//    You may obtain a copy of the License at
//
//        http://www.apache.org/licenses/LICENSE-2.0
//
//    Unless required by applicable law or agreed to in writing, software
//    distributed under the License is distributed on an "AS IS" BASIS,
//    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//    See the License for the specific language governing permissions and
//    limitations under the License.
//
package org.msgpack.jackson.dataformat;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.cfg.MapperBuilder;

import java.math.BigDecimal;
import java.math.BigInteger;

public class MessagePackMapper extends ObjectMapper
{
    private static final long serialVersionUID = 3L;

    public static class Builder extends MapperBuilder<MessagePackMapper, Builder>
    {
        public Builder(MessagePackMapper m)
        {
            super(m);
        }
    }

    public MessagePackMapper()
    {
        this(new MessagePackFactory());
    }

    public MessagePackMapper(MessagePackFactory f)
    {
        super(f);
    }

    public MessagePackMapper handleBigIntegerAsString()
    {
        configOverride(BigInteger.class).setFormat(JsonFormat.Value.forShape(JsonFormat.Shape.STRING));
        return this;
    }

    public MessagePackMapper handleBigDecimalAsString()
    {
        configOverride(BigDecimal.class).setFormat(JsonFormat.Value.forShape(JsonFormat.Shape.STRING));
        return this;
    }

    public MessagePackMapper handleBigIntegerAndBigDecimalAsString()
    {
        return handleBigIntegerAsString().handleBigDecimalAsString();
    }

    public static Builder builder()
    {
        return new Builder(new MessagePackMapper());
    }

    public static Builder builder(MessagePackFactory f)
    {
        return new Builder(new MessagePackMapper(f));
    }
}
