package it.unibz.inf.ontop.rdf4j.predefined;

import it.unibz.inf.ontop.query.RDF4JQuery;
import it.unibz.inf.ontop.query.resultset.TupleResultSet;

public interface PredefinedTupleQuery extends PredefinedQuery<RDF4JQuery<TupleResultSet>> {
}
