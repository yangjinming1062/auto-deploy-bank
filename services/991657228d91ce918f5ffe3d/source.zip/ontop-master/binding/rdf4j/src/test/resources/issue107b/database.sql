create table SG_TABLE_ONE (ID integer, NAME varchar(10));

insert into SG_TABLE_ONE (ID, NAME) values (1, 'S030500');