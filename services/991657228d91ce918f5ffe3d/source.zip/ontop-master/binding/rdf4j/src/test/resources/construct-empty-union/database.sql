create table test (id integer);

insert into test (id) values (1);
insert into test (id) values (2);
insert into test (id) values (3);
insert into test (id) values (4);