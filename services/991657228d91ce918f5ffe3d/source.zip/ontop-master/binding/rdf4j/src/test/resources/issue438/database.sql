DROP TABLE IF EXISTS mytable;
CREATE TABLE mytable (
                           cover varchar(150),
                           coveren text
);

insert into mytable (cover, coveren) values ('v1', 'v1');
insert into mytable (cover, coveren) values ('v2', 'v3');
