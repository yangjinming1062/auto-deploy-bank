create table AGENCY (
"agency_id" integer,
agency_url varchar(100));

insert into agency ("agency_id", agency_url) values (42, 'http://aaa.com');