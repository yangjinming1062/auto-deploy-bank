create table table1 (
                        id1 integer,
                        val1 integer);

insert into table1 (id1, val1) values (1, 1);
insert into table1 (id1, val1) values (2, 1);
insert into table1 (id1, val1) values (3, 1);

create table table2 (id2 integer, val2 integer);
insert into table2 (id2, val2) values (2, 2);

create table table3 (id3 integer, val3 integer);
insert into table3 (id3, val3) values (3, 3);