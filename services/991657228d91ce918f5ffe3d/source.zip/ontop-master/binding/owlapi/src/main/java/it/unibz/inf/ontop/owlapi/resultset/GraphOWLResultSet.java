package it.unibz.inf.ontop.owlapi.resultset;


import org.semanticweb.owlapi.model.OWLAxiom;

public interface GraphOWLResultSet extends IterableOWLResultSet<OWLAxiom> {

}
