create table restaurants (
	restaurant_id int,
	restaurantName varchar(100),
	address varchar(100)
);

insert into restaurants (restaurant_id, restaurantName, address) values (1,'Tartaruga', 'aa');
insert into restaurants (restaurant_id, restaurantName, address) values (2,'Tortuga', 'bb');
