DROP TABLE wellboreSpain;
DROP TABLE wellboreFinland;
DROP TABLE namesMap;

