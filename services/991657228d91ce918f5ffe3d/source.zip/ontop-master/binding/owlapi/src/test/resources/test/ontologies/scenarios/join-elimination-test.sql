CREATE TABLE address (
id integer NOT NULL,
street character varying(100),
number integer,
city character varying(100),
state character varying(100),
country character varying(100),
PRIMARY KEY(id));