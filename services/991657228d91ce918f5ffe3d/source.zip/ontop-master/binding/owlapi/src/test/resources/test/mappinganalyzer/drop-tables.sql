DROP TABLE "table1";
DROP TABLE "table2";
DROP TABLE "table3";
