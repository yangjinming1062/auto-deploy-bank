CREATE TABLE data (
    id integer NOT NULL,
    number integer
);
INSERT INTO data VALUES (0, 0);
INSERT INTO data VALUES (1, 1);
INSERT INTO data VALUES (2, 2);