create table person (
   nr integer
);

create table review (
   nr integer
);