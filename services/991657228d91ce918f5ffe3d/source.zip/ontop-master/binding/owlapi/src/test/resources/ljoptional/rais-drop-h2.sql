DROP TABLE archiveobject ;

DROP TABLE physicalobject ;
