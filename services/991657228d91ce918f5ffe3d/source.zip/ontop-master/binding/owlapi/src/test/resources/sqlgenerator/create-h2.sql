CREATE TABLE "T1" (
	"c1" INT
);


CREATE TABLE "T2" (
	"c1" INT
);

