DROP TABLE client;

