CREATE TABLE test (
    name1 character varying(100),
	name2 character varying(100),
	name3 character varying(100)
);

INSERT INTO test (name1, name2, name3) VALUES ('John Smith', 'John Smith 2', 'John Smith 3');
INSERT INTO test (name1, name2, name3) VALUES ('Cote D''ivore', 'Cote D''ivore 2', 'Cote D''ivore 3');
