DROP TABLE address;
DROP TABLE client;
DROP TABLE company;
