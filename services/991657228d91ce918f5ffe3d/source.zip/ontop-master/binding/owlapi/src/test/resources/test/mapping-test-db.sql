/* Test database for mapping materializer */

CREATE TABLE data (fn VARCHAR, ln VARCHAR, age INTEGER, schooluri VARCHAR);
INSERT INTO data VALUES ('mariano','rodriguez',30,'http://schools.com/fub');
INSERT INTO data VALUES ('alexandra','eckert',26,'http://schools.com/tnt');
INSERT INTO data VALUES ('vlad','rhyzikov',27,'http://schools.com/fub');

