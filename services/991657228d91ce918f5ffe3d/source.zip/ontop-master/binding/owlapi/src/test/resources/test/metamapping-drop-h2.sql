DROP TABLE "table1";
