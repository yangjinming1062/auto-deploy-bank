CREATE TABLE COMAESN(
    IDCUENTA integer NOT NULL,
    SITUACION character varying(100)
);
