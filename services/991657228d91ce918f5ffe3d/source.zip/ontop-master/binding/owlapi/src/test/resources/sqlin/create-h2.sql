CREATE TABLE l_ship_route (
	route_id INT PRIMARY KEY,
	position_in_route INT,
	vertex_id INT
);


CREATE TABLE l_ship_initial_position (
	berth_id INT PRIMARY KEY
);

