DROP TABLE tbl_patient;

DROP TABLE t_name;

DROP TABLE t_nsclc;

DROP TABLE t_sclc;
