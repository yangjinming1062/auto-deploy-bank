CREATE TABLE IF NOT EXISTS "t11" ("s" varchar(255) NOT NULL, "o" varchar(255) NOT NULL);
CREATE TABLE IF NOT EXISTS "t12" ("s" varchar(255) NOT NULL, "o" varchar(255) NOT NULL, "l" varchar(10));
CREATE TABLE IF NOT EXISTS "t2" ("s" varchar(255) NOT NULL, "o" varchar(255) NOT NULL);
CREATE TABLE IF NOT EXISTS "t3" ("s" varchar(255) NOT NULL, "o" LONG NOT NULL);