CREATE TABLE "company_name" (
"id" INT NOT NULL PRIMARY KEY,
"country_code" VARCHAR(40)
);

INSERT INTO "company_name"
("id","country_code") VALUES
(1,'[be]'),
(2,'[ph]'),
(3, '[it]'),
(4, '[cn]');
