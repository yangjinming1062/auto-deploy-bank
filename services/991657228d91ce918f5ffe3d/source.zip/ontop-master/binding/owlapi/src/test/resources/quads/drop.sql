drop table Job;
drop table Person;