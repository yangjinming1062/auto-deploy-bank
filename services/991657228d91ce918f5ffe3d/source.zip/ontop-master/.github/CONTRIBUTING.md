# How to contribute to Ontop

Please visit https://ontop-vkg.org/community/contributing/ for the guidelines.



