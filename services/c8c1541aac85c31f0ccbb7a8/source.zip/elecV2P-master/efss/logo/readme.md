默认的一些 logo 图标。

在 elecV2P webUI 中可使用 efss/logo/logo_name.png 来使用。

其他一些说明

### apple touch icon - elecV2P.png

apple touch icon，即在 iOS safari 浏览器中添加网页到桌面时使用的图标。默认使用的是 **elecV2P.png**，如果想要修改为其他图标，删除旧的 elecV2P.png，然后并上传新的图标并命名为 **elecV2P.png** 即可。推荐尺寸 180x180。

除 **elecV2P.png** 有这个特殊使用情况外，其他图标都可以进行自由地增改或删除。