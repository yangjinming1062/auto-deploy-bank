#!/bin/sh

echo -e ${data}"\nhi from shell"