#!/bin/sh

if [ "$name" = "" ]
then
name='elecV2P'
fi

echo "hello "${name}", - shell"
echo $PWD