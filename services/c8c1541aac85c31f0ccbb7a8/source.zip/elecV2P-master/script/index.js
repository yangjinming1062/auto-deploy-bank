const { CONFIG_RULE, getJsResponse, setRewriteRule } = require('./rule')
const { CONFIG_RUNJS, runJSFile } = require('./runJSFile')

module.exports = { CONFIG_RULE, getJsResponse, setRewriteRule, CONFIG_RUNJS, runJSFile }