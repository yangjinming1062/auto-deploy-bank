CREATE database if NOT EXISTS `init_embed` default character set utf8mb4 collate utf8mb4_general_ci;
use
    `init_embed`;

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

############################



############################


SET FOREIGN_KEY_CHECKS = 1;
