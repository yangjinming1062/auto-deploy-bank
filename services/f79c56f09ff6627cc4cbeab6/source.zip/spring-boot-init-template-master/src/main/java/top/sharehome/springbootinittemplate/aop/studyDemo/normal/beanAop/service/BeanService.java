package top.sharehome.springbootinittemplate.aop.studyDemo.normal.beanAop.service;

/**
 * 针对切点参数为bean型的切面类的服务接口
 *
 * @author AntonyCheng
 */
public interface BeanService {

    void doMethod();

}