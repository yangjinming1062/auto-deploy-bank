package top.sharehome.springbootinittemplate.common.validate;

/**
 * 校验分组 Put请求
 *
 * @author AntonyCheng
 */
public interface PutGroup {

}