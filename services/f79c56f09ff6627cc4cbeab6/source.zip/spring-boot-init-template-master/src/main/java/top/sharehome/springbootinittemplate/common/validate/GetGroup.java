package top.sharehome.springbootinittemplate.common.validate;

/**
 * 校验分组 Get请求
 *
 * @author AntonyCheng
 */
public interface GetGroup {

}