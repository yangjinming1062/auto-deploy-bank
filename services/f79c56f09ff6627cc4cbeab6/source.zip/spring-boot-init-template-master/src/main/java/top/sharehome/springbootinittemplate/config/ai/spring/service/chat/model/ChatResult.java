package top.sharehome.springbootinittemplate.config.ai.spring.service.chat.model;

import lombok.Data;
import lombok.experimental.Accessors;
import org.springframework.ai.chat.messages.Message;
import org.springframework.ai.chat.messages.UserMessage;
import org.springframework.ai.chat.prompt.Prompt;

import java.io.Serial;
import java.io.Serializable;

/**
 * Chat结果集
 *
 * @author AntonyCheng
 */
@Data
@Accessors(chain = true)
public class ChatResult implements Serializable {

    /**
     * 结果
     */
    private String content;

    /**
     * 思考内容
     */
    private String reasoningContent;

    /**
     * 耗时（单位：毫秒）
     */
    private Long time;

    /**
     * Token数
     */
    private Integer usage;

    /**
     * 提示词
     */
    private Prompt prompt;

    /**
     * 服务名称
     */
    private String modelService;

    /**
     * 模型名称
     */
    private String modelName;

    public ChatResult(String content, String reasoningContent, Long time, Integer usage, String modelService, String modelName, String prompt) {
        this.content = content;
        this.reasoningContent = reasoningContent;
        this.time = time;
        this.usage = usage;
        this.modelService = modelService;
        this.modelName = modelName;
        this.prompt = new Prompt(new UserMessage(prompt));
    }

    public ChatResult(String content, String reasoningContent, Long time, Integer usage, String modelService, String modelName, Message... prompt) {
        this.content = content;
        this.reasoningContent = reasoningContent;
        this.time = time;
        this.usage = usage;
        this.modelService = modelService;
        this.modelName = modelName;
        this.prompt = new Prompt(prompt);
    }

    public ChatResult(String content, String reasoningContent, Long time, Integer usage, String modelService, String modelName, Prompt prompt) {
        this.content = content;
        this.reasoningContent = reasoningContent;
        this.time = time;
        this.usage = usage;
        this.modelService = modelService;
        this.modelName = modelName;
        this.prompt = prompt;
    }

    @Serial
    private static final long serialVersionUID = -2953969518518794478L;

}
