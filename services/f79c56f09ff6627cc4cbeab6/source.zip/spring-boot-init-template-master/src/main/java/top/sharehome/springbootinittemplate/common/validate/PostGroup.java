package top.sharehome.springbootinittemplate.common.validate;

/**
 * 校验分组 Post请求
 *
 * @author AntonyCheng
 */
public interface PostGroup {

}