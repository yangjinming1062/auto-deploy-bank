package top.sharehome.springbootinittemplate.config.ai.spring.vector.mapper;

public class KnowledgeMapper {
}
