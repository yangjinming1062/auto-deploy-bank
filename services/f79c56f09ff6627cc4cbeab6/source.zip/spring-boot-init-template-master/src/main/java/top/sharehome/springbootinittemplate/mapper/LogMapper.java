package top.sharehome.springbootinittemplate.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import top.sharehome.springbootinittemplate.model.entity.Log;

/**
 * 日志Mapper类
 *
 * @author AntonyCheng
 */
public interface LogMapper extends BaseMapper<Log> {

}