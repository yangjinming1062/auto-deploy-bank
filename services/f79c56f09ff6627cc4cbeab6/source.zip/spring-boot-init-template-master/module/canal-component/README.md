# Canal部署以及使用指南

如果想要了解完整部署版本，请点击[**这里**](https://pan.baidu.com/s/1CCyQO3QFjTT8AuBPMm0sHw?pwd=1900)。
