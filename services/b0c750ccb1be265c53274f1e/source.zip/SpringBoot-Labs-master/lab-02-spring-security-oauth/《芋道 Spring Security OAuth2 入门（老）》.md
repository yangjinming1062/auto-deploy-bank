<http://www.iocoder.cn/Spring-Security/OAuth2-learning-old/?github>
