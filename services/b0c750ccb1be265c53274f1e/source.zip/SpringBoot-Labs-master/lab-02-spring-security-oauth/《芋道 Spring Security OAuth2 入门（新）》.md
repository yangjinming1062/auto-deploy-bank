<http://www.iocoder.cn/Spring-Security/OAuth2-learning/?github>

对应 [lab-68](https://github.com/YunaiV/SpringBoot-Labs/tree/master/lab-68) 示例。
