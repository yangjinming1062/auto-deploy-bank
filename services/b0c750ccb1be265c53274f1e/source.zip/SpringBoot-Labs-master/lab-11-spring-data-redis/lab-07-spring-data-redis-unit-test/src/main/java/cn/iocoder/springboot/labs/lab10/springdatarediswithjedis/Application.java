package cn.iocoder.springboot.labs.lab10.springdatarediswithjedis;

import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
//@EnableTransactionManagement
public class Application {
}
