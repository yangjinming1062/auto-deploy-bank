package cn.iocoder.springboot.labs.lab10.springdatarediswithjedis.service;

import org.springframework.stereotype.Service;

@Service
public class UserService01 {



}
