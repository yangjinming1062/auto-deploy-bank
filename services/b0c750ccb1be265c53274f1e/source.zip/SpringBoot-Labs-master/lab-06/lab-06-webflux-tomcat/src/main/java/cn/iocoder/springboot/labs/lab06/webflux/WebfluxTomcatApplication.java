package cn.iocoder.springboot.labs.lab06.webflux;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebfluxTomcatApplication {

    public static void main(String[] args) {
        SpringApplication.run(WebfluxTomcatApplication.class);
    }

}
