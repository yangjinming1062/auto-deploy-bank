package cn.iocoder.springboot.lab04.rabbitmqdemo;
