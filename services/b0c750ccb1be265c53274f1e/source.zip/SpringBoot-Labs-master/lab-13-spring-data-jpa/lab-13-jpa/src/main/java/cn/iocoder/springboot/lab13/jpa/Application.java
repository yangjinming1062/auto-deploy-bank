package cn.iocoder.springboot.lab13.jpa;

import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Application {
}
