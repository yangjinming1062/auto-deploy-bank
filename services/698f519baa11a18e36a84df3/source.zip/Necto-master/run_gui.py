from rlbot_gui import gui

# This is a useful way to start up RLBotGUI directly from your bot project. You can use it to
# arrange a match with the settings you like, and if you have a good IDE like PyCharm,
# you can do breakpoint debugging on your bot.
if __name__ == '__main__':
    gui.start()
