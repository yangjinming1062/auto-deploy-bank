/*
 * Copyright 2020 VMware, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.micrometer.graphite;

import io.micrometer.core.instrument.Meter;
import io.micrometer.core.instrument.config.NamingConvention;
import io.micrometer.core.instrument.simple.SimpleMeterRegistry;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Tests for {@link GraphiteDimensionalNameMapper}.
 *
 * @author Jon Schneider
 * @author Johnny Lim
 * @author Andrew Fitzgerald
 */
class GraphiteDimensionalNameMapperTest {

    private final GraphiteDimensionalNameMapper nameMapper = new GraphiteDimensionalNameMapper();

    private final SimpleMeterRegistry registry = new SimpleMeterRegistry();

    private final NamingConvention namingConvention = new GraphiteDimensionalNamingConvention();

    @Test
    void simpleName() {
        Meter meter = registry.counter("a.simple.counter");
        assertThat(getName(meter)).isEqualTo("a.simple.counter");
    }

    @Test
    void singleTag() {
        Meter meter = registry.counter("a.simple.counter", "key", "value");
        assertThat(getName(meter)).isEqualTo("a.simple.counter;key=value");
    }

    @Test
    void multipleTags() {
        Meter meter = registry.counter("a.simple.counter", "key1", "value1", "key2", "value2");
        assertThat(getName(meter)).isEqualTo("a.simple.counter;key1=value1;key2=value2");
    }

    private String getName(Meter meter) {
        return nameMapper.toHierarchicalName(meter.getId(), namingConvention);
    }

}
