import re

def base_io(input_str):
    pass