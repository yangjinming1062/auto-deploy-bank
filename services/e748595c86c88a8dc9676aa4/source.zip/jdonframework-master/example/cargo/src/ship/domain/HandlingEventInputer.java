package ship.domain;

/**
 * @stereotype role
 */

public class HandlingEventInputer {

	private ship.domain.HandlingEvent lnkHandleEvent;
}
