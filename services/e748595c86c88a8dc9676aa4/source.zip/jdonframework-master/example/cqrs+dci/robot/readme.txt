english:http://jivejdon.blogspot.com/2011/09/ddd-dci-and-domain-events-example.html
chineae:http://www.jdon.com/jdonframework/dci.html


http://localhost:8080/myweb/

