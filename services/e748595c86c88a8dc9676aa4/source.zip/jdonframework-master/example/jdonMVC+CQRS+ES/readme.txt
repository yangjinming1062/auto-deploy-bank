
gradle: gradlew.bat war
maven: mvn package

deploy the testWeb.war to  server, 

please setup at first your database, and configure in testWeb.war
if you have tomcat, modify src\main\webapp\META-INF\context.xml
run it in browser url: http://localhost:8080/testWeb/



