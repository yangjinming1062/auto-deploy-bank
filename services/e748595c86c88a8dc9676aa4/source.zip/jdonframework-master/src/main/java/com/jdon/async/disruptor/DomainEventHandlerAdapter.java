/*
 * Copyright 2003-2009 the original author or authors.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain event copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * 
 */
package com.jdon.async.disruptor;

import com.jdon.container.pico.Startable;
import com.jdon.domain.message.DomainEventHandler;
import com.lmax.disruptor.EventHandler;
import com.lmax.disruptor.LifecycleAware;

public class DomainEventHandlerAdapter implements EventHandler<EventDisruptor>, LifecycleAware {
	private DomainEventHandler handler;

	public DomainEventHandlerAdapter(DomainEventHandler handler) {
		super();
		this.handler = handler;
	}

	public void onEvent(EventDisruptor event, long sequence, boolean endOfBatch) throws Exception {
		try {
			handler.onEvent(event, endOfBatch);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void onStart() {
		if (handler instanceof Startable) {
			Startable st = (Startable) handler;
			st.start();
		}

	}

	@Override
	public void onShutdown() {
		if (handler instanceof Startable) {
			Startable st = (Startable) handler;
			st.stop();
		}

	}

}
