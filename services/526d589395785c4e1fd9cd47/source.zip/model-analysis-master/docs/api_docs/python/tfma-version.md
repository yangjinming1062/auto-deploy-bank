
# TFMA Version

::: tensorflow_model_analysis.version
