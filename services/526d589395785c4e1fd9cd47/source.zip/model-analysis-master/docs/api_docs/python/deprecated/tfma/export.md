<div itemscope itemtype="http://developers.google.com/ReferenceObject">
<meta itemprop="name" content="tfma.export" />
<meta itemprop="path" content="Stable" />
</div>

# Module: tfma.export

Defined in
[`eval_saved_model/export.py`](https://github.com/tensorflow/model-analysis/tree/master/tensorflow_model_analysis/eval_saved_model/export.py).

<!-- Placeholder for "Used in" -->

Library for exporting the EvalSavedModel.

## Functions

[`build_parsing_eval_input_receiver_fn(...)`](../tfma/export/build_parsing_eval_input_receiver_fn.md):
Build a eval_input_receiver_fn expecting fed tf.Examples.
