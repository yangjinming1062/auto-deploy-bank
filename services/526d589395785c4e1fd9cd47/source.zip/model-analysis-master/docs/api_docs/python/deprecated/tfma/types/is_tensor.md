<div itemscope itemtype="http://developers.google.com/ReferenceObject">
<meta itemprop="name" content="tfma.types.is_tensor" />
<meta itemprop="path" content="Stable" />
</div>

# tfma.types.is_tensor

```python
tfma.types.is_tensor(obj)
```

Defined in
[`types.py`](https://github.com/tensorflow/model-analysis/tree/master/tensorflow_model_analysis/types.py).

<!-- Placeholder for "Used in" -->
