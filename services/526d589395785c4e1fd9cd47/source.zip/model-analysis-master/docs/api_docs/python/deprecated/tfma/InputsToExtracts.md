<div itemscope itemtype="http://developers.google.com/ReferenceObject">
<meta itemprop="name" content="tfma.InputsToExtracts" />
<meta itemprop="path" content="Stable" />
</div>

# tfma.InputsToExtracts

```python
tfma.InputsToExtracts(
    *args,
    **kwargs
)
```

<!-- Placeholder for "Used in" -->

Converts serialized inputs (e.g. examples) to Extracts.
