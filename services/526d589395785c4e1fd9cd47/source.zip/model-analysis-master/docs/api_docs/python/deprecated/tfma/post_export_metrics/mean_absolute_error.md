<div itemscope itemtype="http://developers.google.com/ReferenceObject">
<meta itemprop="name" content="tfma.post_export_metrics.mean_absolute_error" />
<meta itemprop="path" content="Stable" />
</div>

# tfma.post_export_metrics.mean_absolute_error

```python
tfma.post_export_metrics.mean_absolute_error(
    *args,
    **kwargs
)
```

Defined in
[`post_export_metrics/post_export_metrics.py`](https://github.com/tensorflow/model-analysis/tree/master/tensorflow_model_analysis/post_export_metrics/post_export_metrics.py).

<!-- Placeholder for "Used in" -->

This is the function that the user calls.
