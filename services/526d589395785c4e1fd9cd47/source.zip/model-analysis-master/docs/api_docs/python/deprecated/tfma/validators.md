<div itemscope itemtype="http://developers.google.com/ReferenceObject">
<meta itemprop="name" content="tfma.validators" />
<meta itemprop="path" content="Stable" />
</div>

# Module: tfma.validators

Defined in
[`validators/__init__.py`](https://github.com/tensorflow/model-analysis/tree/master/tensorflow_model_analysis/validators/__init__.py).

<!-- Placeholder for "Used in" -->

Init module for TensorFlow Model Analysis validators.

## Classes

[`class Validator`](../tfma/validators/Validator.md): Validator(stage_name,
ptransform)
