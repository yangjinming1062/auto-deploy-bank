<div itemscope itemtype="http://developers.google.com/ReferenceObject">
<meta itemprop="name" content="tfma.default_writers" />
<meta itemprop="path" content="Stable" />
</div>

# tfma.default_writers

```python
tfma.default_writers(output_path)
```

Defined in
[`api/model_eval_lib.py`](https://github.com/tensorflow/model-analysis/tree/master/tensorflow_model_analysis/api/model_eval_lib.py).

<!-- Placeholder for "Used in" -->

Returns the default writers for use in WriteResults.

#### Args:

*   <b>`output_path`</b>: Path to store results files under.
