<div itemscope itemtype="http://developers.google.com/ReferenceObject">
<meta itemprop="name" content="tfma.version" />
<meta itemprop="path" content="Stable" />
<meta itemprop="property" content="VERSION"/>
</div>

# Module: tfma.version

Defined in
[`version.py`](https://github.com/tensorflow/model-analysis/tree/master/tensorflow_model_analysis/version.py).

<!-- Placeholder for "Used in" -->

Contains the version string for this release of TFMA.

## Other Members

<h3 id="VERSION"><code>VERSION</code></h3>
