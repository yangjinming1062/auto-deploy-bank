<div itemscope itemtype="http://developers.google.com/ReferenceObject">
<meta itemprop="name" content="tfma.ExtractAndEvaluate" />
<meta itemprop="path" content="Stable" />
</div>

# tfma.ExtractAndEvaluate

```python
tfma.ExtractAndEvaluate(
    *args,
    **kwargs
)
```

<!-- Placeholder for "Used in" -->

Performs Extractions and Evaluations in provided order.
