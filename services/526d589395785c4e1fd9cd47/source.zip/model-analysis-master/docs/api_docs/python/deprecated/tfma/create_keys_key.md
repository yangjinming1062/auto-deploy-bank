<div itemscope itemtype="http://developers.google.com/ReferenceObject">
<meta itemprop="name" content="tfma.create_keys_key" />
<meta itemprop="path" content="Stable" />
</div>

# tfma.create_keys_key

```python
tfma.create_keys_key(key)
```

Defined in
[`util.py`](https://github.com/tensorflow/model-analysis/tree/master/tensorflow_model_analysis/util.py).

<!-- Placeholder for "Used in" -->

Creates secondary key representing the sparse keys associated with key.
