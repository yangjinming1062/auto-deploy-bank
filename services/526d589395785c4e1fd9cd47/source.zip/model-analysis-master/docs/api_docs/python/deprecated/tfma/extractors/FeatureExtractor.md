<div itemscope itemtype="http://developers.google.com/ReferenceObject">
<meta itemprop="name" content="tfma.extractors.FeatureExtractor" />
<meta itemprop="path" content="Stable" />
</div>

# tfma.extractors.FeatureExtractor

```python
tfma.extractors.FeatureExtractor(
    additional_extracts=None,
    excludes=None,
    extract_source=constants.FEATURES_PREDICTIONS_LABELS_KEY
)
```

Defined in
[`extractors/feature_extractor.py`](https://github.com/tensorflow/model-analysis/tree/master/tensorflow_model_analysis/extractors/feature_extractor.py).

<!-- Placeholder for "Used in" -->
