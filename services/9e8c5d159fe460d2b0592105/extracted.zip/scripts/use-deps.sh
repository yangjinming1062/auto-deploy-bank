# Find locally installed dependencies
if [ -f deps/environment.sh ]; then
    . deps/environment.sh
fi
