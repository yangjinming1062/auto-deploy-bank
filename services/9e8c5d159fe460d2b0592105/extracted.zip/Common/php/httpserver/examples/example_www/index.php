<?php

echo "<h1>It works!</h1>";

echo "<a href='/phpinfo.php'>";
echo "<img src='/admin.gif' alt='phpinfo' title='phpinfo'>";
echo "</a>";
