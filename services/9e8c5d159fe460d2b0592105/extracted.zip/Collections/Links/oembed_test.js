var oembed = require("./oembed");

//oembed.fetch({url:"http://www.youtube.com/watch?v=3A0RFDm8_rE"},console.log);
//oembed.fetch({url:"http://www.flickr.com/photos/peterscottnz/2531444191/"},console.log);
//oembed.fetch({url:"http://www.viddler.com/explore/myeliteteam/videos/164/"},console.log);
//oembed.fetch({url:"http://blip.tv/schloerbits/apple-5611856"},console.log);
//oembed.fetch({url:"http://www.hulu.com/watch/285329/the-simpsons-history-lesson"},console.log);
//oembed.fetch({url:"http://vimeo.com/28129586"},console.log);
//oembed.fetch({url:"http://www.dailymotion.com/video/xliy1s_the-lxd-in-the-internet-age-dance-evolves_music"},console.log);
//oembed.fetch({url:"http://www.scribd.com/doc/1313/Steve-Jobs-Commencement-Speech-at-Stanford"},console.log);
//oembed.fetch({url:"http://www.slideshare.net/cooldaemon/kademlia-presentation"},console.log);
//oembed.fetch({url:"http://media.photobucket.com/image/autumn%20photography/Featured_Page/Fall%20Hub/redleafonrockinsteam250x250.jpg?o=1"},console.log);
//oembed.fetch({url:"http://megancharland.wordpress.com/2011/09/15/lovin-letterpress-week-1/"},console.log);
//oembed.fetch({html:'<link rel="alternate" type="application/json+oembed" href="http://public-api.wordpress.com/oembed/1.0/?format=json&url=http%3A%2F%2Fblog.singly.com%2F2011%2F10%2F08%2Fon-the-shoulders-of-giants%2F&for=wpcom-auto-discovery" />', url:"http://blog.singly.com/2011/10/08/on-the-shoulders-of-giants/"},console.log);
oembed.fetch({url:"http://yfrog.com/o0h6iflj"},console.log);