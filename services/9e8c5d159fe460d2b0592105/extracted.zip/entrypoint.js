require('./node_path_shim');
var lconfig = require('./Common/node/lconfig.js');
lconfig.load('Config/config.json');
var logger = require('logger');
var fs = require('fs');
var spawn = require('child_process').spawn;
var carrier = require('carrier');
var execSync = require('child_process').execSync;
var syncManager = require('lsyncmanager');
var serviceManager = require('lservicemanager');
var registry = require('./Ops/registry.js');
var webservice = require('./Ops/webservice.js');

logger.info('Starting locker service...');

// Ensure MongoDB data directory exists
var mongoDir = lconfig.me + '/' + lconfig.mongo.dataDir;
if (!fs.existsSync(mongoDir)) {
    fs.mkdirSync(mongoDir, 0755);
}

// Start mongod if not already running
var mongoProcess;
var mongodExisted = false;
try {
    var pidFile = '/proc/' + process.pid + '/fd';
    // Simple check - try to connect to see if mongod is already running
    var net = require('net');
    var sock = new net.Socket();
    sock.setTimeout(1000);
    sock.on('connect', function() {
        mongodExisted = true;
        sock.destroy();
        logger.info('MongoDB already running');
        startKeyGeneration();
    });
    sock.on('timeout', function() {
        sock.destroy();
        startMongo();
    });
    sock.on('error', function() {
        startMongo();
    });
    sock.connect(lconfig.mongo.port, 'localhost');
} catch (e) {
    startMongo();
}

function startMongo() {
    logger.info('Starting mongod...');
    var mongoOptions = ['--dbpath', lconfig.lockerDir + '/' + lconfig.me + '/' + lconfig.mongo.dataDir, '--port', lconfig.mongo.port];
    mongoProcess = spawn('mongod', mongoOptions);

    var mongoStdout = carrier.carry(mongoProcess.stdout);
    mongoStdout.on('line', function(line) {
        logger.info('[mongo] ' + line);
    });

    var mongoStderr = carrier.carry(mongoProcess.stderr);
    mongoStderr.on('line', function(line) {
        logger.error('[mongo] ' + line);
    });

    mongoProcess.on('exit', function(code, signal) {
        if (code !== 0 && code !== 48) { // 48 = already running
            logger.error('mongod exited with code ' + code);
        }
    });

    // Wait for MongoDB to be ready
    var checkMongo = setInterval(function() {
        var net = require('net');
        var sock = new net.Socket();
        sock.setTimeout(1000);
        sock.on('connect', function() {
            clearInterval(checkMongo);
            sock.destroy();
            logger.info('MongoDB is ready');
            startKeyGeneration();
        });
        sock.on('timeout', function() {
            sock.destroy();
        });
        sock.on('error', function() {});
        sock.connect(lconfig.mongo.port, 'localhost');
    }, 1000);
}

function startKeyGeneration() {
    // Generate symKey synchronously
    var symKeyFile = lconfig.me + '/symKey';
    if (!fs.existsSync(symKeyFile)) {
        logger.info('Generating symmetric key...');
        execSync('openssl rand -out ' + symKeyFile + ' 24');
        fs.chmodSync(symKeyFile, 0600);
    }
    logger.info('Symmetric key ready');

    // Generate PK keys synchronously
    var keyFile = lconfig.me + '/key';
    if (!fs.existsSync(keyFile)) {
        logger.info('Generating RSA key pair...');
        execSync('openssl genrsa -out key 1024', {cwd: lconfig.me});
        logger.info('Generating public key...');
        execSync('openssl rsa -pubout -in key -out key.pub', {cwd: lconfig.me});
        fs.chmodSync(lconfig.me + '/key', 0600);
    }
    logger.info('RSA keys ready');

    // Now initialize services
    startServices();
}

function startServices() {
    syncManager.init(serviceManager, function() {
        registry.init(serviceManager, syncManager, lconfig, {}, function() {
            serviceManager.init(syncManager, registry, function() {
                // Start web server
                webservice.startService(lconfig.lockerPort, lconfig.lockerListenIP, function(locker) {
                    registry.app(locker);
                    logger.info('Locker is up and running at ' + lconfig.lockerBase);
                });
            });
        });
    });
}

// Handle shutdown
process.on('SIGINT', function() {
    logger.info('Shutting down...');
    if (mongoProcess) mongoProcess.kill();
    process.exit(0);
});
process.on('SIGTERM', function() {
    logger.info('Shutting down...');
    if (mongoProcess) mongoProcess.kill();
    process.exit(0);
});