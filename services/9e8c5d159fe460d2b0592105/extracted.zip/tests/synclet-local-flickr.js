var fakeweb = require('node-fakeweb');
var photos = require('../Connectors/Flickr/photos');
var contacts = require('../Connectors/Flickr/contacts');
var assert = require("assert");
var RESTeasy = require('api-easy');
var vows = require("vows");
var suite = RESTeasy.describe("Flickr Synclet");
var fs = require('fs');
var path = require("path");
var curDir = process.cwd();

process.setMaxListeners(0);
process.on('uncaughtException',function(error){
    console.dir(error.stack);
});

var mePath = '/Data/flickr';

console.log(curDir);
var pinfo = JSON.parse(fs.readFileSync(__dirname + mePath + '/me.json'));
pinfo.config = {};
pinfo.absoluteSrcdir = path.resolve("Connectors/Flickr");
pinfo.workingDirectory =  mePath;

suite.next().suite.addBatch({
    "Can get contacts" : {
        topic: function() {
            fakeweb.allowNetConnect = false;
            fakeweb.registerUri({
                uri : 'http://api.flickr.com:80/services/rest/?api_sig=eb6c6301baa8ce6c94f0c55dd27f987b&api_key=sdf&auth_token=qwert&format=json&method=flickr.contacts.getList&nojsoncallback=1&page=1&per_page=1000',
                file : __dirname + '/fixtures/flickr/contacts_1.json' });
            contacts.sync(pinfo, this.callback) },
        "successfully" : function(err, response) {
            assert.isNull(err);
            assert.equal(response.data.contact.length, 3);
            assert.equal(response.data.contact[0].type, 'new');
            assert.equal(response.data.contact[0].obj.nsid, '12345679@N00');
            assert.equal(response.data.contact[0].obj.iconfarm, 2);
        },
        "and handles paging": function(err, response) {
            assert.isNull(err);
            assert.equal(response.config.paging["contact"].lastPage, 1);
            assert.equal(response.config.nextRun, -1);
        }
    }
}).addBatch({
        "Can get photos" : {
            topic: function() {
                fakeweb.allowNetConnect = false;
                fakeweb.registerUri({
                    uri : 'http://api.flickr.com:80/services/rest/?api_sig=d5f12fd8355652478c1b9ca3df6042e2&api_key=sdf&auth_token=qwert&extras=description,license,date_upload,date_taken,owner_name,icon_server,original_format,last_update,geo,tags,machine_tags,o_dimsviews,media,path_alias,url_sq,url_t,url_s,url_m,url_z,url_l,url_o&format=json&method=flickr.people.getPhotos&min_upload_date=0&nojsoncallback=1&page=1&per_page=500&user_id=12345678@N00',
                    file : __dirname + '/fixtures/flickr/photos_1.json' });
                fakeweb.registerUri({
                    uri : 'http://farm5.static.flickr.com/4072/4921264930_022f68c6d9_s.jpg',
                    file : __dirname + '/fixtures/flickr/img.png',
                    contentType: 'image/png' });
                fakeweb.registerUri({
                    uri : 'http://farm5.static.flickr.com/4127/4922121188_3fc1ee8735_s.jpg',
                    file : __dirname + '/fixtures/flickr/img.png',
                    contentType: 'image/png' });

                fakeweb.registerUri({
                    uri : 'http://farm5.static.flickr.com/4072/4921264930_022f68c6d9_b.jpg',
                    file : __dirname + '/fixtures/flickr/img.png',
                    contentType: 'image/png' });
                fakeweb.registerUri({
                    uri : 'http://farm5.static.flickr.com/4127/4922121188_3fc1ee8735_z.jpg',
                    file : __dirname + '/fixtures/flickr/img.png',
                    contentType: 'image/png' });
                photos.sync(pinfo, this.callback) },
            "successfully" : function(err, response) {
                assert.isNull(err);
                assert.equal(response.data.photo.length, 2);
                assert.equal(response.data.photo[0].obj.id, '4912129188');
                assert.equal(response.data.photo[0].obj.lastupdate, '1282612259');
            }
        }
}).addBatch({
  "Error responses": {
    topic:function() {
      pinfo.config = {paging:{contact:{lastPage:50}}};
      fakeweb.allowNetConnect = false;
      fakeweb.registerUri({
        uri : 'http://api.flickr.com:80/services/rest/?api_sig=38a0193a7ae1fd2b2d379fc2a12ffc12&api_key=sdf&auth_token=qwert&format=json&method=flickr.contacts.getList&nojsoncallback=1&page=51&per_page=1000',
        file:__dirname + "/fixtures/flickr/bad.json" });
      contacts.sync(pinfo, this.callback) },
    "are handled properly": function(err, topic) {
      assert.equal(err, "Missing signature")
      err = null;
    }
  }
});
suite.export(module);
