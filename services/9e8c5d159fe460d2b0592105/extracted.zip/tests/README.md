In order to run the front end tests, you need:

- ruby
- rubygems
- bundler
- chromedriver

To install dependencies:
```
cd integration && bundle install
```

This will install everything except chromedriver, which you need to get
yourself.
