Pandora doesn't have an API, but it looks like all the social data is public, you just need the webname to connect.

Auth popup would ask the person to log in, go to their profile page, and paste in the url in the browser, mine is:

	http://www.pandora.com/#!/profile/activity/jeremie48

My friends list is then at
	http://www.pandora.com/content/following?startIndex=0&webname=jeremie48
My newsfeed is at
	http://www.pandora.com/content/newsfeed?si=0&webname=jeremie48&followingCount=6&only_own=false
My likes are at
	http://www.pandora.com/content/likes?webname=jeremie48
My stations are at
	http://www.pandora.com/content/stations?startIndex=0&webname=jeremie48


