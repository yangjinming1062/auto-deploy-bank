
exports.fetch = function(url){}