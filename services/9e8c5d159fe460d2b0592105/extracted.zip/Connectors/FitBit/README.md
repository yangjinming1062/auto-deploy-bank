While not free FitBit looks to have an amazing wealth of health related information.  They have a [public API](http://dev.fitbit.com) currently in beta.
