# Twitter Setup Instructions #

1.  Put in application name "Locker Proj"
2. Application Name: "My Personal Data"
3. Description must be 10 characters. "I want to access my data, and
keep a copy for myself. "
4. Application Website: "http://lockerproject.org"
5. Paste in callback url at "Callback URL:"
6. Select "Read, Write, & Direct Messages" under "Default Access
type:"
7. Fill out Captcha
8. Click "I accept"

This will take you to a new page, where you need to copy two things.

First, the Consumer Key.
Secondly, the Consumer Secret

Paste those here.