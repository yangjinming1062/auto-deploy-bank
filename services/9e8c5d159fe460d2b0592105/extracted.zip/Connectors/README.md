Docs dir has a bit more background...

To add/hack on anything here:

* first, see if you can extend/fix an existing one before creating another from scratch
* don't be afraid to start another if it's just easier, try to make sure it's distinct enough from others though if so
* if new, try to name it appropriately and follow the naming style
