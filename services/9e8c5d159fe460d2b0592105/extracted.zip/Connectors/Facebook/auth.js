module.exports =  {
    endPoint : 'https://graph.facebook.com/oauth',
    grantType : '',
    handler : {oauth2 : 'GET'},
    authUrl : 'https://graph.facebook.com/oauth/authorize?response_type=code&scope=email,offline_access,read_stream,user_photos,friends_photos,user_photo_video_tags'
};