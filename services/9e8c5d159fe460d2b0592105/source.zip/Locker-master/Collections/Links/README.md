This is a stub for a collection of URLs.  These could come from parsing tweets, wall posts, emails or even more direct sources such as bookmarks.

Potential required connectors:
* Twitter
* Facebook
* Browser History
