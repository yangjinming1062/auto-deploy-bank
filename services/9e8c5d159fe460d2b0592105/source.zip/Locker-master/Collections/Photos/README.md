This is a stub for a collection that would contain images and photos

Possibly required connectors:
* Facebook
* Flickr
* Instagram
* Path
