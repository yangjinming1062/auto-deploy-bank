These are high level generalizations of the common data patterns, each one has it's own intelligence about how to merge its sources and provide a smart API into it's type of data.

New ones should only be created if they are common sense to many people and a general type of data and if it really doesn't fit within any others, don't be offended if any get split/merged and evolve over time :)

Check the Docs for a bit more background...