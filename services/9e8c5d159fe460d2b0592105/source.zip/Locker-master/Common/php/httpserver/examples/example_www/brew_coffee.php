<?php

header("HTTP/1.1 418 I'm a teapot");

echo "<a href='http://tools.ietf.org/html/rfc2324#page-5'>short and stout</a>";