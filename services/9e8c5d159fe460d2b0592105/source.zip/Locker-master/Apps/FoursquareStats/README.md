# This is an example locker app for displaying Foursquare check-ins. #

It uses your Foursquare history to map everywhere you have ever checked in.

