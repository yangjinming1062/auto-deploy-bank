# coding: UTF-8
require 'rubygems'
require 'bundler/setup'
require 'sinatra-locker'

get '/' do 
  "Hello, Ruby! ☺"
end
