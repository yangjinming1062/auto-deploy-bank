# This is a "static" example of a contacts locker app. #

It uses Boilerplate and jQuery for best practices, and is documented with YUI Doc comments.

Let us know if you do something cool based on this!
-> #lockerproject on irc.freenode.net
