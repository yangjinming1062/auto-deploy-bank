Basic Wakemate app based on HelloContacts app.

Requires the Wakemate connector.



Feel free to contact me with questions:
Sjors Provoost
sjors@sprovoost.nl
http://sprovoost.nl/
http://twitter.com/provoost
http://nl.linkedin.com/in/provoost