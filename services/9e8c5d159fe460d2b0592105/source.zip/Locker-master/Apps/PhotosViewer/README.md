Let us know if you do something cool based on this!
-> #lockerproject on irc.freenode.net
