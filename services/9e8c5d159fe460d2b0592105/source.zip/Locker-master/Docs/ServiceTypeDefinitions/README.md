These are descriptions of services based on type.  Generally this is a set of REST URIs made available by a type.
