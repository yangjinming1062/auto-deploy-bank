exports.authAndRun = function(app, externalUrl, onCompletedCallback) {
        onCompletedCallback();
        return;
}

exports.isAuthed = function() { return true; };