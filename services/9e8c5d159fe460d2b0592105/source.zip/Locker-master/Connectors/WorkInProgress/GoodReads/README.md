Goodreads is the largest social network for readers in the world.  They have an API (http://www.goodreads.com/api).
