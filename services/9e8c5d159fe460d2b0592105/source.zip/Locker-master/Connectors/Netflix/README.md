If you request a Netflix API key from Mashery it may not work immediately. If you get 401 "invalid signature" errors try waiting an hour or two for it to be activated.

TODO:
=====

- A ratings synclet
- Verify that the Netflix API doesn't work with Authorization headers
