export const _LC_CONTEXT_VARIABLES_KEY = Symbol.for("lc:context_variables");

export const _LC_CHILD_RUN_END_PROMISES_KEY = Symbol.for(
  "lc:child_run_end_promises"
);

export const _REPLICA_TRACE_ROOTS_KEY = Symbol.for(
  "langsmith:replica_trace_roots"
);
