---
name: Bug report
about: Create a report to help us improve
title: ''
labels: ''
assignees: ''

---

### Description

### Steps to Reproduce

### Robolectric & Android Version

### Link to a public git repo demonstrating the problem:
