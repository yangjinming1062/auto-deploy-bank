package org.robolectric.integrationtests.axt;

import android.app.Activity;

/**
 * A Activity that receives browser intents. Used for
 * IntentsTest#testIntendedSuccess_truthChainedCorrespondence
 */
public class StubBrowserActivity extends Activity {}
