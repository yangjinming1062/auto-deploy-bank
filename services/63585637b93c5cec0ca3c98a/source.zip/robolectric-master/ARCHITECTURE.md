This documentation has moved to [robolectric.org](https://robolectric.org/architecture).
