ES5
===

If your browser does not support ECMAScript 6, you will need to run babel to compile an ES5-compatible version of the ES6 mpw-js code.

1. Install npm.  On OS X, you can use `brew install npm`.
2. Install babel.  With npm installed, you can use `npm -g install babel-cli babel-preset-es2015`
3. Build the ES5-translation of the ES6 code.  From this directory, just run `make`.
