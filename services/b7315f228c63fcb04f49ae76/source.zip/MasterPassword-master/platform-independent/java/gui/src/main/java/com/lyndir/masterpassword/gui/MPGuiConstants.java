package com.lyndir.masterpassword.gui;

import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import javax.swing.*;


/**
 * @author lhunath, 2018-07-31
 */
public final class MPGuiConstants {

    public static final KeyStroke ui_hotkey = KeyStroke.getKeyStroke( KeyEvent.VK_P, InputEvent.CTRL_DOWN_MASK | InputEvent.META_DOWN_MASK );
}
