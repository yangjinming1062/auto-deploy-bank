//
//  Tests.h
//  Tests
//
//  Created by Maarten Billemont on 04/07/12.
//  Copyright (c) 2012 Lyndir. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface Tests : SenTestCase

@end
