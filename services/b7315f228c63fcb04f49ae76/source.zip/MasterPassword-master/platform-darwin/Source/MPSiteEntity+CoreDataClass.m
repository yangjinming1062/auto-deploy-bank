//
//  MPSiteEntity+CoreDataClass.m
//  MasterPassword-iOS
//
//  Created by Maarten Billemont on 2017-04-30.
//  Copyright © 2017 Lyndir. All rights reserved.
//

#import "MPSiteEntity+CoreDataClass.h"
#import "MPSiteQuestionEntity+CoreDataClass.h"

#import "MPUserEntity+CoreDataClass.h"

@implementation MPSiteEntity

@end
