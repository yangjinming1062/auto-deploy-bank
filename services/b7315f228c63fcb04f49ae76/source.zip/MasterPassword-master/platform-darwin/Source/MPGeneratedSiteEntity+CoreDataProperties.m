//
//  MPGeneratedSiteEntity+CoreDataProperties.m
//  MasterPassword-iOS
//
//  Created by Maarten Billemont on 2017-04-30.
//  Copyright © 2017 Lyndir. All rights reserved.
//

#import "MPGeneratedSiteEntity+CoreDataProperties.h"

@implementation MPGeneratedSiteEntity (CoreDataProperties)

+ (NSFetchRequest<MPGeneratedSiteEntity *> *)fetchRequest {
	return [[NSFetchRequest alloc] initWithEntityName:@"MPGeneratedSiteEntity"];
}

@dynamic counter_;

@end
