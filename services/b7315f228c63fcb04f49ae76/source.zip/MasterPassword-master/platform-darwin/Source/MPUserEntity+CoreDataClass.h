//
//  MPUserEntity+CoreDataClass.h
//  MasterPassword-iOS
//
//  Created by Maarten Billemont on 2017-04-30.
//  Copyright © 2017 Lyndir. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@class MPSiteEntity;

NS_ASSUME_NONNULL_BEGIN

@interface MPUserEntity : NSManagedObject

@end

NS_ASSUME_NONNULL_END

#import "MPUserEntity+CoreDataProperties.h"
