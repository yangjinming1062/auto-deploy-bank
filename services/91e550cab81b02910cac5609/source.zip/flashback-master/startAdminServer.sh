#!/bin/sh

./gradlew startAdminServer "-PArgs=$*"
