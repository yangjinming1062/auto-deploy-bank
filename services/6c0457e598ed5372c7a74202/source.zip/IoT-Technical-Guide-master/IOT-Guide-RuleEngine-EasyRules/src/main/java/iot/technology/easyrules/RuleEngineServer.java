package iot.technology.easyrules;

/**
 * @author james mu
 * @date 2020/5/20 16:41
 */
public class RuleEngineServer {

    public static void main(String[] args) {
        System.out.println("waiting update......!");
    }
}
