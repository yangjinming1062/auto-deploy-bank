package iot.technology.thingsboard.ruleengine;

/**
 * @author james mu
 * @date 2020/8/30 23:47
 */
public class RuleEngineThingsBoardServer {

    public static void main(String[] args) {
        System.out.println("waiting update......!");
    }
}
