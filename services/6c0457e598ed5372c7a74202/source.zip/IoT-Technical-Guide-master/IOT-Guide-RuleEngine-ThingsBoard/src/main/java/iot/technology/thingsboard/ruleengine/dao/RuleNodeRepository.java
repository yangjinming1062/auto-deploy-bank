package iot.technology.thingsboard.ruleengine.dao;

/**
 * @author mushuwei
 */
public interface RuleNodeRepository {
}
