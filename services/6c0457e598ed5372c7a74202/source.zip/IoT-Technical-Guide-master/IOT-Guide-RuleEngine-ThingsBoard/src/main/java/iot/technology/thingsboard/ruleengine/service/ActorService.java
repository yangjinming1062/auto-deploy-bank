package iot.technology.thingsboard.ruleengine.service;

/**
 * @author mushuwei
 */
public interface ActorService {
}
