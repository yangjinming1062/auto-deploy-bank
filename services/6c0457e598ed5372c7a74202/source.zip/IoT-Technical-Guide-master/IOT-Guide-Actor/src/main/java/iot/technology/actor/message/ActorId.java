package iot.technology.actor.message;

/**
 * @author mushuwei
 */
public interface ActorId {
}
