package iot.technology.actor.core;

/**
 * @author mushuwei
 */
public enum ActorStopReason {

    INIT_FAILED, STOPPED
    
}
