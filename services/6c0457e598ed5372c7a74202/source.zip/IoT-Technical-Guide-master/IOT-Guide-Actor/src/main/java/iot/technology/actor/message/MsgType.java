package iot.technology.actor.message;

/**
 * @author mushuwei
 */
public enum MsgType {
    /**
     * Special message to indicate  update request
     */
    UPDATED_MSG,

    QUEUE_TO_RULE_ENGINE_MSG,
}
