package iot.technology.dao.device;

public class DeviceServiceImpl {
}
