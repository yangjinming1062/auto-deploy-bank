package iot.technology.dao.customer;

public interface CustomerService {
}
