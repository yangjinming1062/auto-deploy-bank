package iot.technology.dao.tenant;

public class TenantServiceImpl {
}
