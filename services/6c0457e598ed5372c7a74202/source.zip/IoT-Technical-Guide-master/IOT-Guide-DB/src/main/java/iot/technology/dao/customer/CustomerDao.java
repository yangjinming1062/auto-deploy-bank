package iot.technology.dao.customer;

public interface CustomerDao {
}
