package iot.technology.dao.customer;

public class CustomerServiceImpl {
}
