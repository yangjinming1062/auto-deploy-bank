package iot.technology.dao.tenant;

public interface TenantDao {
}
