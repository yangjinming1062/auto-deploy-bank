package iot.technology.dao.device;

public interface DeviceDao {
}
