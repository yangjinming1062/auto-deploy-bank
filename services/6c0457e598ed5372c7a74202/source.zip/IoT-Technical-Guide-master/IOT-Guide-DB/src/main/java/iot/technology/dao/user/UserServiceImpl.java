package iot.technology.dao.user;

/**
 * @Author: 穆书伟
 * @Date: 19-4-11 下午3:19
 * @Version 1.0
 */
public class UserServiceImpl implements UserService{
}
