package iot.technology.kubernetes;

/**
 * @author james mu
 * @date 2020/5/20 17:39
 */
public class KubernetesServer {

    public static void main(String[] args) {
        System.out.println("waiting update......!");
    }
}
