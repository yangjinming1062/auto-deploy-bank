package iot.technology.tsl.session;

/**
 * @Author: 穆书伟
 * @Date: 19-4-2
 * @Version 1.0
 */
public interface FromDeviceRequestMsg  extends FromDeviceMsg{

    Integer getRequestId();

}
