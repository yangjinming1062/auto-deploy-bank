package iot.technology.tsl.data.model;

import lombok.Data;

/**
 * @Author: 穆书伟
 * @Date: 19-4-16
 * @Version 1.0
 */
@Data
public class ResponseModel {
    private String key;
    private String value;
}
