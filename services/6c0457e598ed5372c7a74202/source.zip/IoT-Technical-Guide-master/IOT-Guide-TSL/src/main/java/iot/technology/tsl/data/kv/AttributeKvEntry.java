package iot.technology.tsl.data.kv;

/**
 * @Author: 穆书伟
 * @Date: 19-4-2
 * @Version 1.0
 */
public interface AttributeKvEntry extends KvEntry {

    long getLastUpdateTs();

}
