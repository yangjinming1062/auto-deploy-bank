package iot.technology.mongodb;

/**
 * @author james mu
 * @date 2020/7/17 22:36
 */
public class MongoDBServer {
    public static void main(String[] args) {
        System.out.println("waiting update......!");
    }
}
