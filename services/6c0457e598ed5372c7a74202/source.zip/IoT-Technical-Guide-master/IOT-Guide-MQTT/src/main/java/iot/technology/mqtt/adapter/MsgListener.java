package iot.technology.mqtt.adapter;

/**
 * @author jamesmsw
 * @date 2021/2/19 3:09 下午
 */
public class MsgListener {
}
