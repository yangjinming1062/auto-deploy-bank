package iot.technology.mqtt.storage.msg;

/**
 * @author james mu
 * @date 2020/8/31 12:08
 */
public interface QueueMsgMetadata {
}
