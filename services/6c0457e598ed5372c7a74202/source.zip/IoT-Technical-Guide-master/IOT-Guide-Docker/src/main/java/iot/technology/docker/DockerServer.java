package iot.technology.docker;

/**
 * @author james mu
 * @date 2020/5/20 16:47
 */
public class DockerServer {

    public static void main(String[] args) {
        System.out.println("waiting update......!");
    }
}
