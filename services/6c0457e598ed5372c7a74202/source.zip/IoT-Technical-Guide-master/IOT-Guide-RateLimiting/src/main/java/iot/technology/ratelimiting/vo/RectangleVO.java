package iot.technology.ratelimiting.vo;

import lombok.Getter;

/**
 * @author mushuwei
 */
@Getter
public class RectangleVO {

    private double length;
    private double width;
}
