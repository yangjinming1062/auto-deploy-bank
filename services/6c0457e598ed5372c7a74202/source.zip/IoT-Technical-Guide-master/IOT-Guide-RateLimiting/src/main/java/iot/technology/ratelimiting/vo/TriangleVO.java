package iot.technology.ratelimiting.vo;

import lombok.Getter;

/**
 * @author mushuwei
 */
@Getter
public class TriangleVO {

    private double bottom;
    private double height;
}
