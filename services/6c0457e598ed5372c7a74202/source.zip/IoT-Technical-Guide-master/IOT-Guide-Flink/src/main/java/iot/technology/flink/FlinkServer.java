package iot.technology.flink;

/**
 * @author james mu
 * @date 2020/5/20 16:49
 */
public class FlinkServer {

    public static void main(String[] args) {
        System.out.println("waiting update......!");
    }
}
