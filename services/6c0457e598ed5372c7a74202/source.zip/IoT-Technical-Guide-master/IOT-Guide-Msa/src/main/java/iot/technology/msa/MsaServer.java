package iot.technology.msa;

/**
 * @author james mu
 * @date 2020/5/20 17:11
 */
public class MsaServer {

    public static void main(String[] args) {
        System.out.println("waiting update......!");
    }
}
