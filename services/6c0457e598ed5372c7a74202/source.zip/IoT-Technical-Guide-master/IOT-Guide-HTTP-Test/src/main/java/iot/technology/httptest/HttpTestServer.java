package iot.technology.httptest;

/**
 * @author james mu
 * @date 2020/5/20 17:40
 */
public class HttpTestServer {

    public static void main(String[] args) {
        System.out.println("waiting update......!");
    }
}
