package tech.powerjob.remote.framework.base;

/**
 * 服务器类型类型
 *
 * @author tjq
 * @since 2022/12/31
 */
public enum ServerType {
    SERVER,
    WORKER
}
