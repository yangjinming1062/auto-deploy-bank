package tech.powerjob.common.exception;

/**
 * ImpossibleException
 *
 * @author tjq
 * @since 2023/7/12
 */
public class ImpossibleException extends RuntimeException {
}
