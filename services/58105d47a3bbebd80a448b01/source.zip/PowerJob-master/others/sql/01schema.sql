-- powerjob
create database `powerjob-daily` default character set utf8mb4 collate utf8mb4_general_ci;
