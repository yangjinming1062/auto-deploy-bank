package tech.powerjob.client.extension;

/**
 * 扩展上下文
 *
 * @author tjq
 * @since 2024/8/11
 */
public class ExtensionContext {
}
