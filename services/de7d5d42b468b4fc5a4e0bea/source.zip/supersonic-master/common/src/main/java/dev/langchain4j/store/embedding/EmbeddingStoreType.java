package dev.langchain4j.store.embedding;

public enum EmbeddingStoreType {
    IN_MEMORY, MILVUS, CHROMA, PGVECTOR, OPENSEARCH
}
