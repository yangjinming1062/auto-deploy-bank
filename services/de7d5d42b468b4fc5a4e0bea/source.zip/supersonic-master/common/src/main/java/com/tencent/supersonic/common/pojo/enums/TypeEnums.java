package com.tencent.supersonic.common.pojo.enums;

public enum TypeEnums {
    METRIC, DIMENSION, VALUE, TAG, DOMAIN, DATASET, MODEL, UNKNOWN
}
