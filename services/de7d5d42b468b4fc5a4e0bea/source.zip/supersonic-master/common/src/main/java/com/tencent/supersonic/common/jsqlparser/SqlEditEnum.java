package com.tencent.supersonic.common.jsqlparser;

public enum SqlEditEnum {
    NUMBER_FILTER, DATEDIFF
}
