package com.tencent.supersonic.common.pojo;

public class DimensionConstants {

    public static final String DIMENSION_TIME_FORMAT = "time_format";

    public static final String DIMENSION_TYPE = "dimension_type";

    public static final String DIMENSION_DATA_TYPE = "dimension_data_type";
}
