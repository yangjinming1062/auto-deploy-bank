package com.tencent.supersonic.common.pojo.enums;

public enum EventType {
    ADD, UPDATE, DELETE
}
