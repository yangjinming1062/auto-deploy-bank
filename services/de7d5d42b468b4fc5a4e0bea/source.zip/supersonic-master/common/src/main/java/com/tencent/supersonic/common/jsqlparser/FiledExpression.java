package com.tencent.supersonic.common.jsqlparser;

import lombok.Data;

@Data
public class FiledExpression {

    private String operator;

    private String fieldName;
}
