package com.tencent.supersonic.common.pojo.enums;

public enum TimeDimensionEnum {
    DAY, WEEK, MONTH;
}
