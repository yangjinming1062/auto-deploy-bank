package com.tencent.supersonic.common.pojo.enums;

public enum ApiItemType {
    METRIC, TAG, DIMENSION
}
