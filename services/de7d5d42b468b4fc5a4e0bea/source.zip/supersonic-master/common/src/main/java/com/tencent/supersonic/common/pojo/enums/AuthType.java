package com.tencent.supersonic.common.pojo.enums;

public enum AuthType {
    VIEWER, ADMIN
}
