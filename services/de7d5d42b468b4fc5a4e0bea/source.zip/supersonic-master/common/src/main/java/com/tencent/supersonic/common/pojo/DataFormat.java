package com.tencent.supersonic.common.pojo;

import lombok.Data;

@Data
public class DataFormat {

    private boolean needMultiply100;

    private Integer decimalPlaces;
}
