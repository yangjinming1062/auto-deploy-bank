package com.tencent.supersonic.chat.server.agent;

import lombok.Data;

@Data
public class VisualConfig {

    private boolean enableSimpleMode;

    private boolean showDebugInfo;
}
