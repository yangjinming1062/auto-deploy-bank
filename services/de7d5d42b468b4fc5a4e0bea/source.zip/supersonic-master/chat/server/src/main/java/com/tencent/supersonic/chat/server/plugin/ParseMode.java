package com.tencent.supersonic.chat.server.plugin;

public enum ParseMode {
    EMBEDDING_RECALL, FUNCTION_CALL;
}
