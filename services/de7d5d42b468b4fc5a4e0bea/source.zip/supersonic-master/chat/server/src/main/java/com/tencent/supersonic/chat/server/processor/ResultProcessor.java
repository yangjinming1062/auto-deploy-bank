package com.tencent.supersonic.chat.server.processor;

/** A ResultProcessor wraps things up before returning results to users. */
public interface ResultProcessor {
}
