package com.tencent.supersonic.chat.server.config;

import lombok.Data;

@Data
public class ChatConfigFilterInternal {

    private Long id;
    private Long modelId;
    private Integer status;
}
