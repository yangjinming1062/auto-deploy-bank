package com.tencent.supersonic.chat.api.pojo.request;

import lombok.Data;

@Data
public class ChatConfigEditReqReq extends ChatConfigBaseReq {

    private Long id;
}
