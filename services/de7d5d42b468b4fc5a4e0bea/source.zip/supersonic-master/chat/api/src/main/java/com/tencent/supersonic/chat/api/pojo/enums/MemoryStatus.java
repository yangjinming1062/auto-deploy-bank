package com.tencent.supersonic.chat.api.pojo.enums;

public enum MemoryStatus {
    PENDING, ENABLED, DISABLED;
}
