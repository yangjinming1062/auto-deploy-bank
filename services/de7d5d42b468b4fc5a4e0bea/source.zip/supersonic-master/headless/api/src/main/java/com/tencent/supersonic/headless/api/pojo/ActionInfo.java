package com.tencent.supersonic.headless.api.pojo;

import lombok.Data;

import java.util.List;

@Data
public class ActionInfo {

    private List<Object> out;
}
