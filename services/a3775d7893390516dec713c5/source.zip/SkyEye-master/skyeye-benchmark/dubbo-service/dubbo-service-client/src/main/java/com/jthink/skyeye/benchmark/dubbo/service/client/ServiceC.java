package com.jthink.skyeye.benchmark.dubbo.service.client;

/**
 * JThink@JThink
 *
 * @author JThink
 * @version 0.0.1
 * @desc service c 接口定义
 * @date 2016-12-14 16:34:24
 */
public interface ServiceC {

    public String invokeC();
}
