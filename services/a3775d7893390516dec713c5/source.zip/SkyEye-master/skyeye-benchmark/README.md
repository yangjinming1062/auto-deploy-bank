# 项目介绍
监控中心项目的测试项目
## log-generater
日志生成器
## dubbo-service-trace
dubbox服务链条项目，提供服务链条调用
