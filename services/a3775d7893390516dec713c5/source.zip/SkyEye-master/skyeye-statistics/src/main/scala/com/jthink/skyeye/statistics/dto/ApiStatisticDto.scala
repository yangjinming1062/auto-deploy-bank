package com.jthink.skyeye.statistics.dto

/**
  * JThink@JThink
  *
  * @author JThink
  * @version 0.0.1
  */
class ApiStatisticDto {

  // row key
  var row: String = _
  // api
  var api: String = _
  // api请求的状态
  var status: String = _
  // api请求的次数
  var cnt: Int = _
}
