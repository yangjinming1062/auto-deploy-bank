package com.jthink.skyeye.statistics.model.value

/**
  * JThink@JThink
  *
  * @author JThink
  * @version 0.0.1
  */
trait Value extends Serializable {

}
