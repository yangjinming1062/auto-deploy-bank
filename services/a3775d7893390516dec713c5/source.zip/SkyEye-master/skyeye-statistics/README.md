# 项目介绍
spark steaming流计算相关的实时统计数据
