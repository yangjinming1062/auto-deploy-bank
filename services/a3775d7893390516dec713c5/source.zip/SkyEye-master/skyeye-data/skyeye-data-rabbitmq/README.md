# 项目介绍
监控组rabbitmq操作封装