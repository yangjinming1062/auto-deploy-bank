package com.jthink.skyeye.data.http.test;

/**
 * JThink@JThink
 *
 * @author JThink
 * @version 0.0.1
 * @desc http请求
 * @date 2016-11-17 10:49:52
 */
public class HttpRequestTest {

    public static void main(String[] args) {

    }
}

