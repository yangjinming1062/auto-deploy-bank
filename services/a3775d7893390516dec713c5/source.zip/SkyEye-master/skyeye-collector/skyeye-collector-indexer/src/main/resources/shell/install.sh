#!/bin/bash

echo "--> install python-pip module"
sudo apt-get install python-pip
echo "--> install elasticsearch module"
sudo pip install pyelasticsearch