package com.jthink.skyeye.trace.core.sampler;

/**
 * JThink@JThink
 *
 * @author JThink
 * @version 0.0.1
 * @desc 基于hash进行采样设计
 * @date 2017-02-15 11:07:38
 */
public class HashSampler implements Sampler {

    @Override
    public boolean isCollect() {
        // TODO: 具体实现
        return false;
    }
}
