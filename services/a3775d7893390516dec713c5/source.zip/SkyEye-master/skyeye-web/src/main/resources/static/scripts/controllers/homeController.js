/**
 * the home controller
 * 
 * @author JThink
 */
define(['controllers/controllers', 'common/util', 'common/constant', 'services/dataService'], function(controllers, util, constant) {
  'use strict';  
  controllers.controller('HomeController', ['$scope', 'DataService', function($scope, DataService) {

    var initData = function() {

    };

    var initEvent = function() {

    };

    initData();

    initEvent();
  }]);
});