class DrawingTool extends Tool {
    constructor (name, options) {
        super(name, options);
    }
}