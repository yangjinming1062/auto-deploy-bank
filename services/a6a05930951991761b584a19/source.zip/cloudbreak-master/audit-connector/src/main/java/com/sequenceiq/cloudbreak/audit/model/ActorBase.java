package com.sequenceiq.cloudbreak.audit.model;

public abstract class ActorBase {
}
