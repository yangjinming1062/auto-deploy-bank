package com.sequenceiq.periscope.domain;

public interface Clustered {
    Cluster getCluster();
}
