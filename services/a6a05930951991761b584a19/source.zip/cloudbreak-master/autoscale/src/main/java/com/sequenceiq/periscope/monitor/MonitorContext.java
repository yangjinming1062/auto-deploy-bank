package com.sequenceiq.periscope.monitor;

public enum MonitorContext {
    APPLICATION_CONTEXT,
}
