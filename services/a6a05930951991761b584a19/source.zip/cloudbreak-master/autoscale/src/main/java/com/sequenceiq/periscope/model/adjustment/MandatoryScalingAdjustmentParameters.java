package com.sequenceiq.periscope.model.adjustment;

public interface MandatoryScalingAdjustmentParameters {

    Integer getUpscaleAdjustment();

    Integer getDownscaleAdjustment();
}
