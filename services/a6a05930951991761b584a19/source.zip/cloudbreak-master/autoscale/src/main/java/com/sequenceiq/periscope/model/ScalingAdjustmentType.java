package com.sequenceiq.periscope.model;

public enum ScalingAdjustmentType {
    REGULAR,
    STOPSTART
}
