package com.sequenceiq.periscope.api.model;

public enum ScalingStatus {
    FAILED, SUCCESS, ENABLED, DISABLED, CONFIG_UPDATED, TRIGGER_FAILED, TRIGGER_INFO
}
