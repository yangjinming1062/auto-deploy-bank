package com.sequenceiq.periscope.api.model;

public enum AdjustmentType {
    NODE_COUNT,
    PERCENTAGE,
    EXACT,
    LOAD_BASED
}
