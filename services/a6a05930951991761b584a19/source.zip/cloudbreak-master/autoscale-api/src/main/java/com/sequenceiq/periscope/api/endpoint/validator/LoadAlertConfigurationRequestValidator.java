package com.sequenceiq.periscope.api.endpoint.validator;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

import com.sequenceiq.common.api.util.ValidatorUtil;
import com.sequenceiq.periscope.api.model.LoadAlertConfigurationRequest;

public class LoadAlertConfigurationRequestValidator implements ConstraintValidator<ValidLoadAlertConfiguration, LoadAlertConfigurationRequest> {

    @Override
    public void initialize(ValidLoadAlertConfiguration constraintAnnotation) {
    }

    @Override
    public boolean isValid(LoadAlertConfigurationRequest request, ConstraintValidatorContext context) {
        boolean validRequest = true;
        if (request.getMinResourceValue() >= request.getMaxResourceValue()) {
            validRequest = false;
            String message = "The specified loadAlertConfiguration is not valid because the minResourceValue " +
                    " must be less than maxResourceValue.";
            ValidatorUtil.addConstraintViolation(context, message, "minResourceValue")
                    .disableDefaultConstraintViolation();
        }
        return validRequest;
    }

}
