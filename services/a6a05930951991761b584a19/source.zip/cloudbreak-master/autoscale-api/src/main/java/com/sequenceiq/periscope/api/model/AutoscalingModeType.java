package com.sequenceiq.periscope.api.model;

public enum AutoscalingModeType {
    TIME_BASED,
    LOAD_BASED
}
