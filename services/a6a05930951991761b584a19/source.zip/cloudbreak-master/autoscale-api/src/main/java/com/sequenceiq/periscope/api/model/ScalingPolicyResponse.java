package com.sequenceiq.periscope.api.model;

import io.swagger.v3.oas.annotations.media.Schema;

@Schema
public class ScalingPolicyResponse extends ScalingPolicyBase {
}
