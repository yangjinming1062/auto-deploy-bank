package com.sequenceiq.periscope.api.model;

/**
 * Classes marked as Json can be converted to other classes.
 */
public interface Json {
}
