package com.sequenceiq.periscope.api.model;

public enum ClusterState {
    RUNNING, SUSPENDED, PENDING, DELETED
}
