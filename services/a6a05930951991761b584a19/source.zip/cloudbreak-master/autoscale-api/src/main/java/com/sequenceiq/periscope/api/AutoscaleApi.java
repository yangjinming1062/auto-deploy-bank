package com.sequenceiq.periscope.api;

public class AutoscaleApi {

    public static final String API_ROOT_CONTEXT = "/api";

    private AutoscaleApi() {
    }
}

