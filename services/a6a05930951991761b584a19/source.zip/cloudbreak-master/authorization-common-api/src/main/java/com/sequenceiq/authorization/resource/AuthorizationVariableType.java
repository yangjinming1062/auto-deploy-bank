package com.sequenceiq.authorization.resource;

public enum AuthorizationVariableType {
    NAME,
    CRN,
    NAME_LIST,
    CRN_LIST;
}
