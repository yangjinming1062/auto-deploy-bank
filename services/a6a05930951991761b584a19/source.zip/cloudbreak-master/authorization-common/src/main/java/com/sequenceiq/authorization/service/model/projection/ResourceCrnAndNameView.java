package com.sequenceiq.authorization.service.model.projection;

public interface ResourceCrnAndNameView {

    String getName();

    String getCrn();
}
