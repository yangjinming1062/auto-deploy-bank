package com.sequenceiq.cloudbreak.auth.security.internal;

import com.sequenceiq.cloudbreak.auth.CrnUser;

public class InternalUserModifier {

    public void persistModifiedInternalUser(CrnUser newUser) {

    }
}
