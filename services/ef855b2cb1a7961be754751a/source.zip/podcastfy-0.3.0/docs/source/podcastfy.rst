podcastfy package
=================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   podcastfy.content_parser

Submodules
----------

podcastfy.client module
-----------------------

.. automodule:: podcastfy.client
   :members:
   :undoc-members:
   :show-inheritance:

podcastfy.content\_generator module
-----------------------------------

.. automodule:: podcastfy.content_generator
   :members:
   :undoc-members:
   :show-inheritance:

podcastfy.text\_to\_speech module
---------------------------------

.. automodule:: podcastfy.text_to_speech
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: podcastfy
   :members:
   :undoc-members:
   :show-inheritance:
