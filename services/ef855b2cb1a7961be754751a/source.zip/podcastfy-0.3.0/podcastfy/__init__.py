# This file can be left empty for now
__version__ = "0.3.0"  # or whatever version you're on
