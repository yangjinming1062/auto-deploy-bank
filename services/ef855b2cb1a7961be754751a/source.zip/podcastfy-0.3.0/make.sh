#!/bin/bash

export PYTHONPATH="~src/podcastfy:$PYTHONPATH"