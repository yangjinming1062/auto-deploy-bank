import { version } from "react";

export const config = {
    approot: '',
    aiServicePort: '',
    danmuWSport: '',
    version: ''
}