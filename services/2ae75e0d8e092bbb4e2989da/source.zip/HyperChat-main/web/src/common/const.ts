export const isOnBrowser = typeof window != "undefined" ? !window.ext : false;
