#!/usr/bin/env node
require("./js/main_no_electron");
