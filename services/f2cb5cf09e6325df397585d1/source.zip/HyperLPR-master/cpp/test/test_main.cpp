//
// Created by tunm on 2023/2/11.
//
#define CATCH_CONFIG_RUNNER
#include "test_settings.h"

int main(int argc, char* argv[]) {

    return Catch::Session().run(argc, argv);;
}