//
// Created by tunm on 2023/1/25.
//

#ifndef ZEPHYRLPR_NN_IMPLEMENTATION_ALL_H
#define ZEPHYRLPR_NN_IMPLEMENTATION_ALL_H

#include "recognition/all.h"
#include "detect/all.h"
#include "classification/all.h"

#endif //ZEPHYRLPR_NN_IMPLEMENTATION_ALL_H
