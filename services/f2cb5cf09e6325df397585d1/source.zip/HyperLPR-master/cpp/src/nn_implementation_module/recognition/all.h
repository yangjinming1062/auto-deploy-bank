//
// Created by Tunm-Air13 on 2022/12/30.
//

#ifndef ZEPHYRLPR_RECOGNITION_ALL_H
#define ZEPHYRLPR_RECOGNITION_ALL_H

#include "plate_recognition.h"
#include "recognition_commom.h"
#include "recognition_engine.h"

#endif //ZEPHYRLPR_RECOGNITION_ALL_H
