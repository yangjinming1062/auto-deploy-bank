//
// Created by tunm on 2022/12/29.
//
#pragma once
#ifndef ZEPHYRLPR_DETECT_ALL_H
#define ZEPHYRLPR_DETECT_ALL_H

#include "plate_det_common.h"
#include "plate_detector.h"
#include "det_backbone.h"
#include "det_header.h"
#include "det_arch.h"



#endif //ZEPHYRLPR_DETECT_ALL_H
