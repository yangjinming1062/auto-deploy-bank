//
// Created by tunm on 2023/1/22.
//

#ifndef ZEPHYRLPR_PLATE_CLS_COMMON_H
#define ZEPHYRLPR_PLATE_CLS_COMMON_H

typedef enum {
    BLUE,       ///< 蓝牌
    GREEN,      ///< 绿牌
    YELLOW,     ///< 黄牌
} PlateColor;

#endif //ZEPHYRLPR_PLATE_CLS_COMMON_H
