//
// Created by tunm on 2023/1/22.
//
#pragma once
#ifndef ZEPHYRLPR_CLASSIFICATION_ALL_H
#define ZEPHYRLPR_CLASSIFICATION_ALL_H

#include "plate_classification.h"
#include "plate_cls_common.h"
#include "classification_engine.h"

#endif //ZEPHYRLPR_CLASSIFICATION_ALL_H
