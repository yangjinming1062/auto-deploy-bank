
#pragma once

#define HYPERLPR_VER_MAJOR 3
#define HYPERLPR_VER_MINOR 0
#define HYPERLPR_VER_PATCH 1
