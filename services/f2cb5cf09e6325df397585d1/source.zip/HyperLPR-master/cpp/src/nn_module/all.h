//
// Created by tunm on 2023/1/25.
//

#ifndef ZEPHYRLPR_MNN_ADAPTER_ALL_H
#define ZEPHYRLPR_MNN_ADAPTER_ALL_H

#include "mnn_adapter.h"

#endif //ZEPHYRLPR_MNN_ADAPTER_ALL_H
