from .hyperlpr3 import LicensePlateCatcher
from .common.typedef import *

__version__ = "0.1.3"

