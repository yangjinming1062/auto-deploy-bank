cp -r 3rdparty_hyper_inspire_op/MNN-2.2.0/ios/MNN.framework Prj-iOS/hyperlpr3
cp -r 3rdparty_hyper_inspire_op/opencv-4.5.1/ios/opencv2.framework Prj-iOS/hyperlpr3
