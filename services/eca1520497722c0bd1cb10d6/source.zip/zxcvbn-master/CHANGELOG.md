# Changelog

You can find the changelog in the packages for example for the [main](https://github.com/zxcvbn-ts/zxcvbn/blob/master/packages/libraries/main/CHANGELOG.md) package.
