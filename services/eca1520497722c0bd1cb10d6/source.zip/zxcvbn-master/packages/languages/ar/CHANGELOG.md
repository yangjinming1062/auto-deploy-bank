# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

# 3.1.0 (2023-09-17)

### Features

- **languages:** Add Arabic Language Package ([#229](https://github.com/zxcvbn-ts/zxcvbn/issues/229)) ([04c4a1f](https://github.com/zxcvbn-ts/zxcvbn/commit/04c4a1f24a1b72ed3ad6687caab72d4751306219))
