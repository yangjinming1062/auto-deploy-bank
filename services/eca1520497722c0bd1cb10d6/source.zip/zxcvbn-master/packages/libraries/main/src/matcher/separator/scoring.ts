import { SEPERATOR_CHAR_COUNT } from '../../data/const'

export default () => {
  return SEPERATOR_CHAR_COUNT
}
