// TODO make some more appropriated guesses logic?
export default () => {
  return 1
}
