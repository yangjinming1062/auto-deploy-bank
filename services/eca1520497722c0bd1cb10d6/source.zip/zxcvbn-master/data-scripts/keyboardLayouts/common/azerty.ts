export default {
  slanted: true,
  layout: `
²~ &1 é2 "3 '4 (5 -6 è7 _8 ç9 à0 )° +=
    aA zZ eE rR tT yY uU iI oO pP ^" $£
     qQ sS dD fF gG hH jJ kK lL mM ù% *µ
   <> wW xX cC vV bB nN ,? ;. :/ !§
  `,
  shiftedRx: /[1234567890°+AZERYTUIOP¨£QSDFGHJKLM%µ>WXCVBN?/.§]/,
}
