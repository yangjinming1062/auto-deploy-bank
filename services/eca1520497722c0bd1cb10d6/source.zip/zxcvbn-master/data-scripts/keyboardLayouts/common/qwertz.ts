export default {
  slanted: true,
  layout: `
^° 1! 2" 3§ 4$ 5% 6& 7/ 8( 9) 0= ß? ´\`
    qQ wW eE rR tT zZ uU iI oO pP üÜ +*
     aA sS dD fF gG hH jJ kK lL öÖ äÄ #'
   <> yY xX cC vV bB nN mM ,; .: -_
  `,
  shiftedRx: /[°!"§$%&/()=?QWERTZUIOPÜ*ASDFGHJKLÖÄ'>YXCVBNM;:_]/,
}
