export default {
  semi: false,
  quoteProps: 'consistent',
  trailingComma: 'all',
  singleQuote: true,
  htmlWhitespaceSensitivity: 'ignore',
}
