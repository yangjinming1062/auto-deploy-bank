<template>
  <div class="fillcontain">
    <router-view></router-view>
  </div>
</template>

<script>
    export default {

    }
</script>

<style lang="less" scoped>
  @import './style/common';
</style>