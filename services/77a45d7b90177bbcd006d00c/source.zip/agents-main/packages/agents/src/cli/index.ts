#!/usr/bin/env node

import { createCli } from "./create";

void createCli().parse();
