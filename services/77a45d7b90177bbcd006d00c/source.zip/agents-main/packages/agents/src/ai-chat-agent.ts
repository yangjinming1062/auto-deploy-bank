export * from "@cloudflare/ai-chat";

console.log(
  "All the AI Chat related modules are now in @cloudflare/ai-chat. This module is deprecated and will be removed in the next major version."
);
