export * from "@cloudflare/codemode/ai";

console.log(
  "Codemode is now in @cloudflare/codemode. This module is deprecated and will be removed in the next major version."
);
