// properly set up the act environment for react-tests
// @ts-expect-error - react specific API
globalThis.IS_REACT_ACT_ENVIRONMENT = true;
