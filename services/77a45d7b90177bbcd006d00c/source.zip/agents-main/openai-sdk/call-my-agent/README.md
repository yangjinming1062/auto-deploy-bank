# Call My Agent

Let's make an agent that you can make a phone call to! Powerd by the OpenAI agents sdk and twilio.
