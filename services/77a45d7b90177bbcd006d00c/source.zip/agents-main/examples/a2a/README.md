# A2A demo

A minimal example showing an `A2A` running in Wrangler.

## Instructions

```sh
npm install
npm start
```

You should have the A2A agent running on http://localhost:5173. Navigate to http://localhost:5173/.well-known/agent.json to see the agent card.
