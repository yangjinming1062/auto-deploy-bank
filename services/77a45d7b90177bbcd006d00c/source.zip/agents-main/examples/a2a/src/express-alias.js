// blank alias to avoid vite trying to bundle express
export default {};
