.. include:: includes/main_page.rst
.. include:: ../../AUTHORS.rst

