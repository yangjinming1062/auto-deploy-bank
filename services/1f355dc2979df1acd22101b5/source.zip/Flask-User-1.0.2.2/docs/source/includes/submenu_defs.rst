.. |bullet| raw:: html

    &bull;

.. |spacing| raw:: html

    &nbsp; &nbsp; &nbsp;
