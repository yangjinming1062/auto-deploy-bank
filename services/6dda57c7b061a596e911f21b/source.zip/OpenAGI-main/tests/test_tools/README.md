# test/test_tools

This tests specific tools the agents can use and makes sure they are working. Each tool has its own test.
