# tests

This directory contains tests you can use to test specific features of the project so you can figure out which specific parts work easier. 

For example, test_agent_creation.py simply tests the AgentProcess ability to hold agents.

We want to use error code to differentiate between successful and failed tests in the future.
