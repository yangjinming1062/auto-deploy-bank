# Agent Tasks
This directory test tasks for each agent, containing examples of prompts that could be given to that agent. This is used by `eval.py` when running tests.
