# pyopenagi

The internal implementation for OpenAGI.

1. `agents/` contains the agent implementation all future agents have to follow.
2. `queues/` contains the class implementation for queues.
3. `utils/` contains some helpful internal utilities.
4. `tools/` contains the tools the agents can use.
