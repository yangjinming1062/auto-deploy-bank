# pyopenagi/queues

This contains implementations for queries to be passed to the LLM in a queue format so that we can have some waiting while one request is completing. 
