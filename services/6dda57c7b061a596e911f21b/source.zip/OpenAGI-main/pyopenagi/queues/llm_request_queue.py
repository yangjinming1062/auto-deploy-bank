from .base_queue import BaseQueue

class LLMRequestQueue(BaseQueue):
    pass
