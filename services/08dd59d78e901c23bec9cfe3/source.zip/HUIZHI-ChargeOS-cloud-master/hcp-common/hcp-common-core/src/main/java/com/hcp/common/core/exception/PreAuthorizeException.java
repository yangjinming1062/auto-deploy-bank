package com.hcp.common.core.exception;

/**
 * 权限异常
 *
 * @author vctgo
 */
public class PreAuthorizeException extends RuntimeException
{
    private static final long serialVersionUID = 1L;

    public PreAuthorizeException()
    {
    }
}
