package com.hcp.common.core.utils.bean;

public enum RandomType {
    INT,
    STRING,
    ALL;

    private RandomType() {
    }
}
