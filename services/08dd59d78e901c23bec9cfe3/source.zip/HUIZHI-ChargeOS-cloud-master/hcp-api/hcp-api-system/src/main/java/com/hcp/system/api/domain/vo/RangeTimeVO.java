package com.hcp.system.api.domain.vo;

import lombok.Data;

@Data
public class RangeTimeVO {
    private float startTime;

    private float endTime;


}
