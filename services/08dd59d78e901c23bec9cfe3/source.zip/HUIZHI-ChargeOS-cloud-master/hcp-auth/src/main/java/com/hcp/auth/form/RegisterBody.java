package com.hcp.auth.form;

import lombok.Data;

/**
 * 用户注册对象
 *
 * @author vctgo
 */
@Data
public class RegisterBody extends LoginBody
{

}
