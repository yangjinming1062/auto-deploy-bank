package com.hcp.operator.constant;

public interface FeeConstant {
    /**
     * 收费
     */
    public static final String NEED_FEE = "2001";
    /**
     * 免费
     */
    public static final String FREE_FEE = "2002";

}
