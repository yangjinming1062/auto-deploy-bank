package com.hcp.file.constant;

public class PlatformConstant {
    public static String MINIO = "minio-1";
    public static String OBS = "huawei-obs-1";
    public static String OSS = "aliyun-oss-1";
    public static String KODO = "qiniu-kodo-1";
    public static String COS = "tencent-cos-1";
    public static String BOS = "baidu-bos-1";
}
