package com.hcp.mp.constant;

public interface MpConstant {

    /**
     * 通过token 反查用户id
     */
    String USER_TOKEN = "member:token:";

}
