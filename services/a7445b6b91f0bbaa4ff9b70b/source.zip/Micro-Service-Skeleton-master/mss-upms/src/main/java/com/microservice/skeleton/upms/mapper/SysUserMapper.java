package com.microservice.skeleton.upms.mapper;

import com.microservice.skeleton.upms.entity.SysUser;
import tk.mybatis.mapper.common.Mapper;

public interface SysUserMapper extends Mapper<SysUser> {
}