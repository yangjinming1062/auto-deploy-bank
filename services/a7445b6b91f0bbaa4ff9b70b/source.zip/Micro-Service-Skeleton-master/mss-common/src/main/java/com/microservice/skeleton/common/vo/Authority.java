package com.microservice.skeleton.common.vo;

/**
 * @author Mr.Yangxiufeng
 * @date 2020-10-29
 * @time 14:38
 */
public class Authority {
    private String authority;

    public String getAuthority() {
        return authority;
    }

    public void setAuthority(String authority) {
        this.authority = authority;
    }
}
