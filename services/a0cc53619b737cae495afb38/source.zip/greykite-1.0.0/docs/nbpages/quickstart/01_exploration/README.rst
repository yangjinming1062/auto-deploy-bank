Data exploration
----------------

Here are some library features for data exploration.


