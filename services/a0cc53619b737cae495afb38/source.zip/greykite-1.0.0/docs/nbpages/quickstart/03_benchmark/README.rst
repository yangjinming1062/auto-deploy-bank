Grid Search and Benchmarking
----------------------------

Here are some library features for grid search and benchmarking.