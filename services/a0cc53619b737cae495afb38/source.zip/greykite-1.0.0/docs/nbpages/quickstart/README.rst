Quickstart
==========

Here are some examples to get you started with core library functionality,
starting with a simple forecast.