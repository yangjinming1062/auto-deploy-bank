=======
Credits
=======

Development Leads
-----------------

* Reza Hosseini <rhosseini@linkedin.com> (Core Algorithms and Models)
* Albert Chen <abchen@linkedin.com> (Modeling Framework, Templates, Auto-Tuning)

Authors
-------
* Reza Hosseini
* Albert Chen
* Kaixu Yang
* Sayan Patra
* Yi Su
* Rachit Arora

Other Contributors
------------------
* Qiang Fei
* Saad Eddin Al Orjany
* Rachit Kumar
* Phil Gaudreau
* Yi-Wei Liu
* Katherine Li
