""" Version information for Lackey module

"""

__version__ = "0.7.4"
__sikuli_version__ = "1.1.0"
