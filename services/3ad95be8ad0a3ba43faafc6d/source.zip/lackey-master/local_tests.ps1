python -m coverage run --source=lackey -m unittest tests.test_cases
py -3 -m coverage run -a --source=lackey -m unittest tests.test_cases
coverage html
rm coverage.svg
coverage-badge -o coverage.svg