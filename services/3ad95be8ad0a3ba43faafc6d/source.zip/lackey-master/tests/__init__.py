# Makes tests runnable with `python -m unittest tests.test_cases`
