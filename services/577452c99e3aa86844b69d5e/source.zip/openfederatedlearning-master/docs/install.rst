.. # Copyright (C) 2020-2021 Intel Corporation
.. # SPDX-License-Identifier: Apache-2.0

.. _install_software_root:

***********************
Installing the Software
***********************

.. note::

   This project is expected to be continually developed and improved. Changes to this manual, the project code, and the project design should be expected.

.. toctree::
   :maxdepth: 4

   install.design
   install.installing
   
