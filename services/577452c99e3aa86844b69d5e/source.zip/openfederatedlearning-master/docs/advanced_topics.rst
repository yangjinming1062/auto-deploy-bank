.. # Copyright (C) 2020 Intel Corporation
.. # Licensed subject to the terms of the separately executed evaluation license agreement between Intel Corporation and you.

.. _advanced_topics:

***************
Advanced Topics
***************

.. toctree::
   :maxdepth: 4

   multiple_plans
   compression_settings
   overriding_agg_fn


