"""openfl nlp keras template."""
