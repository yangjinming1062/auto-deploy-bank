#!/bin/sh

java -Dawt.useSystemAAFontSettings=on -jar PacketProxy-*.jar

