/*
 * Copyright 2019 DeNA Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package packetproxy;

import static packetproxy.util.Logging.errWithStackTrace;

import com.google.common.collect.Sets;
import java.io.File;
import java.lang.reflect.Modifier;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Set;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import javax.tools.DiagnosticCollector;
import javax.tools.JavaCompiler;
import javax.tools.JavaFileManager;
import javax.tools.JavaFileObject;
import javax.tools.StandardLocation;
import javax.tools.ToolProvider;
import org.apache.commons.io.FilenameUtils;
import packetproxy.encode.Encoder;

public class EncoderManager {

	private static EncoderManager instance;
	private boolean isDuplicated = false;

	public static EncoderManager getInstance() throws Exception {
		if (instance == null) {

			instance = new EncoderManager();
		}
		return instance;
	}

	private static final String DEFAULT_PLUGIN_DIR = System.getProperty("user.home") + "/.packetproxy/plugins";
	private HashMap<String, Class<Encoder>> module_list;
	private static final String encode_package = "packetproxy.encode";
	private static final Class<Encoder> encode_class = packetproxy.encode.Encoder.class;

	// リフレクションを利用して自動でモジュールをロードするようになったので、クラス名を追記する必要はありません。

	private EncoderManager() {
		try {

			loadModules();
		} catch (Exception e) {

			errWithStackTrace(e);
		}
	}

	private void loadModules() throws Exception {
		isDuplicated = false;
		module_list = new HashMap<String, Class<Encoder>>();
		JavaCompiler compiler = ToolProvider.getSystemJavaCompiler();
		JavaFileManager fm = compiler.getStandardFileManager(new DiagnosticCollector<JavaFileObject>(), null, null);

		Set<JavaFileObject.Kind> kind = Sets.newHashSet(JavaFileObject.Kind.CLASS);
		for (JavaFileObject f : fm.list(StandardLocation.CLASS_PATH, encode_package, kind, false)) {

			try {

				Path encode_file_path = Paths.get(f.getName());
				Path encode_file_name = encode_file_path.getFileName();
				String encode_class_path = encode_package + "."
						+ encode_file_name.toString().replaceAll("\\.class.*$", "");
				Class klass = Class.forName(encode_class_path);
				if (encode_class.isAssignableFrom(klass) && !Modifier.isAbstract(klass.getModifiers())) {

					@SuppressWarnings("unchecked")
					Encoder encoder = createInstance((Class<Encoder>) klass, null);
					module_list.put(encoder.getName(), klass);
				}
			} catch (Exception e) {

				errWithStackTrace(e);
			}
		}
		loadModulesFromJar(module_list);
	}

	private void loadModulesFromJar(HashMap<String, Class<Encoder>> module_list) throws Exception {
		File[] files = new File(DEFAULT_PLUGIN_DIR).listFiles();
		if (null == files) {

			return;
		}
		for (File file : files) {

			if (!file.isFile() || !"jar".equals(FilenameUtils.getExtension(file.getName()))) {

				continue;
			}
			URLClassLoader urlClassLoader = URLClassLoader.newInstance(new URL[]{file.toURI().toURL()});
			JarFile jarFile = new JarFile(file.getPath());
			for (Enumeration<JarEntry> entries = jarFile.entries(); entries.hasMoreElements();) {

				// Jar filter
				JarEntry jarEntry = entries.nextElement();
				if (jarEntry.isDirectory())
					continue;

				// class filter
				String fileName = jarEntry.getName();
				if (!fileName.endsWith(".class"))
					continue;

				Class<?> klass;
				try {

					// jar内のクラスファイルの階層がパッケージに準拠している必要がある
					// 例: packetproxy.plugin.EncodeHTTPSample
					// -> packetproxy/plugin/EncodeHTTPSample.class
					String encode_class_path = fileName.replaceAll("\\.class.*$", "").replaceAll("/", ".");
					klass = urlClassLoader.loadClass(encode_class_path);
				} catch (Exception e) {

					errWithStackTrace(e);
					continue;
				}

				// Encode Classを継承しているか
				if (!encode_class.isAssignableFrom(klass))
					continue;
				if (Modifier.isAbstract(klass.getModifiers()))
					continue;

				@SuppressWarnings("unchecked")
				Encoder encoder = createInstance((Class<Encoder>) klass, null);
				String encoderName = encoder.getName();
				if (module_list.containsKey(encoderName)) {

					isDuplicated = true;
					encoderName += "-" + file.getName();
				}
				module_list.put(encoderName, (Class<Encoder>) klass);
			}
		}
	}

	public void addEncoder(String name, Class klass) {
		if (Encoder.class.isAssignableFrom(klass)) {

			module_list.put(name, klass);
		}
	}

	public void removeEncoder(String name) {
		module_list.remove(name);
	}

	public boolean hasDuplicateModules() {
		return isDuplicated;
	}

	public String[] getEncoderNameList() {
		String[] names = new String[module_list.size()];
		int i = 0;
		for (String name : module_list.keySet()) {

			names[i++] = name;
		}
		Arrays.sort(names);
		return names;
	}

	private Encoder createInstance(Class<Encoder> klass, String ALPN) throws Exception {
		return klass.getConstructor(String.class).newInstance(ALPN);
	}

	public Encoder createInstance(String encoderName, String ALPN) throws Exception {
		Class<Encoder> klass = module_list.get(encoderName);
		if (klass == null) {

			return null;
		}
		return createInstance(klass, ALPN);
	}
}
