The standalone test folder is reserved for tests that require dedicated environment (e.g. memory stress tests)
