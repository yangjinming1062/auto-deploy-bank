This folder is reserved for end-to-end tests that typically require multiple GPUs.
