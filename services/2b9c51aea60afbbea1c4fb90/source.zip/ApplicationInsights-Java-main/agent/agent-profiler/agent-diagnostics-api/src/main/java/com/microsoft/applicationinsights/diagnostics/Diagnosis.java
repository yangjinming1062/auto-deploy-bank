// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

package com.microsoft.applicationinsights.diagnostics;

/** Interface used as a marker for all Diagnoses. */
public interface Diagnosis {}
