plugins {
  id("ai.java-conventions")
}

dependencies {
  implementation("org.slf4j:slf4j-api")
  implementation("com.google.errorprone:error_prone_annotations")
}
