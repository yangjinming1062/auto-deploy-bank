// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

package com.microsoft.applicationinsights.agent.internal.init;

import com.azure.monitor.opentelemetry.autoconfigure.implementation.AiSemanticAttributes;
import io.opentelemetry.context.Context;
import io.opentelemetry.sdk.logs.LogRecordProcessor;
import io.opentelemetry.sdk.logs.ReadWriteLogRecord;

public final class InheritedRoleNameLogProcessor implements LogRecordProcessor {

  @Override
  public void onEmit(Context context, ReadWriteLogRecord logRecord) {
    String roleName = context.get(AiContextKeys.ROLE_NAME);
    if (roleName != null) {
      logRecord.setAttribute(AiSemanticAttributes.INTERNAL_ROLE_NAME, roleName);
    }
  }
}
