// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

package com.microsoft.azure.functions.rpc.messages;

public class InvocationRequest {

  public RpcTraceContext getTraceContext() {
    throw new UnsupportedOperationException();
  }

  public String getInvocationId() {
    throw new UnsupportedOperationException();
  }
}
