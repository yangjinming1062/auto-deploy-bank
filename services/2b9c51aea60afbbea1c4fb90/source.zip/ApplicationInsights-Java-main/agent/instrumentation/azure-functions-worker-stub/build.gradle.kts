plugins {
  id("ai.java-conventions")
}

// this module is needed since the azure functions worker artifact is not available in maven central
