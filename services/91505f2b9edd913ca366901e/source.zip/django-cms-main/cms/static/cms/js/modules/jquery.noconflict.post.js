// reset assigned jQuery
var __jQuery;
window.jQuery = (__jQuery) ? __jQuery : window.jQuery || undefined;
window.$ = window.jQuery;
