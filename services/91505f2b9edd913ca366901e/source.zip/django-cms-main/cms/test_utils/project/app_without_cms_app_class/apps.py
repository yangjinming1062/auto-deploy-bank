from django.apps import AppConfig


class WithoutCMSAppClassConfig(AppConfig):
    name = 'cms.test_utils.project.app_without_cms_app_class'
    label = 'app_without_cms_app_class'
