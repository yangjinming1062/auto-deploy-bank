default_app_config = 'cms.test_utils.project.app_without_cms_app_class.apps.WithoutCMSAppClassConfig'
