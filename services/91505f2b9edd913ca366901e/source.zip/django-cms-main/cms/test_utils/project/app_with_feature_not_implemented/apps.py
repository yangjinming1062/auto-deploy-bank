from django.apps import AppConfig


class CMSFeatureConfig(AppConfig):
    name = 'cms.test_utils.project.app_with_feature_not_implemented'
    label = 'app_with_feature_not_implemented'
