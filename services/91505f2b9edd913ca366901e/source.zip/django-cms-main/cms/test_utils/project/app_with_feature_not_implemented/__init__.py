default_app_config = 'cms.test_utils.project.app_with_feature_not_implemented.apps.CMSFeatureConfig'
