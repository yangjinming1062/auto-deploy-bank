from cms.app_base import CMSAppConfig, CMSAppExtension


class CMSFeatureConfig(CMSAppExtension):
    pass


class CMSFeatureConfig2(CMSAppExtension):
    pass


class CMSConfig(CMSAppConfig):
    pass
