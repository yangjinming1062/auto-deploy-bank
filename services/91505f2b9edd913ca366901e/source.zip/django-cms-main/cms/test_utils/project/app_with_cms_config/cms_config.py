from cms.app_base import CMSAppConfig


class CMSConfigConfig(CMSAppConfig):
    app_with_cms_feature_enabled = True
