default_app_config = 'cms.test_utils.project.app_with_bad_cms_file.apps.BadCMSFileConfig'
