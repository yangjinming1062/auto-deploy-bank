---
name: Feature Request
about: Suggest an idea for this project
title: ''
labels: 'new feature'
assignees: ''

---

- As a [user/developer], I wish I could use Compose to ...

#### Code Example

```python
# Your code here, if applicable

```
