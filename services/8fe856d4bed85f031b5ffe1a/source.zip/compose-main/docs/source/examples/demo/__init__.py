import os
import warnings

warnings.filterwarnings("ignore")
PWD = os.path.dirname(__file__)
