==========
User Guide
==========

Use these guides to learn how to use label transformations and generate better training examples.

.. toctree::
    :glob:
    :maxdepth: 1

    user_guide/controlling_cutoff_times
    user_guide/using_label_transforms
    user_guide/data_slice_generator

|
