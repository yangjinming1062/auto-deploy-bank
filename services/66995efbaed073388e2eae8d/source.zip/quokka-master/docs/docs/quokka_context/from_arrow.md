# QuokkaContext.from_arrow

::: pyquokka.df.QuokkaContext.from_arrow
