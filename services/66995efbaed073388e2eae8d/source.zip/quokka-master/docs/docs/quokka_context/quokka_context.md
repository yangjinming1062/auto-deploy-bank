# QuokkaContext

::: pyquokka.df.QuokkaContext.__init__
