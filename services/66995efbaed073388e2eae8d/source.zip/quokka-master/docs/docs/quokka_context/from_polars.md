# QuokkaContext.from_polars

::: pyquokka.df.QuokkaContext.from_polars
