# QuokkaContext.from_pandas

::: pyquokka.df.QuokkaContext.from_pandas
