# stop_cluster

::: pyquokka.utils.stop_cluster
