# QuokkaClusterManager.stop_cluster

::: pyquokka.utils.QuokkaClusterManager.start_cluster
