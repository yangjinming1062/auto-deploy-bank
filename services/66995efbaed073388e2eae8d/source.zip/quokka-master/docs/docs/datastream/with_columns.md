# DataStream.with_columns

::: pyquokka.datastream.DataStream.with_columns
