# DataStream.transform

::: pyquokka.datastream.DataStream.transform
