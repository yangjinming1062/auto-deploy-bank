# DataStream.top_k

::: pyquokka.datastream.DataStream.top_k
