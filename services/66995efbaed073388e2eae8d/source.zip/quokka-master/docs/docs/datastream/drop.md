# DataStream.drop

::: pyquokka.datastream.DataStream.drop
