# DataStream.agg

::: pyquokka.datastream.DataStream.agg
