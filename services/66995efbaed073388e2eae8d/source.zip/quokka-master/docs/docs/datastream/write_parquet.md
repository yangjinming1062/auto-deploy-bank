# DataStream.write_parquet

::: pyquokka.datastream.DataStream.write_parquet
