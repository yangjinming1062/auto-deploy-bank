# DataStream.compute

::: pyquokka.datastream.DataStream.compute
