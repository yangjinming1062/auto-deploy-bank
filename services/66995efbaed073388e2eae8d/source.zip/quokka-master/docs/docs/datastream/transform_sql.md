# DataStream.transform_sql

::: pyquokka.datastream.DataStream.transform_sql
