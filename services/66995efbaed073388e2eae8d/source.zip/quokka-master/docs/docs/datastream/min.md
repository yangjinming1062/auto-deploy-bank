# DataStream.min

::: pyquokka.datastream.DataStream.min
