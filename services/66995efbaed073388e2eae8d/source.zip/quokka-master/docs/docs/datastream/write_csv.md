# DataStream.write_csv

::: pyquokka.datastream.DataStream.write_csv
