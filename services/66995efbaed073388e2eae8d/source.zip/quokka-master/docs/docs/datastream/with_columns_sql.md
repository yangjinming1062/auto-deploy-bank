# DataStream.with_columns_sql

::: pyquokka.datastream.DataStream.with_columns_sql
