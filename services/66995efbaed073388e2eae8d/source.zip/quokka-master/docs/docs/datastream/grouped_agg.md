# GroupedDataStream.agg

::: pyquokka.datastream.GroupedDataStream.agg
