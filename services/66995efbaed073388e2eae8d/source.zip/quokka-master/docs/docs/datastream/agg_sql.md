# DataStream.agg_sql

::: pyquokka.datastream.DataStream.agg_sql
