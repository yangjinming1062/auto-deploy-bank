# ExprStringNameSpace.json_extract

::: pyquokka.expression.ExprStringNameSpace.json_extract
