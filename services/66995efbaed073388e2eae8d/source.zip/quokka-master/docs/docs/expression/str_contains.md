# ExprStringNameSpace.contains

::: pyquokka.expression.ExprStringNameSpace.contains
