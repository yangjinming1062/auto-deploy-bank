# ExprDateTimeNameSpace.strftime

::: pyquokka.expression.ExprDateTimeNameSpace.strftime
