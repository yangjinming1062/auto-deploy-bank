# ExprDateTimeNameSpace.microsecond

::: pyquokka.expression.ExprDateTimeNameSpace.microsecond
