# ExprDateTimeNameSpace.millisecond

::: pyquokka.expression.ExprDateTimeNameSpace.millisecond
