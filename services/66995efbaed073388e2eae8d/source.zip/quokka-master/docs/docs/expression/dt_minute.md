# ExprDateTimeNameSpace.minute

::: pyquokka.expression.ExprDateTimeNameSpace.minute
