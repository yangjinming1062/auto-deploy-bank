# ExprStringNameSpace.ends_with

::: pyquokka.expression.ExprStringNameSpace.ends_with
