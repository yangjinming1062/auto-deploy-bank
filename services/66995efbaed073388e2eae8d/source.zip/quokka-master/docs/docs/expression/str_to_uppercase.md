# ExprStringNameSpace.to_uppercase

::: pyquokka.expression.ExprStringNameSpace.to_uppercase
