# ExprStringNameSpace.starts_with

::: pyquokka.expression.ExprStringNameSpace.starts_with
