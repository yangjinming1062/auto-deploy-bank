# ExprDateTimeNameSpace.month

::: pyquokka.expression.ExprDateTimeNameSpace.month
