sudo apt-get update
sudo apt-get install -y python3-pip
sudo apt-get install -y curl
sudo apt-get install -y python3.8-dev
sudo apt-get install -y unzip
sudo apt-get install -y nvme-cli
# curl "https://awscli.amazonaws.com/awscli-exe-linux-x86_64.zip" -o "awscliv2.zip"
# unzip -o  awscliv2.zip
# sudo ./aws/install
pip3 install awscli
sudo apt-get install -y python-cffi
