#!/bin/bash
# Entrypoint script for Alluxio Docker container

ALLUXIO_HOME="/opt/alluxio"

# Log JAR file location for security scanning
if [ -f /app/target.jar ]; then
    echo "JAR file available at: /app/target.jar ($(du -h /app/target.jar | cut -f1))"
else
    echo "WARNING: JAR file not found at /app/target.jar"
fi

echo "Starting Alluxio..."

# Set default environment variables
export ALLUXIO_MASTER_HOSTNAME=${ALLUXIO_MASTER_HOSTNAME:-localhost}
export ALLUXIO_UNDERFS_ADDRESS=${ALLUXIO_UNDERFS_ADDRESS:-/underFSStorage}
export ALLUXIO_RAM_FOLDER=${ALLUXIO_RAM_FOLDER:-/dev/shm}
export ALLUXIO_LOGS_DIR=${ALLUXIO_LOGS_DIR:-/tmp/alluxio/logs}

# Ensure directories exist with proper permissions
mkdir -p ${ALLUXIO_HOME}/journal
mkdir -p ${ALLUXIO_HOME}/metastore
mkdir -p /underFSStorage
mkdir -p ${ALLUXIO_LOGS_DIR}

# Execute the run-alluxio.sh script
exec /usr/local/bin/run-alluxio.sh