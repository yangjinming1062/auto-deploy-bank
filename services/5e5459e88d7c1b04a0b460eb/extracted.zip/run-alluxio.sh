#!/bin/bash
# Run Alluxio script - uses Alluxio's built-in startup mechanism

ALLUXIO_HOME="/opt/alluxio"
ALLUXIO_CONF_DIR="${ALLUXIO_HOME}/conf"
ALLUXIO_LOGS_DIR="/tmp/alluxio/logs"

echo "Starting Alluxio local cluster..."

cd ${ALLUXIO_HOME}

# Format if needed
if [ ! -d "${ALLUXIO_HOME}/journal/RaftJournal" ]; then
    echo "Formatting Alluxio journal..."
    ./bin/alluxio formatMasters 2>/dev/null || true
fi

# Start Alluxio using built-in script
echo "Starting Alluxio services with alluxio-start.sh..."

# Start all services in local mode (master, worker, job-master, job-worker)
# Use NoMount to avoid ramdisk mounting issues in container
./bin/alluxio-start.sh local NoMount

echo ""
echo "Alluxio started successfully!"
echo "Web UI available at: http://localhost:19999"
echo ""

# Monitor health
while true; do
    sleep 30

    # Check Web UI
    if curl -s -o /dev/null -w "%{http_code}" http://localhost:19999/ 2>/dev/null | grep -q "200\|302"; then
        echo "Alluxio cluster is healthy - Web UI responding at $(date)"
    else
        echo "Warning: Web UI not responding at $(date)"
    fi
done