---
name: Document Defect
about: Report a Documentation defect
title: ''
labels: type-docs
assignees: ''

---

**Page**
Include the link to the page you are reporting a defect

**Summary**
What is the defect and suggested improvement
