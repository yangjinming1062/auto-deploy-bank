---
page_type: sample
languages:
- language1
- language2
products:
- ai-services
- azure-openai
description: Example description.
---

## Your Sample Name

### Overview

This tutorial provides a step-by-step guide on how to leverage Generative AI to build and deploy with Azure. It covers the entire workflow, from data preparation and model development to deployment and monitoring.

### Objective

The main objective of this tutorial is to help users understand the process of creating, training, and deploying an AI model in Azure. By the end of this tutorial, you should be able to:

 - a
 - b
 - c

### Programming Languages
 - Python

### Estimated Runtime: 30 mins
