package com.sohu.cache.utils;

/**
 * custom environment setting
 */
public class EnvCustomUtil {
    //是否启用默认密码
    public static boolean pwdswitch = false;
}
