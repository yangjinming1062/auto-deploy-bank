package com.sohu.cache.alert.utils;

/**
 * Created by yijunzhang
 */
public class AlertUtils {
    /**
     * 邮箱报警接口
     */
    public static String EMAIL_ALERT_INTERFACE;
    /**
     * 短信报警接口
     */
    public static String MOBILE_ALERT_INTERFACE;
    /**
     * 微信报警接口
     */
    public static String WECHAT_ALERT_INTERFACE;
    /**
     * 报警邮箱
     */
    public static String EMAILS;
    /**
     * 报警电话
     */
    public static String PHONES;
    /**
     * 报警微信
     */
    public static String WECHAT;
}
