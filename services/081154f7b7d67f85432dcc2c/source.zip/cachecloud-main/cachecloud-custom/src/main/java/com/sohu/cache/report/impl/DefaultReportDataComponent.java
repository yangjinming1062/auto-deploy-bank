package com.sohu.cache.report.impl;

import com.sohu.cache.report.ReportDataComponent;

/**
 * @Author: zengyizhao
 * @DateTime: 2022/2/21 11:22
 * @Description: 上报数据默认实现
 */
public class DefaultReportDataComponent implements ReportDataComponent {

    @Override
    public void reportCommandData(Object msg) {
        //todo
    }

    @Override
    public void reportExceptionData(Object msg) {
        //todo
    }

    @Override
    public void reportRedisInfoData(Object msg) {
        //todo
    }

    @Override
    public void reportSlowLogData(Object msg) {
        //todo
    }

    @Override
    public void reportLatencyData(Object msg) {
        //todo
    }

    @Override
    public void reportMachineData(Object msg) {
        //todo
    }

}
