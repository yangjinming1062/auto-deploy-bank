-- app_desc change
ALTER TABLE app_desc ADD custom_password varchar(255) DEFAULT NULL COMMENT '自定义密码';
