package com.sohu.cache.task.constant;

/**
 * Created by rucao on 2019/1/23
 */
public class MachineExamContants {
    public final static double BASE_RATIO=1.0;
    public final static double defult_memUseThreshold=0.80;
    public final static double middle_memUseThreshold=0.75;
    public final static double small_memUseThreshold=0.70;
    public final static String  MACHINE_IP="machineIp";
    public final static String MEM="mem";
    public final static String CPU="cpu";
    public final static String USED_MEM="used_mem";
    public final static String APPLY_MEM="apply_mem";
    public final static String USED_CPU="used_cpu";
    public final static String USED_MEM_RATIO="used_mem_ratio";
    public final static String APPLY_MEM_RATIO="apply_mem_ratio";
    public final static String USED_CPU_RATIO="used_cpu_ratio";
}
