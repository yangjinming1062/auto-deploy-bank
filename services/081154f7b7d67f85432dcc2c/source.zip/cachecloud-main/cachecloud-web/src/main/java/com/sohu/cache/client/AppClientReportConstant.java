package com.sohu.cache.client;

import java.util.Arrays;
import java.util.List;

/**
 * Created by rucao on 2019/12/18
 */
public class AppClientReportConstant {
    public final static List<String> ClientReportCommandBlacklist = Arrays.asList("info", "ping");
}
