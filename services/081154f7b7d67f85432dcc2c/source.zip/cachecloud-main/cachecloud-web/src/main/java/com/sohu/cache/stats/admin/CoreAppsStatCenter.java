package com.sohu.cache.stats.admin;

/**
 * Created by rucao on 2020/3/25
 */
public interface CoreAppsStatCenter {
    boolean sendExpAppsStatDataEmail(String searchDate);
}
