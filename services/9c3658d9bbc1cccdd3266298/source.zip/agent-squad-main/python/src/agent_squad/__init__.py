from .shared import user_agent

user_agent.inject_user_agent()