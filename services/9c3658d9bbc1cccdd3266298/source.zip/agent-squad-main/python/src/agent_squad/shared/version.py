"""Exposes version constant."""

VERSION = "1.0.0"