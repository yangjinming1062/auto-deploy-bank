// this file is auto generated, do not modify
export const MAOTS_VERSION = '1.0.0';
