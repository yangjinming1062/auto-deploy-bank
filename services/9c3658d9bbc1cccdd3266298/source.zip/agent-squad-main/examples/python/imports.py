# some_file.py
import sys
# caution: path[0] is reserved for script path (or '' in REPL)

# import your demo here
sys.path.insert(1, './movie-production')
sys.path.insert(1, './travel-planner')
