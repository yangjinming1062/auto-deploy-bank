/* eslint-disable quotes */
/* eslint-disable indent */

export default {
    baseUrl: ""
}
