## redis manager 2.1.0
analysis(@Truman)
基本功能完成

user manage(@Jay)
权限控制：url级别、cluster 级别





