package com.newegg.ec.redis.entity;

/**
 * @author Jay.H.Zou
 * @date 8/2/2019
 */
public class RedisClientName {

    private RedisClientName() {
    }

    public static final String REDIS_MANAGER_ClIENT = "data";

}
