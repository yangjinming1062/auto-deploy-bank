package com.newegg.ec.redis.plugin.alert.entity;

import java.sql.Timestamp;

/**
 * @author Jay.H.Zou
 * @date 2019/7/29
 */
public class AlertRecord {

    private Integer recordId;

    private Integer groupId;

    private Boolean clusterAlert;

    private String groupName;

    private Integer clusterId;

    private String clusterName;

    private Integer ruleId;

    private String redisNode;

    private String alertRule;

    private String actualData;

    private Integer checkCycle;

    private String ruleInfo;

    private Timestamp updateTime;

    public Integer getRecordId() {
        return recordId;
    }

    public void setRecordId(Integer recordId) {
        this.recordId = recordId;
    }

    public Integer getGroupId() {
        return groupId;
    }

    public void setGroupId(Integer groupId) {
        this.groupId = groupId;
    }

    public Boolean getClusterAlert() {
        return clusterAlert;
    }

    public void setClusterAlert(Boolean clusterAlert) {
        this.clusterAlert = clusterAlert;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public Integer getClusterId() {
        return clusterId;
    }

    public void setClusterId(Integer clusterId) {
        this.clusterId = clusterId;
    }

    public String getClusterName() {
        return clusterName;
    }

    public void setClusterName(String clusterName) {
        this.clusterName = clusterName;
    }

    public Integer getRuleId() {
        return ruleId;
    }

    public void setRuleId(Integer ruleId) {
        this.ruleId = ruleId;
    }

    public String getRedisNode() {
        return redisNode;
    }

    public void setRedisNode(String redisNode) {
        this.redisNode = redisNode;
    }

    public String getAlertRule() {
        return alertRule;
    }

    public void setAlertRule(String alertRule) {
        this.alertRule = alertRule;
    }

    public String getActualData() {
        return actualData;
    }

    public void setActualData(String actualData) {
        this.actualData = actualData;
    }

    public Integer getCheckCycle() {
        return checkCycle;
    }

    public void setCheckCycle(Integer checkCycle) {
        this.checkCycle = checkCycle;
    }

    public String getRuleInfo() {
        return ruleInfo;
    }

    public void setRuleInfo(String ruleInfo) {
        this.ruleInfo = ruleInfo;
    }

    public Timestamp getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Timestamp updateTime) {
        this.updateTime = updateTime;
    }

    @Override
    public String toString() {
        return "AlertRecord{" +
                "recordId=" + recordId +
                ", groupId=" + groupId +
                ", groupName='" + groupName + '\'' +
                ", clusterId=" + clusterId +
                ", clusterName='" + clusterName + '\'' +
                ", ruleId=" + ruleId +
                ", redisNode='" + redisNode + '\'' +
                ", alertRule='" + alertRule + '\'' +
                ", actualData='" + actualData + '\'' +
                ", checkCycle=" + checkCycle +
                ", ruleInfo='" + ruleInfo + '\'' +
                ", updateTime=" + updateTime +
                '}';
    }
}
