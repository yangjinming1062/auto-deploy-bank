package com.newegg.ec.redis.service;

import org.quartz.Job;

/**
 * @author Kyle.K.Zhao
 * @date 1/9/2020 08:22
 */
public interface IRdbScheduleJob extends Job{
}
