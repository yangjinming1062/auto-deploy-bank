package com.alibaba.fastjson.deserializer.issues3796.bean;




import java.util.List;


public class ObjectJ_A {

	
	private long a;

	
	private int b;

	
	private int c;

	
	private int d;

	
	private int e;

	
	private int f;

	
	private int g;

	
	private int h;

	
	private int i;

	
	private List<ObjectJ_B> j;

	
	private List<ObjectC> k;

	
	private List<ObjectJ_C> l;

	
	private List<CommonObject> m;

	public long getA() {
		return a;
	}

	public void setA(long a) {
		this.a = a;
	}

	public int getB() {
		return b;
	}

	public void setB(int b) {
		this.b = b;
	}

	public int getC() {
		return c;
	}

	public void setC(int c) {
		this.c = c;
	}

	public int getD() {
		return d;
	}

	public void setD(int d) {
		this.d = d;
	}

	public int getE() {
		return e;
	}

	public void setE(int e) {
		this.e = e;
	}

	public int getF() {
		return f;
	}

	public void setF(int f) {
		this.f = f;
	}

	public int getG() {
		return g;
	}

	public void setG(int g) {
		this.g = g;
	}

	public int getH() {
		return h;
	}

	public void setH(int h) {
		this.h = h;
	}

	public int getI() {
		return i;
	}

	public void setI(int i) {
		this.i = i;
	}

	public List<ObjectJ_B> getJ() {
		return j;
	}

	public void setJ(List<ObjectJ_B> j) {
		this.j = j;
	}

	public List<ObjectC> getK() {
		return k;
	}

	public void setK(List<ObjectC> k) {
		this.k = k;
	}

	public List<ObjectJ_C> getL() {
		return l;
	}

	public void setL(List<ObjectJ_C> l) {
		this.l = l;
	}

	public List<CommonObject> getM() {
		return m;
	}

	public void setM(List<CommonObject> m) {
		this.m = m;
	}
}
