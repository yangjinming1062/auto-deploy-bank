package com.alibaba.fastjson.deserializer.issues3796.bean;




import java.util.List;


public class ObjectJ {
	
	private long a;
	
	private int b;

	
	private int c;
	
	private int d;

	
	private int e;

	

	private int f;
	

	private int g;
	

	private int h;
	
	private List<CommonObject3> i;
	
	private int j;
	
	private int k;

	
	private int l;
	
	private int m;
	
	private List<CommonObject> n;

	
	private List<Integer> o;
	
	private int p;
	
	private int q;
	
	private int r;
	
	private int s;
	
	private int t;
	
	private int x;

	
	private int y;
	
	private int z;
	
	private int a1;

	
	private int b1;
	
	private List<ObjectJ_A> c1;

	private List<ObjectK> d1;
	
	private List<Long> e1;

	
	private int f1;

	
	private int g1;

	
	boolean  h1;

	public long getA() {
		return a;
	}

	public void setA(long a) {
		this.a = a;
	}

	public int getB() {
		return b;
	}

	public void setB(int b) {
		this.b = b;
	}

	public int getC() {
		return c;
	}

	public void setC(int c) {
		this.c = c;
	}

	public int getD() {
		return d;
	}

	public void setD(int d) {
		this.d = d;
	}

	public int getE() {
		return e;
	}

	public void setE(int e) {
		this.e = e;
	}

	public int getF() {
		return f;
	}

	public void setF(int f) {
		this.f = f;
	}

	public int getG() {
		return g;
	}

	public void setG(int g) {
		this.g = g;
	}

	public int getH() {
		return h;
	}

	public void setH(int h) {
		this.h = h;
	}

	public List<CommonObject3> getI() {
		return i;
	}

	public void setI(List<CommonObject3> i) {
		this.i = i;
	}

	public int getJ() {
		return j;
	}

	public void setJ(int j) {
		this.j = j;
	}

	public int getK() {
		return k;
	}

	public void setK(int k) {
		this.k = k;
	}

	public int getL() {
		return l;
	}

	public void setL(int l) {
		this.l = l;
	}

	public int getM() {
		return m;
	}

	public void setM(int m) {
		this.m = m;
	}

	public List<CommonObject> getN() {
		return n;
	}

	public void setN(List<CommonObject> n) {
		this.n = n;
	}

	public List<Integer> getO() {
		return o;
	}

	public void setO(List<Integer> o) {
		this.o = o;
	}

	public int getP() {
		return p;
	}

	public void setP(int p) {
		this.p = p;
	}

	public int getQ() {
		return q;
	}

	public void setQ(int q) {
		this.q = q;
	}

	public int getR() {
		return r;
	}

	public void setR(int r) {
		this.r = r;
	}

	public int getS() {
		return s;
	}

	public void setS(int s) {
		this.s = s;
	}

	public int getT() {
		return t;
	}

	public void setT(int t) {
		this.t = t;
	}

	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}

	public int getZ() {
		return z;
	}

	public void setZ(int z) {
		this.z = z;
	}

	public int getA1() {
		return a1;
	}

	public void setA1(int a1) {
		this.a1 = a1;
	}

	public int getB1() {
		return b1;
	}

	public void setB1(int b1) {
		this.b1 = b1;
	}

	public List<ObjectJ_A> getC1() {
		return c1;
	}

	public void setC1(List<ObjectJ_A> c1) {
		this.c1 = c1;
	}

	public List<ObjectK> getD1() {
		return d1;
	}

	public void setD1(List<ObjectK> d1) {
		this.d1 = d1;
	}

	public List<Long> getE1() {
		return e1;
	}

	public void setE1(List<Long> e1) {
		this.e1 = e1;
	}

	public int getF1() {
		return f1;
	}

	public void setF1(int f1) {
		this.f1 = f1;
	}

	public int getG1() {
		return g1;
	}

	public void setG1(int g1) {
		this.g1 = g1;
	}

	public boolean isH1() {
		return h1;
	}

	public void setH1(boolean h1) {
		this.h1 = h1;
	}
}