package com.alibaba.fastjson.deserializer.issues3796.bean;






public class ObjectW {
	
	private long a;

	
	private int b;
	
	private long c;

	
	private int d;
	
	private String e;

	
	private long f;

	public long getA() {
		return a;
	}

	public void setA(long a) {
		this.a = a;
	}

	public int getB() {
		return b;
	}

	public void setB(int b) {
		this.b = b;
	}

	public long getC() {
		return c;
	}

	public void setC(long c) {
		this.c = c;
	}

	public int getD() {
		return d;
	}

	public void setD(int d) {
		this.d = d;
	}

	public String getE() {
		return e;
	}

	public void setE(String e) {
		this.e = e;
	}

	public long getF() {
		return f;
	}

	public void setF(long f) {
		this.f = f;
	}
}
