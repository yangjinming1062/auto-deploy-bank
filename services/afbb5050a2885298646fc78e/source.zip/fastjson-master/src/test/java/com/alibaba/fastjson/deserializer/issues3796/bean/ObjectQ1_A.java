package com.alibaba.fastjson.deserializer.issues3796.bean;




import java.util.List;


public class ObjectQ1_A {
    
    private int a;

    
    private List<ObjectQ1_B> b;

    
    private int c;

    
    private boolean d;

    
    private boolean e;

    public int getA() {
        return a;
    }

    public void setA(int a) {
        this.a = a;
    }

    public List<ObjectQ1_B> getB() {
        return b;
    }

    public void setB(List<ObjectQ1_B> b) {
        this.b = b;
    }

    public int getC() {
        return c;
    }

    public void setC(int c) {
        this.c = c;
    }

    public boolean isD() {
        return d;
    }

    public void setD(boolean d) {
        this.d = d;
    }

    public boolean isE() {
        return e;
    }

    public void setE(boolean e) {
        this.e = e;
    }
}
