package com.alibaba.fastjson.deserializer.issues3796.bean;




import java.util.List;


public class ObjectT {
	
	private int a = 0;

	
	private int b = 0;
	
	private int c = 0;

	
	private List<ObjectT_A> d;

	
	private int e = 0;

	
	private int f;

	
	private int g;

	
	private int h;

	
	private int i;

	
	private int j;

	
	private boolean k = false;


	public int getA() {
		return a;
	}

	public void setA(int a) {
		this.a = a;
	}

	public int getB() {
		return b;
	}

	public void setB(int b) {
		this.b = b;
	}

	public int getC() {
		return c;
	}

	public void setC(int c) {
		this.c = c;
	}

	public List<ObjectT_A> getD() {
		return d;
	}

	public void setD(List<ObjectT_A> d) {
		this.d = d;
	}

	public int getE() {
		return e;
	}

	public void setE(int e) {
		this.e = e;
	}

	public int getF() {
		return f;
	}

	public void setF(int f) {
		this.f = f;
	}

	public int getG() {
		return g;
	}

	public void setG(int g) {
		this.g = g;
	}

	public int getH() {
		return h;
	}

	public void setH(int h) {
		this.h = h;
	}

	public int getI() {
		return i;
	}

	public void setI(int i) {
		this.i = i;
	}

	public int getJ() {
		return j;
	}

	public void setJ(int j) {
		this.j = j;
	}

	public boolean isK() {
		return k;
	}

	public void setK(boolean k) {
		this.k = k;
	}
}
