package com.alibaba.fastjson.deserializer.issues3796.bean;






public class ObjectJ2 {

    
    private boolean a;

    
    private boolean b;

    public boolean isA() {
        return a;
    }

    public void setA(boolean a) {
        this.a = a;
    }

    public boolean isB() {
        return b;
    }

    public void setB(boolean b) {
        this.b = b;
    }
}
