package com.alibaba.fastjson.deserializer.issues3796.bean;

public class OjectN_A {
	private long a;
	private String b;
	private String c;
	private int d;
	private String e;

	public long getA() {
		return a;
	}

	public void setA(long a) {
		this.a = a;
	}

	public String getB() {
		return b;
	}

	public void setB(String b) {
		this.b = b;
	}

	public String getC() {
		return c;
	}

	public void setC(String c) {
		this.c = c;
	}

	public int getD() {
		return d;
	}

	public void setD(int d) {
		this.d = d;
	}

	public String getE() {
		return e;
	}

	public void setE(String e) {
		this.e = e;
	}
}
