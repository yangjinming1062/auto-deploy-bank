package com.alibaba.fastjson.deserializer.issues3796.bean;




import java.util.List;


public class ObjectU1 {
	
	private int a;
	
	private String b = "";
	
	private String c = "";
	
	private String d = "";
	
	private List<ObjectU1_A> e;
	
	private List<ObjectU1_B> f;
	
	private long g;
	
	private long h;
	
	private long i;
	
	private long j;
	
	private long k;
	
	private long l;
	
	private List<ObjectV1_A> m;

	public int getA() {
		return a;
	}

	public void setA(int a) {
		this.a = a;
	}

	public String getB() {
		return b;
	}

	public void setB(String b) {
		this.b = b;
	}

	public String getC() {
		return c;
	}

	public void setC(String c) {
		this.c = c;
	}

	public String getD() {
		return d;
	}

	public void setD(String d) {
		this.d = d;
	}

	public List<ObjectU1_A> getE() {
		return e;
	}

	public void setE(List<ObjectU1_A> e) {
		this.e = e;
	}

	public List<ObjectU1_B> getF() {
		return f;
	}

	public void setF(List<ObjectU1_B> f) {
		this.f = f;
	}

	public long getG() {
		return g;
	}

	public void setG(long g) {
		this.g = g;
	}

	public long getH() {
		return h;
	}

	public void setH(long h) {
		this.h = h;
	}

	public long getI() {
		return i;
	}

	public void setI(long i) {
		this.i = i;
	}

	public long getJ() {
		return j;
	}

	public void setJ(long j) {
		this.j = j;
	}

	public long getK() {
		return k;
	}

	public void setK(long k) {
		this.k = k;
	}

	public long getL() {
		return l;
	}

	public void setL(long l) {
		this.l = l;
	}

	public List<ObjectV1_A> getM() {
		return m;
	}

	public void setM(List<ObjectV1_A> m) {
		this.m = m;
	}
}
