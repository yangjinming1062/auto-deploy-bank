package com.alibaba.fastjson.deserializer.issues3796.bean;




import java.util.List;


public class ObjectM1_B {
    
    private long a;
    
    private String b;
    
    private String c;
    
    private int d;

    
    private long e;
    
    private int f;

    
    private int g;

    
    private List<Integer> h;

    
    private List<ObjectM1_C> i;

    
    private int j;

    
    private int k;

    
    private boolean l;

    public long getA() {
        return a;
    }

    public void setA(long a) {
        this.a = a;
    }

    public String getB() {
        return b;
    }

    public void setB(String b) {
        this.b = b;
    }

    public String getC() {
        return c;
    }

    public void setC(String c) {
        this.c = c;
    }

    public int getD() {
        return d;
    }

    public void setD(int d) {
        this.d = d;
    }

    public long getE() {
        return e;
    }

    public void setE(long e) {
        this.e = e;
    }

    public int getF() {
        return f;
    }

    public void setF(int f) {
        this.f = f;
    }

    public int getG() {
        return g;
    }

    public void setG(int g) {
        this.g = g;
    }

    public List<Integer> getH() {
        return h;
    }

    public void setH(List<Integer> h) {
        this.h = h;
    }

    public List<ObjectM1_C> getI() {
        return i;
    }

    public void setI(List<ObjectM1_C> i) {
        this.i = i;
    }

    public int getJ() {
        return j;
    }

    public void setJ(int j) {
        this.j = j;
    }

    public int getK() {
        return k;
    }

    public void setK(int k) {
        this.k = k;
    }

    public boolean isL() {
        return l;
    }

    public void setL(boolean l) {
        this.l = l;
    }
}