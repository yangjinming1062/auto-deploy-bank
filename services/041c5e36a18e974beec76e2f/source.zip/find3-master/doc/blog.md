# Blog

<style>
summary {
    font-size: 1.5em;
    margin-top: 0.83em;
    margin-bottom: 0.83em;
    margin-left: 0;
    margin-right: 0;
    font-weight: bold;    
}
</style>

<details open><summary>July 20th, 2018</summary>
<p>

#### There are new features

```python
print("hello world!")
```

</p>
</details>



<details><summary>July 20th, 2018</summary>
<p>

#### There are new features

```python
print("hello world!")
```

</p>
</details>



<details><summary>July 20th, 2018</summary>
<p>

#### There are new features

```python
print("hello world!")
```

</p>
</details>

