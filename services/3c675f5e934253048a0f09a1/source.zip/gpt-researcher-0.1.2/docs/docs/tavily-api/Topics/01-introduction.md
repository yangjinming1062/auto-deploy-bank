# Introduction

We know that each AI application requires a different set of realtime data. 
For example, a chatbot that answers questions about the coding tasks needs connect to rich code documentation. 
A chatbot that answers questions about the stock market needs to connect stock market-related data, news and people.

For this we're excited to introduce Tavily Search Topics. You can now search for data based on a topic.