# Metric Calculation
