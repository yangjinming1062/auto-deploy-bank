from mmengine.config import read_base

with read_base():
    from .summedits_gen_315438 import summedits_datasets  # noqa: F401, F403
