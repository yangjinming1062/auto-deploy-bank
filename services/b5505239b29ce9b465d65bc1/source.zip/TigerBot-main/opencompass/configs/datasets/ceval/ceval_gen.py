from mmengine.config import read_base

with read_base():
    from .ceval_gen_5f30c7 import ceval_datasets  # noqa: F401, F403
