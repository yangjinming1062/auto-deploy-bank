from mmengine.config import read_base

with read_base():
    from .ceval_ppl_578f8d import ceval_datasets  # noqa: F401, F403
