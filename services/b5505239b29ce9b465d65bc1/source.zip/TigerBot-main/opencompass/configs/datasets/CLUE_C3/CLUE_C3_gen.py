from mmengine.config import read_base

with read_base():
    from .CLUE_C3_gen_8c358f import C3_datasets  # noqa: F401, F403
