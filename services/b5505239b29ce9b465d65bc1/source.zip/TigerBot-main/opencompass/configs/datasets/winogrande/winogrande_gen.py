from mmengine.config import read_base

with read_base():
    from .winogrande_gen_a9ede5 import winogrande_datasets  # noqa: F401, F403
