from mmengine.config import read_base

with read_base():
    from .iwslt2017_gen_d0ebd1 import iwslt2017_datasets  # noqa: F401, F403
