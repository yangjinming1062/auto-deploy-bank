from mmengine.config import read_base

with read_base():
    from .crowspairs_gen_02b6c1 import crowspairs_datasets  # noqa: F401, F403
