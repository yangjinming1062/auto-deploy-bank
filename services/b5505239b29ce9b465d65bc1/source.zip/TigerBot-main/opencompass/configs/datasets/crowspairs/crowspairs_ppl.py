from mmengine.config import read_base

with read_base():
    from .crowspairs_ppl_e811e1 import crowspairs_datasets  # noqa: F401, F403
