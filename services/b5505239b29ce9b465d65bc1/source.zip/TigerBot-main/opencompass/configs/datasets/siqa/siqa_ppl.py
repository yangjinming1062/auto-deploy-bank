from mmengine.config import read_base

with read_base():
    from .siqa_ppl_ced5f6 import siqa_datasets  # noqa: F401, F403
