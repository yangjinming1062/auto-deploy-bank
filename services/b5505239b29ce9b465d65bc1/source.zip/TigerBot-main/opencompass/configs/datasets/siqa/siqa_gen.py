from mmengine.config import read_base

with read_base():
    from .siqa_gen_e78df3 import siqa_datasets  # noqa: F401, F403
