from mmengine.config import read_base

with read_base():
    from .govrepcrs_gen_db7930 import govrepcrs_datasets  # noqa: F401, F403
