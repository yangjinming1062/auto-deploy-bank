from mmengine.config import read_base

with read_base():
    from .PJExam_gen_8cd97c import PJExam_datasets  # noqa: F401, F403
