from mmengine.config import read_base

with read_base():
    from .race_gen_69ee4f import race_datasets  # noqa: F401, F403
