from mmengine.config import read_base

with read_base():
    from .race_ppl_a138cd import race_datasets  # noqa: F401, F403
