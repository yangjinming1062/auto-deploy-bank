from mmengine.config import read_base

with read_base():
    from .CLUE_CMRC_gen_3749cd import CMRC_datasets
