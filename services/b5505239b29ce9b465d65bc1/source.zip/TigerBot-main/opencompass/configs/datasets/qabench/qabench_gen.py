from mmengine.config import read_base

with read_base():
    from .qabench_gen_353ae7 import qabench_datasets  # noqa: F401, F403
