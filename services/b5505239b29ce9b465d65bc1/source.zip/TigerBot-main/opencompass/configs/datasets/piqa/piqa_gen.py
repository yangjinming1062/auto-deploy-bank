from mmengine.config import read_base

with read_base():
    from .piqa_gen_1194eb import piqa_datasets  # noqa: F401, F403
