from mmengine.config import read_base

with read_base():
    from .piqa_ppl_1cf9f0 import piqa_datasets  # noqa: F401, F403
