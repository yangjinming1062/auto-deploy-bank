from mmengine.config import read_base

with read_base():
    from .CLUE_afqmc_ppl_6507d7 import afqmc_datasets  # noqa: F401, F403
