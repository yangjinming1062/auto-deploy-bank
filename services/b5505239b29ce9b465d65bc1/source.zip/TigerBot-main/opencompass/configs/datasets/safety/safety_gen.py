from mmengine.config import read_base

with read_base():
    from .safety_gen_7ce197 import safety_datasets  # noqa: F401, F403
