from mmengine.config import read_base

with read_base():
    from .storycloze_ppl_496661 import storycloze_datasets  # noqa: F401, F403
