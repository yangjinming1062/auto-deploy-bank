from mmengine.config import read_base

with read_base():
    from .storycloze_gen_7f656a import storycloze_datasets  # noqa: F401, F403
