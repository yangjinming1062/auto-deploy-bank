from mmengine.config import read_base

with read_base():
    from .obqa_gen_9069e4 import obqa_datasets  # noqa: F401, F403
