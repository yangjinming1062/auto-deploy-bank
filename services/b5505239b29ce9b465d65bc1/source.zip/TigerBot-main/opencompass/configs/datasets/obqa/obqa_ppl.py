from mmengine.config import read_base

with read_base():
    from .obqa_ppl_c7c154 import obqa_datasets  # noqa: F401, F403
