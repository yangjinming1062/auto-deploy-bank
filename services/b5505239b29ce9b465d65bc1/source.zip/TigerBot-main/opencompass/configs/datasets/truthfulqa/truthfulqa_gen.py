from mmengine.config import read_base

with read_base():
    from .truthfulqa_gen_5ddc62 import truthfulqa_datasets  # noqa: F401, F403
