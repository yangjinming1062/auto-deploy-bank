from mmengine.config import read_base

with read_base():
    from .strategyqa_gen_1180a7 import strategyqa_datasets  # noqa: F401, F403
