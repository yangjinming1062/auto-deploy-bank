from mmengine.config import read_base

with read_base():
    from .bbh_gen_5b92b0 import bbh_datasets  # noqa: F401, F403
