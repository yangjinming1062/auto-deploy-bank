from mmengine.config import read_base

with read_base():
    from .TheoremQA_gen_7009de import TheoremQA_datasets  # noqa: F401, F403
