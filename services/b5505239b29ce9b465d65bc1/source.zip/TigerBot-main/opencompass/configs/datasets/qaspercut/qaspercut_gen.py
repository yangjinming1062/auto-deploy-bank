from mmengine.config import read_base

with read_base():
    from .qaspercut_gen_a2d88a import qaspercut_datasets  # noqa: F401, F403
