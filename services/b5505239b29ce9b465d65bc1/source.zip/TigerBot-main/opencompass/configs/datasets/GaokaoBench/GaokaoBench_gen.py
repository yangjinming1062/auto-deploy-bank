from mmengine.config import read_base

with read_base():
    from .GaokaoBench_gen_5cfe9e import GaokaoBench_datasets  # noqa: F401, F403
