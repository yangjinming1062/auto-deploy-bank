from mmengine.config import read_base

with read_base():
    from .realtoxicprompts_gen_ac723c import realtoxicprompts_datasets  # noqa: F401, F403
