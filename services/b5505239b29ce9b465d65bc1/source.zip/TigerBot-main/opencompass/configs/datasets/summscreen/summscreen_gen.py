from mmengine.config import read_base

with read_base():
    from .summscreen_gen_aa5eb3 import summscreen_datasets  # noqa: F401, F403
