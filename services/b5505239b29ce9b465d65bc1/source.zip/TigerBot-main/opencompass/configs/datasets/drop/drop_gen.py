from mmengine.config import read_base

with read_base():
    from .drop_gen_599f07 import drop_datasets  # noqa: F401, F403
