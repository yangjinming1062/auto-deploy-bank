from mmengine.config import read_base

with read_base():
    from .apps_gen_7fbb95 import apps_datasets  # noqa: F401, F403
