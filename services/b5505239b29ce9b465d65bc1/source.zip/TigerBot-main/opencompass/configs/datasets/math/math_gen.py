from mmengine.config import read_base

with read_base():
    from .math_gen_265cce import math_datasets  # noqa: F401, F403
