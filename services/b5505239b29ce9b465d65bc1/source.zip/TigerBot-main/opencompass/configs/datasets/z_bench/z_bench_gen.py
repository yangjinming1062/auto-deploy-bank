from mmengine.config import read_base

with read_base():
    from .z_bench_gen_5813ec import z_bench_dataset  # noqa: F401, F403
