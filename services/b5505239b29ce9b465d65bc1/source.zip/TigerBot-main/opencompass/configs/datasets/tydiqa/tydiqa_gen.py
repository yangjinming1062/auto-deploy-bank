from mmengine.config import read_base

with read_base():
    from .tydiqa_gen_978d2a import tydiqa_datasets  # noqa: F401, F403
