from mmengine.config import read_base

with read_base():
    from .civilcomments_ppl_6a2561 import civilcomments_datasets  # noqa: F401, F403
