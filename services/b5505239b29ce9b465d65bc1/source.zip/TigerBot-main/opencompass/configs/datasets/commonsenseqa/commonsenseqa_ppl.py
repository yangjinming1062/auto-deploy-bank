from mmengine.config import read_base

with read_base():
    from .commonsenseqa_ppl_5545e2 import commonsenseqa_datasets  # noqa: F401, F403
