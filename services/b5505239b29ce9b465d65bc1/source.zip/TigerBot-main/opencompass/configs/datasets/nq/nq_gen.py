from mmengine.config import read_base

with read_base():
    from .nq_gen_3dcea1 import nq_datasets  # noqa: F401, F403
