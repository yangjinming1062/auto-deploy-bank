from mmengine.config import read_base

with read_base():
    from .SuperGLUE_CB_ppl_0143fe import CB_datasets  # noqa: F401, F403
