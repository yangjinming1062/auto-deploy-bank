from mmengine.config import read_base

with read_base():
    from .ARC_e_ppl_a450bd import ARC_e_datasets  # noqa: F401, F403
