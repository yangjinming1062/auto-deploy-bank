jigsaw_multilingual_summary_groups = []

# bbh
_jigsaw_multilingual = ['es', 'fr', 'it', 'pt', 'ru', 'tr']
_jigsaw_multilingual = ['jigsaw_multilingual_' + s for s in _jigsaw_multilingual]
jigsaw_multilingual_summary_groups.append({'name': 'jigsaw_multilingual', 'subsets': _jigsaw_multilingual})
