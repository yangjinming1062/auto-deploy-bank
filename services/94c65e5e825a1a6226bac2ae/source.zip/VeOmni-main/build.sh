#!/bin/bash
pip3 install build
python3 -m build
