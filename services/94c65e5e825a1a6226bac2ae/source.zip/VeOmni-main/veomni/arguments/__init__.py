from .arguments_types import DataArguments, ModelArguments, TrainingArguments, VeOmniArguments
from .parser import parse_args, save_args
