import { dualPackage } from '../../scripts/rslib.base.config';

export default dualPackage;
