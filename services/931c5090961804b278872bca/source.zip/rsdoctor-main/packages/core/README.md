# @rsdoctor/core

This is the core package of Rsdoctor, providing core tools and analysis capabilities for Rsdoctor plugins.

## Documentation

https://rsdoctor.rs/.

## Contributing

Please read the [Contributing Guide](https://github.com/web-infra-dev/rsdoctor/blob/main/CONTRIBUTING.md).

## License

Rsdoctor is [MIT licensed](https://github.com/web-infra-dev/rsdoctor/blob/main/LICENSE).
