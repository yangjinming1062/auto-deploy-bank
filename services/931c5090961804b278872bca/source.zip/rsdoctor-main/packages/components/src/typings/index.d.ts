interface Window {
  [key: string]: any;
  __RSDOCTOR__: any;
}
