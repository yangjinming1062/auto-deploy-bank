import { Client } from '@rsdoctor/types';

export const name = 'Rule Index';

export const route = Client.RsdoctorClientRoutes.RuleIndex;
