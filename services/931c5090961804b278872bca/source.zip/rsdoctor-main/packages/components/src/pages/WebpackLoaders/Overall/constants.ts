import { Client } from '@rsdoctor/types';

export const name = 'Loaders Timeline';

export const route = Client.RsdoctorClientRoutes.WebpackLoaderOverall;
