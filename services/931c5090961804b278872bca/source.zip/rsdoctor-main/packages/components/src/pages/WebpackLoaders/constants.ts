export const name = 'Loaders';

export const route = '/webpack/loaders';
