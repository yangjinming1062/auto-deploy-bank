import { Client } from '@rsdoctor/types';

export const name = 'Upload and Analysis';

export const route = Client.RsdoctorClientRoutes.Uploader;
