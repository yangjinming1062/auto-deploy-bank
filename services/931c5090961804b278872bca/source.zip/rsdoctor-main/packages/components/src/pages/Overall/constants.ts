import { Client } from '@rsdoctor/types';

export const name = 'Overall';

export const route = Client.RsdoctorClientRoutes.Overall;
