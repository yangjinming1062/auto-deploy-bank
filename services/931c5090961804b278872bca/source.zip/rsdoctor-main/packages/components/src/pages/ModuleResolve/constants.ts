import { Client } from '@rsdoctor/types';

export const name = 'ModuleResolve';

export const route = Client.RsdoctorClientRoutes.ModuleResolve;
