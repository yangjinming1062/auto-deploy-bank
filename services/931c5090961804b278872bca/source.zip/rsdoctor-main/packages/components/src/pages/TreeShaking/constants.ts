import { Client } from '@rsdoctor/types';

export const name = 'TreeShaking';

export const route = Client.RsdoctorClientRoutes.TreeShaking;
