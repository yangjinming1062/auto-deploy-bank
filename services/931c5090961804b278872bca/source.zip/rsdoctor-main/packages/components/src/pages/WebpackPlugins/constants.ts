import { Client } from '@rsdoctor/types';

export const name = 'Plugins Analysis';

export const route = Client.RsdoctorClientRoutes.WebpackPlugins;
