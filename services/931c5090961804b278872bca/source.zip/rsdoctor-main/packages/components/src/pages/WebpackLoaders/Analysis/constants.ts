import { Client } from '@rsdoctor/types';

export const name = 'Loaders Analysis';

export const route = Client.RsdoctorClientRoutes.WebpackLoaderAnalysis;
