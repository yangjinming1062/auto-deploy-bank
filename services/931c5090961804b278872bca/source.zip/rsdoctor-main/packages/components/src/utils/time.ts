import { Time } from '@rsdoctor/utils/common';

const { toFixedDigits, getUnit, formatCosts } = Time;

export { toFixedDigits as toFixed, getUnit, formatCosts };
