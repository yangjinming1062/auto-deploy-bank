export const CompileName = 'Compile Analysis';
