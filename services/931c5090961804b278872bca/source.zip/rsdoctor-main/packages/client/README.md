# @rsdoctor/client

This package is the Rsdoctor reporting platform.

## Documentation

https://rsdoctor.rs/

## Contributing

Please read the [Contributing Guide](https://github.com/web-infra-dev/rsdoctor/blob/main/CONTRIBUTING.md).

## License

Rsdoctor is [MIT licensed](https://github.com/web-infra-dev/rsdoctor/blob/main/LICENSE).
