// Langchain does not provide a nodejs version of the coze sdk.
// Only python version: https://python.langchain.com/docs/integrations/chat/coze
// So use coze sdk first.
