console.log('a');

const { a } = require('./index');
console.log(a);