const ll = 1;

console.log('a');

function kk() {
  console.log('hhe: ', ll);
  return '111';
}

kk();
