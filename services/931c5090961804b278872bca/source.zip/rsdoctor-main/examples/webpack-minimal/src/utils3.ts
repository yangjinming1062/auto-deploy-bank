import { key1 } from './utils';

export const key3 = key1 + 1;
