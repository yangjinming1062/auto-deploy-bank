import highlight from '@babel/highlight';

export { highlight };
export const key1 = '123';
export const key2 = '123';

console.log(key2);
