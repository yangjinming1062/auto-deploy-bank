declare module '@babel/highlight';
