## Rewrite benchmarks

A series of benchmarks for making improvements on the most frequently used core recipes.

To find good sample data, see [this utility](https://gist.github.com/mcxiaoke/b4bdad5727c9400bbf7d101f27297e86).
