# 5. Parser and LST Design Conventions and Best Practices

## Status

Draft

## Context 

As we have developed parsers for more programming languages and data formats a number of conventions and best practices 
have emerged. This document is intended to capture and codify those conventions and best practices.

## Decision


