# Architecture Decision Records

* [1. Record architecture decisions](0001-record-architecture-decisions.md)
* [2. Naming recipes](0002-recipe-naming.md)
* [3. OSS contributor's guidelines](0003-oss-contributors.md)
* [4. Library migration recipe conventions](0004-library-migration-conventions.md)
