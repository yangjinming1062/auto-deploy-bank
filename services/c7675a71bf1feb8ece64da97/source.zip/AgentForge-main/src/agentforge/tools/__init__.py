# =================== DEPRECATION WARNING ===================
# This module is DEPRECATED.
# Do NOT use in production or with untrusted input.
# See: https://github.com/DataBassGit/AgentForge/issues/116 for details.
# This functionality will be replaced in a future version with a secure implementation.
import warnings
warnings.warn(
    "agentforge.tools is DEPRECATED and insecure. Do NOT use in production. See https://github.com/DataBassGit/AgentForge/issues/116",
    DeprecationWarning
)
# ==========================================================
