import { SnippetChooser } from '../../components/ChooserWidget/SnippetChooserWidget';

window.SnippetChooser = SnippetChooser;
