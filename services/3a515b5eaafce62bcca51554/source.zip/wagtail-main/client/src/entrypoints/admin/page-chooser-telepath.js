import { PageChooserFactory } from '../../components/ChooserWidget/PageChooserWidget';

window.telepath.register('wagtail.widgets.PageChooser', PageChooserFactory);
