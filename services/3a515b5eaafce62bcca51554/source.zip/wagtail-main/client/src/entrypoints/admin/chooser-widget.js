import { Chooser } from '../../components/ChooserWidget';

window.Chooser = Chooser;
