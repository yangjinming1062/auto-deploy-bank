# Security

See https://docs.wagtail.org/en/latest/contributing/security.html.

This information can also be found in our security.txt: https://wagtail.org/.well-known/security.txt
