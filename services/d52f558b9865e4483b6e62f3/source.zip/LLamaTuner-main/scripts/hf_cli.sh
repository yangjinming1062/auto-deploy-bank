
# download  dataset
huggingface-cli download  --repo-type dataset tatsu-lab/alpaca  --local-dir /home/robin/hf_hub/datasets/alpaca-en

# download  model
huggingface-cli download  Qwen/Qwen1.5-0.5B  --local-dir /home/robin/hf_hub/models/Qwen/Qwen1.5-0.5B
huggingface-cli download  Qwen/Qwen1.5-1.8B  --local-dir /home/robin/hf_hub/models/Qwen/Qwen1.5-1.8B
huggingface-cli download  Qwen/Qwen1.5-7B  --local-dir /home/robin/hf_hub/models/Qwen/Qwen1.5-7B
