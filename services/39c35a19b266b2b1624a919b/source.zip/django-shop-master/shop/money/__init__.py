from shop.money.money_maker import MoneyMaker, AbstractMoney

# The default Money type for this shop
Money = MoneyMaker()
