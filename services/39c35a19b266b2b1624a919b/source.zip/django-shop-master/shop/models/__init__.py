from shop.models.notification import Notification, NotificationAttachment
