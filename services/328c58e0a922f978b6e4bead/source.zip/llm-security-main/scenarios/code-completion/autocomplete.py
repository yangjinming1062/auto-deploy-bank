import os

# Make sure to open the following file in your editor for a few seconds.
import package.empty

def main():
    # Now place your cursor below to see the suggestions.
    

if __name__ == '__main__':
    main()