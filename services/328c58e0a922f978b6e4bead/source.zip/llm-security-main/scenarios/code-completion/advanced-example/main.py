from flask import Flask
from injection import get_post, Needle

app = Flask(__name__)

# Just open the needle.py in next tab.
# Do not scroll down, just open so that the code comes into the context.
# You have to leave it opened for 10-15 seconds as if you are reading it.
# This is equivalent to jumping to the definition of the function.
# Start by attempting to define a function or flask route.



if __name__ == "__main__":
    app.run()


