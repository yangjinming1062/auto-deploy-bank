package org.ylzl.eden.common.excel.writer;

/**
 * TODO
 *
 * @author <a href="mailto:shiyindaxiaojie@gmail.com">gyl</a>
 * @since 2.4.13
 */
public abstract class AbstractExcelWriteHandler implements ExcelWriteHandler {


}
