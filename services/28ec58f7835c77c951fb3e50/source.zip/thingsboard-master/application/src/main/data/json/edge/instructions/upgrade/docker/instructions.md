#### Upgrading to ${TB_EDGE_VERSION}

Execute the following command to pull **${TB_EDGE_VERSION}** image:

```bash
docker pull thingsboard/tb-edge:${TB_EDGE_VERSION}
{:copy-code}
```

${UPGRADE_DB}
