Start the service

```bash
sudo systemctl tb-edge start
{:copy-code}
```
