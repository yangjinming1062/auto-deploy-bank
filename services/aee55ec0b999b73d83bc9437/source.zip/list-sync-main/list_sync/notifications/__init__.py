"""
Notification modules for ListSync.
"""

from .discord import send_to_discord_webhook

__all__ = ['send_to_discord_webhook']
