"""
ListSync - A tool for syncing media lists to Overseerr.

Authors: Soluify Team
Version: 0.6.6
"""

__version__ = "0.6.6"
__author__ = "Soluify"
