package net.risesoft.consts;

/**
 * 组织节点常量
 *
 * @author shidaobang
 * @date 2025/04/25
 * @since 9.6.8
 */
public class DefaultConsts {

    public static Integer TAB_INDEX = 0;

}
