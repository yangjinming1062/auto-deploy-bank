package net.risesoft;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Y9DemoIdCodeApplication {

    public static void main(String[] args) {
        SpringApplication.run(Y9DemoIdCodeApplication.class, args);
    }

}
