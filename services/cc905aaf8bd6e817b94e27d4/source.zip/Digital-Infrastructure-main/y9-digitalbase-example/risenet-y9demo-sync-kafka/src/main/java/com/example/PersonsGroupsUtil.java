package com.example;

import net.risesoft.model.platform.org.PersonsGroups;

/**
 * 用户组人员同步
 *
 * @author shidaobang
 * @date 2022/12/29
 */
public class PersonsGroupsUtil {

    /**
     * 用户组添加人员
     *
     * @param pg
     */
    public static void addPersonsGroup(PersonsGroups pg) {

    }

    /**
     * 用户组删除人员
     *
     * @param pg
     */
    public static void delPersonsGroup(PersonsGroups pg) {}

    /**
     * 用户组内人员排序
     *
     * @param pg
     */
    public static void sortPersonsGroup(PersonsGroups pg) {}
}
