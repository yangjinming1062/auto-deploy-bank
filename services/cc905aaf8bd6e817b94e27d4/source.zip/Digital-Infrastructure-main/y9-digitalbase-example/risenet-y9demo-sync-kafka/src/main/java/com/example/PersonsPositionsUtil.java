package com.example;

import net.risesoft.model.platform.org.PersonsPositions;

/**
 * 岗位人员同步
 *
 * @author shidaobang
 * @date 2022/12/29
 */
public class PersonsPositionsUtil {

    /**
     * 岗位添加人员
     *
     * @param pp
     */
    public static void addPersonsPositions(PersonsPositions pp) {

    }

    /**
     * 岗位删除人员
     *
     * @param pp
     */
    public static void delPersonsPositions(PersonsPositions pp) {

    }

    /**
     * 岗位内人员排序
     *
     * @param pp
     */
    public static void sortPersonsPositions(PersonsPositions pp) {

    }

}
