package net.risesoft;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Y9demoJpaApplication {

    public static void main(String[] args) {
        SpringApplication.run(Y9demoJpaApplication.class, args);
    }

}
