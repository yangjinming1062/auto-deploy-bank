package net.risesoft.log;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Y9DemoLogApplication {

    public static void main(String[] args) {
        SpringApplication.run(Y9DemoLogApplication.class, args);
    }

}
