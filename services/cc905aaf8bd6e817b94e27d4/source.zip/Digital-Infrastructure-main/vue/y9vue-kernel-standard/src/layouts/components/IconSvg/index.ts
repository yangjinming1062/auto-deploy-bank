import iconsvg from './index.vue';

export default iconsvg;
