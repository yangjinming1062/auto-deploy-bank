编码规范参考 [alibaba/p3c](https://github.com/alibaba/p3c)

可以安装相应的插件进行代码的检测，由于目前阿里p3c的IDE插件暂时没有更新，使用会有各种报错，可以使用 [Alibaba Java Coding Guidelines​(XenoAmess TPM)​
](https://plugins.jetbrains.com/plugin/14109-alibaba-java-coding-guidelines-xenoamess-tpm-) 暂时作为替代（该项目
fork [alibaba/p3c](https://github.com/alibaba/p3c)）

此文件夹中提供了统一代码风格的 eclipse 配置文件
对于使用 Intellij IDEA
的可以通过安装  [Adapter for Eclipse Code Formatter](https://plugins.jetbrains.com/plugin/6546-adapter-for-eclipse-code-formatter)
插件来使用 eclipse 的配置进行代码格式化
