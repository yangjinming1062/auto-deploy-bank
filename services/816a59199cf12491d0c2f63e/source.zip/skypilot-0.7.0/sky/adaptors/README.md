This directory is for third-party cloud adaptors. These adaptors wrap the underlying packages, so cloud-specific packages are loaded on demand.
