#!/usr/bin/env bash
set -ex

sky show-gpus --help
sky show-gpus
sky show-gpus V100
sky show-gpus A100
sky show-gpus --all
