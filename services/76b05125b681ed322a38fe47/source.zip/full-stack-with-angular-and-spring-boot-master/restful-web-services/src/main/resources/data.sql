insert into todo(id, username,description,target_date,is_done)
values(10001, 'in28minutes', 'Learn JPA', CURRENT_DATE(), false);

insert into todo(id, username,description,target_date,is_done)
values(10002, 'in28minutes', 'Learn Data JPA', CURRENT_DATE(), false);

insert into todo(id, username,description,target_date,is_done)
values(10003, 'in28minutes', 'Learn Microservices', CURRENT_DATE(), false);