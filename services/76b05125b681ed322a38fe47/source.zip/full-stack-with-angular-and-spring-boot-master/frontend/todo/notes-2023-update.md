
## STEP 06

- ng lint is deprecated
- e2e folder is NOT created by default
- ng e2e has changed