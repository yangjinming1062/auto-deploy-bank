# builder-processor

This module adds support for `@Prototype.Blueprint` annotation processing.
