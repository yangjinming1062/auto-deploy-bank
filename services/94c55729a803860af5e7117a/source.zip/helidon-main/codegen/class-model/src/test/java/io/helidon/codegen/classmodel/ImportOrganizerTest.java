/*
 * Copyright (c) 2023, 2025 Oracle and/or its affiliates.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package io.helidon.codegen.classmodel;

import java.io.IOException;
import java.io.StringWriter;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import io.helidon.common.types.TypeName;

import org.junit.jupiter.api.Test;

import static org.hamcrest.CoreMatchers.hasItem;
import static org.hamcrest.CoreMatchers.hasItems;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.collection.IsEmptyCollection.empty;

class ImportOrganizerTest {
    @Test
    void testImportSystemLoggerLevel() throws IOException {
        TypeName typeNameLevel = TypeName.create(System.Logger.Level.class);
        assertThat(typeNameLevel.className(), is("Level"));
        assertThat(typeNameLevel.enclosingNames(), hasItems("System", "Logger"));
        assertThat(typeNameLevel.packageName(), is("java.lang"));

        Type type = Type.fromTypeName(typeNameLevel);
        assertThat(type.packageName(), is("java.lang"));
        assertThat(type.declaringClass(), is(Optional.of(Type.fromTypeName(TypeName.create(System.class)))));
        assertThat(type.innerClass(), is(true));

        ImportOrganizer io = ImportOrganizer.builder()
                .typeName("io.helidon.NotImportant")
                .packageName("io.helidon")
                .addImport(type)
                .build();
        StringWriter writer = new StringWriter();
        ModelWriter modelWriter = new ModelWriter(writer, "");
        type.writeComponent(modelWriter, Set.of(), io, ClassType.CLASS);

        String written = writer.toString();
        assertThat(written, is("System.Logger.Level"));

        List<String> imports = io.imports();
        assertThat(imports, empty());
    }

    @Test
    void testImportOrganizerHsonStruct() throws IOException {
        TypeName typeNameStruct = TypeName.create("io.helidon.metadata.hson.Hson.Struct.Builder");
        assertThat(typeNameStruct.className(), is("Builder"));
        assertThat(typeNameStruct.enclosingNames(), hasItems("Hson", "Struct"));
        assertThat(typeNameStruct.packageName(), is("io.helidon.metadata.hson"));

        Type type = Type.fromTypeName(typeNameStruct);
        assertThat(type.packageName(), is("io.helidon.metadata.hson"));
        assertThat(type.declaringClass(), is(Optional.of(Type.fromTypeName(TypeName.create("io.helidon.metadata.hson.Hson")))));
        assertThat(type.innerClass(), is(true));

        ImportOrganizer io = ImportOrganizer.builder()
                .typeName("io.helidon.NotImportant")
                .packageName("io.helidon")
                .addImport(type)
                .build();
        StringWriter writer = new StringWriter();
        ModelWriter modelWriter = new ModelWriter(writer, "");
        type.writeComponent(modelWriter, Set.of(), io, ClassType.CLASS);

        String written = writer.toString();
        assertThat(written, is("Hson.Struct.Builder"));

        List<String> imports = io.imports();
        assertThat(imports, hasItem("io.helidon.metadata.hson.Hson"));
    }

    @Test
    void testImportDoubleInnerType() throws IOException {
        TypeName typeNameLevel = TypeName.create("io.helidon.service.registry.Interception.Interceptor.Chain");
        TypeName topLevelType = TypeName.create("io.helidon.service.registry.Interception");

        assertThat(typeNameLevel.className(), is("Chain"));
        assertThat(typeNameLevel.enclosingNames(), hasItems("Interception", "Interceptor"));
        assertThat(typeNameLevel.packageName(), is("io.helidon.service.registry"));

        Type type = Type.fromTypeName(typeNameLevel);
        assertThat(type.packageName(), is("io.helidon.service.registry"));
        assertThat(type.declaringClass(), is(Optional.of(Type.fromTypeName(topLevelType))));
        assertThat(type.innerClass(), is(true));

        ImportOrganizer io = ImportOrganizer.builder()
                .typeName("io.helidon.NotImportant")
                .packageName("io.helidon")
                .addImport(type)
                .build();
        StringWriter writer = new StringWriter();
        ModelWriter modelWriter = new ModelWriter(writer, "");
        type.writeComponent(modelWriter, Set.of(), io, ClassType.CLASS);

        String written = writer.toString();
        assertThat(written, is("Interception.Interceptor.Chain"));

        List<String> imports = io.imports();
        assertThat(imports, hasItem("io.helidon.service.registry.Interception"));
    }
}