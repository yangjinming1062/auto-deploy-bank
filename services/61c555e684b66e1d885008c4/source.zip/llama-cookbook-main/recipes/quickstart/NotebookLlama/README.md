## Notebook Llama

This recipe has moved to a new directory, [Building a Notebook Llama: A Step-by-Step Guide](https://www.llama.com/resources/cookbook/how-to-build-notebook-llama/).

Please update any bookmarks and scripts to point to this new location.


Thank you!
