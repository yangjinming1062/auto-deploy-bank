package com.example.llamaandroiddemo;

public class AppUtils {
	// Generation Mode
	public static final int CONVERSATION_HISTORY_MESSAGE_LOOKBACK = 1;

	// Note: This is an example project to demonstrate E2E flow.
	// You should NOT use/store API key directly on client
	// Exposing your API key in client-side environments allows malicious users to take
	// that key and make requests on your behalf. Requests should always be routed through
	// your own backend server where you can keep your API key secure.
	public static final String API_KEY = "";
}
