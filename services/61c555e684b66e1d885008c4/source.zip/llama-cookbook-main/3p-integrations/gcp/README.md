In this folder, we show various recipes for Llama models working with GCP. This currently includes:
* Examples for running Llama 4 model inference on Vertex's serverless API offerings (aka. MaaS)
  * tool calling
  * JSON mode (structured outputs)
