In this folder, we show various recipes for Llama models working with Azure AI services. This includes:
* Examples for running Llama model inference on Azure's serverless API offerings (aka. MaaS)
