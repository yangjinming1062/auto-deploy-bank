DIFFLOG:
<!-- markdown-link-check-disable -->
Nested Folders rename:
- /recipes/3p_integrations -> /3p-integrations
- /recipes/quickstart -> /getting-started
- /recipes/responsible_ai -> /end-to-end-use-cases/responsible_ai
- /recipes/use_cases -> /end-to-end-use-cases
- /quickstart/agents -> /end-to-end-use-cases/agents 
- /quickstart/NotebookLlama -> /end-to-end-use-cases/NotebookLlama
- /quickstart/responsible_ai -> /end-to-end-use-cases/responsible_ai
- /recipes/use_cases/end-toend/RAFT-Chatbot -> /end-to-end-use-cases/RAFT-Chatbot
- /docs -> /src/docs/
- /dev_requirements.txt -> /src/dev_requirements.txt
- /requirements.txt -> /src/requirements.txt
- /tools -> /end-to-end-use-cases/benchmarks/ 
- /recipes/experimental/long_context -> /end-to-end-use-cases/long_context


Removed folders:
- /flagged (Empty folder)
- /recipes/quickstart/Running_Llama3_Anywhere (Redundant code)
- /recipes/quickstart/inference/codellama (deprecated model)
- /recipes/quickstart/getting-to-know-llama-3.ipynb
<!-- markdown-link-check-enable -->
