#!/bin/bash
python -m eval.eval_sync_conf --video_path "video_out.mp4"
