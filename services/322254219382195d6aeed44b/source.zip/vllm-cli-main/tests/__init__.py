"""Test suite for vLLM CLI."""
