package com.netflix.ndbench.aws.config;

import org.junit.Test;


public class NdbenchAWSCredentialProviderTest {
    @Test
    public void testDefaults() {

    }
}
