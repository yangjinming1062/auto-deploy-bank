NDBench AWS
===================

This module helps implementing/deploying ndbench in AWS environment. All AWS specific implementations
in NDBench goes in this project, example of such services are ASGDiscovery, AWSCredentialProvider etc.,