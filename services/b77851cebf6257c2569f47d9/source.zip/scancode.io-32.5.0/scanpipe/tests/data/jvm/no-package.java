
public class Foo {}
