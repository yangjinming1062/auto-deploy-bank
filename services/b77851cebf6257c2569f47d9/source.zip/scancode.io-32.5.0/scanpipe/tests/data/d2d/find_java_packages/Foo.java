package org.apache.foo;

class Foo {}