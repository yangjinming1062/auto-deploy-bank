The image is created with the test tar from container-inspector::

    docker build --tag minitag .
    docker save minitag > minitag.tar