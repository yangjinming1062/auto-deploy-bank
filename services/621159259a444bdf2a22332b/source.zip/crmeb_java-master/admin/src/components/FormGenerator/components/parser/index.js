import Parser from './Parser'

export default Parser
