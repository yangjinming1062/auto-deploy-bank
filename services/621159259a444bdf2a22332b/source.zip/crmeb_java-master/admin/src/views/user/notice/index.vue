<template>
  <div>
    用户通知
  </div>
</template>

<script>
export default {

}
</script>

<style lang="sass" scoped>

</style>>
