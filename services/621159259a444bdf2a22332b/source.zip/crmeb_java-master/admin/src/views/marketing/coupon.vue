<template>
  <div>
    营销
  </div>
</template>

<script>
export default {

}
</script>

<style lang="sass" scoped>

</style>
