<template>
  <div>
    优惠券模板
  </div>
</template>

<script>
export default {

}
</script>

<style lang="sass" scoped>

</style>
