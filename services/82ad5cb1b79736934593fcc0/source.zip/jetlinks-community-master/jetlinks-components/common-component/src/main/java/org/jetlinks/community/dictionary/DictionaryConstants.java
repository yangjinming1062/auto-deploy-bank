package org.jetlinks.community.dictionary;

public interface DictionaryConstants {

    /**
     * 系统分类标识
     */
    String CLASSIFIED_SYSTEM = "system";
}
