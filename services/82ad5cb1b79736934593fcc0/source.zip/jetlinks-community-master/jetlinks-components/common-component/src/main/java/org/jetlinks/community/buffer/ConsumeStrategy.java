package org.jetlinks.community.buffer;

public enum ConsumeStrategy {

    // 先进先出
    FIFO,

    // 后进先出
    LIFO
}
