package org.jetlinks.community.buffer;

public interface MemoryUsage {

    int usage();

}
