package org.jetlinks.community.gateway;

public enum GatewayState {
    starting,
    started,
    paused,
    shutdown
}
