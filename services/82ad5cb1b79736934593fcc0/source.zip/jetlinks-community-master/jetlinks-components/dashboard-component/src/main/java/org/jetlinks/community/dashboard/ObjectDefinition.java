package org.jetlinks.community.dashboard;

public interface ObjectDefinition extends Definition {

}