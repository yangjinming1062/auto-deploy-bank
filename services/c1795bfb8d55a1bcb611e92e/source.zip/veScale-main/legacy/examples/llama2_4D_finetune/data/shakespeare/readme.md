
# tiny shakespeare

Tiny shakespeare, of the good old char-rnn fame :)

After running `prepare.py`:

- train.bin has 318,905 tokens
- val.bin has 37,782 tokens
