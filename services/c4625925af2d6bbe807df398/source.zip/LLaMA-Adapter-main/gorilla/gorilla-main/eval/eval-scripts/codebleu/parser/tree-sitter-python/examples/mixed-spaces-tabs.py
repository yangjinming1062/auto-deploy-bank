def main():
	print "hello"
	# 1 tab = 8 spaces in Python 2
        return
