git clone https://github.com/tree-sitter/tree-sitter-python
pip install tree_sitter
python build.py
