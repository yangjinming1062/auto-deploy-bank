---
name: Feature request
about: Suggest an idea for this project
title: "[feature] "
labels: enhancement
assignees: ''

---

**Is the feature request related to a problem?**
Ex. I'm like to see [...] 

**Describe the solution you'd like**
When I run [X], I want to see [Y]

**Additional context**
Add any other context or screenshots about the feature request here.
