---
name: APIBench
about: Create a report to help us improve APIBench
title: "[Apibench] "
labels: apibench-data
assignees: ''

---

**Describe the issue**
A clear and concise description of what the issue is.

**ID datapoint**
1. Datapoint permalink: (If more than one, include as a python list of strings)
2. Provider: TorchHub/HuggingFace/PyTorch Hub
2. Gorilla repo commit #: 

**What is the issue**

**Proposed Changes**

{
 'previous_datapoint':[], 
 'updated_datapoint':[]
}

**Additional context**
Add any other context about the problem here.
