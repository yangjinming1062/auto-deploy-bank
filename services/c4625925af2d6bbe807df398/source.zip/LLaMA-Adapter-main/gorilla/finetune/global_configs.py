tokenizer_path = '/data1/llma/tokenizer.model'
petrel_conf = "/mnt/petrelfs/share_data/gaopeng/ldy/petreloss_all.conf"
petrel_prefix = "cluster_p_ssd:s3://falcon-refinedweb/data"
data_meta_path = "/mnt/petrelfs/share_data/gaopeng/ldy/falcon_list.json"
