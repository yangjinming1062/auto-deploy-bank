# API平台

## 简介
![Home](./public/readme/home.png)
![Home](./public/readme/apilist.png)
![Home](./public/readme/apiindex.png)
![Home](./public/readme/apitest.png)
![Home](./public/readme/project.png)
![Home](./public/readme/addapi.png)
![Home](./public/readme/detail.png)
![Home](./public/readme/markdown.png)
![Home](./public/readme/text.png)

### 安装依赖
```
npm install
```

### 本地服务
```
npm run serve
```

### 编译发布
```
npm run build
```

