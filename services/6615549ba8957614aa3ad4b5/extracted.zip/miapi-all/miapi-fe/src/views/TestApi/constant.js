export const RADIO_TYPE = {
  FORM: 'form',
  RAW: 'raw'
}

export const DEFAULT_HEADER = {
  'Content-Type': 'application/x-www-form-urlencoded',
  // 'Accept-Encoding': 'gzip, deflate',
  'Connection': 'keep-alive'
  // 'Accept': 'application/json, text/plain, */*',
  // 'Accept-Language': 'zh-CN,zh;q=0.9'
}
