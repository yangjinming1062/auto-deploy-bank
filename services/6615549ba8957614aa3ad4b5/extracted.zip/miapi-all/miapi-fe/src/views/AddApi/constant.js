import i18n from '../../lang'

export const RADIO_BTN = [{
  name: i18n.t('importFromProject'),
  value: false
}, {
  name: i18n.t('addManully'),
  value: true
}]
