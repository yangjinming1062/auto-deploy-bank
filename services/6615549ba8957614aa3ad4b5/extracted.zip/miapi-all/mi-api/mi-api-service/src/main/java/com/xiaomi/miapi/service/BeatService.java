package com.xiaomi.miapi.service;


import com.xiaomi.miapi.api.service.bo.BeatInfo;

public interface BeatService {
    void beat(BeatInfo beatInfo);
}
