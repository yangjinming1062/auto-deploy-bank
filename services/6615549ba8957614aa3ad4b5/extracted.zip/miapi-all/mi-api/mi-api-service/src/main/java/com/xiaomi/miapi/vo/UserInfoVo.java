package com.xiaomi.miapi.vo;

import com.xiaomi.youpin.hermes.bo.response.Account;


public class UserInfoVo extends Account {
}
