package com.xiaomi.mock.bo;

import lombok.Data;

@Data
public class EnableMockBo {
    String mockExpID;
    Integer enable;
}
