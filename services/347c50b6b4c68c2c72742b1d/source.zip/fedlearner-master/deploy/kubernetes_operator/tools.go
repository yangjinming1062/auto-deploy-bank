// +build codegen

package main

import _ "k8s.io/code-generator"
