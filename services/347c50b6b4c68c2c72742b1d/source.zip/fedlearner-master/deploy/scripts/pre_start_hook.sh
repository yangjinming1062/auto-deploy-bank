#!/bin/bash

python -c 'from fedlearner.common.hooks import pre_start_hook; pre_start_hook()'
