package datadog.trace.bootstrap.instrumentation.decorator

class OrmClientDecoratorTest extends DatabaseClientDecoratorTest {

  def "test onOperation #testName"() {
    setup:
    decorator = newDecorator({ e -> entityName })

    when:
    decorator.onOperation(span, entity)

    then:
    if (isSet) {
      1 * span.setResourceName(entityName)
    }
    0 * _

    where:
    testName          | entity     | entityName | isSet
    "null entity"     | null       | "name"     | false
    "null entityName" | "not null" | null       | false
    "name set"        | "not null" | "name"     | true
  }


  def newDecorator(name) {
    return new OrmClientDecorator() {
        @Override
        String entityName(Object entity) {
          return name.call(entity)
        }

        @Override
        protected String dbType() {
          return "test-db"
        }

        @Override
        protected String dbUser(Object o) {
          return "test-user"
        }

        @Override
        protected String dbInstance(Object o) {
          return "test-user"
        }

        @Override
        protected String dbHostname(Object o) {
          return "test-hostname"
        }

        @Override
        protected String service() {
          return "test-service"
        }

        @Override
        protected String[] instrumentationNames() {
          return ["test1"]
        }

        @Override
        protected CharSequence spanType() {
          return "test-type"
        }

        @Override
        protected CharSequence component() {
          return "test-component"
        }
      }
  }
}
