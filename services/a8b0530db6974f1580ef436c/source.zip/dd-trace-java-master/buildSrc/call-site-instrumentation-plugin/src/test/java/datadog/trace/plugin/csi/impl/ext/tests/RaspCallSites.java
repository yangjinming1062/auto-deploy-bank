package datadog.trace.plugin.csi.impl.ext.tests;

public interface RaspCallSites {}
