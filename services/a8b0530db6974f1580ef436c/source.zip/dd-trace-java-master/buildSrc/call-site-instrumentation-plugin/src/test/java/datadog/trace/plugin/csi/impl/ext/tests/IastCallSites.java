package datadog.trace.plugin.csi.impl.ext.tests;

public interface IastCallSites {

  interface HasTelemetry {
    void setVerbosity(Object verbosity);
  }
}
