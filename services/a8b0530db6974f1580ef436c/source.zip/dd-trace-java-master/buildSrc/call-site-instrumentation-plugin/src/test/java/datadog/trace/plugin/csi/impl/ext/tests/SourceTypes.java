package datadog.trace.plugin.csi.impl.ext.tests;

public class SourceTypes {

  public static final byte REQUEST_HEADER_NAME = 3;

  public static final byte REQUEST_BODY = 127;
}
