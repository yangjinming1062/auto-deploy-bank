#!/bin/bash
source "$(dirname "$0")/../env.sh"
testworkflow create
