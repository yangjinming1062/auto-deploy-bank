package datadog.communication.serialization;

public interface WritableFormatter extends Writable, MessageFormatter {}
