

1. read the brief about the book: Building LLM from Scratch
2. upload this book in NotbookLM by Google
3. ask this question: "can you give me a brief about all the steps I need to take to build LLMs from scratch?"
4. go to chatGPT to create a prompt for building the project
5. use those 3 stages of prompts and put them in Grok one by one. (check those steps here: https://grok.com/share/bGVnYWN5_81a64be9-1872-4c70-a795-e5edd8e39842
6. use the steps to build your project in VS code.

7. stage 2 and stage 3


# steps to run

1. scipts/train.py



# Assignment
1. complete the project
2. create a flow diagram of building LLM
3. integrate a front end to display the flow of building LLM
4. create  repo on your github and push the code there
5. post a simple demo on linkedin