
1. read the brief about the book: Building LLM from Scratch
2. upload this book in NotbookLM by Google
3. ask this question: "can you give me a brief about all the steps I need to take to build LLMs from scratch?"
4. go to chatGPT to create a prompt for building the project
5. use those 3 stages of prompts and put them in Grok one by one. (check those steps here: https://grok.com/share/bGVnYWN5_576d166e-264d-41ef-a50d-eacf9d953c60)
6. use the steps to build your project in VS code.
