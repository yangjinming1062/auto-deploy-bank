Agent - Simple Financial Research Agent

- setup env
- install langchain and other frameworks or libraries
