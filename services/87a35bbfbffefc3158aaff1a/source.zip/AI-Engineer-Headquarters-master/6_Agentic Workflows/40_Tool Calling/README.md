

- [Tool Use] Allowing LLMs to Interact with the Real World
- [Function Calling] How Modern LLMs Use Tools
- [Custom Tools] Giving an Agent New Superpowers

agent.py

- calling a calculator
- fetching data from sources the llm is not trained on
- external interaction - browse web, execute code, interact with database etc



# task
"Plan a weekend trip to a european city for two people, including flight, hotel, local activities, given a budget of $1500 and starting from India"

- flight search API
- hotel booking API
- activity/attraction API
- weather API
- budget calculator
- calender tool
