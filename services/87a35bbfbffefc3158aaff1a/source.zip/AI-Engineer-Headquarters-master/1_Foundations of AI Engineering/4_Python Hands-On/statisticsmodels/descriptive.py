import math

class Descript:

    def mean(self, data):
        return sum(data) / len(data)
    
    def mode(self, data):
        return "mode: " + str(data)