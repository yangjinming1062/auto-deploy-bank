msg = "Indore is the Best City in India"

def vijay():
    return "Vijay is the Best"

def nagar(n):
    return n + "Nagar is the Best"