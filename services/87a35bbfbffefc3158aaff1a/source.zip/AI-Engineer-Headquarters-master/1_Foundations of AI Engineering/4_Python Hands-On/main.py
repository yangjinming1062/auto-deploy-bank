# import indore

# print(indore.msg)

# print(indore.vijay())


# import statisticsmodels

from statisticsmodels import descriptive

object = descriptive.Descript()

print(object.mean([1,2,3,4,5]))