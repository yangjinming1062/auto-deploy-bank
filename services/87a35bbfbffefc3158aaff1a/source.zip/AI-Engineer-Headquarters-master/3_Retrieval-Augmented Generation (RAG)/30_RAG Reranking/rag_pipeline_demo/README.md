
## Advanced RAG

- basic RAG
- reranking RAG
- structured RAG