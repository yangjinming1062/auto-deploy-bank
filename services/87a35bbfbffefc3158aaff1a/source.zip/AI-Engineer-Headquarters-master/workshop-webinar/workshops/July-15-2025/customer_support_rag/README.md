# Production ready RAG for Customer Support Automation





conda create -n rag_env python=3.9
conda activate rag_env

pip install unstructured sentence-transformers faiss-cpu ragas pandas numpy requests fastapi uvicorn jinja2 huggingface-hub rank-bm25


