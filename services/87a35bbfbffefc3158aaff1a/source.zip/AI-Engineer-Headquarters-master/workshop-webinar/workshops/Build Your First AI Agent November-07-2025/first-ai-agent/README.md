Building First AI Agent

steps
- create an environment
- install google-generativeai for llm calls as its python SDK by gemini
- env file - hold the api key from gemini