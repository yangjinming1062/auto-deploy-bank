- Perplexity [language modeling], BERTScore [semantic similarity]
- [Hands-On] Evaluating LLama
- [Hands-On] Fine-tuning job cost estimate using Azure ML pricing calculator


Perplexity [the confusion metric]
- how well a language model predicts a sequence of text

- lower Perplexity - model finds the text more predictable

The cat sat on the _____
"mat" - high confidence (low surprise, low ppl [Perplexity])

how condused the model is on real world text

BERTScore [the meaning metric]

- it measures semantic similarity between generated text(candidate) and reference text (ground truth)