/* 
 * Copyright (C) 2015 Information Retrieval Group at Universidad Autónoma
 * de Madrid, http://ir.ii.uam.es
 *
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/.
 */
package org.ranksys.formats.rec;

import es.uam.eps.ir.ranksys.core.Recommendation;

import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UncheckedIOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.function.Consumer;
import java.util.function.Supplier;
import java.util.stream.Stream;

/**
 * Recommendation writers and readers with a common format.
 *
 * @param <U> type of the users
 * @param <I> type of the items
 * @author Saúl Vargas (saul.vargas@uam.es)
 */
public interface RecommendationFormat<U, I> {

    /**
     * Gets a writer for a file path.
     *
     * @param path file path
     * @return a recommendation writer
     * @throws IOException if path does not exist or IO error
     */
    default Writer<U, I> getWriter(Path path) throws IOException {
        return getWriter(Files.newOutputStream(path));
    }

    /**
     * Gets a writer for a file path.
     *
     * @param path file path
     * @return a recommendation writer
     * @throws IOException if path does not exist or IO error
     */
    default Writer<U, I> getWriter(String path) throws IOException {
        return getWriter(new File(path));
    }

    /**
     * Gets a writer for a file.
     *
     * @param file file
     * @return a recommendation writer
     * @throws IOException if path does not exist or IO error
     */
    default Writer<U, I> getWriter(File file) throws IOException {
        return getWriter(new FileOutputStream(file));
    }

    /**
     * Gets a writer for an output stream.
     *
     * @param out output stream
     * @return a recommendation writer
     * @throws IOException if path does not exist or IO error
     */
    Writer<U, I> getWriter(OutputStream out) throws IOException;

    /**
     * Recommendation writer.
     *
     * @param <U> type of the users
     * @param <I> type of the items
     */
    interface Writer<U, I> extends Closeable, Consumer<Recommendation<U, I>> {

        /**
         * Writes the recommendation.
         *
         * @param recommendation to be written
         * @throws IOException when IO error
         */
        void write(Recommendation<U, I> recommendation) throws IOException;

        @Override
        default void accept(Recommendation<U, I> recommendation) {
            try {
                write(recommendation);
            } catch (IOException ex) {
                throw new UncheckedIOException(ex);
            }
        }

    }

    /**
     * Gets a reader for a file path.
     *
     * @param path file path
     * @return a recommendation reader
     * @throws IOException when IO error
     */
    default Reader<U, I> getReader(Path path) throws IOException {
        return getReader(Files.newInputStream(path));
    }

    /**
     * Gets a reader for a file path.
     *
     * @param path file path
     * @return a recommendation reader
     * @throws IOException when IO error
     */
    default Reader<U, I> getReader(String path) throws IOException {
        return getReader(new File(path));
    }

    /**
     * Gets a reader for a file.
     *
     * @param file file
     * @return a recommendation reader
     * @throws IOException when IO error
     */
    default Reader<U, I> getReader(File file) throws IOException {
        return getReader(new FileInputStream(file));
    }

    /**
     * Gets a reader for an input stream.
     *
     * @param in input stream
     * @return a recommendation reader
     * @throws IOException when IO error
     */
    Reader<U, I> getReader(InputStream in) throws IOException;

    /**
     * Recommendation reader.
     *
     * @param <U> type of the users
     * @param <I> type of the items
     */
    interface Reader<U, I> extends Supplier<Stream<Recommendation<U, I>>> {

        /**
         * Reads all recommendations.
         *
         * @return a stream of recommendations
         */
        Stream<Recommendation<U, I>> readAll();

        @Override
        default Stream<Recommendation<U, I>> get() {
            return readAll();
        }

    }
}
