from promptda.utils.logger import Log


def main():
    pass


if __name__ == "__main__":
    main()
