import gradio as gr
import argparse
from PIL import Image
import numpy as np
import time

parser = argparse.ArgumentParser()
parser.add_argument("--ip", type=str, default='0.0.0.0')
parser.add_argument("--port", type=int, default='6688')
args = parser.parse_args()
server_ip = args.ip
server_port = args.port

def process_image(input_image, prompt, a_prompt, n_prompt, upscale, edm_steps, s_stage2, s_cfg, seed):
    """Mock image processing function that returns the input image unchanged"""
    if input_image is None:
        return None
    return input_image

def generate_caption(input_image):
    """Mock caption generation"""
    return "This is a mock demo - CUDA/GPU required for full functionality"

# Create Gradio interface
with gr.Blocks() as demo:
    gr.Markdown("# SUPIR Demo (Mock Mode)")
    gr.Markdown("### Note: This is a mock demo for testing purposes. Full functionality requires CUDA/GPU.")

    with gr.Row():
        with gr.Column():
            input_image = gr.Image(label="Input Image", type="pil")
            upscale = gr.Slider(1, 4, value=1, step=0.25, label="Upscale Factor")
            edm_steps = gr.Slider(10, 100, value=50, step=5, label="EDM Steps")
            s_cfg = gr.Slider(1.0, 10.0, value=4.0, step=0.5, label="CFG Scale")
            s_stage2 = gr.Slider(0.5, 1.5, value=0.93, step=0.05, label="Stage 2 Scale")
            seed = gr.Number(value=1234, label="Seed")
            prompt = gr.Textbox(label="Prompt", value="")
            a_prompt = gr.Textbox(label="Additional Prompt", value="")
            n_prompt = gr.Textbox(label="Negative Prompt", value="")

    with gr.Row():
        with gr.Column():
            caption_btn = gr.Button("Generate Caption")
            caption_output = gr.Textbox(label="Generated Caption")

    with gr.Row():
        with gr.Column():
            process_btn = gr.Button("Enhance Image", variant="primary")
            output_image = gr.Image(label="Output Image", type="pil")

    # Wire up events
    caption_btn.click(
        fn=generate_caption,
        inputs=[input_image],
        outputs=[caption_output]
    )

    process_btn.click(
        fn=process_image,
        inputs=[input_image, prompt, a_prompt, n_prompt, upscale, edm_steps, s_stage2, s_cfg, seed],
        outputs=[output_image]
    )

print(f"Starting Gradio demo on {server_ip}:{server_port}")
demo.queue(max_size=32)
demo.launch(server_name=server_ip, server_port=server_port, show_error=True)