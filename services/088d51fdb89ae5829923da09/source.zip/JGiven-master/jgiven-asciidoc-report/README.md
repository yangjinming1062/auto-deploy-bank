# AsciiDoc Report

This plug-in will generate test reports in the [AsciiDoc](https://asciidoc.org/) format.
It thus combines the simplicity of plain text with lean markup elements for structure, links etc.
Easily convertible to formats like HTML or PDF.
