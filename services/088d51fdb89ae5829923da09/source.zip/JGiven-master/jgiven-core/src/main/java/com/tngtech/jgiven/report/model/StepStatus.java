package com.tngtech.jgiven.report.model;

public enum StepStatus {
    PASSED,
    FAILED,
    SKIPPED,
    PENDING,
    ABORTED
}
