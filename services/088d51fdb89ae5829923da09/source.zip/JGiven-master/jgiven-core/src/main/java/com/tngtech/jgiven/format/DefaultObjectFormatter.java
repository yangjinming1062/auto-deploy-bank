package com.tngtech.jgiven.format;

/**
 * A default formatter for {@code Object} types
 */
public class DefaultObjectFormatter extends DefaultFormatter<Object> {
}
