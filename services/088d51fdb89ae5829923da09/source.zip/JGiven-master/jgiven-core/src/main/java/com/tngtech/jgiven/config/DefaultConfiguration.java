package com.tngtech.jgiven.config;

public final class DefaultConfiguration extends AbstractJGivenConfiguration {

    @Override
    public void configure() {}

}
