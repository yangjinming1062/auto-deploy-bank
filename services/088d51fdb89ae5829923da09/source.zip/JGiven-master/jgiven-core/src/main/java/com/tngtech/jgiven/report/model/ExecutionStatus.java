package com.tngtech.jgiven.report.model;

public enum ExecutionStatus {
    SCENARIO_PENDING,
    SUCCESS,
    FAILED,
    ABORTED,
    SOME_STEPS_PENDING
}
