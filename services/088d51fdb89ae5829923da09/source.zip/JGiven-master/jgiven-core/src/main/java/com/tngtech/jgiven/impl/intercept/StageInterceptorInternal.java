package com.tngtech.jgiven.impl.intercept;

public interface StageInterceptorInternal {
    void __jgiven_setStepInterceptor( StepInterceptor stepInterceptor );
}
