package com.tngtech.jgiven.integration;

public interface CanWire {
    void wire( Object o );
}
