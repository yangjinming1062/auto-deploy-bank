package com.tngtech.jgiven.examples.userguide;

import com.tngtech.jgiven.annotation.ScenarioState;

public class RocketSimulator {


    public boolean launchRocket() {
        return true;
    }

}
