package com.tngtech.jgiven.examples.userguide;

import com.tngtech.jgiven.Stage;
// tag::noPackage[]
public class GivenAdditionalState extends Stage<GivenAdditionalState>{

    public void some_additional_state() {
        
    }

}
// end::noPackage[]