package com.tngtech.jgiven.examples.userguide;

public class Customer {

    
    
    private String name;

    public Customer(String name) {
        this.name = name;
    }

}
