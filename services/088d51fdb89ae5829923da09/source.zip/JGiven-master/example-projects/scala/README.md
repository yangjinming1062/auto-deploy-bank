# JGiven with Scala

Execute the tests and generate the HTML report:
```
sbt test jgivenReport
```

Report default location is `target/jgiven-reports/html`.
