# Android Project

This project shows how to use JGiven for testing Android applications together with the Espresso framework.

## Setup

1. Install Android SDK
2. Start an Android Emulator
3. Execute `./gradlew connectedAndroidTest`
4. Open `build/reports/jgiven/html/index.html` with a browser

