# JGiven with Spring Boot

This project shows how to use JGiven with Spring Boot

1. Run `./gradlew build`
2. Open `build/reports/jgiven/test/html/index.html`

