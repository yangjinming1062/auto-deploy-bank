# Kotlin JUnit 5 Example Project

This project shows how JGiven can be used with Kotlin and JUnit 5

1. Run `../../gradlew build`
2. Open `build/reports/jgiven/test/html/index.html`
