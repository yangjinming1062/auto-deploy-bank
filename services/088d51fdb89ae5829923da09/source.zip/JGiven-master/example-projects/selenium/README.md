# Selenium Example Project

This project shows how Selenium can be used together with JGiven
1. Ensure Google Chrome is installed on your machine,
2. Run `gradle build`
3. Open `build/reports/jgiven/test/html/index.html`
