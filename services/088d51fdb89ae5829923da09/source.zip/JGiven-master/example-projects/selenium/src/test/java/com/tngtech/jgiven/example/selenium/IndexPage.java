package com.tngtech.jgiven.example.selenium;

import org.openqa.selenium.WebElement;

public class IndexPage {

    WebElement title;

    WebElement clickMeBtn;

}
