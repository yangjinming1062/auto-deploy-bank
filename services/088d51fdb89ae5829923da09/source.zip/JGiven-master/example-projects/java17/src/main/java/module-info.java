module jgiven.exampleprojects.java17 {
    exports com.tngtech.jgiven.exampleprojects.java17;
    requires java.base;
}