package com.tngtech.jgiven.spock.stages

import com.tngtech.jgiven.Stage

class When extends Stage<When> {

    When some_action() {
        return self()
    }
}
