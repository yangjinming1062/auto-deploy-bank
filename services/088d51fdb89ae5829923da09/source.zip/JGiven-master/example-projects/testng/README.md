# TestNG Example Project

This project shows how JGiven can be used with TestNG

1. Run `../../gradlew build`
2. Open `build/reports/jgiven/test/html/index.html`
