This subproject contains tests that make use of Java 8 features such as lambdas.
This project is only built when using Java 8.
