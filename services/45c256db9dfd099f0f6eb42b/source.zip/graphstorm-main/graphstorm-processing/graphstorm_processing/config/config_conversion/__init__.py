"""
This module contains the classes to convert different specifications to GSProcessing
"""

from .gconstruct_converter import GConstructConfigConverter
