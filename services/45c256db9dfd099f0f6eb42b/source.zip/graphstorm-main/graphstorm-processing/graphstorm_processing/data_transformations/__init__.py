"""
We use this module for top-level data transformations.
The goal is to be able to easily add new data transformations without
changing the code of the main processing module.
"""
