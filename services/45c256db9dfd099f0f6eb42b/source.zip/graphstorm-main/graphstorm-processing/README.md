# GraphStorm Distributed Processing

This library enables distributed pre-processing of
graph data that can then be fed into a
GraphStorm distributed training pipeline.
