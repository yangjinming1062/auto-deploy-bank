cd /usr/lib/spark/graphstorm/graphstorm-processing/
pip install .
python3 -m pytest .

