This folder contains the scripts that augment the MovieLens dataset for the end-to-end tests.
* gen\_multi\_feat\_nc.py: This renames node features so that node features on different node types have different feature names.
* gen\_multilabel.py: This generates fake multi-labels on each node.
* remove\_mask.py: This removes the training/val/test masks on the dataset.
