from .oneshot import OneShotPredictor
