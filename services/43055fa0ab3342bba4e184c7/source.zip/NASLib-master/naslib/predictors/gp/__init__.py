from .gp_base import BaseGPModel
from .gp import GPPredictor
from .sparse_gp import SparseGPPredictor
from .var_sparse_gp import VarSparseGPPredictor
from .gpwl import GPWLPredictor
