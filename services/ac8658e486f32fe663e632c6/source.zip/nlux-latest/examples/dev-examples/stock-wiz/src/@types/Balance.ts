export type Balance = {
    investedAmount: number;
    currentValue: number;
};
