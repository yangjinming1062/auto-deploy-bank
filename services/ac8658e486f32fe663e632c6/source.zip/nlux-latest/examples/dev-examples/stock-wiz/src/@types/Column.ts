export type Column = {
    field: string;
    name: string;
    width?: number | string;
};
