import {getSharedViteConfig} from '../../sharedViteConfig';

export default getSharedViteConfig(
    '../../../..',
    true,
    [],
);
