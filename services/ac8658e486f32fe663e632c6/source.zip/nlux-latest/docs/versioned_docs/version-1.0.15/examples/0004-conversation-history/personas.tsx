export default `export const personaOptions = {
  bot: {
    name: 'FeatherBot',
    picture: 'https://nlux.ai/images/demos/persona-feather-bot.png',
    tagline: 'Yer AI First Mate!',
  },
  user: {
    name: 'Alex',
    picture: 'https://nlux.ai/images/demos/persona-user.jpeg'
  }
};`;
