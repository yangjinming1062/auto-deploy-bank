export default `export const botStyle = {
  background: 'linear-gradient(yellow, orange)',
  fontSize: '1.5rem',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
};

export const user = {
  name: 'Alex',
  picture: 'https://nlux.ai/images/demos/persona-user.jpeg'
};
`;
