export default `export const user = {
  name: 'Alex',
  picture: 'https://nlux.ai/images/demos/persona-user.jpeg'
};`;
