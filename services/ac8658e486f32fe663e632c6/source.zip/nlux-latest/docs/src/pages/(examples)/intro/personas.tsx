export default `import {PersonaOptions, UserPersona} from '@nlux/react';

export const user: UserPersona = {
  name: 'Alex',
  avatar: 'https://docs.nlkit.com/nlux/images/personas/alex.png'
};

export const assistantAvatar = 'https://docs.nlkit.com/nlux/images/personas/albert.png';
`;
