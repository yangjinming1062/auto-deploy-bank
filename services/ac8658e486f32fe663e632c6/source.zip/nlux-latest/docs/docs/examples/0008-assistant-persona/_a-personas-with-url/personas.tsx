export default `export const user = {
  name: 'Alex',
  avatar: 'https://docs.nlkit.com/nlux/images/personas/alex.png'
};`;
