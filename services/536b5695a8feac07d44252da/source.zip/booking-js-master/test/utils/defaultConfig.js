'use strict';

// Default config used across tests
module.exports = {
  app_key: '12345'
}
