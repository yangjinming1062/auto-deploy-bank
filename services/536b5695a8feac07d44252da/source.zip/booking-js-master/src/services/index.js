
'use strict';

module.exports = require('./widget');