// InteractiveConfigDefault.d.ts
import { InteractiveConfig } from './InteractiveConfigContext';

declare const InteractiveConfigDefault: InteractiveConfig;
export = InteractiveConfigDefault;
