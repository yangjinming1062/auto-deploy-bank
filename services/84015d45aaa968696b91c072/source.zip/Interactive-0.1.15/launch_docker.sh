#!/bin/sh
docker-compose down
docker-compose pull
docker-compose up
