service HelloWorld {
    string hello(1:string LUCID);
}
