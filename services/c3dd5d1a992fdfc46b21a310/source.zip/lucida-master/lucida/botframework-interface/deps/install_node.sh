#!/bin/bash

sudo apt-get install npm && sudo npm install -g n && sudo n lts
