#!/bin/bash
javac -cp .:../../../../lib/nlp/snowball.jar SnowballStemmer.java
mv SnowballStemmer.class ../../../../bin/info/ephyra/nlp/
