# Lucida

This directory contains all the back-end services and the command center.
Only `make` when you already install all the dependencies specified in `../tools`.
