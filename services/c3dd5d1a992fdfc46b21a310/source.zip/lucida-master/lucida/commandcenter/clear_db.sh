mongo
use lucida
db.text_yba.drop()
db.images_yba.drop()
db.fs.files.find() # opencv
db.fs.files.drop() # opencv
db.dropDatabase()
exit
