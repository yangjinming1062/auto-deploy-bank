``sockjs.tornado.transports.base``
==================================

.. automodule:: sockjs.tornado.transports.base

.. autoclass:: BaseTransportMixin

    .. automethod:: get_conn_info
    .. automethod:: session_closed
