``sockjs.tornado.transports.xhr``
=================================

.. automodule:: sockjs.tornado.transports.xhr

.. autoclass:: XhrPollingTransport

    .. automethod:: post
    .. automethod:: send_pack

.. autoclass:: XhrSendHandler

    .. automethod:: post
