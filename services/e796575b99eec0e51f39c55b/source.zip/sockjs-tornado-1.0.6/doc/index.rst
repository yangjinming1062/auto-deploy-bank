sockjs-tornado
==============

This is implementation of the `SockJS <http://github.com/sockjs/>`_ realtime
transport library on top of the `Tornado <http://www.tornadoweb.org>`_ framework.


Topics
------

.. toctree::
   :maxdepth: 2

   stats
   faq
   api


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
