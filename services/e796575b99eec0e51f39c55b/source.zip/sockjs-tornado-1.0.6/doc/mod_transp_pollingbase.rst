``sockjs.tornado.transports.pollingbase``
=========================================

.. automodule:: sockjs.tornado.transports.pollingbase

.. autoclass:: PollingTransportBase

    .. automethod:: send_message
    .. automethod:: session_closed
