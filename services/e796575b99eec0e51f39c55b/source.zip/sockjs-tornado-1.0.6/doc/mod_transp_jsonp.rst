``sockjs.tornado.transports.jsonp``
===================================

.. automodule:: sockjs.tornado.transports.jsonp

.. autoclass:: JSONPTransport

    .. automethod:: get
    .. automethod:: send_pack

.. autoclass:: JSONPSendHandler

    .. automethod:: post
