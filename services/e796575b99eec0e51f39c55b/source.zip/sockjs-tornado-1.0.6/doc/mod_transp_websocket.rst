``sockjs.tornado.transports.websocket``
=======================================

.. automodule:: sockjs.tornado.transports.websocket

.. autoclass:: WebSocketTransport

    .. automethod:: open
    .. automethod:: on_message
    .. automethod:: on_close
    .. automethod:: send_pack

Sessions
^^^^^^^^

    .. automethod:: WebSocketTransport.session_closed
    .. automethod:: WebSocketTransport._detach
