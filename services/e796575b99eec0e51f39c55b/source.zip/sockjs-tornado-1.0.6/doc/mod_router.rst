``sockjs.tornado.router``
=========================

.. automodule:: sockjs.tornado.router

    .. autoclass:: SockJSRouter

    .. automethod:: SockJSRouter.__init__

    URLs
    ^^^^

    .. autoattribute:: SockJSRouter.urls
    .. automethod:: SockJSRouter.apply_routes

    Connection
    ^^^^^^^^^^

    .. automethod:: SockJSRouter.get_session
    .. automethod:: SockJSRouter.get_connection_class
