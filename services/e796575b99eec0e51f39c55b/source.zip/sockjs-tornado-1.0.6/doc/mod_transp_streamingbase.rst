``sockjs.tornado.transports.streamingbase``
===========================================

.. automodule:: sockjs.tornado.transports.streamingbase

.. autoclass:: StreamingTransportBase

    .. automethod:: should_finish
    .. automethod:: session_closed

