``sockjs.tornado.transports.xhrstreaming``
==========================================

.. automodule:: sockjs.tornado.transports.xhrstreaming

.. autoclass:: XhrStreamingTransport

    .. automethod:: post
    .. automethod:: send_pack
