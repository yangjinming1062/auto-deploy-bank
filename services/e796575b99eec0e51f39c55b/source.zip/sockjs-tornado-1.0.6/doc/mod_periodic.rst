``sockjs.tornado.periodic``
===========================

.. automodule:: sockjs.tornado.periodic

.. autoclass:: Callback

    .. automethod:: __init__
    .. automethod:: calculate_next_run
    .. automethod:: start
    .. automethod:: stop
    .. automethod:: delay
