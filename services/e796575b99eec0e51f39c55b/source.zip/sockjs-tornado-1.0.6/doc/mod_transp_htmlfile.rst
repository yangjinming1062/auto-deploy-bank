``sockjs.tornado.transports.htmlfile``
======================================

.. automodule:: sockjs.tornado.transports.htmlfile

.. autoclass:: HtmlFileTransport

    .. automethod:: get
    .. automethod:: send_pack
