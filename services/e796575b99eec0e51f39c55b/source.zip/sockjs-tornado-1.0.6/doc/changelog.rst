Changelog
---------

1.0.6
-----

 - XSS security fix for the HTMLFILE transport

1.0.2
~~~~~
 - Tornado 5.x compatibility fix

1.0.1
~~~~~
 - Tornado 4.x compatibility fix

1.0.0
~~~~~
 - Major version bump. sockjs-tornado can be considered mature
 - Python 3 support
 - Tornado 3.0 support on both Python 2 and Python 3
 - Bug fixes


0.0.5
~~~~~
 - iOS 6 support
 - SockJS 0.3.3 client support
 - Some headers and request URI path is now passed to on_open handler
 - Added binary transport support for raw websocket transport
 - Minor multiplex sample fixes

0.0.4
~~~~~

 - Added support for older simplejson library versions
 - Fixed installation script

0.0.3
~~~~~

 - SockJS 0.3 support
 - Connection multiplexing sample
 - IP validation is now optional

0.0.2
~~~~~

 - SockJS 0.2 support and compatibility fixes

0.0.1
~~~~~

Initial release.
