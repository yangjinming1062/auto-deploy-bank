``sockjs.tornado.transports.eventsource``
=========================================

.. automodule:: sockjs.tornado.transports.eventsource

.. autoclass:: EventSourceTransport

    .. automethod:: get
    .. automethod:: send_pack
