``sockjs.tornado.stats``
========================

.. automodule:: sockjs.tornado.stats

    .. autoclass:: StatsCollector

        .. automethod:: dump

    .. autoclass:: MovingAverage

        .. automethod:: __init__
        .. automethod:: add
        .. automethod:: flush
