``sockjs.tornado.migrate``
==========================

.. automodule:: sockjs.tornado.migrate

    .. autoclass:: WebsocketHandler

        .. automethod:: open
        .. automethod:: on_open

