package com.cf.framework.domain.ucenter.request;

import lombok.Data;
import lombok.ToString;

/**
 * Created by mrt on 2020/3/5.
 */
@Data
@ToString
public class RequestData {
}
