package com.cf.carpark.device.camera.hk;

import com.cf.carpark.device.camera.BaseResult;
import lombok.Data;

import java.io.Serializable;

@Data
public class HkResult extends BaseResult implements Serializable {

}
