package com.cf.carpark.device.camera.HuaXia;

import java.io.Serializable;

public class TrigerData implements Serializable {

    private String action;

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }
}
