package com.cf.carpark.domain.type;

/**
 * 停车场通用配置
 */
public class CarParkConfig {

    public static final String TEMPORARY_NUMBER_PLATE = "临A88888";   //临时车牌
    public static final String TEMPORARY_NUMBER_PLATE_RELEASE = "临时车牌放行";

}
