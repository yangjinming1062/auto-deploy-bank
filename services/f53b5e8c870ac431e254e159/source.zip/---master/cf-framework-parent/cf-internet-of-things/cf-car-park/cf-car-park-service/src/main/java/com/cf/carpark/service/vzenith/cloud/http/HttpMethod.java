package com.cf.carpark.service.vzenith.cloud.http;

public enum HttpMethod {
  GET, POST, PUT, DELETE, HEAD;
}
