from flask_appbuilder import AppBuilder


appbuilder = AppBuilder()
