SQLAlchemy and Files Example
----------------------------

Simple application using file upload and download associated with projects.

Create an Admin user::

    $ fabmanager create-admin


Run it::

    $ fabmanager run


