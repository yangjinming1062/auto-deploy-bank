---
name: 提交 BUG
about: 仅提交BUG，汉化请另外开贴
title: '[Bug] '
labels: 'bug'
assignees: ''

---

- [ ] 问题1

**截图/视频**

**如何复现**


- [ ] 问题2

**截图/视频**

**如何复现**

