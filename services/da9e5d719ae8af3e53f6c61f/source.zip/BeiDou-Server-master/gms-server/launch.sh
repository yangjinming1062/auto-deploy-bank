#!/bin/sh

# cover write
./jdk-21.0.2/bin/java -Dspring.config.location=application.yml -jar BeiDou.jar &
