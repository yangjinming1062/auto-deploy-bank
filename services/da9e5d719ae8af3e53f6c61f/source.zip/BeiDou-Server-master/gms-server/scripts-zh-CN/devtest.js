function run(chr) {
    chr.message("devtest.js")
}
