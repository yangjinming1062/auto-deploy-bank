function start() {
    cm.sendNext("看起来这个地区没有什么可疑的东西。");
    cm.dispose();
}