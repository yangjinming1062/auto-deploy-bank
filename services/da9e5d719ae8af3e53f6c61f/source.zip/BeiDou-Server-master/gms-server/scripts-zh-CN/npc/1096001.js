function start() {
    cm.sendOk("我会不会完成清理呢？这艘船实在太大了…");
    cm.dispose();
}