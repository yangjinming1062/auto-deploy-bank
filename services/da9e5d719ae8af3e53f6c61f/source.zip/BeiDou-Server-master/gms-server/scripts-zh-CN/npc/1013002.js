function start() {
    cm.forceCompleteQuest(22011);
    cm.playerMessage(5, "你获得了龙蛋。");//actually getInfoMessage
    cm.warp(900090103, 0);
    cm.dispose();
}