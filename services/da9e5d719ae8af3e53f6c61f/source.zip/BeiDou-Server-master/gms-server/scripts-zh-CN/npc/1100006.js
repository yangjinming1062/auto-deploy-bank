/**
 ----------------------------------------------------------------------------------
 Skyferry Between Victoria Island, Ereve and Orbis.

 1100006 Kiru (On boat between Ereve and Orbis)

 Credits to: MapleSanta
 ----------------------------------------------------------------------------------
 **/

function start() {
    cm.sendOk("“啊，多么美好的风。只要没有愚蠢的顾客因为尝试一些奇怪的技能而掉下去，这将是一次完美的航行。当然，我说的就是你。请不要使用你的技能。”");
    cm.dispose();
}