/**
 ----------------------------------------------------------------------------------
 Skyferry Between Victoria Island, Ereve and Orbis.

 1100005 Kiriru (On boat between Ereve and Victoria Island)

 Credits to: MapleSanta
 ----------------------------------------------------------------------------------
 **/

function start() {
    cm.sendOk("天气真好。按照这个速度，我们很快就会到了……");
    cm.dispose();
}