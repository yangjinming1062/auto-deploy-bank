function start(ms) {
    ms.setDirection(0);
    ms.setDirectionStatus(true);
    ms.lockUI2();
    ms.startDirection("cannon_tuto_02");
}