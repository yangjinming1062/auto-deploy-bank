function start(ms) {
    ms.unlockUI();
    ms.mapEffect("maplemap/enter/1020000");
}