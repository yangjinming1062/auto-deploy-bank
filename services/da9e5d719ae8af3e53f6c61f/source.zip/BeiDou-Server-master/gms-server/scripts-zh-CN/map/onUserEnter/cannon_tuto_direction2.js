function start(ms) {
    ms.playSound("cannonshooter/bang");
    ms.setDirectionStatus(true);
    ms.showIntro("Effect/Direction4.img/cannonshooter/Scene01");
    ms.showIntro("Effect/Direction4.img/cannonshooter/out02");
}