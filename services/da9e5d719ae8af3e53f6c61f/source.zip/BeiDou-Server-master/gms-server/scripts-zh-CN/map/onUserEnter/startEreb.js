function start(ms) {
    if (ms.getJobId() == 1000 && ms.getLevel() >= 10) {
        ms.unlockUI();
    }
}