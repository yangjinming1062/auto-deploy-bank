function start(ms) {
    ms.getPlayer().resetEnteredScript();
    ms.spawnMonster(9300331, -28, 0);
}  