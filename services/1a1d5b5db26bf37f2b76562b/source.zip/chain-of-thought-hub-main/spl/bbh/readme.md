TODO:
* read the example prompts in `gsm8k`
* complete the standard prompts for BBH