Implementation of paper: 

Yao Fu, Hao Peng, Ashish Sabharwal, Peter Clark, Tushar Khot, _Complexity-Based Prompting for Multi-Step Reasoning_. ICLR 2023

Paths to files may be incorrect because we moved the files from other places. Yet these errors should be simple to fix if you encounter one. 

Note that `code-davinci-002` is no longer available because OpenAI stoped offerring it since April 2022. 

As of May 2023, it is recommended to start with `gpt-3.5-turbo`. For this engine we recommend use in-context learning in a dialog format. See notebook `gpt3.5turbo_gsm8k_complex.ipynb` for details. 
