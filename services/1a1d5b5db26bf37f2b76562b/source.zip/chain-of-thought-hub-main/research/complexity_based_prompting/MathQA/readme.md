We recommend start with the notebook `mathqa_chain_of_harder_thoughts_dev.ipynb` since most of the prompt engineering experiments are in there. 

The MathQA dataset can be downloaded at: https://math-qa.github.io/