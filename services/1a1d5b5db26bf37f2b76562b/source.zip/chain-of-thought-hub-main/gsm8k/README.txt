outputs/*                    
  -- outputs of all methods

codex_gsm8k_complex.ipynb
  -- code-davinci-002, complex prompts
  
gpt3.5turbo_gsm8k_complex.ipynb
  -- gpt-3.5-turbo, complex prompts