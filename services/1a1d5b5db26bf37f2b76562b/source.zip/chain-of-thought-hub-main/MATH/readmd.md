Still under construction

Dataset can be downloaded at: https://github.com/hendrycks/math