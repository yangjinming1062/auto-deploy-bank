package qunar.tc.qconfig.admin.greyrelease;

public enum MachinePushState {
    success, fail, waiting
}
