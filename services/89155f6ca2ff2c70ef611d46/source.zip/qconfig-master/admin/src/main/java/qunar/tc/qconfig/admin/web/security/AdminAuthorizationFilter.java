package qunar.tc.qconfig.admin.web.security;

/**
 * @author zhenyu.nie created on 2016 2016/6/1 15:00
 */
public class AdminAuthorizationFilter extends AuthorizationFilter {

}
