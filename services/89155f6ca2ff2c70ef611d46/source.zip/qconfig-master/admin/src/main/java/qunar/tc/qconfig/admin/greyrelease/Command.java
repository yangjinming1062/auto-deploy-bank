package qunar.tc.qconfig.admin.greyrelease;

/**
 * @author zhenyu.nie created on 2018 2018/5/21 14:50
 */
public enum Command {

    next, pause, cancel
}
