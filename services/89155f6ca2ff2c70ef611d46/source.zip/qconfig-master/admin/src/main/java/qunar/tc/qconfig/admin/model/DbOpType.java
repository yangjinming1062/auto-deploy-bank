package qunar.tc.qconfig.admin.model;

/**
 * Created by dongcao on 2018/7/7.
 */
public enum DbOpType {

    READ, WRITE, DOUBLE_READ, DOUBLE_WRITE

}
