package qunar.tc.qconfig.admin.greyrelease;

/**
 * @author zhenyu.nie created on 2018 2018/5/23 12:06
 */
public class GreyReleaseUtil {

    public static final int BASTION_BATCH_NUM = 0;

    public static final int INIT_FINISHED_BATCH_NUM = -1;

    public static final String EMPTY_UUID = "";
}
