package qunar.tc.qconfig.admin.greyrelease;

/**
 * @author zhenyu.nie created on 2018 2018/5/21 15:15
 */
public class ModificationDuringPublishingException extends RuntimeException {

    public ModificationDuringPublishingException(String message) {
        super(message);
    }
}
