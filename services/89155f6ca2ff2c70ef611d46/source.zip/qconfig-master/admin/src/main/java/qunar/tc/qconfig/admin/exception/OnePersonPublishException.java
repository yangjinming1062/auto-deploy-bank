package qunar.tc.qconfig.admin.exception;

/**
 * @author zhenyu.nie created on 2017 2017/3/22 14:36
 */
public class OnePersonPublishException extends RuntimeException {


}
