package qunar.tc.qconfig.admin.web.security;

/**
 * @author zhenyu.nie created on 2014 2014/5/30 13:27
 */
public class MdcConstants {

    public static String CORP = "corp";

    public static String USER_ID = "rtxId";

    public static String IP = "ip";
}
