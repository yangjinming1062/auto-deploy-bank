package qunar.tc.qconfig.admin.exception;

/**
 * User: zhaohuiyu
 * Date: 5/23/14
 * Time: 3:48 PM
 */
public class ModifiedException extends RuntimeException {
    private static final long serialVersionUID = -4927961429965161473L;
}
