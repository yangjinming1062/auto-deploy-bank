package qunar.tc.qconfig.admin.web.security;

/**
 * @author zhenyu.nie created on 2017 2017/10/30 19:58
 */
public class LoginAuthorizationFilter extends AuthorizationFilter {

}
