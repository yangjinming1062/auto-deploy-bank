package qunar.tc.qconfig.admin.exception;

/**
 * Created by pingyang.yang on 2018/11/14
 */
public class TemplateDealException extends RuntimeException {
}
