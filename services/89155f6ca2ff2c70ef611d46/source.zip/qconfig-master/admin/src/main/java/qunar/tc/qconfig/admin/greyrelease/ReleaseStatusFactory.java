package qunar.tc.qconfig.admin.greyrelease;

/**
 * @author zhenyu.nie created on 2018 2018/5/23 11:57
 */
public interface ReleaseStatusFactory {

    ReleaseStatus create(StatusInfo statusInfo);
}
