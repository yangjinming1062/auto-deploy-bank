package qunar.tc.qconfig.admin.exception;

/**
 * @author zhenyu.nie created on 2017 2017/5/16 20:38
 */
public class FileDeletingException extends RuntimeException {
}
