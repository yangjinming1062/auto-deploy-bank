package qunar.tc.qconfig.admin.model;

public enum EffectEnv {

    PROD, BETA, ALL;
}