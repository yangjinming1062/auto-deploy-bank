package qunar.tc.qconfig.admin.exception;

/**
 * @author zhenyu.nie created on 2016/4/5 11:48
 */
public class TemplateChangedException extends RuntimeException {
    private static final long serialVersionUID = -5666713209311411199L;
}
