package qunar.tc.qconfig.admin.service;

public interface PropertiesTemplateService {

    void setTemplate(String template);
}
