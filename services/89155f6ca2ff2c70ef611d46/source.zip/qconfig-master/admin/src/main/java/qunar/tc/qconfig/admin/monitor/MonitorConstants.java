package qunar.tc.qconfig.admin.monitor;

public class MonitorConstants {

    private static final String TYPE = "type";
    public static final String STATICS = "user_statistics";

    public static final String[] FAIL_CODE = new String[]{"code"};

    public static final String[] TYPE_TAG = new String[]{TYPE};
}
