{{ target: RectProps }}
RectProps的类型定义为：
```
interface RectProps {
  left: number;
  right: number;
  top: number;
  bottom: number;
  width: number;
  height: number;
}
```