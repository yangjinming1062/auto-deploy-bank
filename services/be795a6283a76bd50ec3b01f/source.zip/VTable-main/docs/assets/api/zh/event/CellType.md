{{ target: CellLocation }}
CellType类型定义为：
```
type CellLocation = 'body' | 'rowHeader' | 'columnHeader' | 'cornerHeader';
```