{{ target: svg-icon }}

${prefix} type ('svg')
icon内容类型为 'svg'。

${prefix} svg (string)
svg 内容。支持 svg path 或者 url。

{{ use: base-icon(
    prefix = ${prefix}
) }}