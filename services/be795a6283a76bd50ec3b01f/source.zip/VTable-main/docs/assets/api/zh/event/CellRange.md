{{ target: CellRange }}

CellRange类型定义为：
```
interface CellRange {
  start: CellAddress;
  end: CellAddress;
}
```
{{ use: CellAddress() }}