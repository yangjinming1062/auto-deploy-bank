{{ target: DrillMenuEventInfo }}
DrillMenuEventInfo类型定义为：
```
 {
  dimensionKey: string | number;
  title: string;
  drillDown: boolean;
  drillUp: boolean;
  col: number;
  row: number;
}
```