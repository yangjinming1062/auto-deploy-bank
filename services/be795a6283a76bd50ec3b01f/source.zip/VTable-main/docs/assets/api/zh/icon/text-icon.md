{{ target: text-icon }}

${prefix} type ('text')
icon 内容类型为 'text'.

${prefix} content (string)
文本内容。

{{ use: base-icon(
    prefix = ${prefix}
) }}

${prefix} style (ITextAttribute)
文本样式。[ITextAttribute](https://www.visactor.com/vrender/option/Text#attribute)
