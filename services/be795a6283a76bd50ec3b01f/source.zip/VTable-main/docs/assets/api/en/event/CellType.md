{{ target: CellLocation }}
CellLocation is defined as:
```
type CellLocation = 'body' | 'rowHeader' | 'columnHeader' | 'cornerHeader';
```