{{ target: CellRange }}

The CellRange type is defined as:
```
interface CellRange {
  start: CellAddress;
  end: CellAddress;
}
```
{{ use: CellAddress() }}