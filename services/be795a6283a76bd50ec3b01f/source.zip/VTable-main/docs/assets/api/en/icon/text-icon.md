{{ target: text-icon }}

${prefix} type ('text')
The icon content type is 'text'.

${prefix} content (string)
The content of text.

{{ use: base-icon(
    prefix = ${prefix}
) }}

${prefix} style (ITextAttribute)
The style of text. [ITextAttribute](https://www.visactor.com/vrender/option/Text#attribute)
