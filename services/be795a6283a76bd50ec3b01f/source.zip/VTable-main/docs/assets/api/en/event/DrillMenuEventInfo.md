{{ target: DrillMenuEventInfo }}
The type definition for DrillMenuEventInfo is:
```
 {
  dimensionKey: string | number;
  title: string;
  drillDown: boolean;
  drillUp: boolean;
  col: number;
  row: number;
}
```