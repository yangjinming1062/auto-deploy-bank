{{ target: RectProps }}
The type definition of RectProps is:
```
interface RectProps {
  left: number;
  right: number;
  top: number;
  bottom: number;
  width: number;
  height: number;
}
```