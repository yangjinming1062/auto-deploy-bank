{{ target: svg-icon }}

${prefix} type ('svg')
icon content type is 'svg'.

${prefix} svg (string)
svg content. Supports svg path or url.

{{ use: base-icon(
    prefix = ${prefix}
) }}