declare const __VERSION__: string;
