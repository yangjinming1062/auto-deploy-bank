# Create project

## Description

Create a project

## Usage

```bash
rush create [--name | -n] [packageName]
```

