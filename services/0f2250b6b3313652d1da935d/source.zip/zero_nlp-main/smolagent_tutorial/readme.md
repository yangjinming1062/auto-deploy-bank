## 基于smolagent做的agent教程



## selenium 爬虫（使用chrome + selenium 进行爬虫。）
1. selenium控制chrome，需要通过chrome driver进行控制。
2. chrome driver 需要从这里下载：
    1. chrome 115以下版本，从这里下载：[https://developer.chrome.com/docs/chromedriver/downloads?hl=zh-cn](https://developer.chrome.com/docs/chromedriver/downloads?hl=zh-cn)
    2. chrome 116以上版本，从这里下载：[https://googlechromelabs.github.io/chrome-for-testing/](https://googlechromelabs.github.io/chrome-for-testing/)

