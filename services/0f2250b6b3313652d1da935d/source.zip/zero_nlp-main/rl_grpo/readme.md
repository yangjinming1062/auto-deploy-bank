# grpo的代码解读

1. "trl=0.14.0"版本依赖


## 具体步骤
1. 前往trl的仓库[https://github.com/huggingface/trl](https://github.com/huggingface/trl)

2. 选择分支为"0.14-release"

3. 将里面的`trl`文件夹复制到本目录下，并把目录名称改为`trl_main`即可

4. 运行对应的sh文件，下载模型和数据: `sh dl_model.sh`；`sh dl_dataset.sh`

5. 然后使用vscode进行调试


## 更多
1. 已经上传grpo_trainer.drawio流程图，打开方式可以从这个网站下载软件[https://www.drawio.com](https://www.drawio.com)