python run.py \
    --dataset_dir \
    data/test001data \
    --cache_dir \
    cache_data \
    --output_dir \
    testoutput001 \
    --per_device_train_batch_size \
    3