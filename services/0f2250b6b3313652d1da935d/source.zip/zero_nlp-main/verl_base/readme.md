# verl 系列视频使用的代码

| 视频链接                                                                                       | 文件夹                   | 大概介绍                       |
|--------------------------------------------------------------------------------------------|-----------------------|----------------------------|
| [https://www.bilibili.com/video/BV116gozmEdn](https://www.bilibili.com/video/BV116gozmEdn) | base01_worker_and_ray | 主要是介绍verl里面的ray和worker怎么使用 |
| [https://www.bilibili.com/video/BV1gjgqzYEJ3](https://www.bilibili.com/video/BV1gjgqzYEJ3) | base02_calc_logit     | 介绍使用verl使用fsdp计算logits     |
