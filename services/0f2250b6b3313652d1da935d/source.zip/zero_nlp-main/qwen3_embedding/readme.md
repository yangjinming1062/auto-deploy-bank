## qwen3-embedding qwen3-reranker


1. 介绍qwen3的emebdding、reranker模型的原理
2. 基于ray的轻量简单的多卡部署方式