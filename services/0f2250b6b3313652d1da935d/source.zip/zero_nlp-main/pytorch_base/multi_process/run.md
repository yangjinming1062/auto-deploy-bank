```sh
torchrun --nproc_per_node=2 \
  --nnode=1 \
  
```