## 介绍pytorch的基础知识

### `multi_process`:
1. 从python多线程介绍到pytorch的多线程，了解torchun的本质
2. 在使用pytorch多线程的时候，不同线程的数据如何分发、收集。
3. 在了解pytorch的线程数据共享之后，实现一个ddp（虽然pytorch已经有ddp，但是主要从原理上再次认清这个思路）

