package com.penglecode.flink;

/**
 * @author pengpeng
 * @version 1.0
 * @since 2021/11/29 22:12
 */
public class BasePackage {
}
