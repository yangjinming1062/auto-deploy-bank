package com.bolingcavalry.customizeaware;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CustomizeawareApplication {

	public static void main(String[] args) {
		SpringApplication.run(CustomizeawareApplication.class, args);
	}
}
