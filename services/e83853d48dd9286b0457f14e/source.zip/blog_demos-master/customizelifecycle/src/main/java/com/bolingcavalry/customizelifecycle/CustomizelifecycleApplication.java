package com.bolingcavalry.customizelifecycle;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CustomizelifecycleApplication {

	public static void main(String[] args) {
		SpringApplication.run(CustomizelifecycleApplication.class, args);
	}
}
