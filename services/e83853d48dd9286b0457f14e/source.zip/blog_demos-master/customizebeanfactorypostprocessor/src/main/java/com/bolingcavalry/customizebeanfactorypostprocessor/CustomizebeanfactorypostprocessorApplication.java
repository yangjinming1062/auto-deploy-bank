package com.bolingcavalry.customizebeanfactorypostprocessor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CustomizebeanfactorypostprocessorApplication {

    public static void main(String[] args) {
        SpringApplication.run(CustomizebeanfactorypostprocessorApplication.class, args);
    }
}
