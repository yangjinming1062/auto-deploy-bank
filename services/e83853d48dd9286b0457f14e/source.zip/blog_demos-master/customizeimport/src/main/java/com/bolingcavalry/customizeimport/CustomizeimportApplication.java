package com.bolingcavalry.customizeimport;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CustomizeimportApplication {

    public static void main(String[] args) {
        SpringApplication.run(CustomizeimportApplication.class, args);
    }
}
