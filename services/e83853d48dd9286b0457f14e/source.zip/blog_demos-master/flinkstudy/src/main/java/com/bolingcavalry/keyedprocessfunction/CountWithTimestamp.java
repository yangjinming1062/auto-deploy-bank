package com.bolingcavalry.keyedprocessfunction;

/**
 * @author will
 * @email zq2599@gmail.com
 * @date 2020-05-17 13:47
 * @description 实体类，保存在key状态中
 */
public class CountWithTimestamp {
    public String key;

    public long count;

    public long lastModified;
}
