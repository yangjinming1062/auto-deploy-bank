### 关于此项目

这是client-go的DynamicClient客户端的使用demo，功能是远程请求kubernetes，得到指定namespace下的pod列表

