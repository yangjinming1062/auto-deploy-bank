package com.bolingcavalry.customizebeanpostprocessor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CustomizebeanpostprocessorApplication {

    public static void main(String[] args) {
        SpringApplication.run(CustomizebeanpostprocessorApplication.class, args);
    }
}
