package com.bolingcavalry.customizebeandefinitionregistrypostprocessor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CustomizebeandefinitionregistrypostprocessorApplication {

	public static void main(String[] args) {
		SpringApplication.run(CustomizebeandefinitionregistrypostprocessorApplication.class, args);
	}
}
