package com.bolingcavalry.customizeimportselector;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CustomizeimportselectorApplication {

    public static void main(String[] args) {
        SpringApplication.run(CustomizeimportselectorApplication.class, args);
    }
}
