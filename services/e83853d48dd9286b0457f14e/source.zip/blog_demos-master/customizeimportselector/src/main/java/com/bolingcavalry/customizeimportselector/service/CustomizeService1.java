package com.bolingcavalry.customizeimportselector.service;

/**
 * @Description: 测试接口
 * @author: willzhao E-mail: zq2599@gmail.com
 * @date: 2018/9/9 13:20
 */
public interface CustomizeService1 {
    void execute();
}
