package com.bolingcavalry;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BasicEventApplication {
	public static void main(String[] args) {
		SpringApplication.run(BasicEventApplication.class, args);
	}
}
