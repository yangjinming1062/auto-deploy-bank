package com.bolingcavalry;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConsumeModeApplication {
	public static void main(String[] args) {
		SpringApplication.run(ConsumeModeApplication.class, args);
	}
}
