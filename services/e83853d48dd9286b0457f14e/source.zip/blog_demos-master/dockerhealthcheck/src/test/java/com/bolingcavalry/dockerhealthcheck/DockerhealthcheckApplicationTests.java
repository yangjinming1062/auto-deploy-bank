package com.bolingcavalry.dockerhealthcheck;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DockerhealthcheckApplicationTests {

    @Test
    void contextLoads() {
    }

}
