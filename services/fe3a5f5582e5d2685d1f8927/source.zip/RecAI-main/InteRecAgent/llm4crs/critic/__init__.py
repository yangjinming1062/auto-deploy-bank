# Copyright (c) Microsoft Corporation.
# Licensed under the MIT license.

from .base import Critic