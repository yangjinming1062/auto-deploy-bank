# Copyright (c) Microsoft Corporation.
# Licensed under the MIT license.

from .query_tool import QueryTool