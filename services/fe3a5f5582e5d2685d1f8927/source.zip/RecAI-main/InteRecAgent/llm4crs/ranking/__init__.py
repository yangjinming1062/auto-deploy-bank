# Copyright (c) Microsoft Corporation.
# Licensed under the MIT license.

# Ranking module
from .reco_model_tool import RecModelTool