# Copyright (c) Microsoft Corporation.
# Licensed under the MIT license.

# Item corups table module
from .base import BaseGallery