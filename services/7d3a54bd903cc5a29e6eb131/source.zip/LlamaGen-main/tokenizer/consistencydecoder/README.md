## Consistency Decoder from OpenAI

### install
```
pip install diffusers
pip install accelerate
```

### demo
```
cd ${THIS_REPO_ROOT}
python3 tokenizer/consistencydecoder/cd_demo.py
```

