## VAE Models from Stable Diffusion

### install
```
pip install diffusers
pip install accelerate
```

### demo
```
cd ${THIS_REPO_ROOT}
python3 tokenizer/vae/sd_vae_demo.py
```

