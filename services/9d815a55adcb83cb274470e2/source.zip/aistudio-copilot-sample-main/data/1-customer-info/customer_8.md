## Customer_Info

First Name: Melissa 
Last Name: Davis 
Age: 31 
Email Address: melissad@example.com 
Phone Number: 555-333-4444 
Shipping Address: 789 Ash St, Another City USA, 67890 
Membership: Gold 

## Recent_Purchases

order_number: 4 
date: 2023-04-22 
item:
- description:  TrailMaster X4 Tent, quantity 2, price $500 
  item_number: 1 

order_number: 17 
date: 2023-03-30 
item:
- description:  TrekReady Hiking Boots, quantity 1, price $140 
  item_number: 4 

order_number: 25 
date: 2023-04-10 
item:
- description:  EcoFire Camping Stove, quantity 1, price $80 
  item_number: 6 

order_number: 34 
date: 2023-04-25 
item:
- description:  SummitClimber Backpack, quantity 1, price $120 
  item_number: 9 

order_number: 46 
date: 2023-05-16 
item:
- description:  PowerBurner Camping Stove, quantity 1, price $100 
  item_number: 13 

order_number: 55 
date: 2023-05-31 
item:
- description:  TrailLite Daypack, quantity 1, price $60 
  item_number: 16 

order_number: 64 
date: 2023-06-16 
item:
- description:  Adventure Dining Table, quantity 1, price $90 
  item_number: 19 

