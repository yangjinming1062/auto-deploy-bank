## Customer_Info

First Name: John 
Last Name: Smith 
Age: 35 
Email Address: johnsmith@example.com 
Phone Number: 555-123-4567 
Shipping Address: 123 Main St,  Anytown USA, 12345 
Membership: None 

## Recent_Purchases

order_number: 1 
date: 2023-01-05 
item:
- description:  TrailMaster X4 Tent, quantity 2, price $500 
  item_number: 1 

order_number: 19 
date: 2023-01-25 
item:
- description:  BaseCamp Folding Table, quantity 1, price $60 
  item_number: 5 

order_number: 29 
date: 2023-02-10 
item:
- description:  Alpine Explorer Tent, quantity 2, price $700 
  item_number: 8 

order_number: 41 
date: 2023-03-01 
item:
- description:  TrekMaster Camping Chair, quantity 1, price $50 
  item_number: 12 

order_number: 50 
date: 2023-03-16 
item:
- description:  SkyView 2-Person Tent, quantity 2, price $400 
  item_number: 15 

order_number: 59 
date: 2023-04-01 
item:
- description:  TrekStar Hiking Sandals, quantity 1, price $70 
  item_number: 18 

