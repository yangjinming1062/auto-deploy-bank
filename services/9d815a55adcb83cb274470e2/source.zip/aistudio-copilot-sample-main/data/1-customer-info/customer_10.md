## Customer_Info

First Name: Amanda 
Last Name: Perez 
Age: 26 
Email Address: amandap@example.com 
Phone Number: 555-123-4567 
Shipping Address: 654 Pine St,  Suburbia USA, 23456 
Membership: Gold 

## Recent_Purchases

order_number: 5 
date: 2023-05-01 
item:
- description:  TrailMaster X4 Tent, quantity 1, price $250 
  item_number: 1 

order_number: 18 
date: 2023-05-04 
item:
- description:  TrekReady Hiking Boots, quantity 3, price $420 
  item_number: 4 

order_number: 28 
date: 2023-04-15 
item:
- description:  CozyNights Sleeping Bag, quantity 1, price $100 
  item_number: 7 

order_number: 37 
date: 2023-04-30 
item:
- description:  TrailBlaze Hiking Pants, quantity 1, price $75 
  item_number: 10 

order_number: 58 
date: 2023-06-06 
item:
- description:  RainGuard Hiking Jacket, quantity 1, price $110 
  item_number: 17 

order_number: 67 
date: 2023-06-21 
item:
- description:  CompactCook Camping Stove, quantity 1, price $60 
  item_number: 20 

