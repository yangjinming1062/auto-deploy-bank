## Customer_Info

First Name: Emily 
Last Name: Rodriguez 
Age: 29 
Email Address: emilyr@example.com 
Phone Number: 555-111-2222 
Shipping Address: 987 Oak Ave,  Cityville USA, 56789 
Membership: None 

## Recent_Purchases

order_number: 3 
date: 2023-03-18 
item:
- description:  TrailMaster X4 Tent, quantity 3, price $750 
  item_number: 1 

order_number: 12 
date: 2023-02-20 
item:
- description:  Summit Breeze Jacket, quantity 2, price $240 
  item_number: 3 

order_number: 21 
date: 2023-04-02 
item:
- description:  BaseCamp Folding Table, quantity 1, price $60 
  item_number: 5 

order_number: 31 
date: 2023-04-20 
item:
- description:  Alpine Explorer Tent, quantity 1, price $350 
  item_number: 8 

order_number: 39 
date: 2023-03-30 
item:
- description:  TrailWalker Hiking Shoes, quantity 2, price $220 
  item_number: 11 

order_number: 48 
date: 2023-04-16 
item:
- description:  MountainDream Sleeping Bag, quantity 2, price $260 
  item_number: 14 

order_number: 61 
date: 2023-06-11 
item:
- description:  TrekStar Hiking Sandals, quantity 1, price $70 
  item_number: 18 

