## Customer_Info

First Name: Sarah 
Last Name: Lee 
Age: 38 
Email Address: sarahlee@example.com 
Phone Number: 555-867-5309 
Shipping Address: 321 Maple St, Bigtown USA, 90123 
Membership: Platinum 

## Recent_Purchases

order_number: 2 
date: 2023-02-10 
item:
- description:  TrailMaster X4 Tent, quantity 1, price $250 
  item_number: 1 

order_number: 26 
date: 2023-02-05 
item:
- description:  CozyNights Sleeping Bag, quantity 1, price $100 
  item_number: 7 

order_number: 35 
date: 2023-02-20 
item:
- description:  TrailBlaze Hiking Pants, quantity 1, price $75 
  item_number: 10 

order_number: 42 
date: 2023-04-06 
item:
- description:  TrekMaster Camping Chair, quantity 2, price $100 
  item_number: 12 

order_number: 51 
date: 2023-04-21 
item:
- description:  SkyView 2-Person Tent, quantity 1, price $200 
  item_number: 15 

order_number: 56 
date: 2023-03-26 
item:
- description:  RainGuard Hiking Jacket, quantity 1, price $110 
  item_number: 17 

order_number: 65 
date: 2023-04-11 
item:
- description:  CompactCook Camping Stove, quantity 1, price $60 
  item_number: 20 

