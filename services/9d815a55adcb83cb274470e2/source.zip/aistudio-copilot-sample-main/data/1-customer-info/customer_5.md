## Customer_Info

First Name: David 
Last Name: Kim 
Age: 42 
Email Address: davidkim@example.com 
Phone Number: 555-555-5555 
Shipping Address: 654 Pine St,  Suburbia USA, 23456 
Membership: Gold 

## Recent_Purchases

order_number: 7 
date: 2023-02-15 
item:
- description:  Adventurer Pro Backpack, quantity 2, price $180 
  item_number: 2 

order_number: 16 
date: 2023-02-25 
item:
- description:  TrekReady Hiking Boots, quantity 2, price $280 
  item_number: 4 

order_number: 24 
date: 2023-03-05 
item:
- description:  EcoFire Camping Stove, quantity 2, price $160 
  item_number: 6 

order_number: 33 
date: 2023-03-20 
item:
- description:  SummitClimber Backpack, quantity 2, price $240 
  item_number: 9 

order_number: 45 
date: 2023-04-11 
item:
- description:  PowerBurner Camping Stove, quantity 2, price $200 
  item_number: 13 

order_number: 54 
date: 2023-04-26 
item:
- description:  TrailLite Daypack, quantity 2, price $120 
  item_number: 16 

order_number: 63 
date: 2023-05-11 
item:
- description:  Adventure Dining Table, quantity 2, price $180 
  item_number: 19 

