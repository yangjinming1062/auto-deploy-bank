## Customer_Info

First Name: Jason 
Last Name: Brown 
Age: 50 
Email Address: jasonbrown@example.com 
Phone Number: 555-222-3333 
Shipping Address: 456 Cedar Rd, Anytown USA, 12345 
Membership: None 

## Recent_Purchases

order_number: 8 
date: 2023-03-20 
item:
- description:  Adventurer Pro Backpack, quantity 1, price $90 
  item_number: 2 

order_number: 27 
date: 2023-03-10 
item:
- description:  CozyNights Sleeping Bag, quantity 2, price $200 
  item_number: 7 

order_number: 36 
date: 2023-03-25 
item:
- description:  TrailBlaze Hiking Pants, quantity 2, price $150 
  item_number: 10 

order_number: 43 
date: 2023-05-11 
item:
- description:  TrekMaster Camping Chair, quantity 1, price $50 
  item_number: 12 

order_number: 52 
date: 2023-05-26 
item:
- description:  SkyView 2-Person Tent, quantity 1, price $200 
  item_number: 15 

order_number: 57 
date: 2023-05-01 
item:
- description:  RainGuard Hiking Jacket, quantity 2, price $220 
  item_number: 17 

order_number: 66 
date: 2023-05-16 
item:
- description:  CompactCook Camping Stove, quantity 2, price $120 
  item_number: 20 

