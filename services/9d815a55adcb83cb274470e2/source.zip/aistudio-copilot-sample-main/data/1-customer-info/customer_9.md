## Customer_Info

First Name: Daniel 
Last Name: Wilson 
Age: 47 
Email Address: danielw@example.com 
Phone Number: 555-444-5555 
Shipping Address: 321 Birch Ln,  Smallville USA, 34567 
Membership: None 

## Recent_Purchases

order_number: 9 
date: 2023-04-25 
item:
- description:  Adventurer Pro Backpack, quantity 3, price $270 
  item_number: 2 

order_number: 13 
date: 2023-03-25 
item:
- description:  Summit Breeze Jacket, quantity 1, price $120 
  item_number: 3 

order_number: 22 
date: 2023-05-07 
item:
- description:  BaseCamp Folding Table, quantity 3, price $180 
  item_number: 5 

order_number: 40 
date: 2023-04-05 
item:
- description:  TrailWalker Hiking Shoes, quantity 1, price $110 
  item_number: 11 

order_number: 49 
date: 2023-05-21 
item:
- description:  MountainDream Sleeping Bag, quantity 1, price $130 
  item_number: 14 

