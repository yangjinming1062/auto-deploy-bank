## Customer_Info

First Name: Karen 
Last Name: Williams 
Age: 29 
Email Address: karenw@example.com 
Phone Number: 555-987-6543 
Shipping Address: 456 Oak St, Another City USA, 67890 
Membership: Gold 

## Recent_Purchases

order_number: 14 
date: 2023-04-30 
item:
- description:  Summit Breeze Jacket, quantity 3, price $360 
  item_number: 3 

