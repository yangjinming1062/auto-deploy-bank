# OpenLineage Java Client

Java client for [OpenLineage](https://openlineage.io).

Refer to the [documentation](https://openlineage.io/docs/client/java) for details.
