---
name: General
about: General issue template
labels: ["state:needs-triage"]
assignees: ''

---
<!---
Thank you for your interest in OpenLineage! We appreciate the community's efforts to improve OpenLineage.

Note, you do not need to create an issue if you have a change ready to submit!
You can open a [pull request](https://github.com/OpenLineage/OpenLineage/pulls) immediately instead.
-->

**Details:**
