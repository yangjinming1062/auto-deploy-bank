# OpenLineage Integration Common

Common modules for OpenLineage integrations.

For setting up a development environment, see the [Python development setup guide](https://openlineage.io/docs/client/python/development/setup).
