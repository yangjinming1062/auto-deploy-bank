use mydb
var c =
{
	"city": "Saint Malo",
	"location" : {
        "lat" : 48.6333,
        "lon" : 2
	}
}

db.mygeocollec54.save(c)