// export function
exports.concatString = function(a, b) {
    return a + ' ' + b;
};
