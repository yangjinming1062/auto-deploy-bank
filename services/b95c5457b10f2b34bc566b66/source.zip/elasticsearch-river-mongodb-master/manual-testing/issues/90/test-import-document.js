use mydb90
var o =
{
	"firstName": "John",
	"lastName": "Doe",
	"created": new Date()
}

db.mycollec90.save(o)