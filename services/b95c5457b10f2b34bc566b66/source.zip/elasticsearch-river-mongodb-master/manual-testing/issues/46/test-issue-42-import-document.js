use mydb
var o =
{
	"firstName": "John42",
	"lastName": "Doe42",
	"age": 34,
	"state": "OPENED"
}

db.mycollec.save(o)