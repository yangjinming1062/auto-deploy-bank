use mydb101
var o = {
	'name': 'issue101'
}
db.mycollec101.save(o)
