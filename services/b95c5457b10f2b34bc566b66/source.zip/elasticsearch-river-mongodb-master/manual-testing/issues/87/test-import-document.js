use mydb87
var o =
{
	"firstName": "John",
	"lastName": "Doe",
	"created": new Date()
}

db.mycollec87.save(o)