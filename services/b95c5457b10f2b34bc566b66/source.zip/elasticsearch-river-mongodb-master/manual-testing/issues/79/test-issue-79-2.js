use mydb79
var o = {
  'name': 'richard'
}
db.mycollec79.save(o)