use mydb79
var o = {
	'name': 'issue79'
}

db.mycollec79.save(o)
db.mycollec79.drop()