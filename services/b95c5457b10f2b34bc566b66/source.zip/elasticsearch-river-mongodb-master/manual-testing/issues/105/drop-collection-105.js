use mydb105
db.document.drop()