use mydb
var o =
{
	"firstName": "John-61",
	"lastName": "Doe-61"
}

db.mycollec.save(o)