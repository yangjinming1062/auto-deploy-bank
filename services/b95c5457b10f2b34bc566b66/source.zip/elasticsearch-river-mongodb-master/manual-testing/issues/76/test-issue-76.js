use mydb76
var o =
{
	"exclude-1": "xxx",
	"exclude-2": "yyy",
	"enrollment": "390"
}

db.mycollec76.save(o)