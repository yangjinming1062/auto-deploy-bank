package org.elasticsearch.river.mongodb.gridfs;

import org.elasticsearch.river.mongodb.RiverMongoDBTestAbstract;

public abstract class RiverMongoGridFSTestAbstract extends RiverMongoDBTestAbstract {

    protected RiverMongoGridFSTestAbstract() {
        super(true);
    }

}
