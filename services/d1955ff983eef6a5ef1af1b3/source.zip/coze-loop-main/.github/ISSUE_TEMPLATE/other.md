---
name: Other
about: Something not captured by any other template
title: ''
labels: ''
assignees: ''

---

- [] I acknowledge that issues using this template may be closed without further explanation at the maintainer's discretion.