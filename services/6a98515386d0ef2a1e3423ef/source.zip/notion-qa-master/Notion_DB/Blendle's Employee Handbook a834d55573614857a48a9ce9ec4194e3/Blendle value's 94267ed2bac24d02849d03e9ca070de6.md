# Blendle value's

Putting our set of values or our way of life in writing wasn't an easy task. Mainly because the moment we started putting this in writing, it already altered. We started with a set of Blendle peeps writing down every word that came to mind when thinking about Blendle. We made categories and tried making sentences out of it. We shared that with the whole group, got some good feedback and slimmed it down to 5 powerful value's.

![Blendle%20value's%2094267ed2bac24d02849d03e9ca070de6/freedom.png](Blendle%20value's%2094267ed2bac24d02849d03e9ca070de6/freedom.png)

![Blendle%20value's%2094267ed2bac24d02849d03e9ca070de6/honesty.png](Blendle%20value's%2094267ed2bac24d02849d03e9ca070de6/honesty.png)

![Blendle%20value's%2094267ed2bac24d02849d03e9ca070de6/proactive.png](Blendle%20value's%2094267ed2bac24d02849d03e9ca070de6/proactive.png)

![Blendle%20value's%2094267ed2bac24d02849d03e9ca070de6/team_spirit.png](Blendle%20value's%2094267ed2bac24d02849d03e9ca070de6/team_spirit.png)

![Blendle%20value's%2094267ed2bac24d02849d03e9ca070de6/responsible.png](Blendle%20value's%2094267ed2bac24d02849d03e9ca070de6/responsible.png)

---

# Work at Blendle

If you want to work at Blendle you can check our [job ads here](https://blendle.homerun.co/).