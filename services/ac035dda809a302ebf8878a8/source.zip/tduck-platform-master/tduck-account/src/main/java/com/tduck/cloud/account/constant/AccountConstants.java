package com.tduck.cloud.account.constant;

/**
 * @author : smalljop
 * @description :
 * @create : 2020-11-11 18:16
 **/
public interface AccountConstants {
    /**
     * 默认头像
     */
    String DEFAULT_AVATAR = "https://s1.locimg.com/2023/05/16/17db376b12ec4.png";
}
