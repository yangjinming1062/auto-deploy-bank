package com.tduck.cloud.common.validator.group;

/**
 * @description: 修改校验组
 * @author: smalljop
 * @create: 2018-10-12 10:00
 **/
public interface UpdateGroup {
}
