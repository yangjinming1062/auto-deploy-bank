package com.tduck.cloud.envconfig.entity;

import lombok.Data;

/**
 * @author : tduck
 * @since :  2023/04/06 10:59
 **/
@Data
public class SystemInfoConfig {
    private String webBaseUrl;
}
