package com.tduck.cloud.form.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.tduck.cloud.form.entity.UserFormLogicEntity;

public interface UserFormLogicService extends IService<UserFormLogicEntity> {
}
