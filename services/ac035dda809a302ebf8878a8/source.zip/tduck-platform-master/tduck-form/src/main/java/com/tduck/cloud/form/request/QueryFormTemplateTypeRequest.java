package com.tduck.cloud.form.request;

import lombok.Data;

/**
 * @author : smalljop
 * @description : 查询表单模板分页
 * @create : 2020-12-10 15:04
 **/
@Data
public class QueryFormTemplateTypeRequest {


    @Data
    public static class List {
    }

}