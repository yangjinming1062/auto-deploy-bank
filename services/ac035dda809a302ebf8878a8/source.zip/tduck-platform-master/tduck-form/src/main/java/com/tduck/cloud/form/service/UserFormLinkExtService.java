package com.tduck.cloud.form.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.tduck.cloud.form.entity.UserFormLinkExtEntity;

/**
 * 单链接扩展值Service接口
 *
 * @author tduck-gen
 * @date 2021-12-14 14:26:38
 */
public interface UserFormLinkExtService extends IService<UserFormLinkExtEntity> {

}
