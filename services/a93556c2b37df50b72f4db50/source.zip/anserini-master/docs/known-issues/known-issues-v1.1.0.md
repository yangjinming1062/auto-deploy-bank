# Anserini Known Issues (v1.1.0)

+ Method overloading in `IndexReaderUtils` breaks Pyserini: https://github.com/castorini/pyserini/issues/2166
