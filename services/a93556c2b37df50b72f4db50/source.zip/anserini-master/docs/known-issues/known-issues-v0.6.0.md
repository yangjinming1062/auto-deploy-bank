# Anserini Known Issues (v0.6.0)

+ Solr indexing for Washington Post broke due to [417ac12](https://github.com/castorini/anserini/commit/c5ee9af442c500ec43fc28808903cfca2417ac12) and has been fixed in [#807](https://github.com/castorini/anserini/pull/807) and [#809](https://github.com/castorini/anserini/pull/809).
+ SearchSolr is broken due to [72b8052](https://github.com/castorini/anserini/commit/ca253a4794b5f5bea38749bd40e5f9f4272b8052) and has been fixed in [#816](https://github.com/castorini/anserini/pull/816).