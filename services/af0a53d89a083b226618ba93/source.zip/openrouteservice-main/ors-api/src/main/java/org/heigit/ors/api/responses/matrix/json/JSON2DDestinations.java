/*
 * This file is part of Openrouteservice.
 *
 * Openrouteservice is free software; you can redistribute it and/or modify it under the terms of the
 * GNU Lesser General Public License as published by the Free Software Foundation; either version 2.1
 * of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License along with this library;
 * if not, see <https://www.gnu.org/licenses/>.
 */

package org.heigit.ors.api.responses.matrix.json;

import com.fasterxml.jackson.annotation.JsonInclude;
import org.heigit.ors.matrix.ResolvedLocation;
import org.heigit.ors.util.FormatUtility;

@JsonInclude(JsonInclude.Include.NON_DEFAULT)
public class JSON2DDestinations extends JSONLocation {
    JSON2DDestinations(ResolvedLocation destination, boolean includeResolveLocations) {
        super(destination, includeResolveLocations);
    }

    @Override
    public Double[] getLocation() {
        Double[] location2D = new Double[2];
        location2D[0] = FormatUtility.roundToDecimals(location.x, COORDINATE_DECIMAL_PLACES);
        location2D[1] = FormatUtility.roundToDecimals(location.y, COORDINATE_DECIMAL_PLACES);
        // location2D[3] = location.z; --> example for third dimension
        return location2D;
    }
}
