package org.heigit.ors.api.responses.isochrones.geojson;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class GeoJSONIsochronePropertiesTest {

    @BeforeEach
    void setUp() throws Exception {
    }

    @Test
    void getGroup_index() {
    }

    @Test
    void getValue() {
    }

    @Test
    void getCenter() {
    }

    @Test
    void getArea() {
    }

    @Test
    void getReachfactor() {
    }

    @Test
    void getTotal_pop() {
    }
}