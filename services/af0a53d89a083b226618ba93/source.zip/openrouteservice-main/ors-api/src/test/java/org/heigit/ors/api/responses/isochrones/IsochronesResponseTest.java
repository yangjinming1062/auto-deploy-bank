package org.heigit.ors.api.responses.isochrones;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class IsochronesResponseTest {

    @BeforeEach
    void setUp() throws Exception {
    }

    @Test
    void getResponseInformation() {
    }

    @Test
    void getBbox() {
    }
}