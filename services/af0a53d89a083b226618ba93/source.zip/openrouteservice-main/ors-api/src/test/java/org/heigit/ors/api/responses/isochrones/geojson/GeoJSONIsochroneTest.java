package org.heigit.ors.api.responses.isochrones.geojson;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class GeoJSONIsochroneTest {

    @BeforeEach
    void setUp() throws Exception {
    }

    @Test
    void getGeometry() {
    }

    @Test
    void getProperties() {
    }
}