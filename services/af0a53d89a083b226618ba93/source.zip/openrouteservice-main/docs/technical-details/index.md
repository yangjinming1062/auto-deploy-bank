# Technical details

[//]: # (Attention: Pages in Technical details are linked from api-playground. When refactoring, adapt the links in the annotations in the java classes)

In this section you can find additional information on some important value lists
and explanation about the internal workings of openrouteservice:

* [Country List](country-list.md)
* [Travel Speeds](travel-speeds/index.md)
* [Tag Filtering](tag-filtering.md)
