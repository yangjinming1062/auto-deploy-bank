# `ors.endpoints.defaults`

Common settings for all ors endpoints.

| key         | type   | description                                | default value |
|-------------|--------|--------------------------------------------|---------------|
| attribution | string | Attribution added to the response metadata | _NA_          |
