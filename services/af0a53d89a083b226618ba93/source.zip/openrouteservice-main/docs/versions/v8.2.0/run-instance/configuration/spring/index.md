# Spring Properties

Since **openrouteservice** is based on spring, all common
[spring properties](https://docs.spring.io/spring-boot/docs/current/reference/html/application-properties.html) can be set in the `ors-config.yml` file. 

