# `ors.endpoints`

Settings beneath `ors.endpoints` are required at runtime to process API requests.
