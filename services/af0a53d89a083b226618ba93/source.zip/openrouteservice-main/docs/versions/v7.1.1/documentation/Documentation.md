# Documentation
For an easy and interactive way to test the api, visit our documentation at [openrouteservice.org](https://openrouteservice.org).
After obtaining your key you can try out the different endpoints instantly and start firing requests.

