# Opening openrouteservice code in IntelliJ

Though IntelliJ provides functionality to directly clone a repository, the steps below are the general procedure for getting openrouteservice up and running in IntelliJ:
1. Clone the repository into a folder
2. Open IntelliJ and Create a project via File -> New -> Project from Existing Sources
3. Select the "pom.xml" file from the cloned "openrouteservice" folder and click "Open"
4. Click through project settings with "Next" until you reach the page for selecting project SDK.
5. Choose "17" as project SDK and click "Next"
6. Finalize the project import by clicking "Finish" in the last window.
