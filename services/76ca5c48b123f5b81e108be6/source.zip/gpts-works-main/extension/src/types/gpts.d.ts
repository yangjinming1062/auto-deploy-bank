export interface Gpts {
  id: string
  name: string
  description: string
  author_name: string
  avatar_url: string
  created_at: string
  updated_at: string
  visit_url: string
}
