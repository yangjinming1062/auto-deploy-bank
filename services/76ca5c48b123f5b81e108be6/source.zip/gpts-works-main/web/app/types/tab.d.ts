export interface Tab {
  name: string;
  title: string;
  icon?: JSX.Element;
}
