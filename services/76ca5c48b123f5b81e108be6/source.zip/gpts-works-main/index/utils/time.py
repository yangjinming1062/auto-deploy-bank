import time


def get_current_timestamp():
    timestamp = int(time.time())

    return timestamp
