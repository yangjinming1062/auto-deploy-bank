export const MODAL_TYPES = {
  ABOUT: "core/about-modal"
};
