module.exports = {
  saveAs: jest.fn()
};
