---
name: "\U0001F33D Kernel / Runtime Issue"
about: Get Help Diagnosing Kernel / Runtime Problem

---

<!--

Note: nteract desktop will not detect your Anaconda and conda environments.

In order to detect those environments as kernels, you'll want to set them up following these instructions:

https://ipython.readthedocs.io/en/stable/install/kernel_install.html#kernels-for-different-environments

If that doesn't help you solve it, run `jupyter kernelspec list` to see what jupyter is seeing for installed kernels as well as where they get installed to.

-->
