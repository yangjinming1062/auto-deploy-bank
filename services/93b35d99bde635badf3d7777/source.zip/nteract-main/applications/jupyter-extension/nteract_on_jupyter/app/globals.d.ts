declare var __webpack_public_path__: string;
