module.exports = {
  find: kernelName => Promise.resolve({ name: kernelName })
};
