export const appName = "nteract";
