declare namespace NodeJS {
  export interface Global {
    store: any;
  }
}
