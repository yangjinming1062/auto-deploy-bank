# This file has now been slighly repurposed and will simply give other parts of
# the package access to some global meta-information about itself

# you know what f*ck it
# this is hardcoded for now because of that damn project / package name discrepancy
# i'll fix it one day
VERSION = "3.2.1"
HOMEPAGE = "https://github.com/krateng/maloja"


USER_AGENT = f"Maloja/{VERSION} ( {HOMEPAGE} )"
