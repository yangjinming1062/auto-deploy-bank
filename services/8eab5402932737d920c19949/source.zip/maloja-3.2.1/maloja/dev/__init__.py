### Subpackage that takes care of all things that concern the server process itself,
### e.g. analytics
