# monkey patching
from .pkg_global import monkey
# configuration before all else
from .pkg_global import conf
