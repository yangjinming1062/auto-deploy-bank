maloja_scrobbler_selector_playbar = "//div[contains(@class,'music-player-panel')]"


maloja_scrobbler_selector_metadata = ".//span[contains(@class,'audio-title')]"

maloja_scrobbler_selector_title = ".//span[contains(@class,'songTitle')]/text()"
maloja_scrobbler_selector_artist = ".//span[contains(@class,'songArtist')]/text()"
maloja_scrobbler_selector_duration = ".//span[contains(@class,'duration')]/text()"


maloja_scrobbler_selector_control = ".//span[contains(@class,'group play-btn')]/@title"

maloja_scrobbler_label_playing = "Click to pause"
maloja_scrobbler_label_paused = "Click to play"
