maloja_scrobbler_selector_playbar = "//footer[@data-testid='now-playing-bar']"


maloja_scrobbler_selector_metadata = ".//div[@data-testid='now-playing-widget']"

maloja_scrobbler_selector_title = ".//a[@data-testid='context-item-link']/text()"
maloja_scrobbler_selector_artists = ".//a[contains(@href,'/artist/')]"
maloja_scrobbler_selector_artist = "./text()"
maloja_scrobbler_selector_duration = ".//div[@data-testid='playback-duration']/text()"


maloja_scrobbler_selector_control = ".//button[@data-testid='control-button-playpause']/@aria-label"
