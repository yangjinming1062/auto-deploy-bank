#!/usr/bin/env sh
apt update
apt install \
	python3-pip \
	python3
