git tag -l '*.0' -n1 --sort=v:refname
