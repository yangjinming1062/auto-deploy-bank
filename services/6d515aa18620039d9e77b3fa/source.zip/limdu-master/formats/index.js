module.exports = {
	arff: require("./arff"),
	json: require("./json"),
	tsv: require("./tsv"),
	svmlight: require("./svmlight"),
}
