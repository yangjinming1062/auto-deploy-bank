# 1.0.0 (2023-06-19)


### Bug Fixes

* add semantic-release packages ([b669fe7](https://github.com/erelsgl/limdu/commit/b669fe7a80a3991a267c7309e915ca4f9ac0276e))
* node version in publish.yml ([e4063b2](https://github.com/erelsgl/limdu/commit/e4063b261e3637a5c0e0b5bbac08978358af3142))
* node version to 20.x ([d2d46c9](https://github.com/erelsgl/limdu/commit/d2d46c96f93ff828968582a7ccc35393e9d6970a))
* use codfish semantic action ([c8c766b](https://github.com/erelsgl/limdu/commit/c8c766bbfbcac70d9851e24b3f8f3479cc80130f))


### Features

* automatically publish to npm ([c3cd44f](https://github.com/erelsgl/limdu/commit/c3cd44f0d8d8266951c3f71685195f692284cc46))
