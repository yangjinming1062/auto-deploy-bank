# bayesian

`bayesian` is a JavaScript naive [Bayesian classifier](http://en.wikipedia.org/wiki/Bayesian_spam_filtering).

It is based on the 'classifier' project by Heather Arthur:
https://github.com/harthur/classifier

