This folder should contain several kinds of feature extractors.

A feature extractor is a function that takes an input object, and returns a features object for that object, for use in training and/or classification.
