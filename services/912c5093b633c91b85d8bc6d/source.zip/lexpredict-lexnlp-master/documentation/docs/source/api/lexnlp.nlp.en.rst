lexnlp.nlp.en package
=====================

Subpackages
-----------

.. toctree::

   lexnlp.nlp.en.segments
   lexnlp.nlp.en.tests
   lexnlp.nlp.en.transforms

Submodules
----------

lexnlp.nlp.en.stanford module
-----------------------------

.. automodule:: lexnlp.nlp.en.stanford
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.nlp.en.tokens module
---------------------------

.. automodule:: lexnlp.nlp.en.tokens
   :members:
   :undoc-members:
   :show-inheritance:


Module contents
---------------

.. automodule:: lexnlp.nlp.en
   :members:
   :undoc-members:
   :show-inheritance:
