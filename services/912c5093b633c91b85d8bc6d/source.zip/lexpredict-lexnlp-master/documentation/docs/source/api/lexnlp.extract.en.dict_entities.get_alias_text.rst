get_alias_text
==============

.. currentmodule:: lexnlp.extract.en.dict_entities

.. autofunction:: get_alias_text
