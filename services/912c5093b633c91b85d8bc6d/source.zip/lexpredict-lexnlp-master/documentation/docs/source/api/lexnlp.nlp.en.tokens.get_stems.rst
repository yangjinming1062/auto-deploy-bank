get_stems
=========

.. currentmodule:: lexnlp.nlp.en.tokens

.. autofunction:: get_stems
