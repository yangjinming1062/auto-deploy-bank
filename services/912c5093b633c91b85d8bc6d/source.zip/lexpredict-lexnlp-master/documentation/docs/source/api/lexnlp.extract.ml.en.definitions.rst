lexnlp.extract.ml.en.definitions package
========================================

Subpackages
-----------

.. toctree::

   lexnlp.extract.ml.en.definitions.tests

Submodules
----------

lexnlp.extract.ml.en.definitions.definition\_phrase\_detector module
--------------------------------------------------------------------

.. automodule:: lexnlp.extract.ml.en.definitions.definition_phrase_detector
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.ml.en.definitions.definition\_term\_detector module
------------------------------------------------------------------

.. automodule:: lexnlp.extract.ml.en.definitions.definition_term_detector
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.ml.en.definitions.layered\_definition\_detector module
---------------------------------------------------------------------

.. automodule:: lexnlp.extract.ml.en.definitions.layered_definition_detector
   :members:
   :undoc-members:
   :show-inheritance:


Module contents
---------------

.. automodule:: lexnlp.extract.ml.en.definitions
   :members:
   :undoc-members:
   :show-inheritance:
