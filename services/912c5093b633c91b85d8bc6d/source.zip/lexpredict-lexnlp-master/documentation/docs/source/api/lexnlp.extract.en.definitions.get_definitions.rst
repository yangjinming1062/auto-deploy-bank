get_definitions
===============

.. currentmodule:: lexnlp.extract.en.definitions

.. autofunction:: get_definitions
