get_nouns
=========

.. currentmodule:: lexnlp.nlp.en.tokens

.. autofunction:: get_nouns
