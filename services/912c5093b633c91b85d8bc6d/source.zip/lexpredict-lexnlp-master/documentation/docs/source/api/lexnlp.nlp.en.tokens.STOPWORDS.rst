STOPWORDS
=========

.. currentmodule:: lexnlp.nlp.en.tokens

.. autodata:: STOPWORDS
