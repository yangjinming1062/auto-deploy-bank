SearchResultPosition
====================

.. currentmodule:: lexnlp.extract.en.dict_entities

.. autoclass:: SearchResultPosition
   :show-inheritance:

   .. rubric:: Attributes Summary

   .. autosummary::

      ~SearchResultPosition.alias_text
      ~SearchResultPosition.entities_dict
      ~SearchResultPosition.start

   .. rubric:: Attributes Documentation

   .. autoattribute:: alias_text
   .. autoattribute:: entities_dict
   .. autoattribute:: start
