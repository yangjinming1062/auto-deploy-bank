get_alias_id
============

.. currentmodule:: lexnlp.extract.en.dict_entities

.. autofunction:: get_alias_id
