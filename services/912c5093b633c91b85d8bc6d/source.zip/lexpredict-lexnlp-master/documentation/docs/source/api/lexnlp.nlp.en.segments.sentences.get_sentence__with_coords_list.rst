get_sentence__with_coords_list
==============================

.. currentmodule:: lexnlp.nlp.en.segments.sentences

.. autofunction:: get_sentence__with_coords_list
