SECTION_SEGMENTER_MODEL
=======================

.. currentmodule:: lexnlp.nlp.en.segments.titles

.. autodata:: SECTION_SEGMENTER_MODEL
