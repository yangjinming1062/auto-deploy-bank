get_adjectives
==============

.. currentmodule:: lexnlp.nlp.en.tokens

.. autofunction:: get_adjectives
