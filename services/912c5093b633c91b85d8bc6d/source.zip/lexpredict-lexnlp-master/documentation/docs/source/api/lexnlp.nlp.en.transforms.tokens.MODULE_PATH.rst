MODULE_PATH
===========

.. currentmodule:: lexnlp.nlp.en.transforms.tokens

.. autodata:: MODULE_PATH
