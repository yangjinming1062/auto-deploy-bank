get_lemma_list
==============

.. currentmodule:: lexnlp.nlp.en.tokens

.. autofunction:: get_lemma_list
