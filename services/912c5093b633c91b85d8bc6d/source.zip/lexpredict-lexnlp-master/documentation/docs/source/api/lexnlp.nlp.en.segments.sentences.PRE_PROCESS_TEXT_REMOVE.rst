PRE_PROCESS_TEXT_REMOVE
=======================

.. currentmodule:: lexnlp.nlp.en.segments.sentences

.. autodata:: PRE_PROCESS_TEXT_REMOVE
