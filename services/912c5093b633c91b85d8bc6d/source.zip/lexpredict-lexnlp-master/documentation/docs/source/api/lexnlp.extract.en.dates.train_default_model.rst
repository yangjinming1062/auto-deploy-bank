train_default_model
===================

.. currentmodule:: lexnlp.extract.en.dates

.. autofunction:: train_default_model
