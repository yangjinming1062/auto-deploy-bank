add_aliases_to_entity
=====================

.. currentmodule:: lexnlp.extract.en.dict_entities

.. autofunction:: add_aliases_to_entity
