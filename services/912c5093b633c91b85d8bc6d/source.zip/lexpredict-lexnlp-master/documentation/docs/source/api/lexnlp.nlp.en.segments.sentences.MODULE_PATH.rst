MODULE_PATH
===========

.. currentmodule:: lexnlp.nlp.en.segments.sentences

.. autodata:: MODULE_PATH
