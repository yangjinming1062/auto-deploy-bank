SENTENCE_SPLITTERS_LOWER_EXCLUDE
================================

.. currentmodule:: lexnlp.nlp.en.segments.sentences

.. autodata:: SENTENCE_SPLITTERS_LOWER_EXCLUDE
