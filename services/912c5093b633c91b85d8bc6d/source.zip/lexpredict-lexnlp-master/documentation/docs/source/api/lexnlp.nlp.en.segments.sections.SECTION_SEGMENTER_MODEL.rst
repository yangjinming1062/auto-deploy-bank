SECTION_SEGMENTER_MODEL
=======================

.. currentmodule:: lexnlp.nlp.en.segments.sections

.. autodata:: SECTION_SEGMENTER_MODEL
