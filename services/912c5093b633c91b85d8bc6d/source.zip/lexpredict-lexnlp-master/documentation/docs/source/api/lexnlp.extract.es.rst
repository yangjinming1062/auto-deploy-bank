lexnlp.extract.es package
=========================

Subpackages
-----------

.. toctree::

   lexnlp.extract.es.tests

Submodules
----------

lexnlp.extract.es.copyrights module
-----------------------------------

.. automodule:: lexnlp.extract.es.copyrights
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.es.courts module
-------------------------------

.. automodule:: lexnlp.extract.es.courts
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.es.dates module
------------------------------

.. automodule:: lexnlp.extract.es.dates
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.es.definitions module
------------------------------------

.. automodule:: lexnlp.extract.es.definitions
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.es.language\_tokens module
-----------------------------------------

.. automodule:: lexnlp.extract.es.language_tokens
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.es.regulations module
------------------------------------

.. automodule:: lexnlp.extract.es.regulations
   :members:
   :undoc-members:
   :show-inheritance:


Module contents
---------------

.. automodule:: lexnlp.extract.es
   :members:
   :undoc-members:
   :show-inheritance:
