DEFAULT_STEMMER
===============

.. currentmodule:: lexnlp.nlp.en.tokens

.. autodata:: DEFAULT_STEMMER
