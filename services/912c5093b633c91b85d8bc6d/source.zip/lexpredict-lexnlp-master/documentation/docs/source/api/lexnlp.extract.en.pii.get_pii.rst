get_pii
=======

.. currentmodule:: lexnlp.extract.en.pii

.. autofunction:: get_pii
