get_trademarks
==============

.. currentmodule:: lexnlp.extract.en.trademarks

.. autofunction:: get_trademarks
