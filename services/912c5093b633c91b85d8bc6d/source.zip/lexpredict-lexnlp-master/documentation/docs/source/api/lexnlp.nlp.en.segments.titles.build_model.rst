build_model
===========

.. currentmodule:: lexnlp.nlp.en.segments.titles

.. autofunction:: build_model
