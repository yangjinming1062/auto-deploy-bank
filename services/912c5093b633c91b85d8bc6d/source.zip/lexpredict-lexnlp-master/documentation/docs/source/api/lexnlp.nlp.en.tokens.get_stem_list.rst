get_stem_list
=============

.. currentmodule:: lexnlp.nlp.en.tokens

.. autofunction:: get_stem_list
