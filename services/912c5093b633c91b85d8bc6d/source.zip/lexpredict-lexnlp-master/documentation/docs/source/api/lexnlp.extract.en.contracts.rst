lexnlp.extract.en.contracts package
===================================

Subpackages
-----------

.. toctree::

   lexnlp.extract.en.contracts.tests

Submodules
----------

lexnlp.extract.en.contracts.detector module
-------------------------------------------

.. automodule:: lexnlp.extract.en.contracts.detector
   :members:
   :undoc-members:
   :show-inheritance:


Module contents
---------------

.. automodule:: lexnlp.extract.en.contracts
   :members:
   :undoc-members:
   :show-inheritance:
