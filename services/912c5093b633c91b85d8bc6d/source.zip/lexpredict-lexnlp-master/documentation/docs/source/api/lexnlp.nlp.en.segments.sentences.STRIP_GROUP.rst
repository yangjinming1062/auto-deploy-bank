STRIP_GROUP
===========

.. currentmodule:: lexnlp.nlp.en.segments.sentences

.. autodata:: STRIP_GROUP
