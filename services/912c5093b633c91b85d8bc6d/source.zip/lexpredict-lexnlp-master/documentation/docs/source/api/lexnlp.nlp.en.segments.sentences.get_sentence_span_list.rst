get_sentence_span_list
======================

.. currentmodule:: lexnlp.nlp.en.segments.sentences

.. autofunction:: get_sentence_span_list
