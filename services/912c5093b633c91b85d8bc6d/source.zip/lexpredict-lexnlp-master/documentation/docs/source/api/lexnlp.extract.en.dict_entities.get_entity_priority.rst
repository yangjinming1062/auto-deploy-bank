get_entity_priority
===================

.. currentmodule:: lexnlp.extract.en.dict_entities

.. autofunction:: get_entity_priority
