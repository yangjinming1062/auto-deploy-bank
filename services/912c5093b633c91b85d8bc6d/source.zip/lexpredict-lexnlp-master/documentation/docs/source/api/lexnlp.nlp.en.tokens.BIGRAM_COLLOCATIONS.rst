BIGRAM_COLLOCATIONS
===================

.. currentmodule:: lexnlp.nlp.en.tokens

.. autodata:: BIGRAM_COLLOCATIONS
