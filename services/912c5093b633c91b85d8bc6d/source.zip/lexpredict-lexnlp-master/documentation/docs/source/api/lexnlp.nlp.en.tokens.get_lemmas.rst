get_lemmas
==========

.. currentmodule:: lexnlp.nlp.en.tokens

.. autofunction:: get_lemmas
