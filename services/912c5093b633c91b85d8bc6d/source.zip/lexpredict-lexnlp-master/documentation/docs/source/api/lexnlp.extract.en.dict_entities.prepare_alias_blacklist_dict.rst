prepare_alias_blacklist_dict
============================

.. currentmodule:: lexnlp.extract.en.dict_entities

.. autofunction:: prepare_alias_blacklist_dict
