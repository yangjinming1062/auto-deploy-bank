find_dict_entities
==================

.. currentmodule:: lexnlp.extract.en.dict_entities

.. autofunction:: find_dict_entities
