get_pages
=========

.. currentmodule:: lexnlp.nlp.en.segments.pages

.. autofunction:: get_pages
