lexnlp.extract.common.durations package
=======================================

Submodules
----------

lexnlp.extract.common.durations.durations\_parser module
--------------------------------------------------------

.. automodule:: lexnlp.extract.common.durations.durations_parser
   :members:
   :undoc-members:
   :show-inheritance:


Module contents
---------------

.. automodule:: lexnlp.extract.common.durations
   :members:
   :undoc-members:
   :show-inheritance:
