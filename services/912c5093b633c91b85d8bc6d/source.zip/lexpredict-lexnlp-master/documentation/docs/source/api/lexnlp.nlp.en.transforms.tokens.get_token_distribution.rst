get_token_distribution
======================

.. currentmodule:: lexnlp.nlp.en.transforms.tokens

.. autofunction:: get_token_distribution
