pre_process_document
====================

.. currentmodule:: lexnlp.nlp.en.segments.sentences

.. autofunction:: pre_process_document
