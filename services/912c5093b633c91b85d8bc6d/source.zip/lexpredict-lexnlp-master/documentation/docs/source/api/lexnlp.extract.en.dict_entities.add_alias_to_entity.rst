add_alias_to_entity
===================

.. currentmodule:: lexnlp.extract.en.dict_entities

.. autofunction:: add_alias_to_entity
