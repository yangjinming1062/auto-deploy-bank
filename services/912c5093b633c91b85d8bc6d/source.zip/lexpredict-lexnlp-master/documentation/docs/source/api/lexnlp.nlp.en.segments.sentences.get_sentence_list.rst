get_sentence_list
=================

.. currentmodule:: lexnlp.nlp.en.segments.sentences

.. autofunction:: get_sentence_list
