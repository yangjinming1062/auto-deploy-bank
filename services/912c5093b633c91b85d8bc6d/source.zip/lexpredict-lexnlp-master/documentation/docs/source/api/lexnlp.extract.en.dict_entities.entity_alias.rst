entity_alias
============

.. currentmodule:: lexnlp.extract.en.dict_entities

.. autofunction:: entity_alias
