lexnlp.extract.es.tests package
===============================

Submodules
----------

lexnlp.extract.es.tests.test\_copyrights module
-----------------------------------------------

.. automodule:: lexnlp.extract.es.tests.test_copyrights
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.es.tests.test\_courts module
-------------------------------------------

.. automodule:: lexnlp.extract.es.tests.test_courts
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.es.tests.test\_dates module
------------------------------------------

.. automodule:: lexnlp.extract.es.tests.test_dates
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.es.tests.test\_definitions module
------------------------------------------------

.. automodule:: lexnlp.extract.es.tests.test_definitions
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.es.tests.test\_regulations module
------------------------------------------------

.. automodule:: lexnlp.extract.es.tests.test_regulations
   :members:
   :undoc-members:
   :show-inheritance:


Module contents
---------------

.. automodule:: lexnlp.extract.es.tests
   :members:
   :undoc-members:
   :show-inheritance:
