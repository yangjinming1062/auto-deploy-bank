lexnlpprivate.extract.en.addresses.tests package
================================================

Submodules
----------

lexnlpprivate.extract.en.addresses.tests.test\_addresses\_train module
----------------------------------------------------------------------

.. automodule:: lexnlpprivate.extract.en.addresses.tests.test_addresses_train
   :members:
   :undoc-members:
   :show-inheritance:


Module contents
---------------

.. automodule:: lexnlpprivate.extract.en.addresses.tests
   :members:
   :undoc-members:
   :show-inheritance:
