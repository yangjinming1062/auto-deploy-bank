post_process_sentence
=====================

.. currentmodule:: lexnlp.nlp.en.segments.sentences

.. autofunction:: post_process_sentence
