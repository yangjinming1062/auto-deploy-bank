lexnlpprivate.extract.en.addresses package
==========================================

Subpackages
-----------

.. toctree::

   lexnlpprivate.extract.en.addresses.tests

Submodules
----------

lexnlpprivate.extract.en.addresses.addresses\_train module
----------------------------------------------------------

.. automodule:: lexnlpprivate.extract.en.addresses.addresses_train
   :members:
   :undoc-members:
   :show-inheritance:

lexnlpprivate.extract.en.addresses.convert\_geonames\_cities\_to\_word\_set module
----------------------------------------------------------------------------------

.. automodule:: lexnlpprivate.extract.en.addresses.convert_geonames_cities_to_word_set
   :members:
   :undoc-members:
   :show-inheritance:


Module contents
---------------

.. automodule:: lexnlpprivate.extract.en.addresses
   :members:
   :undoc-members:
   :show-inheritance:
