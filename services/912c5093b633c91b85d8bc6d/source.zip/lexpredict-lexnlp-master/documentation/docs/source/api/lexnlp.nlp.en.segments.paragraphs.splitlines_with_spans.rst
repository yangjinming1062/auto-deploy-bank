splitlines_with_spans
=====================

.. currentmodule:: lexnlp.nlp.en.segments.paragraphs

.. autofunction:: splitlines_with_spans
