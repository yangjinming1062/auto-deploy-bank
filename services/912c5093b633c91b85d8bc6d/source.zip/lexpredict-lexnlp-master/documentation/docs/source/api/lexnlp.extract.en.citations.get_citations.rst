get_citations
=============

.. currentmodule:: lexnlp.extract.en.citations

.. autofunction:: get_citations
