get_skipgram_distribution
=========================

.. currentmodule:: lexnlp.nlp.en.transforms.tokens

.. autofunction:: get_skipgram_distribution
