conflicts_take_first_by_id
==========================

.. currentmodule:: lexnlp.extract.en.dict_entities

.. autofunction:: conflicts_take_first_by_id
