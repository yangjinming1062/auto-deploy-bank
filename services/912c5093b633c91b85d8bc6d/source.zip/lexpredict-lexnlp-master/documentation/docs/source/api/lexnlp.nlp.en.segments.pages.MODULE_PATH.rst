MODULE_PATH
===========

.. currentmodule:: lexnlp.nlp.en.segments.pages

.. autodata:: MODULE_PATH
