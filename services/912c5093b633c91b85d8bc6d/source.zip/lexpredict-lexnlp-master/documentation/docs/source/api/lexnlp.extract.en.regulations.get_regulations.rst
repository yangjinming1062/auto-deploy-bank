get_regulations
===============

.. currentmodule:: lexnlp.extract.en.regulations

.. autofunction:: get_regulations
