lexnlp.nlp.train package
========================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   lexnlp.nlp.train.en

Submodules
----------

lexnlp.nlp.train.train\_data\_manager module
--------------------------------------------

.. automodule:: lexnlp.nlp.train.train_data_manager
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: lexnlp.nlp.train
   :members:
   :undoc-members:
   :show-inheritance:
