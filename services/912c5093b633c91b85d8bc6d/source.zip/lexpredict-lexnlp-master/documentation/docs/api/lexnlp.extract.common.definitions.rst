lexnlp.extract.common.definitions package
=========================================

Submodules
----------

lexnlp.extract.common.definitions.common\_definition\_patterns module
---------------------------------------------------------------------

.. automodule:: lexnlp.extract.common.definitions.common_definition_patterns
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.common.definitions.definition\_match module
----------------------------------------------------------

.. automodule:: lexnlp.extract.common.definitions.definition_match
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.common.definitions.universal\_definition\_parser module
----------------------------------------------------------------------

.. automodule:: lexnlp.extract.common.definitions.universal_definition_parser
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: lexnlp.extract.common.definitions
   :members:
   :undoc-members:
   :show-inheritance:
