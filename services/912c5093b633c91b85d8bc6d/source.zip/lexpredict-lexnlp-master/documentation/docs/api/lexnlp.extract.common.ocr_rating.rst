lexnlp.extract.common.ocr\_rating package
=========================================

Submodules
----------

lexnlp.extract.common.ocr\_rating.lang\_vector\_distribution\_builder module
----------------------------------------------------------------------------

.. automodule:: lexnlp.extract.common.ocr_rating.lang_vector_distribution_builder
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.common.ocr\_rating.ocr\_rating\_calculator module
----------------------------------------------------------------

.. automodule:: lexnlp.extract.common.ocr_rating.ocr_rating_calculator
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: lexnlp.extract.common.ocr_rating
   :members:
   :undoc-members:
   :show-inheritance:
