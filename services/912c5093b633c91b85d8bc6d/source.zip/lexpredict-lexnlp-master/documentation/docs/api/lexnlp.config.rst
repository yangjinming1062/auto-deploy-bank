lexnlp.config package
=====================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   lexnlp.config.en

Submodules
----------

lexnlp.config.stanford module
-----------------------------

.. automodule:: lexnlp.config.stanford
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: lexnlp.config
   :members:
   :undoc-members:
   :show-inheritance:
