lexnlp.extract package
======================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   lexnlp.extract.all_locales
   lexnlp.extract.common
   lexnlp.extract.de
   lexnlp.extract.en
   lexnlp.extract.es
   lexnlp.extract.ml

Module contents
---------------

.. automodule:: lexnlp.extract
   :members:
   :undoc-members:
   :show-inheritance:
