lexnlp.extract.en.contracts package
===================================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   lexnlp.extract.en.contracts.tests

Submodules
----------

lexnlp.extract.en.contracts.contract\_type\_detector module
-----------------------------------------------------------

.. automodule:: lexnlp.extract.en.contracts.contract_type_detector
   :members:
   :undoc-members:
   :show-inheritance:

lexnlp.extract.en.contracts.predictors module
---------------------------------------------

.. automodule:: lexnlp.extract.en.contracts.predictors
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: lexnlp.extract.en.contracts
   :members:
   :undoc-members:
   :show-inheritance:
