export * from '@blocksuite/affine-block-callout/view';
