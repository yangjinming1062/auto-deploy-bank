export * from '@blocksuite/affine-inline-mention/view';
