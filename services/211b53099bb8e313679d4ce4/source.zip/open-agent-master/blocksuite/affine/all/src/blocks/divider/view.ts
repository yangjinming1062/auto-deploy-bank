export * from '@blocksuite/affine-block-divider/view';
