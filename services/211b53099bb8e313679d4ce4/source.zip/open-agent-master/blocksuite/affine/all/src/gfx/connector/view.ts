export * from '@blocksuite/affine-gfx-connector/view';
