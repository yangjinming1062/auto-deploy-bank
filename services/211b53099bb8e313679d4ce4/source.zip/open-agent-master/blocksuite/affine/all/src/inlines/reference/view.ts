export * from '@blocksuite/affine-inline-reference/view';
