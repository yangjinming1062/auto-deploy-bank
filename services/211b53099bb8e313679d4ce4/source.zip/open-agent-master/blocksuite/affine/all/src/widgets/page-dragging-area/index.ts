export * from '@blocksuite/affine-widget-page-dragging-area';
