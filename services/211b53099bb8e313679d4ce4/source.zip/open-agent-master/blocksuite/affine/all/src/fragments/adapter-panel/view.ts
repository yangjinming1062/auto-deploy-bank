export * from '@blocksuite/affine-fragment-adapter-panel/view';
