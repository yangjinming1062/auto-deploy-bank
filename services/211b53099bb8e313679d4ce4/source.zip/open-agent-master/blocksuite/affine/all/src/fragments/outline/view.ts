export * from '@blocksuite/affine-fragment-outline/view';
