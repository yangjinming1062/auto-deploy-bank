export * from '@blocksuite/affine-block-bookmark/store';
