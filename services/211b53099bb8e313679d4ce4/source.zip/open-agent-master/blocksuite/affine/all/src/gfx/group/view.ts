export * from '@blocksuite/affine-gfx-group/view';
