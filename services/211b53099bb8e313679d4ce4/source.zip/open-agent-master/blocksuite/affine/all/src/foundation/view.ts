export * from '@blocksuite/affine-foundation/view';
