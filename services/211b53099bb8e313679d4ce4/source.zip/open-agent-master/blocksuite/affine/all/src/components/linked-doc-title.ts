export * from '@blocksuite/affine-components/linked-doc-title';
