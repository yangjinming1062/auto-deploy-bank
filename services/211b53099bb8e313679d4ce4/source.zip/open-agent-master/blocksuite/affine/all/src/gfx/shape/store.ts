export * from '@blocksuite/affine-gfx-shape/store';
