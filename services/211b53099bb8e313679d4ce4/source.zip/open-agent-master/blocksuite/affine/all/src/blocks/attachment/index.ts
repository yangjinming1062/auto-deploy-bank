export * from '@blocksuite/affine-block-attachment';
