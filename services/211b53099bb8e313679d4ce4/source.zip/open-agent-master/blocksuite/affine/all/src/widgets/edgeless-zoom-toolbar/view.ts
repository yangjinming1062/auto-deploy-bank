export * from '@blocksuite/affine-widget-edgeless-zoom-toolbar/view';
