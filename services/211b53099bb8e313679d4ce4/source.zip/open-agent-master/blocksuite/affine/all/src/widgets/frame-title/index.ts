export * from '@blocksuite/affine-widget-frame-title';
