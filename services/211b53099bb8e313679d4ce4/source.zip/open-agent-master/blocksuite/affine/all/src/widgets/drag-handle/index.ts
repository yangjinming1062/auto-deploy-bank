export * from '@blocksuite/affine-widget-drag-handle';
