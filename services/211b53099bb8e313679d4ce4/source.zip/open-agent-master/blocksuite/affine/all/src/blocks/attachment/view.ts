export * from '@blocksuite/affine-block-attachment/view';
