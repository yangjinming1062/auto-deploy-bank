export * from '@blocksuite/affine-inline-footnote';
