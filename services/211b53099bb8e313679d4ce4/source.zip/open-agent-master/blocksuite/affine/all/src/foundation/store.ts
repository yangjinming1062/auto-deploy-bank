export * from '@blocksuite/affine-foundation/store';
