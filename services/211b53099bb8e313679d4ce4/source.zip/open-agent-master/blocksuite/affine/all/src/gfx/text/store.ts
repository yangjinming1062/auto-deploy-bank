export * from '@blocksuite/affine-gfx-text/store';
