export * from '@blocksuite/affine-block-surface-ref/view';
