export * from '@blocksuite/affine-widget-note-slicer';
