export * from '@blocksuite/affine-components/size-dropdown-menu';
