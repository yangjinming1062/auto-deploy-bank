export * from '@blocksuite/affine-gfx-link';
