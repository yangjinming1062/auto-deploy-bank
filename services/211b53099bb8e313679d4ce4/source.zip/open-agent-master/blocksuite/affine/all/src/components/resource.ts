export * from '@blocksuite/affine-components/resource';
