export * from '@blocksuite/affine-shared/selection';
