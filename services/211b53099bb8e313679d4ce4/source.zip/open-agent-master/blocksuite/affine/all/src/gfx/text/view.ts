export * from '@blocksuite/affine-gfx-text/view';
