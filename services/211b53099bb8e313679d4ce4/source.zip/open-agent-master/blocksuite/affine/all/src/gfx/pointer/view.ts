export * from '@blocksuite/affine-gfx-pointer/view';
