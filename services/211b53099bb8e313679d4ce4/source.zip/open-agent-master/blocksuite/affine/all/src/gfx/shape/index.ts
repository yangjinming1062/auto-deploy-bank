export * from '@blocksuite/affine-gfx-shape';
