export * from '@blocksuite/affine-components/edgeless-line-width-panel';
