export * from '@blocksuite/affine-block-embed-doc';
