export * from '@blocksuite/affine-components/tooltip-content-with-shortcut';
