export * from '@blocksuite/affine-widget-linked-doc';
