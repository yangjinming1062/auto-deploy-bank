export * from '@blocksuite/affine-widget-remote-selection';
