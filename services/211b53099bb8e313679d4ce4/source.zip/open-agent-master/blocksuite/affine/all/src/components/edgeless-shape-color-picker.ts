export * from '@blocksuite/affine-components/edgeless-shape-color-picker';
