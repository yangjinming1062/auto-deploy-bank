export * from '@blocksuite/affine-widget-edgeless-dragging-area';
