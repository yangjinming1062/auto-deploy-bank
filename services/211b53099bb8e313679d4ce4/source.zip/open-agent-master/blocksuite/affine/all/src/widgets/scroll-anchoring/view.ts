export * from '@blocksuite/affine-widget-scroll-anchoring/view';
