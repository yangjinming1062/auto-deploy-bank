export * from '@blocksuite/affine-components/smooth-corner';
