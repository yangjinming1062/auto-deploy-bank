export * from '@blocksuite/affine-gfx-template';
