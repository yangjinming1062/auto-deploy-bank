export * from '@blocksuite/affine-widget-edgeless-selected-rect/view';
