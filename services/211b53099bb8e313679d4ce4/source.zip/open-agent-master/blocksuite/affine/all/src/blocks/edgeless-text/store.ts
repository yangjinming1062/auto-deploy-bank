export * from '@blocksuite/affine-block-edgeless-text/store';
