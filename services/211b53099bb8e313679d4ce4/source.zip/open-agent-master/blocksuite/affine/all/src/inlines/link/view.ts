export * from '@blocksuite/affine-inline-link/view';
