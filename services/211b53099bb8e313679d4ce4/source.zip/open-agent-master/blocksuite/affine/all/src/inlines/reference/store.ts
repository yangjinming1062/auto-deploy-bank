export * from '@blocksuite/affine-inline-reference/store';
