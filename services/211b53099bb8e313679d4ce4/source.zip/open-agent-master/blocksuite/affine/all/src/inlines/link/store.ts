export * from '@blocksuite/affine-inline-link/store';
