export * from '@blocksuite/affine-block-edgeless-text/view';
