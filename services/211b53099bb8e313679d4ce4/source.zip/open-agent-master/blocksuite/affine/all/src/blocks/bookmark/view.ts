export * from '@blocksuite/affine-block-bookmark/view';
