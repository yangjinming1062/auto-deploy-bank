export * from '@blocksuite/affine-block-table/view';
