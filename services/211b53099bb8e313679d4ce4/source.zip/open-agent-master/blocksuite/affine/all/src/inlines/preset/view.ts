export * from '@blocksuite/affine-inline-preset/view';
