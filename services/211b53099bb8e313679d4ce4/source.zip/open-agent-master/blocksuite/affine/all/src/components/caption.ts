export * from '@blocksuite/affine-components/caption';
