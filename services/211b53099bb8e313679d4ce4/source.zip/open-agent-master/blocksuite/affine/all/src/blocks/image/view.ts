export * from '@blocksuite/affine-block-image/view';
