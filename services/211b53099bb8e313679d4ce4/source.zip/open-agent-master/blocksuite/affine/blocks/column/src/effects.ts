import { ColumnBlockComponent } from './column-block.js';

export function effects() {
  customElements.define('affine-column', ColumnBlockComponent);
}
