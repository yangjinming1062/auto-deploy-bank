import { DataViewBlockComponent } from './data-view-block';

export function effects() {
  customElements.define('affine-data-view', DataViewBlockComponent);
}
