import { EdgelessTextBlockComponent } from './edgeless-text-block';

export function effects() {
  customElements.define('affine-edgeless-text', EdgelessTextBlockComponent);
}
