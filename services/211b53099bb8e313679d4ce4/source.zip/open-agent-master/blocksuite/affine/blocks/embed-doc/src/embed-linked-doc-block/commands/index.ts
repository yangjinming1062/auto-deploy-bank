export * from './insert-embed-linked-doc';
