export { insertEmbedSyncedDocCommand } from './insert-embed-synced-doc';
