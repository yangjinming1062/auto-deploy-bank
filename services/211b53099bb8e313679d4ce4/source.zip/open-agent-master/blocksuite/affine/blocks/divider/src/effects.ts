import { DividerBlockComponent } from './divider-block';

export function effects() {
  customElements.define('affine-divider', DividerBlockComponent);
}
