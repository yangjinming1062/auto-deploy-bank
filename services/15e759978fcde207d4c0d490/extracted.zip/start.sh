#!/bin/bash

echo "Waiting for database..."
until mysql --ssl=0 -h mariadb -u frappe -pfrappe -e "SELECT 1" frappe > /dev/null 2>&1; do
    echo "Database not ready, waiting..."
    sleep 5
done
echo "Database ready!"

# Try to initialize frappe site
cd /app

echo "Attempting Frappe initialization..."
python3 << 'PYEOF'
import sys
import time
import subprocess
import signal

# Set a timeout for Frappe initialization
import os
os.environ['FRAPPE_NO_POOL'] = '1'

import frappe

try:
    # Initialize Frappe
    frappe.init(site='localhost', sites_path='/app/sites')
    frappe.connect()

    # Try a simple operation that requires the Core module
    try:
        from frappe.core.doctype.system_settings.system_settings import SystemSettings
        print('Core module loaded successfully!')
    except Exception as e:
        print(f'Core module error: {e}')
        # Try to load the module from DocType
        meta = frappe.get_meta('System Settings')
        print(f'Got System Settings meta')

    frappe.migrate()
    print('Frappe initialized successfully!')
    sys.exit(0)
except Exception as e:
    print(f'Frappe initialization failed: {e}')
    sys.exit(1)
PYEOF

INIT_RESULT=$?

if [ $INIT_RESULT -eq 0 ]; then
    echo "Starting Frappe with full application..."
    exec gunicorn --bind 0.0.0.0:8000 --threads 4 --workers 2 frappe.app:application
else
    echo "Starting fallback server (Frappe initialization failed)..."
    exec python3 /app/fallback_server.py
fi