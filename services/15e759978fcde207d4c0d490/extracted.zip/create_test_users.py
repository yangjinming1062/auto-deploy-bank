#!/usr/bin/env python3
"""
User Account Creation Script for Frappe Framework

This script demonstrates how to create user accounts in Frappe Framework.
Users can be created using the CLI command or programmatically.
"""

import frappe


def create_user_programmatically(email, first_name=None, last_name=None, password=None, roles=None):
    """
    Create a user programmatically in Frappe.

    Args:
        email: User's email address (used as username)
        first_name: User's first name (defaults to part of email)
        last_name: User's last name (optional)
        password: User's password (optional, will be set later)
        roles: List of roles to assign (defaults to ["System Manager"])
    """
    # Check if user already exists
    if frappe.db.exists("User", email):
        user_doc = frappe.get_doc("User", email)
        print(f"User {email} already exists")
        return user_doc

    # Create new user document
    user = frappe.new_doc("User")
    user.update({
        "name": email,
        "email": email,
        "enabled": 1,
        "first_name": first_name or email.split("@", 1)[0],
        "last_name": last_name,
        "user_type": "System User",
    })
    user.insert()

    # Add roles
    if not roles:
        roles = ["System Manager"]
    user.add_roles(*roles)

    # Set password if provided
    if password:
        from frappe.utils.password import update_password
        update_password(user=email, pwd=password)

    frappe.db.commit()
    print(f"Successfully created user: {email}")
    return user


def create_admin_user(email, password):
    """
    Create an administrator user with all roles.

    Args:
        email: Admin user's email
        password: Admin password
    """
    user = create_user_programmatically(email, roles=["Administrator"])
    if password:
        from frappe.utils.password import update_password
        update_password(user=email, pwd=password)
    frappe.db.commit()
    print(f"Successfully created admin user: {email}")


if __name__ == "__main__":
    # Initialize Frappe (site name required)
    site_name = "your-site-name"  # Replace with actual site name
    frappe.init(site=site_name)
    frappe.connect()

    # Example: Create a test user
    create_user_programmatically(
        email="test@example.com",
        first_name="Test",
        last_name="User",
        password="test123",
        roles=["System Manager", "Blogger"]
    )

    # Example: Create an admin user
    create_admin_user("admin@example.com", "admin123")

    frappe.destroy()