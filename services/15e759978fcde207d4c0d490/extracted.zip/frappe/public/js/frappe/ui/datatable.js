import DataTable from "frappe-datatable";

frappe.DataTable = DataTable;
