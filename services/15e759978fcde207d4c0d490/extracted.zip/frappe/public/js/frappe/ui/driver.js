import Driver from "driver.js";

frappe.Driver = Driver;
