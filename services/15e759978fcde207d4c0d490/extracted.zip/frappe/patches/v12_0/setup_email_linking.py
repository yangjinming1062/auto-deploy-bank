from frappe.desk.page.setup_wizard.install_fixtures import setup_email_linking


def execute():
	setup_email_linking()
