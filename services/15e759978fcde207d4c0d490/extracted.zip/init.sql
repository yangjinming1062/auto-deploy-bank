-- Create basic Frappe tables
USE frappe;

-- Create tabSingles table (required for Frappe to start)
CREATE TABLE IF NOT EXISTS `tabSingles` (
    `doctype` VARCHAR(140) NOT NULL,
    `field` VARCHAR(140) NOT NULL,
    `value` TEXT,
    INDEX `doctype` (`doctype`),
    INDEX `field` (`field`)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb3;

-- Create tabDocType table
CREATE TABLE IF NOT EXISTS `tabDocType` (
    `name` VARCHAR(140) NOT NULL,
    `owner` VARCHAR(140) NOT NULL DEFAULT 'Administrator',
    `creation` DATETIME(6),
    `modified` DATETIME(6),
    `modified_by` VARCHAR(140),
    `docstatus` INT NOT NULL DEFAULT 0,
    `parent` VARCHAR(140),
    `parentfield` VARCHAR(140),
    `parenttype` VARCHAR(140),
    `idx` INT NOT NULL DEFAULT 0,
    `module` VARCHAR(140),
    `app` VARCHAR(140),
    `is_submittable` INT NOT NULL DEFAULT 0,
    `is_tree` INT NOT NULL DEFAULT 0,
    `is_child_table` INT NOT NULL DEFAULT 0,
    `istable` INT NOT NULL DEFAULT 0,
    `depends_on` VARCHAR(140),
    `description` TEXT,
    PRIMARY KEY (`name`),
    INDEX `creation` (`creation`)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb3;

-- Create tabDocField table
CREATE TABLE IF NOT EXISTS `tabDocField` (
    `name` VARCHAR(140) NOT NULL,
    `owner` VARCHAR(140) NOT NULL DEFAULT 'Administrator',
    `creation` DATETIME(6),
    `modified` DATETIME(6),
    `modified_by` VARCHAR(140),
    `docstatus` INT NOT NULL DEFAULT 0,
    `parent` VARCHAR(140),
    `parentfield` VARCHAR(140),
    `parenttype` VARCHAR(140),
    `idx` INT NOT NULL DEFAULT 0,
    `fieldname` VARCHAR(140),
    `fieldtype` VARCHAR(140),
    `label` VARCHAR(140),
    `reqd` INT NOT NULL DEFAULT 0,
    `hidden` INT NOT NULL DEFAULT 0,
    `options` TEXT,
    `default` TEXT,
    PRIMARY KEY (`name`),
    INDEX `parent` (`parent`)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb3;

-- Create tabDocPerm table
CREATE TABLE IF NOT EXISTS `tabDocPerm` (
    `name` VARCHAR(140) NOT NULL,
    `owner` VARCHAR(140) NOT NULL DEFAULT 'Administrator',
    `creation` DATETIME(6),
    `modified` DATETIME(6),
    `modified_by` VARCHAR(140),
    `docstatus` INT NOT NULL DEFAULT 0,
    `parent` VARCHAR(140),
    `parentfield` VARCHAR(140),
    `parenttype` VARCHAR(140),
    `idx` INT NOT NULL DEFAULT 0,
    `role` VARCHAR(140),
    `read` INT NOT NULL DEFAULT 0,
    `write` INT NOT NULL DEFAULT 0,
    `create` INT NOT NULL DEFAULT 0,
    `delete` INT NOT NULL DEFAULT 0,
    PRIMARY KEY (`name`),
    INDEX `parent` (`parent`)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb3;

-- Create tabDefaultValue table
CREATE TABLE IF NOT EXISTS `tabDefaultValue` (
    `name` VARCHAR(140) NOT NULL,
    `owner` VARCHAR(140) NOT NULL DEFAULT 'Administrator',
    `creation` DATETIME(6),
    `modified` DATETIME(6),
    `modified_by` VARCHAR(140),
    `docstatus` INT NOT NULL DEFAULT 0,
    `parent` VARCHAR(140),
    `parentfield` VARCHAR(140),
    `parenttype` VARCHAR(140),
    `idx` INT NOT NULL DEFAULT 0,
    `defkey` VARCHAR(140),
    `defvalue` TEXT,
    PRIMARY KEY (`name`),
    INDEX `parent` (`parent`),
    INDEX `defkey` (`defkey`)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb3;

-- Create tabModule table (required for Core module)
CREATE TABLE IF NOT EXISTS `tabModule` (
    `name` VARCHAR(140) NOT NULL,
    `owner` VARCHAR(140) NOT NULL DEFAULT 'Administrator',
    `creation` DATETIME(6),
    `modified` DATETIME(6),
    `modified_by` VARCHAR(140),
    `docstatus` INT NOT NULL DEFAULT 0,
    `parent` VARCHAR(140),
    `parentfield` VARCHAR(140),
    `parenttype` VARCHAR(140),
    `idx` INT NOT NULL DEFAULT 0,
    `app_name` VARCHAR(140),
    PRIMARY KEY (`name`),
    INDEX `creation` (`creation`)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb3;

-- Create tabUser table
CREATE TABLE IF NOT EXISTS `tabUser` (
    `name` VARCHAR(140) NOT NULL,
    `owner` VARCHAR(140) NOT NULL DEFAULT 'Administrator',
    `creation` DATETIME(6),
    `modified` DATETIME(6),
    `modified_by` VARCHAR(140),
    `docstatus` INT NOT NULL DEFAULT 0,
    `parent` VARCHAR(140),
    `parentfield` VARCHAR(140),
    `parenttype` VARCHAR(140),
    `idx` INT NOT NULL DEFAULT 0,
    `email` VARCHAR(140),
    `username` VARCHAR(140),
    `first_name` VARCHAR(140),
    `last_name` VARCHAR(140),
    `enabled` INT NOT NULL DEFAULT 1,
    `is_admin` INT NOT NULL DEFAULT 0,
    `is_guest` INT NOT NULL DEFAULT 0,
    `last_login` DATETIME(6),
    PRIMARY KEY (`name`),
    UNIQUE INDEX `email` (`email`),
    INDEX `creation` (`creation`)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb3;

-- Insert Core module (required for module resolution)
INSERT IGNORE INTO `tabModule` (`name`, `owner`, `creation`, `modified`, `modified_by`, `app_name`) VALUES
('Core', 'Administrator', NOW(), NOW(), 'Administrator', 'frappe');

-- Insert minimal DocType records
INSERT IGNORE INTO `tabSingles` (`doctype`, `field`, `value`) VALUES
('System Settings', 'app_name', 'Frappe'),
('System Settings', 'enabled', '1'),
('Website Settings', 'website_name', 'My Site'),
('Website Settings', 'enabled', '1');

-- Insert default Admin user
INSERT IGNORE INTO `tabUser` (`name`, `owner`, `email`, `username`, `first_name`, `enabled`, `is_admin`) VALUES
('Administrator', 'Administrator', 'Administrator', 'admin', 'Admin', 1, 1);

-- Set Admin user as enabled in tabSingles
INSERT IGNORE INTO `tabSingles` (`doctype`, `field`, `value`) VALUES
('User', 'email', 'Administrator');