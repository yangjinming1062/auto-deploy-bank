#!/usr/bin/env python3
"""
User Account Creation Script for Frappe Framework

This script creates user accounts in a Frappe site using the framework's API.
It can be used programmatically or run as a standalone script.

Usage:
    python create_users.py

Requirements:
    - Frappe site must be initialized
    - Database and Redis must be running
    - Environment variables or site config must be properly set
"""

import os
import sys


def create_user(
    site_name,
    email,
    first_name=None,
    last_name=None,
    password=None,
    user_type="System User",
    send_welcome_email=False,
    roles=None,
    db_password=None,
    db_host=None,
    db_port=None,
    redis_queue=None,
    redis_cache=None
):
    """
    Create a new user in a Frappe site.

    Args:
        site_name: Name of the Frappe site
        email: User's email (also used as username)
        first_name: User's first name (defaults to email)
        last_name: User's last name
        password: User's password (required for login)
        user_type: Type of user ("System User" or "Website User")
        send_welcome_email: Whether to send welcome email
        roles: List of roles to assign to the user
        db_password: Database password (from site_config or env)
        db_host: Database host
        db_port: Database port
        redis_queue: Redis queue URL
        redis_cache: Redis cache URL

    Returns:
        dict: User creation result with success status and message
    """
    # Set environment variables if provided
    if site_name:
        os.environ["FRAPPE_SITE"] = site_name
    if db_password:
        os.environ["FRAPPE_DB_PASSWORD"] = db_password
    if db_host:
        os.environ["FRAPPE_DB_HOST"] = db_host
    if db_port:
        os.environ["FRAPPE_DB_PORT"] = str(db_port)
    if redis_queue:
        os.environ["FRAPPE_REDIS_QUEUE"] = redis_queue
    if redis_cache:
        os.environ["FRAPPE_REDIS_CACHE"] = redis_cache

    try:
        import frappe

        # Initialize Frappe
        frappe.init(site=site_name)
        frappe.connect()

        # Create user document
        user = frappe.new_doc("User")
        user.update(
            {
                "name": email,
                "email": email,
                "enabled": 1,
                "first_name": first_name or email.split("@")[0],
                "last_name": last_name,
                "user_type": user_type,
                "send_welcome_email": 1 if send_welcome_email else 0,
            }
        )

        # Insert user
        user.insert()
        frappe.db.commit()

        # Add roles if specified
        if roles:
            user.add_roles(*roles)

        # Set password if provided
        if password:
            from frappe.utils.password import update_password
            update_password(user=user.name, pwd=password)
            frappe.db.commit()

        # Cleanup
        frappe.destroy()

        return {
            "success": True,
            "message": f"User '{email}' created successfully",
            "user": email,
        }

    except Exception as e:
        if "frappe" in sys.modules:
            try:
                frappe.destroy()
            except:
                pass

        return {
            "success": False,
            "message": f"Failed to create user: {str(e)}",
            "error": str(e),
        }


def create_users_batch(site_name, users_list):
    """
    Create multiple users in batch.

    Args:
        site_name: Name of the Frappe site
        users_list: List of user dictionaries with user creation parameters

    Returns:
        dict: Batch creation results
    """
    results = []
    failed = []

    for user_data in users_list:
        email = user_data.get("email")
        if not email:
            failed.append({"user_data": user_data, "error": "Email is required"})
            continue

        result = create_user(site_name, **user_data)
        results.append(result)

        if not result["success"]:
            failed.append(result)

    return {
        "total": len(users_list),
        "created": len([r for r in results if r["success"]]),
        "failed": len(failed),
        "results": results,
        "failed_details": failed,
    }


if __name__ == "__main__":
    # Example usage
    # This demonstrates how to use the script programmatically

    # Example 1: Create a single user
    result = create_user(
        site_name="localhost",
        email="user@example.com",
        first_name="John",
        last_name="Doe",
        password="SecurePassword123!",
        user_type="System User",
        roles=["System Manager"],
    )
    print(f"User creation result: {result}")

    # Example 2: Create multiple users
    users = [
        {
            "email": "admin@example.com",
            "first_name": "Admin",
            "last_name": "User",
            "password": "AdminPass123!",
            "user_type": "System User",
            "roles": ["System Manager", "Administrator"],
        },
        {
            "email": "user1@example.com",
            "first_name": "User",
            "last_name": "One",
            "password": "UserPass123!",
            "user_type": "System User",
            "roles": ["Employee"],
        },
        {
            "email": "user2@example.com",
            "first_name": "User",
            "last_name": "Two",
            "password": "UserPass123!",
            "user_type": "System User",
            "roles": ["Employee"],
        },
    ]

    batch_result = create_users_batch("localhost", users)
    print(f"\nBatch creation result: {batch_result}")

    # Note: In production, you would:
    # 1. Load configuration from environment variables or config files
    # 2. Get database credentials from site config
    # 3. Handle errors appropriately
    # 4. Log results for auditing

    print("\n" + "="*60)
    print("Script completed. Review results above.")
    print("="*60)