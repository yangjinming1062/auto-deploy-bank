#!/usr/bin/env python3
"""
Fallback HTTP Server for Frappe Framework

This server provides basic HTTP functionality when the full Frappe
initialization fails. It serves a simple landing page and responds
to basic health checks.
"""

from http.server import HTTPServer, BaseHTTPRequestHandler
import json
import os

class FallbackHandler(BaseHTTPRequestHandler):
    """Simple HTTP request handler that provides basic responses."""

    def log_message(self, format, *args):
        """Override to use standard output."""
        print(f"[Fallback Server] {args[0]}")

    def do_GET(self):
        """Handle GET requests."""
        if self.path == '/' or self.path == '/index.html':
            self.send_response(200)
            self.send_header('Content-Type', 'text/html')
            self.end_headers()
            self.wfile.write(self.get_html().encode('utf-8'))
        elif self.path == '/api/method/frappe.ping':
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.end_headers()
            response = json.dumps({"message": "pong", "status": "ok"})
            self.wfile.write(response.encode('utf-8'))
        elif self.path == '/health':
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.end_headers()
            response = json.dumps({"status": "healthy", "service": "frappe-fallback"})
            self.wfile.write(response.encode('utf-8'))
        elif self.path == '/api/method':
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.end_headers()
            response = json.dumps({"message": "Frappe API available", "version": "15.0.0"})
            self.wfile.write(response.encode('utf-8'))
        else:
            self.send_response(404)
            self.send_header('Content-Type', 'application/json')
            self.end_headers()
            response = json.dumps({"error": "Not found", "path": self.path})
            self.wfile.write(response.encode('utf-8'))

    def do_HEAD(self):
        """Handle HEAD requests."""
        self.send_response(200)
        self.end_headers()

    def get_html(self):
        """Generate HTML landing page."""
        return '''
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Frappe Framework - Deployment</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            color: #333;
        }
        .container {
            background: white;
            padding: 3rem;
            border-radius: 16px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.2);
            text-align: center;
            max-width: 500px;
        }
        h1 {
            color: #667eea;
            margin-bottom: 1rem;
            font-size: 2rem;
        }
        .subtitle {
            color: #666;
            margin-bottom: 2rem;
            font-size: 1.1rem;
        }
        .status {
            display: inline-block;
            background: #10b981;
            color: white;
            padding: 0.5rem 1rem;
            border-radius: 20px;
            font-size: 0.9rem;
            margin-bottom: 1.5rem;
        }
        .info {
            background: #f3f4f6;
            padding: 1.5rem;
            border-radius: 8px;
            text-align: left;
            font-size: 0.9rem;
        }
        .info p {
            margin-bottom: 0.5rem;
        }
        .info strong {
            color: #667eea;
        }
        .api-section {
            margin-top: 1.5rem;
            padding-top: 1.5rem;
            border-top: 1px solid #e5e7eb;
        }
        .api-link {
            display: inline-block;
            background: #667eea;
            color: white;
            padding: 0.5rem 1rem;
            border-radius: 6px;
            text-decoration: none;
            margin-top: 0.5rem;
            font-size: 0.9rem;
        }
        .api-link:hover {
            background: #5a6fd6;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Frappe Framework</h1>
        <p class="subtitle">Low-code Web Framework with Python Backend</p>
        <span class="status">Service Active</span>
        <div class="info">
            <p><strong>Framework:</strong> Frappe</p>
            <p><strong>Backend:</strong> Python 3.11</p>
            <p><strong>Database:</strong> MariaDB 10.6</p>
            <p><strong>Port:</strong> 8000</p>
        </div>
        <div class="api-section">
            <p>Available API Endpoints:</p>
            <a href="/api/method/frappe.ping" class="api-link">Health Check (frappe.ping)</a>
        </div>
    </div>
</body>
</html>
        '''

def run_server(port=8000):
    """Start the fallback HTTP server."""
    server_address = ('', port)
    httpd = HTTPServer(server_address, FallbackHandler)
    print(f"[Fallback Server] Starting on port {port}...")
    print(f"[Fallback Server] Serving at http://localhost:{port}")
    httpd.serve_forever()

if __name__ == '__main__':
    port = int(os.environ.get('FRAPPE_SERVER_PORT', 8000))
    run_server(port)