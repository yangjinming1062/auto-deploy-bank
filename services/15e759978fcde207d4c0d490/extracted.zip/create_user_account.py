#!/usr/bin/env python3
"""
Script to create user accounts in Frappe Framework.

Usage:
    python create_user_account.py --email user@example.com --password mypassword --first_name John --last_name Doe

Environment Variables:
    FRAPPE_SITE: Site name (default: localhost)
    FRAPPE_DB_PASSWORD: Database password (if not using socket)
"""

import os
import sys

# Set default environment variables
os.environ.setdefault("FRAPPE_SITE", "localhost")


def create_user(
    email: str,
    password: str = None,
    first_name: str = None,
    last_name: str = None,
    user_type: str = "System User",
    roles: list = None,
    send_welcome_email: bool = False,
):
    """
    Create a new user in a Frappe site.

    Args:
        email: User's email address (also serves as username)
        password: Optional password (will be prompted if not provided)
        first_name: First name (defaults to part before @ in email)
        last_name: Last name
        user_type: Type of user (System User, Website User, etc.)
        roles: List of role names to assign
        send_welcome_email: Whether to send welcome email

    Returns:
        dict with success status and message
    """
    import frappe
    from frappe.utils.password import update_password

    site = os.environ.get("FRAPPE_SITE", "localhost")
    frappe.init(site=site)

    try:
        frappe.connect()

        # Set default first_name from email if not provided
        if not first_name:
            first_name = email.split("@")[0]

        # Create user document
        user = frappe.new_doc("User")
        user.update(
            {
                "email": email,
                "first_name": first_name,
                "last_name": last_name or "",
                "enabled": 1,
                "user_type": user_type,
                "send_welcome_email": 1 if send_welcome_email else 0,
            }
        )

        # Insert user
        user.insert()
        frappe.db.commit()

        # Add roles if specified
        if roles:
            user.add_roles(*roles)
            frappe.db.commit()

        # Set password if provided
        if password:
            update_password(user=user.name, pwd=password)
            frappe.db.commit()

        result = {
            "success": True,
            "message": f"User '{email}' created successfully",
            "email": email,
            "first_name": first_name,
            "last_name": last_name or "",
            "roles": roles or [],
        }

        print(f"SUCCESS: {result['message']}")
        return result

    except Exception as e:
        error_msg = f"Failed to create user: {str(e)}"
        print(f"ERROR: {error_msg}", file=sys.stderr)
        return {"success": False, "message": error_msg}

    finally:
        frappe.destroy()


def create_admin_user(password: str = None, email: str = "admin@example.com"):
    """
    Create or update the Administrator user.

    Args:
        password: Admin password (required)
        email: Admin email

    Returns:
        dict with success status and message
    """
    import frappe
    from frappe.utils.password import update_password

    if not password:
        print("ERROR: Password is required for admin user", file=sys.stderr)
        return {"success": False, "message": "Password is required"}

    site = os.environ.get("FRAPPE_SITE", "localhost")
    frappe.init(site=site)

    try:
        frappe.connect()

        # Try to get existing admin user
        if frappe.db.exists("User", "Administrator"):
            print("Updating existing Administrator user...")
            user = frappe.get_doc("User", "Administrator")
        else:
            print("Creating new Administrator user...")
            user = frappe.new_doc("User")
            user.update(
                {
                    "name": "Administrator",
                    "email": email,
                    "first_name": "Administrator",
                    "enabled": 1,
                    "is_admin": 1,
                    "user_type": "System User",
                }
            )
            user.insert()
            frappe.db.commit()

        # Add Administrator role
        if not frappe.db.exists("Role", "Administrator"):
            role = frappe.new_doc("Role")
            role.update({"role_name": "Administrator", "is_custom": 0})
            role.insert()
            frappe.db.commit()

        # Ensure user has Administrator role
        admin_role_exists = frappe.db.exists(
            "Has Role", {"parent": "Administrator", "role": "Administrator"}
        )
        if not admin_role_exists:
            user.append("roles", {"role": "Administrator"})
            user.save()
            frappe.db.commit()

        # Set password
        update_password(user="Administrator", pwd=password)
        frappe.db.commit()

        result = {
            "success": True,
            "message": "Administrator user created/updated successfully",
            "email": email,
        }

        print(f"SUCCESS: {result['message']}")
        return result

    except Exception as e:
        error_msg = f"Failed to create admin user: {str(e)}"
        print(f"ERROR: {error_msg}", file=sys.stderr)
        return {"success": False, "message": error_msg}

    finally:
        frappe.destroy()


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(
        description="Create user accounts in Frappe Framework"
    )
    subparsers = parser.add_subparsers(dest="command", help="Command to run")

    # User creation command
    user_parser = subparsers.add_parser("user", help="Create a regular user")
    user_parser.add_argument("--email", required=True, help="User email address")
    user_parser.add_argument("--password", help="User password")
    user_parser.add_argument("--first-name", help="First name")
    user_parser.add_argument("--last-name", help="Last name")
    user_parser.add_argument(
        "--user-type",
        default="System User",
        help="User type (default: System User)",
    )
    user_parser.add_argument(
        "--roles",
        nargs="+",
        help="Roles to assign (e.g., --roles System User Report Viewer)",
    )
    user_parser.add_argument(
        "--send-welcome",
        action="store_true",
        help="Send welcome email to user",
    )

    # Admin user command
    admin_parser = subparsers.add_parser(
        "admin", help="Create or update Administrator user"
    )
    admin_parser.add_argument("--password", required=True, help="Admin password")
    admin_parser.add_argument(
        "--email", default="admin@example.com", help="Admin email"
    )

    args = parser.parse_args()

    if args.command == "user":
        result = create_user(
            email=args.email,
            password=args.password,
            first_name=args.first_name,
            last_name=args.last_name,
            user_type=args.user_type,
            roles=args.roles,
            send_welcome_email=args.send_welcome,
        )
        sys.exit(0 if result["success"] else 1)

    elif args.command == "admin":
        result = create_admin_user(password=args.password, email=args.email)
        sys.exit(0 if result["success"] else 1)

    else:
        parser.print_help()
        sys.exit(1)