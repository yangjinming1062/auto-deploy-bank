// Copyright (c) 2021, Frappe Technologies and contributors
// For license information, please see license.txt

frappe.ui.form.on("Package Release", {
	// refresh: function(frm) {
	// }
});
