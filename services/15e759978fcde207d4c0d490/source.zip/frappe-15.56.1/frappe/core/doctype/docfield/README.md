Represents a field of a DocType analogous to a table column in the database. DocFields represent the properties both the model and the view and hence may or may not have database columns associated (for example, Section Break does not have any column associated.)

See Standard Field Types