function validatedRequest(request, response, next) {
  // NOOP
  next();
}

module.exports = {
  validatedRequest,
};
