from api import api

if __name__ == '__main__':
  api.run(debug=False)