kill -9 $(lsof -t -i tcp:3355) &
kill -9 $(lsof -t -i tcp:8288)