# VectorAdmin Product Screenshots

### Managing Vectors
![Image](./vectors.png)

### Vector Database Connectors
![Image](./connector.png)

### Organization Home
![Image](./org_home.png)

### Workspace Home
![Image](./workspace_home.png)

### Copying data instantly
![Image](./copy.png)

### Background Jobs
![Image](./jobs.png)

