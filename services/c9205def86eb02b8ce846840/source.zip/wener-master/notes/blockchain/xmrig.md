---
title: xmrig
---

# xmrig

- [xmrig/xmrig](https://github.com/xmrig/xmrig)
  - CPU/GPU, Windows, Linux, macOS FreeBSD.
