---
title: thegraph
---

# thegraph

- https://thegraph.com/explorer
- https://testnet.thegraph.com/explorer
- @graphprotocol/graph-ts

```bash
npm add -g @graphprotocol/graph-cli

npx graph init --studio wener/test
npx graph codegen
npx graph build
```


# FAQ

## Failed to deploy to Graph node : Could not deploy subgraph on graph-node: socket hang up
