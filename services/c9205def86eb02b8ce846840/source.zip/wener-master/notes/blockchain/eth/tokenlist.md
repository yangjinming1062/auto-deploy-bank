---
title: Token List
---

# Token List

- [Uniswap/token-lists](https://github.com/Uniswap/token-lists)
  - https://tokenlists.org/ - Ethereum token list
  - https://uniswap.org/tokenlist.schema.json
- [Swap Token](./eth-awesome.md#swap)
  - 流动池也可能会发行自己的 Token 用来激励

```ts
type ExtensionValue = string | number | boolean | null;

export interface TokenInfo {
  readonly chainId: number;
  readonly address: string;
  readonly name: string;
  readonly decimals: number;
  readonly symbol: string;
  readonly logoURI?: string;
  readonly tags?: string[];
  readonly extensions?: {
    readonly [key: string]: { [key: string]: ExtensionValue } | ExtensionValue;
  };
}

export interface Version {
  readonly major: number;
  readonly minor: number;
  readonly patch: number;
}

export interface Tags {
  readonly [tagId: string]: {
    readonly name: string;
    readonly description: string;
  };
}

export interface TokenList {
  readonly name: string;
  readonly timestamp: string;
  readonly version: Version;
  readonly tokens: TokenInfo[];
  readonly keywords?: string[];
  readonly tags?: Tags;
  readonly logoURI?: string;
}
```
