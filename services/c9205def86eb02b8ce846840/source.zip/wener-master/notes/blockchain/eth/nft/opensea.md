---
title: OpenSea
---

# OpenSea

- [ProjectOpenSea/opensea-js](https://github.com/ProjectOpenSea/opensea-js)
- [API Overview](https://docs.opensea.io/reference/api-overview)
  - GET 4/sec/api key
  - POST 2/sec/api key
  - 需要 API Key 的接口 /assets, /events, /validate, /orders
- https://testnets-api.opensea.io/api/v1
- Listing 协议 https://wyvernprotocol.com/
  - [ProjectWyvern/wyvern-js](https://github.com/ProjectWyvern/wyvern-js)
  - https://github.com/ProjectWyvern/wyvern-ethereum/tree/master/contracts

