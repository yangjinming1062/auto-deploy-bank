---
title: DAO
---

# DAO

- [daohaus](./daohaus.md)
- [moloch](./moloch.md)
  - 使用很广泛的 合约
- aragon
- https://www.polkacity.io/
- [gnosis/MultiSigWallet](https://github.com/gnosis/MultiSigWallet)
- gnosis safe
- cobo daas
- dewrok
- vote
  - snapshot
  - vetoken
  - nft+token
- defi
- curve
- cvx
- dune
- coordinape


## Glossary

- 质押土地资产成为DAO的领地
  - Territory 中心化 Vault 协议
