---
title: PolkaSwap
---

# PolkaSwap

- 参考
  - [Introducing the Polkaswap Testnet](https://medium.com/polkaswap/fa85dd8582c0)

## Testnet

- https://test.polkaswap.io/exchange/wallet
- https://testfaucet.polkaswap.io/
