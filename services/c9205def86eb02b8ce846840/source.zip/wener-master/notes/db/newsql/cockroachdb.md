---
title: CockroachDB
---

# CockroachDB

- [cockroachdb/cockroach](https://github.com/cockroachdb/cockroach)
  - BSL, Go
- 参考
  - [Migrate to CockroachDB](https://www.cockroachlabs.com/docs/stable/migration-overview.html)
