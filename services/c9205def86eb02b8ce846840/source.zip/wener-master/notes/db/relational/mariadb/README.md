---
title: MariaDB
tags:
  - Topic
---

# MariaDB

- [MariaDB/server](https://github.com/MariaDB/server)
  - GPLv2, C/C++
- 部分 OS 的 MySQL 为 MariaDB
  - AlpineLinux
- MySQL 5.5.5 fork
- https://hub.docker.com/_/mariadb
