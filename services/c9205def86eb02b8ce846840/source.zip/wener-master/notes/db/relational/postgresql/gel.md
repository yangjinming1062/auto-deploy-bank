---
title: Gel
---

# Gel

- [geldata/gel](https://github.com/geldata/gel)
  - Apache-2.0, Python, Rust
  - 2025-02-26 EdgeDB -> Gel
  - supercharges Postgres with a modern data model, graph queries, Auth & AI solutions
