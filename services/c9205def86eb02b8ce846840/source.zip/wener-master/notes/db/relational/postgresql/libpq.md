---
title: libpq
---

# libpq
* PostgreSQL C 客户端库 - 也用于 C++, Perl, Python, Tcl, ECPG 客户端
* [Environment Variables](https://www.postgresql.org/docs/current/libpq-envars.html)
