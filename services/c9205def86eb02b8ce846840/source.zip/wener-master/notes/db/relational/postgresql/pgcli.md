---
title: pgcli
---

# pgcli

- [dbcli/pgcli](https://github.com/dbcli/pgcli)
  - BSD-3, **Python**


```bash
brew install pgcli
```
