---
title: neon
---

# neon

- [neondatabase/neon](https://github.com/neondatabase/neon)
  - Rust, Apache 2.0
  - serverless PostgreSQL
  - alternative to AWS Aurora Postgres
- 分离存储和计算
