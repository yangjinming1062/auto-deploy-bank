---
title: PostgreSQL Embeded
---

# PostgreSQL Embeded

- [fergusstrange/embedded-postgres](https://github.com/fergusstrange/embedded-postgres)
  - Golang
- https://repo1.maven.org/maven2/io/zonky/test/postgres/
  - `/io/zonky/test/postgres/embedded-postgres-binaries-%s-%s/%s/embedded-postgres-binaries-%s-%s-%s.jar`
