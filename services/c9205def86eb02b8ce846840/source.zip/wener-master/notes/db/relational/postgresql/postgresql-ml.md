---
title: PostgreSQL ML
---

# PostgreSQL ML

- https://postgresml.org/docs/guides/training/algorithm_selection
- https://github.com/postgresml/postgresml/blob/master/docker-compose.yml
