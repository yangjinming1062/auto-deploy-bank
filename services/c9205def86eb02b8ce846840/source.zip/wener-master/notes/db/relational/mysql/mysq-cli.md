---
tags:
  - CLI
---

# MySQL CLI

```bash
mysql -h mysql -P 3306 -u $user -p$passsword my-db -Bse 'select 1'
```
