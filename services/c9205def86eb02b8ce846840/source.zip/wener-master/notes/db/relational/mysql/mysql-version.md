---
tags:
  - Version
---

# MySQL Version

| version     | GA         | eol        |
| ----------- | ---------- | ---------- |
| [MySQL 8.0] | 2018-04-19 | 2026-04    |
| [MySQL 5.7] | 2015-10-21 | 2023-10    |
| [MySQL 5.6] | 2013-02-05 | 2021-02-05 |

- [MySQL 5.7 Release Notes](https://dev.mysql.com/doc/relnotes/mysql/5.7/en/)

## MySQL 8.0

## MySQL 5.7

## MySQL 5.6.5

- `DATETIME(3)` 支持

## MySQL 5.6.4

- 动态默认值
