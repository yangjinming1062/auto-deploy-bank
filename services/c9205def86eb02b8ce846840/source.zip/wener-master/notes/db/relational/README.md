---
title: 关系型数据库
---

# RDBMS
