---
title: DynamoDB
---

# DynamoDB

- Amazon DynamoDB
  - January 2012
- [DynamoDB API Reference](https://docs.aws.amazon.com/amazondynamodb/latest/APIReference/)
  - JSON over HTTP
- KV + JSON Document
- Amazon DocumentDB
  - 基于 DynamoDB 的 MongoDB 适配层
