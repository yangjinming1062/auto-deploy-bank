---
title: Column Store
---

# Column Store

> 推荐 [ClickHouse](./clickhouse/README.md)

- 列式存储大多用于分析
- Wide-column 不是 Column 存储

