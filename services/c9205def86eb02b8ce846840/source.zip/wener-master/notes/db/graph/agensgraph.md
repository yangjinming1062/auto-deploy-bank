---
title: agensgraph
---

# agensgraph

- [bitnine-oss/agensgraph](https://github.com/bitnine-oss/agensgraph)
  - Apache-2.0
  - graph database based on PostgreSQL
- 参考
  - [apache/age-viewer](https://github.com/apache/age-viewer)
    - PostgreSQL 11
