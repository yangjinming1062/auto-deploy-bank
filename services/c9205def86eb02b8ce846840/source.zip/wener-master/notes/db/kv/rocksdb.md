---
title: RocksDB
---

# RocksDB

- [facebook/rocksdb](https://github.com/facebook/rocksdb)
  - fork 自 LevelDB
- 参考
  - used by: AragonDB, MySQL/MariaDB/MyRocks, Ceph BlueStore, FusionDB, TiDB, YugabyteDB
  - wikipedia [RocksDB](https://en.wikipedia.org/wiki/RocksDB)
