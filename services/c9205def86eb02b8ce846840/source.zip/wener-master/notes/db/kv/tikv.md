---
title: TiKV
---

# TiKV

- [tikv/tikv](https://github.com/tikv/tikv)
  - Apache-2.0, Rust
  - 目前就 Java 和 Go 客户端相对稳定 https://tikv.org/docs/dev/develop/clients/introduction/
  - https://tikv.org/adopters/
