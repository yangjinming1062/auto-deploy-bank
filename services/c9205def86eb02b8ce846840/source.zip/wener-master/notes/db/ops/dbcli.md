---
title: dbcli
---

# dbcli

- https://github.com/dbcli
  - 一系列数据库的 CLI
  - pgcli， mysql, litecli, mssql-cli
- 参考
  - https://github.com/laixintao/iredis
