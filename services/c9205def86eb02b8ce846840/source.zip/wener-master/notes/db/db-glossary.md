---
tags:
  - Glossory
---

# 数据库术语

| abbr. | stand for                 | cn                |
| ----- | ------------------------- | ----------------- |
| DSN   | data source name          | connection string |
| STI   | Single Table Inheritance  | 单表继承          |
| ORM   | Object-Relational Mapping | 对象关系映射      |
| ERM   | Entity-Relationship Model | 实体关系模型      |
