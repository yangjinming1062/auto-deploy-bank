---
title: GPT
---

# GPT

- GPT - Generative Pre-trained Transformer - 生成式预训练变换器
