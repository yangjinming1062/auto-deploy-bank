---
title: dify
---

# dify

- [langgenius/dify](https://github.com/langgenius/dify)
  - Apache-2.0+Commons Clause
    - 不允许多租户 SaaS 服务
    - 不允许修改 Logo
- https://github.com/langgenius/dify/blob/main/docker/docker-compose.yaml
  - api
  - worker
  - web
  - postgres
  - redis
  - weaviate
- https://github.com/BorisPolonsky/dify-helm
