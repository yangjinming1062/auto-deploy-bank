---
tags:
  - WebUI
---

# Lobe Chat

- [lobehub/lobe-chat](https://github.com/lobehub/lobe-chat)
  - ~~Apache-2.0~~, TypeScript, React, tRPC, Next.js, antd, drizzle, langchain
  - WebUI
  - 支持 Auth 集成 - logto, zitadel, clerk
  - 依赖 electric-sql/pglite
