---
tags:
- App
---


# ChatBox

- [Bin-Huang/chatbox](https://github.com/Bin-Huang/chatbox)
  - GPLv3, TypeScript, React
  - Client App for AI Models/LLMs


## 安装

- Android [APK](https://chatboxai.app/install?download=android_apk)
- Android Google Play [ChatBox](https://play.google.com/store/apps/details?id=xyz.chatboxapp.chatbox)
- iOS App Store [ChatBox AI](https://apps.apple.com/app/chatbox-ai/id6471368056)
- Web [chatboxai.app](https://chatboxai.app/)
