---
title: Cherry Studio
tags:
  - Desktop
---

# Cherry Studio

- [CherryHQ/cherry-studio](https://github.com/CherryHQ/cherry-studio)
  - ~~Apache-2.0~~, TS, React, Electron
