---
title: 中文分词
---

# 中文分词

- http://sighan.cs.uchicago.edu/
  - http://sighan.cs.uchicago.edu/bakeoff2005/
- https://github.com/go-ego/gse
