
# midjourney

- Dump
  - https://huggingface.co/datasets/vivym/midjourney-messages
  - https://huggingface.co/datasets/succinctly/midjourney-prompts
  - https://www.kaggle.com/datasets/da9b9ba35ffbd86a5f97ccd068d3c74f5742cfe5f34f6aaf1f0f458d7694f55e
  - https://github.com/JourneyDB/JourneyDB
  - https://huggingface.co/datasets/ehristoforu/midjourney-images
