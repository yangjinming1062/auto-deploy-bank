---
title: InternVL
---

# InternVL

- https://github.com/OpenGVLab/InternVL
- [InternVL 3.5](https://huggingface.co/collections/OpenGVLab/internvl35-68ac87bd52ebe953485927fb)
- MPO - Mixed Performance Optimization

:::tip

- feat: support internvl [ggml-org/llama.cpp#9403](https://github.com/ggml-org/llama.cpp/pull/9403)

:::
