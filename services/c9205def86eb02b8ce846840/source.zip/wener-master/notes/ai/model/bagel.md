---
title: BAGEL
---

# BAGEL

- [bytedance-seed/BAGEL](https://github.com/bytedance-seed/BAGEL)
  - Apache-2.0, Python
  - Text-to-Image, Image-to-Image&Text
  - 图片编辑、风格转换、图片理解
  - 基于 Qwen2.5-7B
- 参考
  - [LeanModels/Bagel-DFloat11](https://github.com/LeanModels/Bagel-DFloat11)
    - 32% smaller size
    - model 29.21 GB -> 19.89 GB
    - 1024 Image Gen Peak GPU Memory 30.07 GB -> 21.76 GB
