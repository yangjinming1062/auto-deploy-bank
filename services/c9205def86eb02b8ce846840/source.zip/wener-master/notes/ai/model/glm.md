---
title: GLM
---

# GLM

- [zai-org/GLM-4.1V-Thinking](https://github.com/zai-org/GLM-4.1V-Thinking)
  - 9B, 64K context, Vision, Reasoning
  - 基于 GLM-4-9B-0414
  - glmv_reward
- `<|begin_of_box|>`, `<|end_of_box|>`
  - 核心答案
  - 可能会导致格式错误
  - https://github.com/zai-org/GLM-4.1V-Thinking/issues/79
- `<think>`
- `</think>`
- `<answer>`
- `</answer>`
