---
title: 混元
tags:
  - Tencent
---

# Hunyuan

- 混元
- [Tencent-Hunyuan](https://github.com/Tencent-Hunyuan)
- https://hunyuan.tencent.com/
- [Tencent-Hunyuan/HunyuanVideo-Avatar](https://github.com/Tencent-Hunyuan/HunyuanVideo-Avatar)
  - 5秒, 129帧
  - hf [tencent/HunyuanVideo-Avatar](https://huggingface.co/tencent/HunyuanVideo-Avatar)
  - playround
    - https://fal.ai/models/fal-ai/hunyuan-avatar
