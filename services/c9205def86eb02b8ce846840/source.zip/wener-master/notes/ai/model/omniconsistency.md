---
title: OmniConsistency
---

# OmniConsistency

- [showlab/OmniConsistency](https://github.com/showlab/OmniConsistency)
  - https://huggingface.co/showlab/OmniConsistency

| style            | cn                       |
| ---------------- | ------------------------ |
| 3D Chibi         | 3D 萌系                  |
| American Cartoon | 美式卡通                 |
| Chinese Ink      | 中国水墨                 |
| Clay Toy         | 黏土玩具                 |
| Fabric           | 布艺                     |
| Ghibli           | 吉卜力                   |
| Irasutoya        | いらすとや, 日本插画风格 |
| Jojo             | JOJO风格                 |
| LEGO             | 乐高                     |
| Line             | Line风格                 |
| Macaron          | 马卡龙                   |
| Oil Painting     | 油画                     |
| Origami          | 折纸                     |
| Paper Cutting    | 剪纸                     |
| Picasso          | 毕加索                   |
| Pixel            | 像素风                   |
| Poly             | 多边形                   |
| Pop Art          | 波普艺术                 |
| Rick and Morty   | 瑞克和莫蒂               |
| Snoopy           | 史努比                   |
| Van Gogh         | 梵高                     |
| Vector           | 矢量风                   |
