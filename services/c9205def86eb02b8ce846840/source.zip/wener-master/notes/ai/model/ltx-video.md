---
title: LTX-Video
tags:
  - T2V
---

# LTX-Video

- [Lightricks/LTX-Video](https://github.com/Lightricks/LTX-Video)
  - DiT-based, 30FPS, 1216×704, 高质量, 实时
  - text-to-image, image-to-video, keyframe-based animation, video extension, video-to-video transformations
- 参考
  - ComfyUI-LTXTricks
