---
title: Alpaca
---

# Alpaca

- Alpace - 羊驼
  - = LLaMa + ChatGPT4 Self-Instruct 训练
  - LLaMa -
- [tatsu-lab/stanford_alpaca](https://github.com/tatsu-lab/stanford_alpaca)
- [Alpaca: A Strong, Replicable Instruction-Following Model](https://crfm.stanford.edu/2023/03/13/alpaca.html)
  - 175 seed task -> text-davinci-003
- [yizhongw/self-instruct](https://github.com/yizhongw/self-instruct)
  -  Self-Instruct seed task
