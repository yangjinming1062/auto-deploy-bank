---
tags:
  - Agent
  - CLI
---

# slopus/happy
- https://github.com/slopus/happy
  - MIT, TS
  - Mobile and Web Client for Claude Code & Codex

```bash
npm install -g happy-coder
```
