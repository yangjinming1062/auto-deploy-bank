---
tags:
  - Gateway
---

# BricksLLM

- [bricks-cloud/BricksLLM](https://github.com/bricks-cloud/BricksLLM)
  - MIT, Golang
  - Enterprise-grade API gateway
  - 提供访问控制、监控
  - 支持 OpenAI, Azure OpenAI, Anthropic, vLLM 等
  - 后端 PostgreSQL+Redis
