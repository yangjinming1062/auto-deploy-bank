---
title: langchain
---

# langchain

- [langchain-ai/langchainjs](https://github.com/langchain-ai/langchainjs)
  - MIT, TS
  - reusable components and integrations for building LLM applications

```bash
npm i langchain @langchain/community @langchain/core @langchain/ollama
```
