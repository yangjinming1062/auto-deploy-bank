---
title: AGENTS.md
---

# AGENTS.md

- [openai/agents.md](https://github.com/openai/agents.md)
  - 支持 Codex, Amp, Jules, Cursor, Factory, RooCode
- 参考
  - https://agents.md/
  - Calude Code https://github.com/anthropics/claude-code/issues/6235
- 类似
  - CLAUDE.md
  - GEMINI.md
- https://github.com/search?q=path:**/CLAUDE.md&type=code
- https://github.com/search?q=path:**/settings.local.json&type=code
