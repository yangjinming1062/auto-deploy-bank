---
tags:
- Dev
---

# MCP Dev

- https://github.com/modelcontextprotocol
  - [modelcontextprotocol/inspector](https://github.com/modelcontextprotocol/inspector)


```bash
pnpx @modelcontextprotocol/inspector tsx ./src/main.ts
```


- https://modelcontextprotocol.io/specification/draft/server/tools#output-schema
- 目前即便是返回了 structureContent 也需要返回 content，否则可能会有客户端不支持
