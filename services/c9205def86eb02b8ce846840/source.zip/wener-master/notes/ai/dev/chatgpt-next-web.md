---
tags:
  - WebUI
---

# ChatGPT-Next-Web

- [ChatGPTNextWeb/NextChat](https://github.com/ChatGPTNextWeb/NextChat)
  - MIT, TS, React, SCSS
  - 之前 Yidadaa/ChatGPT-Next-Web
