---
title: ClearML
---

# ClearML

- [allegroai/clearml](https://github.com/allegroai/clearml)
  - Apache-2.0, Python
  - Auto-Magical CI/CD to streamline your AI workload.
