# Nets


* AlexNet
* LeNet
* VGGNetA
* VGGNetD
* GoogleLeNet

* Model Zoo
  * [DL4J](https://deeplearning4j.org/model-zoo)
  * [Keras](https://keras.io/applications/)
  * [MXNet](https://github.com/dmlc/mxnet-model-gallery)
  * [TensorFlow](https://github.com/tensorflow/models)
  * [Torch](https://github.com/torch/torch7/wiki/ModelZoo)
  * [Caffe](https://github.com/BVLC/caffe/wiki/Model-Zoo)
