---
title: DeepSpeech
---

# DeepSpeech
- [mozilla/DeepSpeech](https://github.com/mozilla/DeepSpeech)
  - golang [asticode/go-astideepspeech](https://github.com/asticode/go-astideepspeech)
- Baidu [Deep Speech: Scaling up end-to-end speech recognition](https://arxiv.org/abs/1412.5567)
