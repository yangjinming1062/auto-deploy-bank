https://github.com/jtoy/awesome-tensorflow/

https://github.com/search?o=desc&q=tensorflow&s=stars&type=Repositories
