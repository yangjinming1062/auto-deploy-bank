---
title: GGML
---

# ggml

- [ggml-org/ggml](https://github.com/ggml-org/ggml)
- 参考
  - Which GGUF is right for me? https://gist.github.com/Artefact2/b5f810600771265fc1e39442288e8ec9
