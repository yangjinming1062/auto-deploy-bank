---
title: detectron2
---

# detectron2

- [facebookresearch/detectron2](https://github.com/facebookresearch/detectron2)
  - Apache-2.0, Python
  - by Facebook AI Research (FAIR), 2019
  - platform for object detection, segmentation and other visual recognition
- 参考
  - [Model Zoo](https://github.com/facebookresearch/detectron2/blob/main/MODEL_ZOO.md)
