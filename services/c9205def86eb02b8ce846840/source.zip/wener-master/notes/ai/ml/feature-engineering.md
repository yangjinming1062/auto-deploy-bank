---
title: 特征工程
---

# Feature engineering

- 原始数据变为固体形状的特征数据
  - 例如: image -> 255*255 矩阵
- [Feature engineering](https://en.wikipedia.org/wiki/Feature_engineering)
