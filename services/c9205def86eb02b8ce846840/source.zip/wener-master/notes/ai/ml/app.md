# App

## Tips

## Image Recognition
* [arXiv:1512.00567](https://arxiv.org/abs/1512.00567) - Rethinking the Inception Architecture for Computer Vision
* [Build an Image Recognition API with Go and TensorFlow](https://outcrawl.com/image-recognition-api-go-tensorflow/)
