---
title: OpenCV
---

# OpenCV

- [opencv/opencv](https://github.com/opencv/opencv)
  - Apache-2.0, C++
- [opencv/opencv_contrib](https://github.com/opencv/opencv_contrib) 第三方模块
