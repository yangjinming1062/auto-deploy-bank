# Hardware

* [Deep Learning Hardware Guide](http://timdettmers.com/2015/03/09/deep-learning-hardware-guide/)


https://news.ycombinator.com/item?id=9172048
A Full Hardware Guide to Deep Learning
