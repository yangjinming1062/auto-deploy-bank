---
---

# Segment Anything


- SAM - Segment Anything Model
  - by Meta AI
- https://segment-anything.com/
- 参考
  - [facebookresearch/segment-anything](https://github.com/facebookresearch/segment-anything)
    - SAMv1
  - [facebookresearch/segment-anything-2](https://github.com/facebookresearch/segment-anything-2)
    - SAMv2
    - dataset https://ai.meta.com/datasets/segment-anything-video/
