# Data

* [MNIST](http://yann.lecun.com/exdb/mnist/)
* [ILSVRC-2012-val](http://www.image-net.org/challenges/LSVRC/2012/)
  * Large Scale Visual Recognition Challenge 2012
* 其他下载
  * [dl.caffe.berkeleyvision.org](http://dl.caffe.berkeleyvision.org/)
* [Practice Machine Learning with Datasets from the UCI Machine Learning Repository](http://machinelearningmastery.com/practice-machine-learning-with-small-in-memory-datasets-from-the-uci-machine-learning-repository/)
