---
title: LabelImg
---

# LabelImg

- ~~[HumanSignal/labelImg](https://github.com/HumanSignal/labelImg)~~
  - MIT, Python
  - -> [Label Studio](./label-studio.md)
