---
title: RapidOCR
---

# RapidOCR

- [RapidAI/RapidOCR](https://github.com/RapidAI/RapidOCR)
  - 将 Paddle 处理为 ONNX
  - 提供更便捷的使用方式，专注于推理部署
  - ONNXRuntime、OpenVINO、PaddlePaddle
- [RapidAI/RapidDoc](https://github.com/RapidAI/RapidDoc)
- [RapidAI/RapidTable](https://github.com/RapidAI/RapidTable)
- ~~[RapidAI/RapidOrientation](https://github.com/RapidAI/RapidOrientation)~~
