---
tags:
  - Hub
  - Repository
---

# Hub

- https://pytorch.org/docs/stable/hub.html
- https://pytorch.org/hub/
- 缓存
  - `hub.set_dir(<PATH_TO_HUB_DIR>)`
  - `$TORCH_HOME/hub`
  - `$XDG_CACHE_HOME/torch/hub`
  - ~/.cache/torch/hub
