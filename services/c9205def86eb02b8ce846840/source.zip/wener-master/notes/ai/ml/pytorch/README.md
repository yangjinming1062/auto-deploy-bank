---
title: PyTorch
tags:
  - Framework
---

# PyTorch

- [pytorch](https://github.com/pytorch/pytorch)
  - Python, C++

```bash
pip3 install torch torchvision torchaudio

# for proxychains
brew install proxychains-ng
echo -e '[ProxyList]\nsocks5 	127.0.0.1 8888' > proxychains.conf
proxychains4 pip3 install torch torchvision
```

- https://pytorch.org/tutorials/
- https://www.fast.ai/
