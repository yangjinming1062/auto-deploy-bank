---
tags:
- NLP
---

# PaddleNLP

- [PaddlePaddle/PaddleNLP](https://github.com/PaddlePaddle/PaddleNLP)
  - Apache-2.0, Python
