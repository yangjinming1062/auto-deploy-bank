---
tags:
- TTS
- ASR
---

# PaddleSpeech
- [PaddlePaddle/PaddleSpeech](https://github.com/PaddlePaddle/PaddleSpeech)
