# Word 2 vector

* https://deeplearning4j.org/word2vec
* 中文
  * http://nlp.stanford.edu/projects/chinese-nlp.shtml
