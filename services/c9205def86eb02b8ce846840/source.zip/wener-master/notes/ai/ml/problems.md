# Problems


## OCR
* [端到端的OCR：基于CNN的实现](http://blog.xlvector.net/2016-05/mxnet-ocr-cnn/)
* [Character-Aware Neural Language Models](https://github.com/carpedm20/lstm-char-cnn-tensorflow)
* [tf-lstm-char-cnn](https://github.com/mkroutikov/tf-lstm-char-cnn)
* [Character-Aware Neural Language Models](https://github.com/yoonkim/lstm-char-cnn)
* [LSTMs for OCR July 22,2016](https://www.youtube.com/watch?v=5vW8faXvnrc)
