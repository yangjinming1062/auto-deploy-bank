---
title: shervine
---

# shervine

- https://stanford.edu/~shervine/teaching/

