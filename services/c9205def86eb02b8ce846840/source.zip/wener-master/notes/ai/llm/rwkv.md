---
tags:
- Framework
---

# RWKV

- [BlinkDL/RWKV-LM](https://github.com/BlinkDL/RWKV-LM)
  - Apache-2.0, Python
  - RNN
- [josStorer/RWKV-Runner](https://github.com/josStorer/RWKV-Runner)
