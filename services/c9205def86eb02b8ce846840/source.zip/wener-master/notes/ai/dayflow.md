---
title: Dayflow
tags:
  - Suvillance
---

# Dayflow

- [JerryZLiu/Dayflow](https://github.com/JerryZLiu/Dayflow)
  - MIT, Swift, macOS
  - 定时截屏，定时调用模型统计
- 2k 上下文足够
