---
tags:
  - Server
---

# PaperMC

- [PaperMC/Paper](https://github.com/PaperMC/Paper)
  - GPLv3, MIT, Java
  - fork Spigot -> Bukkit & CraftBukkit
- https://docs.papermc.io/paper/reference/configuration
- https://docs.papermc.io/paper/reference/server-properties
- 参考
  - Hard fork https://forums.papermc.io/threads/the-future-of-paper-hard-fork.1451/
  - https://fill.papermc.io/v3/projects/paper/versions
    - 版本信息

:::caution

- 1.21.5 Update Todo https://github.com/PaperMC/Paper/issues/12289

:::
