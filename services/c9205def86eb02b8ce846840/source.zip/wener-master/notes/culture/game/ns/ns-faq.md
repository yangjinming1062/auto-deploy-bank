---
title: Nitendo Switch FAQ
tags:
  - FAQ
---

# Nitendo Switch FAQ

## 搜索不到 5g WiFi

将路由的 5g WiFi 控制通道修改为小于 149 的通道

## 下载较慢

尝试将网络的 MTU 修改为 1500

## 美国免税邮编

阿拉斯加 99775

## 登记 QR Code


```
https://accounts.nintendo.com/qr_verify?aud=&iat=1586003687&sub=&sig=&exp=1586608487
```

- aud 6ffd70c434d303c8
- 7 天有效期
