---
title: roblox
---

# roblox

- RBLX

```
roblox.com
rbxcdn.com
rbxtrk.com
AS22697
AS11281
```

- [AS22697](https://bgp.tools/as/22697)

## Robux

> 大约 7 RMB / 100 Robux

- USD$ 1 / 100 R$
- RMB$ 7 / 100 R$
- Robux R$
- Premium
  - HK$78 / 月 / 1000 Robux
  - 购买 Robux 额外 35%
- https://gameboost.com/zh/roblox/robux
