---
title: Nobel Prize
---

# Nobel Prize

- since 1901年
- https://www.nobelprize.org/prizes/lists/all-nobel-prizes/
- [诺贝尔奖得主列表](https://zh.wikipedia.org/zh-hans/诺贝尔奖得主列表)
- https://github.com/16131zzzzzzzz/EveryoneNobel
