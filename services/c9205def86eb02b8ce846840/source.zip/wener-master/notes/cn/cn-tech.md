---
title: 国产化
---

# 国产化

- 数据库
- 操作系统
  - UOS - 统信
  - tlinux - 腾讯操作系统
    - http://mirrors.tencent.com/tlinux/
    - 6000/年
  - 欧拉
    - https://www.openeuler.org/
  - 龙蜥
    - CentOS
    - https://mirrors.openanolis.cn/anolis/
