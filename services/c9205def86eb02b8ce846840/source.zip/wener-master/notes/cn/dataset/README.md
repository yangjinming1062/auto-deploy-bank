---
tags:
  - Metadata
---

# 数据集

- 国民经济行业分类
- 行业代码
  - https://www.safe.gov.cn/shaanxi/file/file/20230110/2f2635f29a004452a5542d01f18d6b78.pdf
  - http://www.stats.gov.cn/xxgk/tjbz/gjtjbz/201805/t20180509_1758925.html
- 参考
  - https://github.com/wanghaisheng/healthcaredatastandard
  - https://github.com/ramwin/china-public-data
