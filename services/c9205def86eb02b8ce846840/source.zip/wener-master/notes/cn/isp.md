---
title: ISP
---

# ISP

## 带宽

- 电信互联网专线
  - 50M 约 3W/年
- 联通专线
  - 50M 约 3W/年
- 阿里云 EIP https://help.aliyun.com/zh/eip/product-overview/pay-as-you-go
  - 上海 BGP
    - 50MB ¥3,725/月
    - 100MB ¥7,725/月
    - 按量 ¥0.8/GB + ¥0.02/小时
- 移动互联网专线 - IPv4+80 443
  - 上海 14元/MB/月
    - 50MB 700元/月 - 8400元/年
    - 100M 1400元/月 - 16800元/年
  - 宁波 10元/MB/月
- 移动 SD-WAN - 访问国际互联网
