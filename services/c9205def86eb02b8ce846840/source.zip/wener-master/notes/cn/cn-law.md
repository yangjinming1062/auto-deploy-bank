---
title: 法律法规
---

# 法律法规

- http://www.npc.gov.cn/zgrdw/npc/xinwen/2018-11/05/content_2065671.htm
- https://zh.wikipedia.org/zh-cn/中华人民共和国公司法
