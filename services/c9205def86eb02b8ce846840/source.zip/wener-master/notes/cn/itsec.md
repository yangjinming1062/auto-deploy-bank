---
title: 中国信息安全测评
---

# 中国信息安全测评

- http://www.itsec.gov.cn/fwzz/fwzzcpgg/
- 上海
  - https://www.shtec.org.cn/shsxxaqpczx/index.html
