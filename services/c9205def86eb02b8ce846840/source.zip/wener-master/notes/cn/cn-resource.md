---
tags:
  - Awesome
  - Resource
---

# CN Resources

- 教科书下载
  - https://textbook.synaiv.com/
- https://github.com/TapXWorld/ChinaTextbook
  - 所有小初高、大学PDF教材
