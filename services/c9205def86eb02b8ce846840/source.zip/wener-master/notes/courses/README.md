---
title: 课程
---

# 课程

- [数学]
- Stanford [CS221](./cs221/README.md): Artificial Intelligence: Principles and Techniques
- https://www.deeplearningbook.org/
  - 3 部分
    1. 应用数学和机器学习基础 - Ch 2-5
    2. 现代深度网络实践 - Ch 6-12
    3. 深度学习研究 - Ch 13-20
  - [Deep Learning Book Videos](https://www.youtube.com/playlist?list=PLbBjZEwyU7W1CDs3Vx_GOJ9b3EgYQB3GE)
    - Ch 1-12
