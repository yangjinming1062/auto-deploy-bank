# Adobe

## AE/Pr

- http://www.videocopilot.net/
- http://www.redgiant.com/
- https://fxfactory.com/

- https://helpx.adobe.com/after-effects/using/expression-basics.html
- https://helpx.adobe.com/after-effects/using/keyboard-shortcuts-reference.html

## Pr

- https://helpx.adobe.com/premiere-pro/using/supported-file-formats.html
