---
title: CRC
---

# CRC

- Cyclic Redundancy Check - 循环冗余校验
- crc
- adler32
