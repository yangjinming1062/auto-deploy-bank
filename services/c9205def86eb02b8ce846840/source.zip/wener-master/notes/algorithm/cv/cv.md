http://www.vips.ecs.soton.ac.uk/


该算法可用于游戏地图生成
https://github.com/mxgmn/WaveFunctionCollapse
https://news.ycombinator.com/item?id=12612246

原子图片生成
https://github.com/fogleman/primitive
https://news.ycombinator.com/item?id=12539109


http://stack.gl/

基于 Web 的 CV 库
https://trackingjs.com/
https://github.com/eduardolundgren/tracking.js/

OpenCV js 绑定
https://github.com/peterbraden/node-opencv

自动对照片进行评价
https://keegan.regaind.io/


参数化的 2D 3D 建模
https://github.com/solvespace/solvespace
https://news.ycombinator.com/item?id=12650290



go 并行图像处理库
https://github.com/anthonynsimon/bild


Content aware image resize library
https://github.com/esimov/caire

https://github.com/gen2brain/cam2ip

https://github.com/hunterloftis/pbr

https://github.com/deepfakes/faceswap
