---
title: CV Awesome
tags:
  - Awesome
---

# CV Awesome

- [OpenCV Awesome](../../ai/ml/opencv/opencv-awesome.md)
- [nenadmarkus/picojs](https://github.com/nenadmarkus/picojs)
  - face detection library in 200 lines of JavaScript
  - https://nenadmarkus.com/p/picojs-intro/
  - [nenadmarkus/pico](https://github.com/nenadmarkus/pico)
    - MIT, C
- [imagej/imagej2](https://github.com/imagej/imagej2)
  - BSD-2, Java
  - N-dimensional image processing
- [tesseract-ocr/tesseract](https://github.com/tesseract-ocr/tesseract)
  - Apache-2.0, C++
  - Tesseract Open Source OCR Engine
  - [naptha/tesseract.js](https://github.com/naptha/tesseract.js)
- https://github.com/card-io
  - 信用卡识别
  - iOS, Android
  - 🚧 2018
- https://pyimagesearch.com/
- [roboflow/supervision](https://github.com/roboflow/supervision)
