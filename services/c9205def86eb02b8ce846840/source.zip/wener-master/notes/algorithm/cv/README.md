---
keywords:
  - Computer vision
---

# 计算机视觉

- [CV Awesome](./cv-awesome.md)
- [OpenCV](../../ai/ml/opencv/README.md)
- [ImageMagick](../../service/media/imagemagick.md)
- jpegoptim
- tesseract
- vips
- Haar cascades for object detection
  - [Haar-like feature](https://en.wikipedia.org/wiki/Haar-like_feature)
