---
title: FST
---

# FST

- Finite-State Transducer - 有限状态传感机
  - recognizer
  - generator
  - set relater
  - translator
    - morphological parsing
      - string of letter -> string of morphemes
- 参考
  - [valeriansaliou/sonic](https://github.com/valeriansaliou/sonic)
    使用 FST 构建
  - Automata theory
- vs FSA
  - FSA 无输出
  - FST 有输出
