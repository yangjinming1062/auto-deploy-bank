---
title: Monte-Carlo
---

# Monte-Carlo

- 参考
  - [Monte-Carlo graph search from first principles](https://github.com/lightvector/KataGo/blob/master/docs/GraphSearch.md)
    - [HN](https://news.ycombinator.com/item?id=39662698)
