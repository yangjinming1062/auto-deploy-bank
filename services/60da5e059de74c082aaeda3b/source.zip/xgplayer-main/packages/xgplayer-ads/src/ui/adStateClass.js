export const AD_STATE_CLASS = {
  START: 'xgplayer-ad-start',
  UI_SHOW: 'xgplayer-ad-show-ui'
}
