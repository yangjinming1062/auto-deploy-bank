import * as AdEvents from './events'
import { AdsPlugin } from './plugin'

class AdsUmdPlugin extends AdsPlugin {
  static AdEvents = AdEvents
}

export default AdsUmdPlugin


