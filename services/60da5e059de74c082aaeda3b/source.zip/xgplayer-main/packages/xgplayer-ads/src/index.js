import * as AdEvents from './events'
import { AdsPlugin } from './plugin'

export { AdEvents, AdsPlugin }
export default AdsPlugin
