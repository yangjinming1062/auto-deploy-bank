## 3.0.22
>* fix: tv shouldBlockVideoContent
>* fix: 🐛 (Ads) content video is blocked to play in TV
>* fix: 🐛 (Ads) fix ads plugin umd exports
>* fix: 🐛 (Ads) always autoplay for LG & Samsung TV
## 3.0.21
-
## 3.0.20
>* feat: 🎸 (xgplayer-ads) 增加xgplayer-ads插件，丰富xgplayer货币化能力
>* refactor: 💡 (xgplayer-ads) 完善IMA SDK集成能力
>* feat: 🎸 (xgplayer-ads) 支持IMA SDK插件内异步加载
>* feat: 🎸 (xgplayer-ads) 实现AdUIManager，对Play/Time等UI进行广告适配
>* feat: 🎸 (xgplayer-ads) 支持广告期间，不显示播控UI
>* feat: 🎸 (xgplayer-ads) 广告UI独立于内容UI
>* fix: 🐛 (xgplayer-ads) 修复广告无配置的情况下，内容无法自动播放的问题
>* fix: 🐛 (xgplayer-ads) 针对非广告时，隐藏广告容器，以支持内容区域可操作
>* fix: (xgplayer-ads) 非autoplay时播放器初始化被阻塞
>* refactor: 💡 (xgplayer-ads) 增加adUIManager销毁处理
>* fix: 🐛 (xgplayer-ads) 修复广告被用户跳过后，广告容器依旧展示的问题
>* fix: 🐛 (xgplayer-ads) 修复前贴片广告容器展示的时机，减少内容漏出的时机
>* fix: 🐛 (xgplayer-ads) 广告播放时，隐藏replay组件
>* fix: 🐛 (xgplayer-ads) pod中非最后一个广告，则不隐藏广告容器，减少内容和广告之间的切换



