## 3.0.22
>* fix: (dash) fix the issue of the undefined self variable in the getData method. 
