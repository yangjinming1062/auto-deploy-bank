## 3.0.22
>* fix: (xgplayer-mp4) 修复了当AV1视频流没有colr（颜色信息）box时出现的undefined错误

## 3.0.19
>* feat(xgplayer-mp4、xgplayer-transmuxer): 支持fmp4 + av1解析播放、seek等能力
