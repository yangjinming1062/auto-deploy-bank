export { FlvPlugin as default } from './plugin'
