# 版本更新记录
## 3.0.0-next.3
>* feat(music): export 音乐播放器Preset的所有内置插件
>* feat(music): 增加ab模式和random、setIndex等接口
>* feat(music): 修改UMD全局名称为MusicPreset,并挂载Analyze和歌词
>* feat(music): Analyze默认配色修改为['#ff8177', '#cf556c', '#f99185', '#b12a5b']