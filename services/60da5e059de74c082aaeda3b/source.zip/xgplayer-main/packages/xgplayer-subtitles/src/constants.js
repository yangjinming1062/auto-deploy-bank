
export const EVENTS = {
  RESIZE: 'resize',
  CHANGE: 'change',
  OFF: 'off',
  UPDATE: 'update'
}