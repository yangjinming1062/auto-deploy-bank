# 版本更新记录
## 3.0.19
>* feat(subtitles): 时间戳解析适配xxx:xx.xxx --> xxx:xx.xxx
## 3.0.10
>* feat(subtitles): 字幕展示增加逐字展示能力
## 1.0.24
>*  feat(xgplayer-subtitles): 更新切换字幕的事件触发;添加change事件和off事件
