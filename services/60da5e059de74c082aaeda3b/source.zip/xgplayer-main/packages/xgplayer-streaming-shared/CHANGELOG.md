## xgplayer-streaming-shared@next.34
feat: 增加公共错误码信息
## xgplayer-streaming-shared@next.33
fix: getStats() 统计帧率不准确问题