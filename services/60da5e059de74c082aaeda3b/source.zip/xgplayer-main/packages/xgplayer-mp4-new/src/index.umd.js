export { MP4Plugin as default } from './plugin'
