export { HlsPlugin as default } from './plugin'
