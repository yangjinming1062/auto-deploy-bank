# ShadowHook Documentation

## Manual

[shadowhook Manual - English](manual.md)

[shadowhook 手册 - 简体中文](manual.zh-CN.md)
