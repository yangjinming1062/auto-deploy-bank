#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wunused-variable"
static int a;
#pragma clang diagnostic pop
