import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-salesdetails-window',
  templateUrl: './salesdetails-window.component.html',
  styleUrls: ['./salesdetails-window.component.css']
})
export class SalesdetailsWindowComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
