import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-a-pointofsale-window',
  templateUrl: './a-pointofsale-window.component.html',
  styleUrls: ['./a-pointofsale-window.component.css']
})
export class APointofsaleWindowComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
