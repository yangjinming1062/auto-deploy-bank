import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-outofstock-window',
  templateUrl: './outofstock-window.component.html',
  styleUrls: ['./outofstock-window.component.css']
})
export class OutofstockWindowComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
