import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pickup-order-window',
  templateUrl: './pickup-order-window.component.html',
  styleUrls: ['./pickup-order-window.component.css']
})
export class PickupOrderWindowComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
