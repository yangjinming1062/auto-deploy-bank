import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-new-doctor-order-window',
  templateUrl: './new-doctor-order-window.component.html',
  styleUrls: ['./new-doctor-order-window.component.css']
})
export class NewDoctorOrderWindowComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
