import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-inventory-window',
  templateUrl: './add-inventory-window.component.html',
  styleUrls: ['./add-inventory-window.component.css']
})
export class AddInventoryWindowComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
