import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manage-cashier-account',
  templateUrl: './manage-cashier-account.component.html',
  styleUrls: ['./manage-cashier-account.component.css']
})
export class ManageCashierAccountComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
