import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-supplier-inventory-window',
  templateUrl: './supplier-inventory-window.component.html',
  styleUrls: ['./supplier-inventory-window.component.css']
})
export class SupplierInventoryWindowComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
