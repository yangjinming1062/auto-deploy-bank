export interface Supplier {
  id: string;
  supplierID: string;
  name: string;
  email: string;
  contact: string;
  drugsAvailable: string;

}
