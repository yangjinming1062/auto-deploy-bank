import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-supplier-window',
  templateUrl: './add-supplier-window.component.html',
  styleUrls: ['./add-supplier-window.component.css']
})
export class AddSupplierWindowComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
