import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-about-to-outof-stock-window',
  templateUrl: './about-to-outof-stock-window.component.html',
  styleUrls: ['./about-to-outof-stock-window.component.css']
})
export class AboutToOutofStockWindowComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
