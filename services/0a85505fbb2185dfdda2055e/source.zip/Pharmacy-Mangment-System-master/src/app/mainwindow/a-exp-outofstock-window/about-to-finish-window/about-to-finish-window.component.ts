import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-about-to-finish-window',
  templateUrl: './about-to-finish-window.component.html',
  styleUrls: ['./about-to-finish-window.component.css']
})
export class AboutToFinishWindowComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
