import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-out-of-stock-window',
  templateUrl: './out-of-stock-window.component.html',
  styleUrls: ['./out-of-stock-window.component.css']
})
export class OutOfStockWindowComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
