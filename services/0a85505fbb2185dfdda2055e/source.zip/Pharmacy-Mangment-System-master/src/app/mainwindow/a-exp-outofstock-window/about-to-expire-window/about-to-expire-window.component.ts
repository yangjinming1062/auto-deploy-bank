import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-about-to-expire-window',
  templateUrl: './about-to-expire-window.component.html',
  styleUrls: ['./about-to-expire-window.component.css']
})
export class AboutToExpireWindowComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
