import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-a-sales-window',
  templateUrl: './a-sales-window.component.html',
  styleUrls: ['./a-sales-window.component.css']
})
export class ASalesWindowComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
