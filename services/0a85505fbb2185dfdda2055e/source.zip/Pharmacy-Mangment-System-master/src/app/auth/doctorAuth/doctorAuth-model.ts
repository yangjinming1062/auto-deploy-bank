export interface AuthDoctorData {
  name: string;
  contact: string;
  docId: string;
  email: string;
  password: string;
}
