export interface AuthData {
  name: string;
  contact: string;
  nic: string;
  email: string;
  password: string;
}
