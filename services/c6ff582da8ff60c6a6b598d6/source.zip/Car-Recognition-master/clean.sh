rm data/ -r
rm logs/ -r
rm cars_test/ -r
rm cars_train/ -r
rm devkit/ -r
rm training.log
