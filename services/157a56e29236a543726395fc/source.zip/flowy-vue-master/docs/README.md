# Starter docs - quasar

Hard fork and dirty edit of [Quasar docs](https://github.com/quasarframework/quasar/tree/dev/docs)

[Demo](https://remcoplasmeyer.github.io/quasar-doc-starter/)

- edit `build.publicPath` in `quasar.conf.js`
- `npm run build`
- `npm run deploy`
