export default {
  discordURL: "https://discord.gg/VWf4QX",
  githubURL: "https://github.com/remcoplasmeyer/flowy-vue",
}
