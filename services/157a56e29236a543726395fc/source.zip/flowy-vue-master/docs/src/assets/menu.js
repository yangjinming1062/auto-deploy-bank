// const gettingStarted = [

// ]

// const components = [

// ]

module.exports = [
  {
    name: "Home",
    icon: "room",
    path: "home"
  },
  {
    name: "Home",
    icon: "room",
    path: "anotherone"
  }
];
