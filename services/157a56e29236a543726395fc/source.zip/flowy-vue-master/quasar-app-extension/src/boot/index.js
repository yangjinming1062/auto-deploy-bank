import FlowyPlugin from '@hipsjs/flowy-vue';
import '@hipsjs/flowy-vue/dist/lib/flowy-vue.css';

export default ({ Vue }) => {
  Vue.use(FlowyPlugin);
};
