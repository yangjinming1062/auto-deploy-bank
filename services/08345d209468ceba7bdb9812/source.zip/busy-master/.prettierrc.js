module.exports = {
  singleQuote: true,
  trailingComma: 'all',
  printWidth: 100,
};
