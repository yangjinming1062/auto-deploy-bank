const formatFile = require('..').formatFile;

const file = process.argv[2];

formatFile(file);
