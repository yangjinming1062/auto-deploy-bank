<!-- # DESCRIPTION START # -->

## Description

Discord message components to easily build and display fake Discord messages on
your webpage.

**This is an adaptation of [wc-discord-message] from [Danktuary]**

### Upgrading guide

The source code and documentation of this package has been updated for version
4.x of this package. To find out how to upgrade from v3.x to v4.x, please refer
to the
[upgrading guide](https://discord-components.js.org/upgrading/v3x-v4x/#component-changes)

<!-- # DESCRIPTION END # -->
