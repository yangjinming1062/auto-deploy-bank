# Interesting Papers

- [2008-Aceves-Perez: Answer Fusion...](https://ccc.inaoep.mx/~villasen/articulos/AnswerFusionInMultilingualQA-TSD07.pdf)
- [2015 Gau at arXiv: Multilingual QA](http://arxiv.org/pdf/1505.05612v1.pdf) 
- [2015 Gau at NiPs: mQA](http://papers.nips.cc/paper/5641-are-you-talking-to-a-machine-dataset-and-methods-for-multilingual-image-question.pdf)
- [](http://cs229.stanford.edu/proj2013/MolayKoungTam-LearningCharacteristicsOfSmartphoneUsersFromAccelerometerAndGyroscopeData.pdf)
