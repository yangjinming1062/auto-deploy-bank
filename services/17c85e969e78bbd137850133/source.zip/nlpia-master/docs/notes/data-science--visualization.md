
## Visualization

- [d3 gallery](https://github.com/d3/d3/wiki/Gallery): beautiful interactive live-data visualizations
- [Mike Bostok](https://bost.ocks.org/mike/): Bostok's blog about visualization with d3
- [Seaborn Visualization gallery](http://seaborn.pydata.org/examples/index.html): Lots of great ways to explore data with python
- [Matplotlib Visualization gallery](http://matplotlib.org/gallery.html): Ideas for matplotlib plots
- [R visualization gallery](http://www.r-graph-gallery.com/): Most of these you can do with python too!
