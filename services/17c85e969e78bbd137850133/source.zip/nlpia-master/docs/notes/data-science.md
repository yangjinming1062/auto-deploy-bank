# Data Science

Class notes

## Definition

Science is more important than data in the Wikipedia definition

### VIN Diagram

- hacking skills (working on a problem)
- math and statistics 
- 

### Predictive Modeling is Goal

- don't always have to have an idea of a model
  - statistics may suggest a model

### Communication is key to Model Building
  
- visualizations
- in ML we're often overwhelmed with data
  - difficult to visualize and know when things are going wrong
- compose presentation from the beginning recording the steps you try 
- websites can be shared with public and potential employers


### Anecdote

[Great story](http://mathbabe.org/2012/11/20/columbia-data-science-course-week-12-predictive-modeling-data-leakage-model-evaluation/) about 
- won the prize using patient ID because ID identified whether it was a from a screening center or a treatment clinig