# Tools


## Nonfree

- [GraphLab](https://pypi.python.org/pypi/GraphLab-Create) Distributed Machine learning on Hadoop, AWS, etc