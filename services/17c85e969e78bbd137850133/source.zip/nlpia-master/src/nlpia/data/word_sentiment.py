from nlpia.word_sentiment import *
