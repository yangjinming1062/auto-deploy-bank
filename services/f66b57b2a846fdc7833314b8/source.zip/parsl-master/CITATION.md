Babuji, Y., Woodard, A., Li, Z., Katz, D. S., Clifford, B., Kumar, R., Lacinski, L., Chard, R., Wozniak, J., Foster, I., Wilde, M., and Chard, K., Parsl: Pervasive Parallel Programming in Python. 28th ACM International Symposium on High-Performance Parallel and Distributed Computing (HPDC). 2019.

or

```{tex}
@inproceedings{babuji19parsl,
  author       = {Babuji, Yadu and
                  Woodard, Anna and
                  Li, Zhuozhao and
                  Katz, Daniel S. and
                  Clifford, Ben and
                  Kumar, Rohan and
                  Lacinski, Lukasz and
                  Chard, Ryan and 
                  Wozniak, Justin and
                  Foster, Ian and 
                  Wilde, Mike and
                  Chard, Kyle},
  title        = {Parsl: Pervasive Parallel Programming in Python},
  booktitle    = {28th ACM International Symposium on High-Performance Parallel and Distributed Computing (HPDC)},
  doi          = {10.1145/3307681.3325400},
  year         = {2019},
  url          = {https://doi.org/10.1145/3307681.3325400}
}
```
