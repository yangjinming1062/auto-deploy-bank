:orphan:

.. meta::
    :content http-equiv="refresh": 0;url=apps/index.html

Redirect
--------

This page has been `moved <apps/index.html>`_
