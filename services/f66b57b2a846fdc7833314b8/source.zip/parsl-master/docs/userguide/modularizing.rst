:orphan:

.. meta::
    :content http-equiv="refresh": 0;url=advanced/modularizing.html

Redirect
--------

This page has been `moved <advanced/modularizing.html>`_
