:orphan:

.. meta::
    :content http-equiv="refresh": 0;url=apps/joins.html

Redirect
--------

This page has been `moved <apps/joins.html>`_
