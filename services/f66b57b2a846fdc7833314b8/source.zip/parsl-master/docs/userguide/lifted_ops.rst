:orphan:

.. meta::
    :content http-equiv="refresh": 0;url=workflows/lifted_ops.html

Redirect
--------

This page has been `moved <workflows/lifted_ops.html>`_
