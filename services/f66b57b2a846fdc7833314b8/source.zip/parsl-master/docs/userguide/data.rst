:orphan:

.. meta::
    :content http-equiv="refresh": 0;url=configuration/data.html

Redirect
--------

This page has been `moved <configuration/data.html>`_
