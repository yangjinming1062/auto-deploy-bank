:orphan:

.. meta::
    :content http-equiv="refresh": 0;url=configuration/index.html

Redirect
--------

This page has been `moved <configuration/index.html>`_
