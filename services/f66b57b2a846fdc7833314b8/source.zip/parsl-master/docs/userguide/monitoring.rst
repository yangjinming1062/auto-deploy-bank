:orphan:

.. meta::
    :content http-equiv="refresh": 0;url=advanced/monitoring.html

Redirect
--------

This page has been `moved <advanced/monitoring.html>`_
