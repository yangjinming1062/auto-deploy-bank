:orphan:

.. meta::
    :content http-equiv="refresh": 0;url=advanced/plugins.html

Redirect
--------

This page has been `moved <advanced/plugins.html>`_
