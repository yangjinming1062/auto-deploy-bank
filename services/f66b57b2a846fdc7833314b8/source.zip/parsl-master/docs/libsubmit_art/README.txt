Edittable diagrams embedded in this google doc:
https://docs.google.com/document/d/193LBq7H-dtxrYUER7oZqs0ZlOcLa2fGFPGLOHRS1c5U/edit?usp=sharing

