Developer documentation
=======================

.. toctree::
   :maxdepth: 3

   contributing
   roadmap
   packaging
   ../README
