def some_aux_func():
    pass
