# Security Policy

Please report vulnerabilities privately on security@bugsink.com or
by using the [GitHub Vulnerability Reporting Feature](https://docs.github.com/en/code-security/security-advisories/guidance-on-reporting-and-writing-information-about-vulnerabilities/privately-reporting-a-security-vulnerability)
