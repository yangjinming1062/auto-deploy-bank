Used element dictionaries from dicom3tools library by David Clunie.
Original Location: http://www.dclunie.com/dicom3tools/workinprogress/