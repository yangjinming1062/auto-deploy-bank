#!/bin/sh
set -e

echo "Entrypoint starting..."
ls -la /app/ | head -10

# Always copy the JAR from the image to the volume if it exists
# This ensures the correct JAR is available for security scanning
if [ -f /app/target.jar.image ]; then
    echo "Copying JAR to volume for security scanning..."
    cp /app/target.jar.image /app/target.jar
    chown 65534:65534 /app/target.jar 2>/dev/null || true
    echo "Copy complete. target.jar size: $(ls -lh /app/target.jar | awk '{print $5}')"
else
    echo "ERROR: target.jar.image not found!"
    ls -la /app/target.jar* 2>&1 || true
fi

echo "Entrypoint done, starting application..."
# Run the main command
exec "$@"