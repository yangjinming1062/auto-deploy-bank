    Usage: xml2hl7 [<options>] <xml-file>
    
    Convert <xml-file> (or the standard input if <xml-file> = '-') into HL7 V2 message written to standard output.
    
    Options:
    -h,  --help     display this help and exit
    -V,  --version  output version information and exit
