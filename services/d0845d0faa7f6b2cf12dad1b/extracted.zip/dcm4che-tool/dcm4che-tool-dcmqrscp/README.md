```
usage: dcmqrscp [options] -b [<aet>[@<ip>]:]<port> --dicomdir
                /media/cdrom/DICOMDIR

The dcmqrscp application implements a simple image archive.
-
Options:
    --accept <aet>                      One ore more AE Title(s) that SCP
                                        should accept. By default SCP
                                        accepts any calling AE title.
    --accept-timeout <ms>               timeout in ms for receiving
                                        A-ASSOCIATE-AC, no timeout by
                                        default
    --ae-config <file|url>              file path or URL of list of
                                        configured move destinations,
                                        resource:ae.properties by default
    --all-storage                       accept unknown SOP Classes as
                                        Storage SOP Classes; otherwise
                                        only Storage SOP Classes specified
                                        by --storage-sop-classes are
                                        accepted
    --availability <code>               specify value
                                        (=ONLINE|NEARLINE|OFFLINE|UNAVAILA
                                        BLE) of Instance Availability
                                        (0008,0056) in C-FIND RSP; by
                                        default no Instance Availability
                                        will be included
 -b,--bind <[aet[@ip]:]port>            specify the port on which the
                                        Application Entity shall listening
                                        for incoming association requests.
                                        If no local IP address of the
                                        network interface is specified,
                                        connections on any/all local
                                        addresses are accepted. If an AE
                                        Title is specified, only requests
                                        with matching Called AE Title will
                                        be accepted.
    --cfind-error <code>                return specified error status on
                                        C-FIND-RQs
    --cget-error <code>                 return specified error status on
                                        C-GET-RQs
    --cmove-error <code>                return specified error status on
                                        C-MOVE-RQs
    --connect-timeout <ms>              timeout in ms for TCP connect, no
                                        timeout by default
    --delay-cfind <ms>                  delay in ms returning pending
                                        C-FIND-RSPs, no delay by default
    --delay-cstore <ms>                 delay in ms invoking C-STORE-RQs,
                                        no delay by default
    --dicomdir <file>                   specify path to a DICOMDIR file of
                                        a DICOM File-set into which
                                        received objects are stored and
                                        from which requested objects are
                                        retrieved
    --filepath <pattern>                specifies relative file path in
                                        DICOM File-set of stored objects,
                                        '{ggggeeee,hash}' will be replaced
                                        by the hash of attribute values in
                                        hex;
                                        'DICOM/{0020000D,hash}/{0020000E,h
                                        ash}/{00080018,hash}' by default.
    --fs-desc <txtfile>                 specify File-set Descriptor File
    --fs-desc-cs <code>                 Character Set used in File-set
                                        Descriptor File ("ISO_IR 100" =
                                        ISO Latin 1)
    --fs-id <id>                        specify File-set ID
    --fs-uid <uid>                      specify File-set UID
 -h,--help                              display this help and exit
    --idle-timeout <ms>                 timeout in ms for aborting idle
                                        Associations, no timeout by
                                        default
    --key-pass <password>               password for accessing the key in
                                        the key store, key store password
                                        by default
    --key-store <file|url>              file path or URL of key store
                                        containing the private key,
                                        resource:key.p12 by default
    --key-store-pass <password>         password for key store containing
                                        the private key, 'secret' by
                                        default
    --key-store-type <storetype>        type of key store containing the
                                        private key, PKCS12 by default
    --match-no-value                    if a matching key is not in the
                                        directory record object, consider
                                        the record to be a match anyway.
    --match-pn-icase                    match PN attributes case
                                        insensitive; by default matching
                                        of any attribute value is case
                                        sensitive.
    --max-ops-invoked <no>              maximum number of operations this
                                        AE may invoke asynchronously,
                                        unlimited by default
    --max-ops-performed <no>            maximum number of operations this
                                        AE may perform asynchronously,
                                        unlimited by default
    --max-pdulen-rcv <length>           specifies maximal length of
                                        received P-DATA TF PDUs
                                        communicated during association
                                        establishment. 0 indicates that no
                                        maximum length is specified. 16378
                                        by default
    --max-pdulen-snd <length>           specifies maximal length of sent
                                        P-DATA-TF PDUs by this AE. The
                                        actual maximum length of sent
                                        P-DATA-TF PDUs is also limited by
                                        the maximal length of received
                                        P-DATA-TF PDUs of the peer AE
                                        communicated during association
                                        establishment. 16378 by default
    --no-query                          disable query services; by
                                        default, query services specified
                                        by --query-sop-classes are enabled
    --no-retrieve                       disable retrieve services; by
                                        default, retrieve services
                                        specified by
                                        --retrieve-sop-classes are enabled
    --no-storage                        disable storage services; by
                                        default, storage services
                                        specified by --storage-sop-classes
                                        are enabled if the DICOM File.set
                                        specified by option --dicomdir is
                                        writable
    --not-async                         do not use asynchronous mode;
                                        equivalent to --max-ops-invoked=1
                                        and --max-ops-performed=1
    --not-pack-pdv                      send only one PDV in one P-Data-TF
                                        PDU; pack command and data PDV in
                                        one P-DATA-TF PDU by default
    --pending-cget                      send pending C-GET RSPs; by
                                        default only the final C-GET RSP
                                        will be sent
    --pending-cmove <s>                 send pending C-MOVE RSPs in
                                        specified interval; by default
                                        only the final C-MOVE RSP will be
                                        sent
    --query-sop-classes <file|url>      file path or URL of list of
                                        accepted Query SOP Classes,
                                        resource:query-sop-classes.propert
                                        ies by default
    --record-config <file|url>          file path or URL to configuration
                                        of directory record attributes.
                                        resource:org/dcm4che3/media/Record
                                        Factory.xml by default
    --relational                        support relational queries and
                                        retrievals
    --relational-lenient                accept C-FIND, C-GET and C-MOVE
                                        RQs with missing Unique Key
                                        Attribute for levels above the
                                        Query/Retrieve level even if no
                                        Relational-Queries/Retrieve was
                                        negotiated
    --release-timeout <ms>              timeout in ms for receiving
                                        A-RELEASE-RP, no timeout by
                                        default
    --request-timeout <ms>              timeout in ms for receiving
                                        A-ASSOCIATE-RQ, no timeout by
                                        default
    --response-timeout <ms>             timeout in ms for receiving other
                                        outstanding DIMSE RSPs than C-MOVE
                                        or C-GET RSPs, no timeout by
                                        default
    --retrieve-sop-classes <file|url>   file path or URL of list of
                                        accepted Retrieve SOP Classes,
                                        resource:retrieve-sop-classes.prop
                                        erties by default
    --role-select-lenient               disable check for required SCP/SCU
                                        role selection negotiation on
                                        sending C-STORE-RQs to C-GET SCUs
                                        or N-EVENT-REPORT-RQs to Storage
                                        Commitment SCUs
    --send-timeout <ms>                 timeout in ms for sending other
                                        DIMSE RQs than C-STORE RQs, no
                                        timeout by default
    --soclose-delay <ms>                delay in ms after sending
                                        A-ASSOCATE-RJ, A-RELEASE-RQ or
                                        A-ABORT before the socket is
                                        closed; 50ms by default
    --sorcv-buffer <length>             set SO_RCVBUF socket option to
                                        specified value
    --sosnd-buffer <length>             set SO_SNDBUF socket option to
                                        specified value
    --ssl2Hello                         send/accept SSLv3/TLS ClientHellos
                                        encapsulated in a SSLv2
                                        ClientHello packet; equivalent to
                                        --tls-protocol SSLv2Hello
                                        --tls-protocol SSLv3
                                        --tls-protocol TLSv1
                                        --tls-protocol TLSv1.1
                                        --tls-protocol TLSv1.2
    --ssl3                              enable only TLS/SSL protocol
                                        SSLv3; equivalent to
                                        --tls-protocol SSLv3
    --stgcmt-same-assoc                 attempt to return the Storage
                                        Commitment Result on the same
                                        Association on which the Storage
                                        Commitment Request was received
    --storage-sop-classes <file|url>    file path or URL of list of
                                        accepted Storage SOP Classes,
                                        resource:storage-sop-classes.prope
                                        rties by default
    --store-timeout <ms>                timeout in ms for sending C-STORE
                                        sRQ, no timeout by default
    --tcp-delay                         set TCP_NODELAY socket option to
                                        false, true by default
    --tls                               enable TLS connection without
                                        encryption or with AES or 3DES
                                        encryption; equivalent to
                                        --tls-cipher SSL_RSA_WITH_NULL_SHA
                                        --tls-cipher
                                        TLS_RSA_WITH_AES_128_CBC_SHA
                                        --tls-cipher
                                        SSL_RSA_WITH_3DES_EDE_CBC_SHA
    --tls-3des                          enable TLS connection with 3DES
                                        encryption; equivalent to
                                        --tls-cipher
                                        SSL_RSA_WITH_3DES_EDE_CBC_SHA
    --tls-aes                           enable TLS connection with AES or
                                        3DES encryption; equivalent to
                                        --tls-cipher
                                        TLS_RSA_WITH_AES_128_CBC_SHA
                                        --tls-cipher
                                        SSL_RSA_WITH_3DES_EDE_CBC_SHA
    --tls-cipher <cipher>               enable TLS connection with
                                        specified Cipher Suite. Multiple
                                        Cipher Suites may be enabled by
                                        multiple --tls-cipher options
    --tls-eia-https                     enable server endpoint
                                        identification according RFC 2818:
                                        HTTP Over TLS
    --tls-eia-ldaps                     enable server endpoint
                                        identification according RFC 2830:
                                        LDAP Extension for TLS
    --tls-noauth                        disable client authentification
                                        for TLS
    --tls-null                          enable TLS connection without
                                        encryption; equivalent to
                                        --tls-cipher SSL_RSA_WITH_NULL_SHA
    --tls-protocol <protocol>           TLS/SSL protocol to use. Multiple
                                        TLS/SSL protocols may be enabled
                                        by multiple --tls-protocol
                                        options. Supported values by Java
                                        11: TLSv1, TLSv1.1, TLSv1.2,
                                        TLSv1.3, SSLv3, SSLv2Hello. By
                                        default, only TLSv1.2 is enabled.
    --tls1                              enable only TLS/SSL protocol
                                        TLSv1; equivalent to
                                        --tls-protocol TLSv1
    --tls11                             enable only TLS/SSL protocol
                                        TLSv1.1; equivalent to
                                        --tls-protocol TLSv1.1
    --tls12                             enable only TLS/SSL protocol
                                        TLSv1.2; equivalent to
                                        --tls-protocol TLSv1.2
    --tls13                             enable only TLS/SSL protocol
                                        TLSv1.3; equivalent to
                                        --tls-protocol TLSv1.3
    --trust-store <file|url>            file path of key store containing
                                        trusted certificates,
                                        resource:cacerts.p12 by default
    --trust-store-pass <password>       password for key store with
                                        trusted certificates, 'secret' by
                                        default
    --trust-store-type <storetype>      type of key store with trusted
                                        certificates, PKCS12 by default
 -V,--version                           output version information and
                                        exit
-
Example: dcmqrscp -b DCMQRSCP:11112 --dicomdir /media/cdrom/DICOMDIR
=> Starts server listening on port 11112, accepting association requests
with DCMQRSCP as called AE title.
```
