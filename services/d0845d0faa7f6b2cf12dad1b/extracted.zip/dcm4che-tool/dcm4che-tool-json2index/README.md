````
usage: json2index <schema-dir>

Utility to create search index for UI configuration from JSON schema files

-
Options:
 -h,--help      display this help and exit
 -V,--version   output version information and exit
-
Example: json2index /work/dcm4chee-arc-lang/src/main/webapp/assets/schema
=> Shows attribute names and their descriptions in schema json files
present in specified directory. Also shows the parent of each of the
schemas, if any.
-
````
