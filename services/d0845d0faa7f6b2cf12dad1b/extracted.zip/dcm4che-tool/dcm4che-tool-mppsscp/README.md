```
usage: mppsscp [options] -b [<aet>[@<ip>]:]<port>

The mppsscp application implements a Service Class Provider (SCP) for the
Modality Performed Procedure Step (MPPS) SOP Class. It listens on a
specific TCP/IP port for incoming association requests from a Service
Class User (SCU) of the MPPS SOP Class. MPPS objects received in N-CREATE
requests are stored in DICOM files which are updated on receive of N-SET
requests for that MPPS instance. mppsscp application also supports the
Verification Service Class as a SCP.
-
Options:
    --accept <aet>                   One ore more AE Title(s) that SCP
                                     should accept. By default SCP accepts
                                     any calling AE title.
 -b,--bind <[aet[@ip]:]port>         specify the port on which the
                                     Application Entity shall listening
                                     for incoming association requests. If
                                     no local IP address of the network
                                     interface is specified, connections
                                     on any/all local addresses are
                                     accepted. If an AE Title is
                                     specified, only requests with
                                     matching Called AE Title will be
                                     accepted.
    --directory <path>               directory to which received MPPS
                                     objects are stored, '.' by default
 -h,--help                           display this help and exit
    --idle-timeout <ms>              timeout in ms for aborting idle
                                     Associations, no timeout by default
    --ignore                         do not store received MPPS objects in
                                     files
    --key-pass <password>            password for accessing the key in the
                                     key store, key store password by
                                     default
    --key-store <file|url>           file path or URL of key store
                                     containing the private key,
                                     resource:key.p12 by default
    --key-store-pass <password>      password for key store containing the
                                     private key, 'secret' by default
    --key-store-type <storetype>     type of key store containing the
                                     private key, PKCS12 by default
    --max-ops-invoked <no>           maximum number of operations this AE
                                     may invoke asynchronously, unlimited
                                     by default
    --max-ops-performed <no>         maximum number of operations this AE
                                     may perform asynchronously, unlimited
                                     by default
    --max-pdulen-rcv <length>        specifies maximal length of received
                                     P-DATA TF PDUs communicated during
                                     association establishment. 0
                                     indicates that no maximum length is
                                     specified. 16378 by default
    --max-pdulen-snd <length>        specifies maximal length of sent
                                     P-DATA-TF PDUs by this AE. The actual
                                     maximum length of sent P-DATA-TF PDUs
                                     is also limited by the maximal length
                                     of received P-DATA-TF PDUs of the
                                     peer AE communicated during
                                     association establishment. 16378 by
                                     default
    --ncreate-iod <file|url>         validate received MPPS N-CREATE RQ
                                     against IOD specified in file,
                                     resource:mpps-ncreate-iod.xml by
                                     default
    --no-validate                    do not validate received MPPS
                                     N-CREATE RQ and N-SET RQ
    --not-async                      do not use asynchronous mode;
                                     equivalent to --max-ops-invoked=1 and
                                     --max-ops-performed=1
    --not-pack-pdv                   send only one PDV in one P-Data-TF
                                     PDU; pack command and data PDV in one
                                     P-DATA-TF PDU by default
    --nset-iod <file|url>            validate received MPPS N-SET RQ
                                     against IOD specified in file,
                                     resource:mpps-nset-iod.xml by default
    --release-timeout <ms>           timeout in ms for receiving
                                     A-RELEASE-RP, no timeout by default
    --request-timeout <ms>           timeout in ms for receiving
                                     A-ASSOCIATE-RQ, no timeout by default
    --soclose-delay <ms>             delay in ms after sending
                                     A-ASSOCATE-RJ, A-RELEASE-RQ or
                                     A-ABORT before the socket is closed;
                                     50ms by default
    --sop-classes <file|url>         file path or URL of list of accepted
                                     SOP Classes,
                                     resource:sop-classes.properties by
                                     default
    --sorcv-buffer <length>          set SO_RCVBUF socket option to
                                     specified value
    --sosnd-buffer <length>          set SO_SNDBUF socket option to
                                     specified value
    --ssl2Hello                      send/accept SSLv3/TLS ClientHellos
                                     encapsulated in a SSLv2 ClientHello
                                     packet; equivalent to --tls-protocol
                                     SSLv2Hello --tls-protocol SSLv3
                                     --tls-protocol TLSv1 --tls-protocol
                                     TLSv1.1 --tls-protocol TLSv1.2
    --ssl3                           enable only TLS/SSL protocol SSLv3;
                                     equivalent to --tls-protocol SSLv3
    --tcp-delay                      set TCP_NODELAY socket option to
                                     false, true by default
    --tls                            enable TLS connection without
                                     encryption or with AES or 3DES
                                     encryption; equivalent to
                                     --tls-cipher SSL_RSA_WITH_NULL_SHA
                                     --tls-cipher
                                     TLS_RSA_WITH_AES_128_CBC_SHA
                                     --tls-cipher
                                     SSL_RSA_WITH_3DES_EDE_CBC_SHA
    --tls-3des                       enable TLS connection with 3DES
                                     encryption; equivalent to
                                     --tls-cipher
                                     SSL_RSA_WITH_3DES_EDE_CBC_SHA
    --tls-aes                        enable TLS connection with AES or
                                     3DES encryption; equivalent to
                                     --tls-cipher
                                     TLS_RSA_WITH_AES_128_CBC_SHA
                                     --tls-cipher
                                     SSL_RSA_WITH_3DES_EDE_CBC_SHA
    --tls-cipher <cipher>            enable TLS connection with specified
                                     Cipher Suite. Multiple Cipher Suites
                                     may be enabled by multiple
                                     --tls-cipher options
    --tls-eia-https                  enable server endpoint identification
                                     according RFC 2818: HTTP Over TLS
    --tls-eia-ldaps                  enable server endpoint identification
                                     according RFC 2830: LDAP Extension
                                     for TLS
    --tls-noauth                     disable client authentification for
                                     TLS
    --tls-null                       enable TLS connection without
                                     encryption; equivalent to
                                     --tls-cipher SSL_RSA_WITH_NULL_SHA
    --tls-protocol <protocol>        TLS/SSL protocol to use. Multiple
                                     TLS/SSL protocols may be enabled by
                                     multiple --tls-protocol options.
                                     Supported values by Java 11: TLSv1,
                                     TLSv1.1, TLSv1.2, TLSv1.3, SSLv3,
                                     SSLv2Hello. By default, only TLSv1.2
                                     is enabled.
    --tls1                           enable only TLS/SSL protocol TLSv1;
                                     equivalent to --tls-protocol TLSv1
    --tls11                          enable only TLS/SSL protocol TLSv1.1;
                                     equivalent to --tls-protocol TLSv1.1
    --tls12                          enable only TLS/SSL protocol TLSv1.2;
                                     equivalent to --tls-protocol TLSv1.2
    --tls13                          enable only TLS/SSL protocol TLSv1.3;
                                     equivalent to --tls-protocol TLSv1.3
    --trust-store <file|url>         file path of key store containing
                                     trusted certificates,
                                     resource:cacerts.p12 by default
    --trust-store-pass <password>    password for key store with trusted
                                     certificates, 'secret' by default
    --trust-store-type <storetype>   type of key store with trusted
                                     certificates, PKCS12 by default
 -V,--version                        output version information and exit
-
Example: mppsscp -b MPPSSCP:11112
=> Starts server listening on port 11112, accepting association requests
with MPPSSCP as called AE title. Received Modality Performed Procedure
Step objects will be stored in the working directory.
```
