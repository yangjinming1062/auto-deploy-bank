package com.best.hello.controller.RMI;

public class RMIClient {
    private RMIClient() {}

}
