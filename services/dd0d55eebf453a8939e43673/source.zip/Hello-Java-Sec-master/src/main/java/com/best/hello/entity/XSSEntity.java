package com.best.hello.entity;

public class XSSEntity {
    private Integer id;
    private String user;
    private String content;
    private String date;

    public Integer getId() {
        return id;
    }

    public String getUser() {
        return user;
    }

    public String getContent() {
        return content;
    }

    public String getDate() {
        return date;
    }
}
