package com.best.hello.controller.SQLI;

public class Hibernate {
}
