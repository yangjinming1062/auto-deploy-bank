export const libText = 'Counter From Rslib MF Format';

export const remoteText = 'MF Remote App loaded by Rslib MF Format';
