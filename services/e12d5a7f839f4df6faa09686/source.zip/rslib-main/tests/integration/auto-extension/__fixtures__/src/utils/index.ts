export const bar = 'bar';
