import type { oraPromise } from 'ora';
import React from 'react';

export type { oraPromise };
export const foo = () => {
  return React.version;
};
