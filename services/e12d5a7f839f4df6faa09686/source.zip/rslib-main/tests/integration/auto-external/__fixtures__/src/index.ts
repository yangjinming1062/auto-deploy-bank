import React from 'react';

export const foo = () => {
  return React.version;
};
