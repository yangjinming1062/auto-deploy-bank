export const hidden = 'This is a hidden file';
