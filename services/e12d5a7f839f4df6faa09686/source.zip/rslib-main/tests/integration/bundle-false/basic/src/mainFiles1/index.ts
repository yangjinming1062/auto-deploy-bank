export const mainFiles1 = 'mainFiles1';
