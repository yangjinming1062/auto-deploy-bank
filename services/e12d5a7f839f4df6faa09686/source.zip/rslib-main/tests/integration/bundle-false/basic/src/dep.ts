import depAdd from 'dep_add';

export const added = depAdd.add(1, 2);
