export const mainFiles2 = 'mainFiles2';
