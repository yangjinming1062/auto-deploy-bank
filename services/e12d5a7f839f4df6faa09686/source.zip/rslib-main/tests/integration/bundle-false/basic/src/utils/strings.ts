export const str1 = 'str1';
export const str2 = 'str2';
export const str3 = 'str3';
