export const num1 = 1;
export const num2 = 2;
export const num3 = 3;
