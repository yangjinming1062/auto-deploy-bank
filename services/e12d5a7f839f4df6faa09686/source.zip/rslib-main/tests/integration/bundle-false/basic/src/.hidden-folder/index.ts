export const hiddenFolder = 'This is a hidden folder';
