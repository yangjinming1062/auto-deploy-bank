import importee from 'bundle-false-monorepo-importee-test';

export default importee;
