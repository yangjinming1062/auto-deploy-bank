import Logo from './assets/logo.svg';

export default Logo;
