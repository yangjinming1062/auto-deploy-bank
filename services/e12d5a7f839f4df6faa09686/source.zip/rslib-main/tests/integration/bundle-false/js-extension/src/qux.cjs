module.exports = {
  qux: 'qux',
};
