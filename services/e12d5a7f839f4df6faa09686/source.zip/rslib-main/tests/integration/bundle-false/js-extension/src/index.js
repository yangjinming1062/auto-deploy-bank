import { bar } from './bar';
import { baz } from './baz.js';
import { foo } from './foo.js';
import { qux } from './qux.cjs';

export const text = foo + bar + baz + qux;
