import image from './assets/image.png';
import logoURL from './assets/logo.svg';

console.log(logoURL);
console.log(image);
