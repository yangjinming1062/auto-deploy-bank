export const dyn = 'dynamic';
