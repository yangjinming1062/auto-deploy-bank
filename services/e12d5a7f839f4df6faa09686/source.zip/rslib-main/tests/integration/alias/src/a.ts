export const a = 'hello world';
export type A = string;
