import { a } from '@src/a';

console.info(a);

export type { A } from './a';
