import './index.css';
import { foo } from './foo';

export const text = foo;
