import logo from './assets/image.png';

export default logo;
