import { ReactComponent } from './assets/logo.svg';

console.log('namedImport', 'ReactComponent', ReactComponent);
