import ReactComponent from './assets/logo.svg?react';
import Url from './assets/logo.svg?url';

console.log('queryImport', 'ReactComponent', ReactComponent);
console.log('queryImport', 'Url', Url);
