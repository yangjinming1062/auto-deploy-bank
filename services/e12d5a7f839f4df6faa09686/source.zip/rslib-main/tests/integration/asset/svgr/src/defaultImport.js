import Url from './assets/logo.svg';

console.log('defaultImport', 'Url', Url);
