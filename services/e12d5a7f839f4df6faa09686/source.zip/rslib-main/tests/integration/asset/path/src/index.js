import a from './assets/image.png';

export default a;
