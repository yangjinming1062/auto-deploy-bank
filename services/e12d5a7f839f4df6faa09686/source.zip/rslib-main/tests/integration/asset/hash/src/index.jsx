import a from './assets/image.png';

export default () => {
  return <img src={a} alt="" />;
};
