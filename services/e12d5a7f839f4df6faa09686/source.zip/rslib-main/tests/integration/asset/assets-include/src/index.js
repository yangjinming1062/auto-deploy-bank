import draft from './assets/draft.txt';

console.log(draft);
