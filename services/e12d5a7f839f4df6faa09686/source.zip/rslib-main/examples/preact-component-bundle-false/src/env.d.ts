/// <reference types="@rslib/core/types" />
