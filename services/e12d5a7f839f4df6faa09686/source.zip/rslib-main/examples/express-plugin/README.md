# @examples/express-plugin

This example demonstrates how to use Rslib to build a simple Node.js package.
