import Counter from './Counter.vue';

export { Counter };
