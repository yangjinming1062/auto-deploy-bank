# @examples/vue-component

This example demonstrates how to use Rslib to build a simple bundleless Vue component.
