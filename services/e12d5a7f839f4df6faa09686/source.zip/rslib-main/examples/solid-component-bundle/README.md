# @examples/solid-component

This example demonstrates how to use Rslib to build a simple SolidJS component.
