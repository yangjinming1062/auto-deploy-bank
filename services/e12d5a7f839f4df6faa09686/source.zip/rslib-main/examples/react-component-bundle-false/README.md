# @examples/react-component

This example demonstrates how to use Rslib to build a simple React component.
