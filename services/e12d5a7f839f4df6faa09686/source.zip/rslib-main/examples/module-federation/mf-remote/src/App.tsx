const App = () => {
  return <div id="mf-e2e-remote">MF Remote App loaded by Rslib MF Format</div>;
};

export default App;
