# @examples/react-component-umd

This example demonstrates how to use Rslib to build a simple React component with umd format output.
