# Rslib project

## Setup

Install the dependencies:

```bash
{{ packageManager }} install
```

## Get started

Build the library:

```bash
{{ packageManager }} run build
```

Build the library in watch mode:

```bash
{{ packageManager }} run dev
```
