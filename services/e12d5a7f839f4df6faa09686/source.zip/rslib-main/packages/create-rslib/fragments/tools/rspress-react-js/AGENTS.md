## Tools

### Rspress

- Run `{{ packageManager }} run doc` to start the Rspress documentation dev server
- Run `{{ packageManager }} run doc:build` to build the documentation
