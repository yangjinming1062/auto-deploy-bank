export const squared = (n: number): number => n * n;
