export const squared = (n) => n * n;
