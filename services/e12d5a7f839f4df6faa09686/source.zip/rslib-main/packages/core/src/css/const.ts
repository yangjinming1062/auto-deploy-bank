export const BASE_URI = 'webpack://';
export const MODULE_TYPE = 'css/mini-extract';
export const AUTO_PUBLIC_PATH = '__mini_css_extract_plugin_public_path_auto__';
export const ABSOLUTE_PUBLIC_PATH: string = `${BASE_URI}/mini-css-extract-plugin/`;
export const SINGLE_DOT_PATH_SEGMENT =
  '__mini_css_extract_plugin_single_dot_path_segment__';
