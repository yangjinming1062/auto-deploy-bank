declare const RSLIB_VERSION;
