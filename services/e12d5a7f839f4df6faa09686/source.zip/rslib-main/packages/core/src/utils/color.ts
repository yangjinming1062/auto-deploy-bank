import color from 'picocolors';
export { color };
