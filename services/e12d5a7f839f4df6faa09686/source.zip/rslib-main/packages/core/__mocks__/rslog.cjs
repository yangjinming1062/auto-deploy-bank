module.exports = {
  logger: {
    warn: () => {},
    override: () => {},
    debug: () => {},
  },
};
