import memfs from 'memfs';

const { promises } = memfs;

export default promises;
