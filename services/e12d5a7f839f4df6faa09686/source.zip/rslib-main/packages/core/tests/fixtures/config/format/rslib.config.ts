export default {
  lib: [
    {
      id: 'esm-lib',
      format: 'esm',
    },
    {
      id: 'cjs-lib',
      format: 'cjs',
    },
  ],
};
