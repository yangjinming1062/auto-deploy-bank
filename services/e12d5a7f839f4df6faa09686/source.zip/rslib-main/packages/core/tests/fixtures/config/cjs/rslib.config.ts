export default {
  lib: [],
  source: {
    entry: {
      index: './foo/index.ts',
    },
  },
};
