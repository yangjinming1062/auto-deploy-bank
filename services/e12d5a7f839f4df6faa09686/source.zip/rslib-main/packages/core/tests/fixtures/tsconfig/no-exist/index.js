export const foo = 'foo';
