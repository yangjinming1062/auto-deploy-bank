Examples
========

This section provides practical examples of using Python A2A in various scenarios.

.. toctree::
   :maxdepth: 2
   
   simple
   advanced
   langchain
   langchain_agents
   agent_discovery