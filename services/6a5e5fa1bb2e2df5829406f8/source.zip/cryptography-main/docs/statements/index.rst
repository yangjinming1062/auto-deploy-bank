Statements
==========

Occasional statements from the Python Cryptographic Authority about the project.

.. toctree::
    :maxdepth: 1

    state-of-openssl
