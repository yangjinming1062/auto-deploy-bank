pyca/cryptography vectors
=========================

This package contains test vectors which are used in ``pyca/cryptography``'s
tests.
