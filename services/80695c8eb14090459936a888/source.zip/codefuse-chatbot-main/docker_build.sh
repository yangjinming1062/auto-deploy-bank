#!/bin/bash

docker build -t devopsgpt:latest .