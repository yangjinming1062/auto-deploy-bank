#!/bin/bash

pip install -r requirements.txt
# torch-gpu 安装视具体配置操纵
# pip install torch==2.0.1+cu118 cudatoolkit --index-url https://download.pytorch.org/whl/cu118

# pip3 uninstall crypto
# pip3 uninstall pycrypto
# pip3 install pycryptodome