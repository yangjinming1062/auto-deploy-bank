package io.rackshift.rackshiftproxy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RackshiftProxyApplicationTests {

    @Test
    void contextLoads() {
    }

}
