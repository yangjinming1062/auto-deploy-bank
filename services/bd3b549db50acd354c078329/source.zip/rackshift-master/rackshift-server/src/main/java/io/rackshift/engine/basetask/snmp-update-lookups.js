// Copyright 2016, EMC, Inc.

'use strict';

module.exports = {
    friendlyName: 'Snmp Update Lookups',
    injectableName: 'Task.Base.Snmp.Update.Lookups',
    runJob: 'Job.Snmp.Update.Lookups',
    requiredOptions: [],
    requiredProperties: {},
    properties: {}
};
