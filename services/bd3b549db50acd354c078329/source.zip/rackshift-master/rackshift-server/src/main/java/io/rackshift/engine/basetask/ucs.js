// Copyright 2017, Dell EMC, Inc.

'use strict';

module.exports = {
    friendlyName: 'Base Ucs Task',
    injectableName: 'Task.Base.Ucs',
    runJob: 'Job.Ucs',
    requiredOptions: [],
    requiredProperties: {},
    properties: {}
};
