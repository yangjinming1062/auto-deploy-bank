// Copyright 2016, EMC, Inc.

'use strict';

module.exports = {
    friendlyName: 'Base Notification Trigger',
    injectableName: 'Task.Base.Wait.Notification',
    runJob: 'Job.Wait.Notification',
    requiredOptions: [],
    requiredProperties: {},
    properties: {}
};
