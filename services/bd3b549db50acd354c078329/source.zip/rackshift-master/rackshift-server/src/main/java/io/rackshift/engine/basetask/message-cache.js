// Copyright 2015, EMC, Inc.

'use strict';

module.exports = {
    friendlyName: 'Message Cache',
    injectableName: 'Task.Base.Message.Cache',
    runJob: 'Job.Message.Cache',
    optionsSchema: {},
    requiredProperties: {},
    properties: {}
};
