// Copyright 2016, EMC, Inc.

'use strict';

module.exports = {
    friendlyName: 'Generate a BMC password',
    injectableName: 'Task.Base.Generate.Password',
    runJob: 'Job.BMC.Password',
    requiredOptions: [],
    requiredProperties: {},
    properties: {  }
};
