// Copyright 2015, EMC, Inc.

'use strict';

module.exports = {
    friendlyName: 'Run Work Items',
    injectableName: 'Task.Base.WorkItems.Run',
    runJob: 'Job.WorkItems.Run',
    requiredOptions: [],
    requiredProperties: {},
    properties: {}
};
