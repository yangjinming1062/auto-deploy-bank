// Copyright 2015, EMC, Inc.

'use strict';

module.exports = {
    "friendlyName": "Snmp Cataloger",
    "injectableName": "Task.Base.Snmp.Catalog",
    "runJob": "Job.Snmp.Catalog",
    "requiredOptions": [],
    "requiredProperties": {},
    "properties": {}
};
