// Copyright 2016, EMC, Inc.

'use strict';


module.exports = {
    friendlyName: 'Validate Ssh',
    injectableName: 'Task.Base.Ssh.Validation',
    runJob: 'Job.Ssh.Validation',
    requiredOptions: [],
    requiredProperties: {},
    properties: {}
};
