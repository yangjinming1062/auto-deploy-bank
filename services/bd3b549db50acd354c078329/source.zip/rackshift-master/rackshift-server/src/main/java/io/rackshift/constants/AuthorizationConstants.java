package io.rackshift.constants;

public class AuthorizationConstants {
    public static final String ROLE_ADMIN = "admin";
}
