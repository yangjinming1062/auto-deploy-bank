// Copyright 2015, EMC, Inc.

'use strict';

module.exports = {
    friendlyName: 'Generate SKU',
    injectableName: 'Task.Base.Catalog.GenerateSku',
    runJob: 'Job.Catalog.GenerateSku',
    requiredOptions: [],
    requiredProperties: {},
    properties: {}
};

