// Copyright © 2018 Dell Inc. or its subsidiaries. All Rights Reserved. 

'use strict';

module.exports = {
    friendlyName: 'Wsman Update Lookups',
    injectableName: 'Task.Base.Wsman.Update.Lookups',
    runJob: 'Job.Wsman.Update.Lookups',
    requiredOptions: [],
    requiredProperties: {},
    properties: {}
};
