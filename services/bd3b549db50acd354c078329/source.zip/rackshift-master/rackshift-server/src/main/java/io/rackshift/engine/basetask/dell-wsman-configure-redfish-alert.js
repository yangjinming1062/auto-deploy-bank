// Copyright 2017, Dell EMC, Inc.

'use strict';

module.exports = {
    friendlyName: 'Dell Wsman Configure Redfish Alert',
    injectableName: 'Task.Base.Dell.Wsman.Configure.Redfish.Alert',
    runJob: 'Job.Dell.Wsman.Configure.Redfish.Alert',
    requiredOptions: [
    ],
    requiredProperties: {},
    properties:{}
};
