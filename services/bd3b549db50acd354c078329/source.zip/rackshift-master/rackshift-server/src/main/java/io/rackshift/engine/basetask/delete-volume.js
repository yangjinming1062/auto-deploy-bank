'use strict';

module.exports = {
    friendlyName: 'Delete Volume Base Task',
    injectableName: 'Task.Base.Delete.Volume',
    runJob: 'Job.Delete.Volume',
    requiredOptions: [
    ],
    requiredProperties: {
    },
    properties: {
    }
};
