// Copyright 2015, EMC, Inc.

'use strict';

module.exports = {
    friendlyName: 'Snmp Poller Alerts',
    injectableName: 'Task.Base.Poller.Alert.Snmp',
    runJob: 'Job.Poller.Alert.Snmp',
    requiredOptions: [],
    requiredProperties: {},
    properties: {}
};
