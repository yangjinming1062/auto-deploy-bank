// Copyright 2016, EMC, Inc.

'use strict';

module.exports = {
    friendlyName: 'Redfish Requester',
    injectableName: 'Task.Base.Redfish',
    runJob: 'Job.Redfish',
    requiredOptions: [],
    requiredProperties: {},
    properties: {}
};
