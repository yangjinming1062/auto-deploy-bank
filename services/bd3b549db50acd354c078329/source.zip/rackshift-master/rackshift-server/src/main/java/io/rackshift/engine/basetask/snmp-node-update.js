// Copyright 2015, EMC, Inc.

'use strict';

module.exports = {
    friendlyName: 'Snmp Node Update',
    injectableName: 'Task.Base.Node.Update',
    runJob: 'Job.Snmp.Node.Update',
    requiredOptions: [],
    requiredProperties: {},
    properties: {}
};
