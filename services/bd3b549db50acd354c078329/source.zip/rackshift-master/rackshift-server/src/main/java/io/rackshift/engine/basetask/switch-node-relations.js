// Copyright 2015, EMC, Inc.

'use strict';

module.exports = {
    friendlyName: 'Switch nodes Relations',
    injectableName: 'Task.Base.Catalog.SwitchRelations',
    runJob: 'Job.Catalog.SwitchRelations',
    requiredOptions: [],
    requiredProperties: {},
    properties: {}
};

