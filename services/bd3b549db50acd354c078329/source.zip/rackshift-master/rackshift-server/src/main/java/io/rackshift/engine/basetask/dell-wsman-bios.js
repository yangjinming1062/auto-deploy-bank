// Copyright 2016, Dell, Inc.

'use strict';

module.exports = {
    friendlyName: 'Dell Wsman Get Bios Job',
    injectableName: 'Task.Base.Dell.Wsman.GetBios',
    runJob: 'Job.Dell.Wsman.Bios',
    requiredOptions: [
    ],
    requiredProperties: {
    },
    properties: {
        catalog: {}
    }
};
