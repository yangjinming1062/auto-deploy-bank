'use strict';

module.exports = {
    friendlyName: 'Add Volume Base Task',
    injectableName: 'Task.Base.Add.Volume',
    runJob: 'Job.Add.Volume',
    requiredOptions: [
    ],
    requiredProperties: {
    },
    properties: {
    }
};
