// Copyright 2015, EMC, Inc.

'use strict';

module.exports = {
    friendlyName: 'Ipmi Requester',
    injectableName: 'Task.Base.Ipmi',
    runJob: 'Job.Ipmi',
    requiredOptions: [],
    requiredProperties: {},
    properties: {}
};
