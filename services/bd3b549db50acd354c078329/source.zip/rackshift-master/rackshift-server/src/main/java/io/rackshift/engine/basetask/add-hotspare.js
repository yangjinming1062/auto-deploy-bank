'use strict';

module.exports = {
    friendlyName: 'Add Hotspare Base Task',
    injectableName: 'Task.Base.Add.Hotspare',
    runJob: 'Job.Add.Hotspare',
    requiredOptions: [
    ],
    requiredProperties: {
    },
    properties: {
    }
};
