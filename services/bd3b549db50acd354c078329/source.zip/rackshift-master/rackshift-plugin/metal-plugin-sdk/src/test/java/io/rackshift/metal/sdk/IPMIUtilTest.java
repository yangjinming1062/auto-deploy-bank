package io.rackshift.metal.sdk;

public class IPMIUtilTest {

    public static void main(String[] args) throws Exception {
//        String ip = "xx";
//        String userName = "admin";
//        String password = "admin";
//        IPMIRequest request = new IPMIRequest(ip, userName, password);
//        System.out.println(IPMIUtils.extractSdrIndexValue(IPMIUtils.grep(IPMIUtils.exeCommand(request, "sdr"), "CPU\\d_TEMP"), "\\|", 1, "degreesC"));

//        Pattern p = Pattern.compile("CPU\\d_Temp");
//        Matcher m = p.matcher("CPU0_Temp");
//        System.out.println(m.find());
//        while(m.find()){
//            System.out.println(m.group());
//        }
//                List<String> cmds = new LinkedList<>();
//                cmds.add("ipmitool");
//                cmds.add("-I");
//                cmds.add("lanplus");
//                cmds.add("-H");
//                cmds.add(request.getHost());
//                cmds.add("-U");
//                cmds.add(request.getUserName());
//                cmds.add("-P");
//                cmds.add(request.getPwd());
//                for (String c : "sdr".split(" ")) {
//                    cmds.add(c);
//                }
//                ProcessBuilder builder = new ProcessBuilder(cmds);
//                builder.redirectErrorStream(true);
//                Process p = builder.start();
//                InputStreamReader re = new InputStreamReader(p.getInputStream(), "utf-8");
//                BufferedReader b = new BufferedReader(re);
//                String line = null;
//                StringBuffer sb = new StringBuffer();
////                p.waitFor();
//                while ((line = b.readLine()) != null) {
//                    sb.append(line + "\n");
//                }
//                p.getInputStream().close();
//                re.close();
//                b.close();
//                p.destroy();
//
//        //不同机型 不同硬件数量返回时间可能有不一样的情况 需要在生产上调试这个数值 使得爬虫可以稳定工作
//
//
//        System.out.println(sb);


    }


}
