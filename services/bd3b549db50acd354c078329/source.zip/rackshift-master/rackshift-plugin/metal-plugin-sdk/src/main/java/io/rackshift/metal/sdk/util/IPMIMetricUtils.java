package io.rackshift.metal.sdk.util;

public class IPMIMetricUtils {
}
