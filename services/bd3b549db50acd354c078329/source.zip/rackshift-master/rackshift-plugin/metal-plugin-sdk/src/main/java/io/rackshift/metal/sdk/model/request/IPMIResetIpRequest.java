package io.rackshift.metal.sdk.model.request;

public class IPMIResetIpRequest extends IPMICustomRequest {
}
