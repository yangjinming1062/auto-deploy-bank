package io.rackshift.metal.sdk.model.request;

public class IPMICustomRequest extends IPMIRequest {
    String brand;

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }
}
