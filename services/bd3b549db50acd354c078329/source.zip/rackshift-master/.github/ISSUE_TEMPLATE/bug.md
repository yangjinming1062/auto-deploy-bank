---
name: BUG 提交
about: 提交产品缺陷帮助我们更好的改进
title: "[BUG]"
labels: bug
assignees: zhangdahai112

---

**RackShift 版本**
您所使用的 RackShift 版本是？

**Bug 描述**
简要描述您碰到的问题

**Bug 重现步骤**
1.
2.
3.
4.

**期待的正确结果**
正确情况下应该是什么样的？

**截图**
如果有截图，请附上截图.