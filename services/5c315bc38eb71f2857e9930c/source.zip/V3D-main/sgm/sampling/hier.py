# hierachical sampling, (autogressive sampling like GeNVS)
