package kafka

import (
	"testing"
)

func TestNewProducer(t *testing.T) {

}
