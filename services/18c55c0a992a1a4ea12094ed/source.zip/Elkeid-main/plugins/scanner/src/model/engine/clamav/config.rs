pub const CLAMAV_MAX_FILESIZE: usize = 1024 * 1024 * 18;
pub const CLAMAV_MAX_SCANSIZE: i64 = 1024 * 1024 * 25;
pub const CLAMAV_MAX_SCANTIME: i64 = 5000;
pub const DB_DEFAULT: &str = "./dat";
