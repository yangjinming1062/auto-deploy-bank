package com.security.smith.module;

public interface Patcher {
    void install();
    void uninstall();
}
