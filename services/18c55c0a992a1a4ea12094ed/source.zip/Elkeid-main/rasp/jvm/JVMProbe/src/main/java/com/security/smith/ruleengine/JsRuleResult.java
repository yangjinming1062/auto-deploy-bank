package com.security.smith.ruleengine;

public class JsRuleResult {
    public int ruletype;
    public int ruleid;
    public int rulever;
    public String rulename;

    public JsRuleResult() {
        ruletype = 0;
        ruleid = 0;
        rulever = 0;
        rulename = null;
    }
}