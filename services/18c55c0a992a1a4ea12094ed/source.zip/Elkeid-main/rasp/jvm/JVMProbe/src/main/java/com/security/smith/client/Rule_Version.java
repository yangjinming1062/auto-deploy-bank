package com.security.smith.client;

public class Rule_Version {
    private  int rule_version;
    private String class_filter_version;

    public  Rule_Version() {

    }

    public int getRule_version() {
        return this.rule_version;
    }

    public void setRule_version(int rule_version) {
        this.rule_version = rule_version;
    }

    public String getClass_filter_version() {
        return this.class_filter_version;
    }

    public void setClass_filter_version(String class_filter_version) {
        this.class_filter_version = class_filter_version;
    }
}
