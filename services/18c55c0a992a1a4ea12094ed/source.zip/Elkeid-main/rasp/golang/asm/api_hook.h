#ifndef GO_PROBE_API_HOOK_H
#define GO_PROBE_API_HOOK_H

int hookAPI(void *address, void *replace, void **backup);

#endif //GO_PROBE_API_HOOK_H
