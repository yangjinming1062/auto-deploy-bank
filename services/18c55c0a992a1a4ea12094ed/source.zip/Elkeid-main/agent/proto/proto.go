//go:generate protoc --gogofaster_out=plugins=grpc:. grpc.proto
package proto
