# Logo removal

A sample React/Next.js/TailwindCSS app that removes text and inpain the text region from images

![FTguR51UEAEEZGh](https://user-images.githubusercontent.com/144372/169997829-c5aa0120-7768-4b46-ba01-b09530e5c3b6.jpeg)

### Setup:

```
yarn dev
```

### Build:

```
yarn build
```
