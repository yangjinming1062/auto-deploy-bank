# Decompose layers

A sample React/Next.js/TailwindCSS app that decomposes images into separate layers.

![decompose-layers](../../docs/decompose-web.gif)

### Setup:

```
yarn dev
```

### Build:

```
yarn build
```
