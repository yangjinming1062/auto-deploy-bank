# Remove background bulk

This is a React/TailwindCSS sample that removes background in bulk from a list of images.

![remove-background-bulk](../../docs/bulk.gif)

### Setup:

```
yarn install
```

### Deploy:

```
yarn start
```
