# DragonBones common library

## How to build
* Clone or download [DragonBonesJS](https://github.com/DragonBones/DragonBonesJS/).
* Install [Node.JS](https://nodejs.org/).
* Open `DragonBonesJS/DragonBones/` in command.
* $ `npm install`
* $ `npm run build`