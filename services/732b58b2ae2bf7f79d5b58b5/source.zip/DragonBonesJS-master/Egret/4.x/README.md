## How to build
* Clone or download [DragonBonesJS](https://github.com/DragonBones/DragonBonesJS/).
* Install [Node.JS](https://nodejs.org/).
* Open `DragonBonesJS/Egret/4.x/` in command.
* $ `npm install`
* $ `npm run build`

## Egret declaration
[Get egret.d.ts](https://github.com/egret-labs/egret-core/blob/master/build/egret/egret.d.ts)