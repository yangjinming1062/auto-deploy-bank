class Main extends egret.DisplayObjectContainer {
    public constructor() {
        super();

        this.addChild(new HelloDragonBones());
        // this.addChild(new AnimationBase());
        // this.addChild(new DragonBonesEvent());
        // this.addChild(new AnimationLayer());
        // this.addChild(new BoneOffset());
        // this.addChild(new InverseKinematics());
        // this.addChild(new BoundingBox());
        // this.addChild(new MultiTextureAltas());
        // this.addChild(new ReplaceSlotDisplay());
        // this.addChild(new ReplaceSkin());
        // this.addChild(new ReplaceAnimation());
        // this.addChild(new coreElement.Game());
        // this.addChild(new EyeTracking());
        // this.addChild(new PerformanceTest());
    }
}