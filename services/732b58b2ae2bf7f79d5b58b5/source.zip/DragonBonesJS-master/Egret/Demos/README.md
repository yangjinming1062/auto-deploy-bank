## How to run
1. Make sure you have installed Egret Wing and EgretLauncher (Installed Egret engine such as 5.x).
2. Open the demo with Egret wing.
3. Build project and have fun.