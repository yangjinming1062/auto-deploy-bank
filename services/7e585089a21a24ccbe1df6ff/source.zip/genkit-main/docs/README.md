# Genkit Documentation

The source files for the official Genkit documentation (available at [genkit.dev](https://genkit.dev)) have been moved to:

https://github.com/genkit-ai/docsite

Please refer to the new repository for all documentation updates, contributions, and issues.

## Resources

The `resources` directory in this location contains assets that may still be referenced by other parts of the project.
