## Overview of the issue

## Motivation for or Use Case

## Reproduce the error

## Related issues

## Link to PR (if any)

## KHipster Version(s)

- [] Checking this box is mandatory (this is just to show you read everything)
