import { angularSamples } from '../support/workflow-samples.mjs';

export default angularSamples;
