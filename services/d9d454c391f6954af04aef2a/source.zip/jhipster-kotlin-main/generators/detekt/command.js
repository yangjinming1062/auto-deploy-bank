import { asCommand } from 'generator-jhipster';

export default asCommand({
    configs: {},
});
