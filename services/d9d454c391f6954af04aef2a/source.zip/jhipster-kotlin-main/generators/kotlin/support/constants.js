export const SERVER_MAIN_SRC_KOTLIN_DIR = 'src/main/kotlin/';
export const SERVER_TEST_SRC_KOTLIN_DIR = 'src/test/kotlin/';
