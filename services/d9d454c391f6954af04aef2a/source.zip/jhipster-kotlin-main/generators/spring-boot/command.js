import { asCommand } from 'generator-jhipster';

export default asCommand({
    configs: {},
    import: ['jhipster-kotlin:ktlint'],
});
