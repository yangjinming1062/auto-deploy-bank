import { asCommand } from 'generator-jhipster';

export default asCommand({
    options: {},
    configs: {},
    arguments: {},
});
