package com.devoxx.genie.ui.listener;

public interface ChatMemorySizeListener {

    // TODO - This method is currently not used anywhere in the codebase
    // TODO - Should be triggered when user changes the chat memory size in the settings
    void onChatMemorySizeChanged(int chatMemorySize);
}
