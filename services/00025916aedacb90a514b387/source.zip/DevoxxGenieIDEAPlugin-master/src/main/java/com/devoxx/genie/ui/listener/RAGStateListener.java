package com.devoxx.genie.ui.listener;

public interface RAGStateListener {
    void onRAGStateChanged(boolean enabled);
}
