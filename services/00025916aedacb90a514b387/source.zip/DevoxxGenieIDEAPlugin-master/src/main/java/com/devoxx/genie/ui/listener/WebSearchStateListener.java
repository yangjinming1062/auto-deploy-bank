package com.devoxx.genie.ui.listener;

public interface WebSearchStateListener {
    void onWebSearchStateChange(boolean enabled);
}
