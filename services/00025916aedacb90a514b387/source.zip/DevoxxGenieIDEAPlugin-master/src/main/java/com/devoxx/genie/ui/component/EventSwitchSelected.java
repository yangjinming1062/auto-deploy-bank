package com.devoxx.genie.ui.component;

public interface EventSwitchSelected {

    void onSelected(boolean selected);
}
