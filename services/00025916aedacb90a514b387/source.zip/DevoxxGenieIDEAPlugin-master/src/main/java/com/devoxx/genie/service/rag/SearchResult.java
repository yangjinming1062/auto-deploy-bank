package com.devoxx.genie.service.rag;

public record SearchResult(Double score, String segment) {
}