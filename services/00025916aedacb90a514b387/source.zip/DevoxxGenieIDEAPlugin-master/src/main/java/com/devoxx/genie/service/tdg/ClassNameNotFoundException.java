package com.devoxx.genie.service.tdg;

public class ClassNameNotFoundException extends Exception {
    public ClassNameNotFoundException(String message) {
        super(message);
    }
}
