package com.devoxx.genie.action;

import com.devoxx.genie.model.LanguageModel;
import com.devoxx.genie.model.ScanContentResult;
import com.devoxx.genie.model.enumarations.ModelProvider;
import com.devoxx.genie.service.DevoxxGenieSettingsService;
import com.devoxx.genie.service.FileListManager;
import com.devoxx.genie.service.models.LLMModelRegistryService;
import com.devoxx.genie.service.ProjectContentService;
import com.devoxx.genie.ui.settings.DevoxxGenieStateService;
import com.devoxx.genie.ui.util.NotificationUtil;
import com.devoxx.genie.ui.util.WindowContextFormatterUtil;
import com.intellij.openapi.actionSystem.ActionUpdateThread;
import com.intellij.openapi.actionSystem.AnActionEvent;
import com.intellij.openapi.actionSystem.CommonDataKeys;
import com.intellij.openapi.project.DumbAwareAction;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.vfs.VirtualFile;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;

import static com.devoxx.genie.ui.util.WindowPluginUtil.ensureToolWindowVisible;

public class AddDirectoryAction extends DumbAwareAction {

    private static final String ADD_TO_CONTEXT = "AddDirectoryToContextWindow";
    private static final String COPY_TO_CLIPBOARD = "CopyDirectoryToClipboard";

    @Override
    public void actionPerformed(@NotNull AnActionEvent e) {
        Project project = e.getProject();
        if (project == null) return;

        ensureToolWindowVisible(project);

        VirtualFile selectedDir = e.getData(CommonDataKeys.VIRTUAL_FILE);
        if (selectedDir == null || !selectedDir.isDirectory()) {
            NotificationUtil.sendNotification(project, "Please select a directory");
            return;
        }

        String actionId = e.getActionManager().getId(this);
        if (ADD_TO_CONTEXT.equals(actionId)) {
            addDirectoryToContext(project, selectedDir);
        } else if (COPY_TO_CLIPBOARD.equals(actionId)) {
            copyDirectoryToClipboard(project, selectedDir);
        }
    }

    private void addDirectoryToContext(Project project, @NotNull VirtualFile directory) {
        FileListManager fileListManager = FileListManager.getInstance();
        List<VirtualFile> filesToAdd = new ArrayList<>();
        DevoxxGenieSettingsService settings = DevoxxGenieStateService.getInstance();

        addFilesRecursively(project, directory, fileListManager, filesToAdd, settings);

        if (!filesToAdd.isEmpty()) {
            fileListManager.addFiles(project, filesToAdd);

            ModelProvider selectedProvider = ModelProvider.fromString(settings.getSelectedProvider(project.getLocationHash()));
            String selectedModel = settings.getSelectedLanguageModel(project.getLocationHash());
            Optional<Integer> contextWindow = LLMModelRegistryService.getInstance().getModels()
                    .stream()
                    .filter(model -> model.getProvider().getName().equals(selectedProvider.getName()) &&
                            model.getModelName().equals(selectedModel))
                    .findFirst()
                    .map(LanguageModel::getInputMaxTokens);

            ProjectContentService.getInstance()
                .getDirectoryContent(project, directory, contextWindow.orElse(settings.getDefaultWindowContext()), false)
                .thenAccept(result -> {
                    int fileCount = filesToAdd.size();
                    int tokenCount = result.getTokenCount();
                    NotificationUtil.sendNotification(project,
                        String.format("Added %d files from directory: %s (approx. %s tokens in total using %s tokenizer)%s",
                            fileCount,
                            directory.getName(),
                            WindowContextFormatterUtil.format(tokenCount),
                            selectedProvider.getName(),
                            result.getSkippedFileCount() > 0 ? " Skipped " + result.getSkippedFileCount() + " files" : ""));
                });
        }
    }

    private void addFilesRecursively(Project project, @NotNull VirtualFile directory, FileListManager fileListManager,
                                     List<VirtualFile> filesToAdd, DevoxxGenieSettingsService settings) {
        VirtualFile[] children = directory.getChildren();
        for (VirtualFile child : children) {
            if (child.isDirectory()) {
                if (!settings.getExcludedDirectories().contains(child.getName())) {
                    addFilesRecursively(project, child, fileListManager, filesToAdd, settings);
                }
            } else if (shouldIncludeFile(child, settings) && !fileListManager.contains(project, child)) {
                filesToAdd.add(child);
            }
        }
    }

    private void copyDirectoryToClipboard(Project project, VirtualFile directory) {
        // Because we copy the content to the clipboard, we can set the limit to a high number
        CompletableFuture<ScanContentResult> contentFuture = ProjectContentService.getInstance()
            .getDirectoryContent(project, directory, 2_000_000, false);

        contentFuture.thenAccept(content -> {
            StringBuilder notificationMessage = new StringBuilder("Directory content added to clipboard: ")
                    .append(directory.getName())
                    .append("\n");

            if (content.getSkippedFileCount() > 0 || content.getSkippedDirectoryCount() > 0) {
                notificationMessage.append("(");
                if (content.getSkippedFileCount() > 0) {
                    notificationMessage.append("Skipped: ").append(content.getSkippedFileCount()).append(" files");
                }
                if (content.getSkippedDirectoryCount() > 0) {
                    if (content.getSkippedFileCount() > 0) {
                        notificationMessage.append(" ");
                    }
                    notificationMessage.append("Skipped: ").append(content.getSkippedDirectoryCount()).append(" directories");
                }
                notificationMessage.append(")");
            }

            NotificationUtil.sendNotification(project, notificationMessage.toString());
        });
    }

    private boolean shouldIncludeFile(@NotNull VirtualFile file, @NotNull DevoxxGenieSettingsService settings) {
        String extension = file.getExtension();
        return extension != null && settings.getIncludedFileExtensions().contains(extension.toLowerCase());
    }

    @Override
    public void update(@NotNull AnActionEvent e) {
        VirtualFile file = e.getData(CommonDataKeys.VIRTUAL_FILE);
        e.getPresentation().setEnabledAndVisible(file != null && file.isDirectory());
    }

    @Override
    public @NotNull ActionUpdateThread getActionUpdateThread() {
        return ActionUpdateThread.BGT;
    }

    @Override
    public boolean isDumbAware() {
        return true;
    }
}
