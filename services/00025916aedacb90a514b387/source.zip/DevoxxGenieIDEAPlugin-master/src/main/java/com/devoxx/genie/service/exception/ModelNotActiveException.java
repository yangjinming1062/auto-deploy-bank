package com.devoxx.genie.service.exception;

public class ModelNotActiveException extends RuntimeException {

    public ModelNotActiveException(String message) {
        super(message);
    }
}
