package com.devoxx.genie.ui.listener;

import com.devoxx.genie.model.conversation.Conversation;

public interface ConversationSelectionListener {
    void onConversationSelected(Conversation conversation);
}
