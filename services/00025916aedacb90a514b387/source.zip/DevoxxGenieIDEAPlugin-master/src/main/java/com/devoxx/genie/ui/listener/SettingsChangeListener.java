package com.devoxx.genie.ui.listener;

public interface SettingsChangeListener {

    void settingsChanged(boolean hasKey);
}
