package com.devoxx.genie.ui.listener;

public interface NewlineShortcutChangeListener {
    void onNewlineShortcutChanged(String shortcut);
}
