package com.devoxx.genie.model.mcp;

public enum MCPType {
    AI_MSG,
    TOOL_MSG,
    LOG_MSG
}
