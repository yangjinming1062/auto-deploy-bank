package com.devoxx.genie.controller.listener;

public interface TokenCalculationListener {
    void onTokenCalculationComplete(String message);
}