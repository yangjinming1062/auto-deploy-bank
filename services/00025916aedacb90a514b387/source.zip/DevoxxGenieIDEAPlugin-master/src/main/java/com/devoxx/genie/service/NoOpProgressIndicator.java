package com.devoxx.genie.service;

import com.intellij.openapi.progress.util.AbstractProgressIndicatorExBase;

public class NoOpProgressIndicator extends AbstractProgressIndicatorExBase {

}