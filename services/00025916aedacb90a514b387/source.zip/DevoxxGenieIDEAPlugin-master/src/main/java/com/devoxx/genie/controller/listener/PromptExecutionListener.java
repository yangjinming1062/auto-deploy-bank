package com.devoxx.genie.controller.listener;

public interface PromptExecutionListener {

    void startPromptExecution();

    void stopPromptExecution();

    void endPromptExecution();
}
