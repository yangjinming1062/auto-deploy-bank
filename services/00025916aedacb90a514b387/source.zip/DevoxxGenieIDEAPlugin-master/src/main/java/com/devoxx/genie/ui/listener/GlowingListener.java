package com.devoxx.genie.ui.listener;

public interface GlowingListener {
    void startGlowing();
    void stopGlowing();
}
