package com.devoxx.genie.ui.listener;

public interface CustomPromptChangeListener {
    void onCustomPromptsChanged();
}
