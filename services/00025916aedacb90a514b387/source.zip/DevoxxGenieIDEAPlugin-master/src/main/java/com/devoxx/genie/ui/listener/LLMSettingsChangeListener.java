package com.devoxx.genie.ui.listener;

public interface LLMSettingsChangeListener {
    void llmSettingsChanged();
}
