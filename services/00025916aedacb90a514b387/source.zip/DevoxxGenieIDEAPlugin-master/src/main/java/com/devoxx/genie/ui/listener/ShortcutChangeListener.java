package com.devoxx.genie.ui.listener;

public interface ShortcutChangeListener {
    void onShortcutChanged(String shortcut);
}
