package com.devoxx.genie.model.request;

public record SemanticFile(String filePath, double score) {
}
