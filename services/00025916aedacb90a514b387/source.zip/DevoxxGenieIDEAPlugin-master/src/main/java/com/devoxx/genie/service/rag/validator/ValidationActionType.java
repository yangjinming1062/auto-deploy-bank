package com.devoxx.genie.service.rag.validator;

public enum ValidationActionType {
    OK,
    PULL_CHROMA_DB,
    START_CHROMA_DB,
    PULL_NOMIC
}
