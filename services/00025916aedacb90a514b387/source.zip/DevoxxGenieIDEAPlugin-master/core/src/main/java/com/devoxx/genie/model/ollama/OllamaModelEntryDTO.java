package com.devoxx.genie.model.ollama;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class OllamaModelEntryDTO {
    private String name;
    private String modified_at;
}
