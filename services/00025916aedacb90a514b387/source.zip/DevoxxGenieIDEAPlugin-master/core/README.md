## TODO
We'll refactor this module to devoxxgenie-core and update it with the newest model java files
See also https://github.com/devoxx/DevoxxGenieIDEAPlugin/issues/564