package com.zl.mjga.model.urp;

public enum BindState {
  BIND,
  UNBIND,
  ALL;
}
