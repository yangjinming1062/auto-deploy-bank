package com.zl.mjga.dto.ai;

public record LlmQueryDto(String name, String type) {}
