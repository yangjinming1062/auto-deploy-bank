package com.zl.mjga.dto.scheduler;

public record QueryDto(String name) {}
