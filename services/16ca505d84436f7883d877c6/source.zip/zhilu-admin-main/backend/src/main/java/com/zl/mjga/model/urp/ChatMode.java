package com.zl.mjga.model.urp;

public enum ChatMode {
  NORMAL,
  WITH_LIBRARY
}
