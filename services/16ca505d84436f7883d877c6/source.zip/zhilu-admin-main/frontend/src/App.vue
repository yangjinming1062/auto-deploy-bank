<script setup lang="ts">
import { RouterView } from "vue-router";
import Alert from "./components/ui/Alert.vue";
</script>

<template>
  <RouterView />
  <Alert />
</template>

<style scoped></style>
