import DepartmentTree from "./DepartmentTree.vue";

export { DepartmentTree };

export default {
	DepartmentTree,
};
