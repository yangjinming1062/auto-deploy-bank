import FormInput from "./FormInput.vue";
import FormSelect from "./FormSelect.vue";

export { FormInput, FormSelect };
