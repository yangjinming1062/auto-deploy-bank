export interface TableItem {
    id: number;
    name: string;
    thumb: string;
    money: number;
    state: string;
    date: string;
    address: string;
}