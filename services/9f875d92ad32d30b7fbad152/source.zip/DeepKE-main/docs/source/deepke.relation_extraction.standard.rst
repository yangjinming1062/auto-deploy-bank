Standard
========

.. toctree::
   :maxdepth: 4

   deepke.relation_extraction.standard.models
   deepke.relation_extraction.standard.module
   deepke.relation_extraction.standard.tools
   deepke.relation_extraction.standard.utils
