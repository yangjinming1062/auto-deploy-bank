Models
======

deepke.name\_entity\_re.standard.models.InferBert module
--------------------------------------------------------

.. automodule:: deepke.name_entity_re.standard.models.InferBert
   :members:
   :undoc-members:
   :show-inheritance:

