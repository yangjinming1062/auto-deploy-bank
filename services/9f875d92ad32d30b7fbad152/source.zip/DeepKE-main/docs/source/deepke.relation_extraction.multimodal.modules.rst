Modules
=======


deepke.relation\_extraction.multimodal.modules.dataset module
-------------------------------------------------------------

.. automodule:: deepke.relation_extraction.multimodal.modules.dataset
   :members:
   :undoc-members:
   :show-inheritance:

deepke.relation\_extraction.multimodal.modules.metrics module
-------------------------------------------------------------

.. automodule:: deepke.relation_extraction.multimodal.modules.metrics
   :members:
   :undoc-members:
   :show-inheritance:

deepke.relation\_extraction.multimodal.modules.train module
-----------------------------------------------------------

.. automodule:: deepke.relation_extraction.multimodal.modules.train
   :members:
   :undoc-members:
   :show-inheritance:
