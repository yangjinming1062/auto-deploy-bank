Utils
=====

deepke.name\_entity\_re.few\_shot.utils.util module
---------------------------------------------------

.. automodule:: deepke.name_entity_re.few_shot.utils.util
   :members:
   :undoc-members:
   :show-inheritance:

