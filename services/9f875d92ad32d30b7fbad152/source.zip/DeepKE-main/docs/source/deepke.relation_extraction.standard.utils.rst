Utils
=====

deepke.relation\_extraction.standard.utils.ioUtils module
---------------------------------------------------------

.. automodule:: deepke.relation_extraction.standard.utils.ioUtils
   :members:
   :undoc-members:
   :show-inheritance:

deepke.relation\_extraction.standard.utils.nnUtils module
---------------------------------------------------------

.. automodule:: deepke.relation_extraction.standard.utils.nnUtils
   :members:
   :undoc-members:
   :show-inheritance:

