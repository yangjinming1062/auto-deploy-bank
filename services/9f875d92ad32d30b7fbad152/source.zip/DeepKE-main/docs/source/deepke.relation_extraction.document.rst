Document
========

deepke.relation\_extraction.document.evaluation module
------------------------------------------------------

.. automodule:: deepke.relation_extraction.document.evaluation
   :members:
   :undoc-members:
   :show-inheritance:

deepke.relation\_extraction.document.losses module
--------------------------------------------------

.. automodule:: deepke.relation_extraction.document.losses
   :members:
   :undoc-members:
   :show-inheritance:

deepke.relation\_extraction.document.model module
-------------------------------------------------

.. automodule:: deepke.relation_extraction.document.model
   :members:
   :undoc-members:
   :show-inheritance:

deepke.relation\_extraction.document.module module
--------------------------------------------------

.. automodule:: deepke.relation_extraction.document.module
   :members:
   :undoc-members:
   :show-inheritance:

deepke.relation\_extraction.document.prepro module
--------------------------------------------------

.. automodule:: deepke.relation_extraction.document.prepro
   :members:
   :undoc-members:
   :show-inheritance:

deepke.relation\_extraction.document.utils module
-------------------------------------------------

.. automodule:: deepke.relation_extraction.document.utils
   :members:
   :undoc-members:
   :show-inheritance:

