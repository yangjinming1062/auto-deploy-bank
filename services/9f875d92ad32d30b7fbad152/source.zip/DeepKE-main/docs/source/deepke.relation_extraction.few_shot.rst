Few Shot
========


.. toctree::
   :maxdepth: 4

   deepke.relation_extraction.few_shot.dataset
   deepke.relation_extraction.few_shot.lit_models


deepke.relation\_extraction.few\_shot.generate\_k\_shot module
--------------------------------------------------------------

.. automodule:: deepke.relation_extraction.few_shot.generate_k_shot
   :members:
   :undoc-members:
   :show-inheritance:

deepke.relation\_extraction.few\_shot.get\_label\_word module
-------------------------------------------------------------

.. automodule:: deepke.relation_extraction.few_shot.get_label_word
   :members:
   :undoc-members:
   :show-inheritance:

