Attribution Extraction
======================



.. toctree::
   :maxdepth: 4

   deepke.attribution_extraction.standard
