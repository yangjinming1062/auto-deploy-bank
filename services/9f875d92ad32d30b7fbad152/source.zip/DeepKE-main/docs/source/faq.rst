FAQ 
===


1.Using nearest mirror, will speed up the installation of Anaconda.

2.Using nearest mirror, will speed up pip install XXX.

3.When encountering ModuleNotFoundError: No module named 'past'，run pip install future .

4.It's slow to install the pretrained language models online. Recommend download pretrained models before use and save them in the pretrained folder. Read README.md in every task directory to check the specific requirement for saving pretrained models.

5.The old version of DeepKE is in the deepke-v1.0 branch. Users can change the branch to use the old version. The old version has been totally transfered to the standard relation extraction (example/re/standard).
