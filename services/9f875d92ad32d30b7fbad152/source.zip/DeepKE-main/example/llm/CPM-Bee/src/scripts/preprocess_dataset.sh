#! /bin/bash

CMD="python preprocess_dataset.py --input data_sample.txt --output_path path/to/binary/file --output_name data"

echo $CMD
$CMD