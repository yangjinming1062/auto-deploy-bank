<p align="left">
    <b> English | <a href="https://github.com/zjunlp/DeepKE/blob/main/example/ner/standard/data/README_CN.md">简体中文</a> </b>
</p>

Three types of data formats are supported,including `json`,`docx` and `txt`. The format of each file has been provided.You need to label data according to the given `example.*` file. If it is not csv file,you can use function `json2txt` and function `doc2txt` to transfer in [transform_data.py](https://github.com/zjunlp/DeepKE/blob/main/src/deepke/transform_data.py).