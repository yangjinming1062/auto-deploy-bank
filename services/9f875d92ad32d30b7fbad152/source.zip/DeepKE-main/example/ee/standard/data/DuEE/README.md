# Download DuEE Dataset

```bash
wget 121.41.117.246:8080/Data/ee/DuEE.zip
unzip DuEE.zip
```