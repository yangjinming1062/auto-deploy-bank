Unfortunately these tests can't be moved as they use package-local functionality.
