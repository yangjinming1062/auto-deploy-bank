insert into users (username, password, enabled) values ('user', 'user', true);

insert into authorities (username, authority) values ('user', 'ROLE_ADMIN');