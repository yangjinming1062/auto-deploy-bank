import CustomRenderer from './CustomRenderer';

export default {
  __init__: ['customRenderer'],
  customRenderer: ['type', CustomRenderer]
};
