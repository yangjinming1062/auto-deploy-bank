<!--
 * @Descripttion: 
 * @version: 
 * @Author: zhangchongjie
 * @Date: 2021-05-27 16:33:53
 * @LastEditors: zhangchongjie
 * @LastEditTime: 2021-09-28 14:27:57
 * @FilePath: \workspace-y9boot-9.5.x-vue\y9vue-itemAdmin\src\components\formMaking\views\SecondDev\numberButton.vue
-->
<template>
  <div>
    <el-button size="mini">编号</el-button>
  </div>
</template>

<script>
export default {
  name: "numberButton",
  data(){
    return {
    };
  },
  methods: {
   
  }
};
</script>

<style>
  
</style>