import CustomAutoPlace from './CustomAutoPlace';

export default {
  __init__: ['autoPlace'],
  autoPlace: ['type', CustomAutoPlace]
};
