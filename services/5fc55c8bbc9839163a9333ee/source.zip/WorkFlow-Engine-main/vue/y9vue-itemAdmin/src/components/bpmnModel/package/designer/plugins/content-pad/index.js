import CustomContextPadProvider from './contentPadProvider';

export default {
  __init__: ['contextPadProvider'],
  contextPadProvider: ['type', CustomContextPadProvider]
};
