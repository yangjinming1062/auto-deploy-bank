'use strict';

import CamundaModdleExtension from './extension.js';
export default {
  __init__: ['CamundaModdleExtension'],
  CamundaModdleExtension: ['type', CamundaModdleExtension]
};
