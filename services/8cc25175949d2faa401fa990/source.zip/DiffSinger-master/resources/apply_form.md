# The way to apply for PopCS
Thanks for your attention to our works. Please write the email to jinglinliu@zju.edu.cn with:

"

name: ***

affiliations: *** (school or institution)

research fields: ***

We want to apply for PopCS and agree to the dataset license: CC by-nc-sa 4.0 (NonCommercial!). 

We accept full responsibility for our use of the dataset and shall defend and indemnify the authors of DiffSinger, against any and all claims arising from our use of the dataset, including but not limited to our use of any copies of copyrighted audio files that we may create from the dataset.

We hereby represent that we are fully authorized to enter into this agreement on behalf of my employer.

We will cite your paper if these codes or data have been used. We will not distribute the download link to others without informing the authors of DiffSinger.

"

Then we will provide the download link to you. 

**Please note that, if you are using PopCS, it means that you have accepted the terms above.**

**Please use your Official Email Address (like xxx@zju.edu.cn)! Thank you!**