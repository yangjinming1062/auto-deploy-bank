(function(angular) {
    'use strict';

    angular.module('confidant.resources', [
        'confidant.resources.controllers',
        'confidant.resources.services'
    ])

    ;
})(window.angular);
