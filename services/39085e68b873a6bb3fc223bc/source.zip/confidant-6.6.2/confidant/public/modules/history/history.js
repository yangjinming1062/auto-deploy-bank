(function(angular) {
    'use strict';

    angular.module('confidant.history', [
        'confidant.history.controllers',
        'confidant.history.services'
    ])

    ;
})(window.angular);
