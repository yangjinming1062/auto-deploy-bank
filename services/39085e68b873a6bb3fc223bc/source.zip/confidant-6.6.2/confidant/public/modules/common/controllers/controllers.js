(function(angular) {
    'use strict';


    angular.module('confidant.common.controllers', [
        // Keep this list sorted alphabetically!
        'confidant.common.controllers.NavCtrl'
    ])
    ;
}(angular));
