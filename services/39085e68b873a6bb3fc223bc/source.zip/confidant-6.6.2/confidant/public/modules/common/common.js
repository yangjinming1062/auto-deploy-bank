(function(angular) {
    'use strict';

    angular.module('confidant.common', [
        'confidant.common.controllers',
        'confidant.common.directives',
        'confidant.common.services'
    ])

    ;
})(window.angular);
