(function(angular) {
    'use strict';

    angular.module('confidant.common.directives', [
        'confidant.common.directives.loadingSpinner'
    ])

    ;
}(window.angular));
