# Support

We have a mailing list for discussion, and a low volume list for announcements:

* https://groups.google.com/forum/#!forum/confidant-users
* https://groups.google.com/forum/#!forum/confidant-announce

We also have an IRC channel on freenode and a Gitter channel:

* [#confidant](http://webchat.freenode.net/?channels=confidant)
* [lyft/confidant on Gitter](https://gitter.im/lyft/confidant)

Feel free to drop into either Gitter or the IRC channel for any reason, even
if just to chat. It doesn't matter which one you join, the messages are sync'd
between the two.
