from confidant.scripts import manage

if __name__ == "__main__":
    manage.main()
