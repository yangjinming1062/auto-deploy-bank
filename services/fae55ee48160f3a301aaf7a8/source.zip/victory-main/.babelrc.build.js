module.exports = {
  extends: "./.babelrc.js",
  ignore: [/^.*(.test.)[j|t]sx?$/],
};
