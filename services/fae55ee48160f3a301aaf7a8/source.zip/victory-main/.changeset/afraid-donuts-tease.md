---
"victory-errorbar": patch
---

add default borderwidth value
