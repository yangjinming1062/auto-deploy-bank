# VictoryBrushLine

`victory-brush-line@^30.0.0` exports `VictoryBrushLine`

To view documentation for `VictoryBrushLine` please see https://commerce.nearform.com/open-source/victory/docs/victory-brush-line

To suggest an addition or correction to this documentation please see https://github.com/FormidableLabs/victory/blob/main/docs/src/content/docs/victory-brush-line.md
