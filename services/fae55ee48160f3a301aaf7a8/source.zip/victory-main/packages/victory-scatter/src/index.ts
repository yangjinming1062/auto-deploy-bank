export * from "./victory-scatter";
