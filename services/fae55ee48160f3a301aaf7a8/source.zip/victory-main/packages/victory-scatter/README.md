# VictoryScatter

`victory-scatter@^30.0.0` exports `VictoryScatter`

To view documentation for `VictoryScatter` please see https://commerce.nearform.com/open-source/victory/docs/victory-scatter

To suggest an addition or correction to this documentation please see https://github.com/FormidableLabs/victory/blob/main/docs/src/content/docs/victory-scatter.md
