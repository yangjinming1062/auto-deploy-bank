# VictoryBrushContainer

`victory-brush-container@^30.0.0` exports `VictoryBrushContainer`, `brushContainerMixin` and `BrushHelpers`

To view documentation for `VictoryBrushContainer` please see https://commerce.nearform.com/open-source/victory/docs/victory-brush-container

To suggest an addition or correction to this documentation please see https://github.com/FormidableLabs/victory/blob/main/docs/src/content/docs/victory-brush-container.md
