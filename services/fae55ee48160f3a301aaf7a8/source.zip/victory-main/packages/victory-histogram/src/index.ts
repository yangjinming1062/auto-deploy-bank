export * from "./victory-histogram";
