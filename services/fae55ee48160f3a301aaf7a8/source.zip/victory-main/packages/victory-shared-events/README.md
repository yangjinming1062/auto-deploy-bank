# VictorySharedEvents

`victory-shared-events@^30.0.0` exports `VictorySharedEvents`

To view documentation for `VictorySharedEvents` please see https://commerce.nearform.com/open-source/victory/docs/victory-shared-events

To suggest an addition or correction to this documentation please see https://github.com/FormidableLabs/victory/blob/main/docs/src/content/docs/victory-shared-events.md
