# VictoryVoronoi

`victory-voronoi@^30.0.0` exports `VictoryVoronoi` and `Voronoi` components

To view documentation for `VictoryVoronoi` please see https://commerce.nearform.com/open-source/victory/docs/victory-voronoi

To suggest an addition or correction to this documentation please see https://github.com/FormidableLabs/victory/blob/main/docs/src/content/docs/victory-voronoi.md
