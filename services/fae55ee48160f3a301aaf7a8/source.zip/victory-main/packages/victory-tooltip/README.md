# VictoryTooltip

`victory-tooltip@^30.0.0` exports `VictoryTooltip` and `Flyout` components

To view documentation for `VictoryTooltip` please see https://commerce.nearform.com/open-source/victory/docs/victory-tooltip

To suggest an addition or correction to this documentation please see https://github.com/FormidableLabs/victory/blob/main/docs/src/content/docs/victory-tooltip.md
