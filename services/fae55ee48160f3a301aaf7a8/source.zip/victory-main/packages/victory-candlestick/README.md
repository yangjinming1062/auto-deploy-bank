# VictoryCandlestick

`victory-candlestick@^30.0.0` exports `VictoryCandlestick` and `Candle` components

To view documentation for `VictoryCandlestick` please see https://commerce.nearform.com/open-source/victory/docs/victory-candlestick

To suggest an addition or correction to this documentation please see https://github.com/FormidableLabs/victory/blob/main/docs/src/content/docs/victory-candlestick.md
