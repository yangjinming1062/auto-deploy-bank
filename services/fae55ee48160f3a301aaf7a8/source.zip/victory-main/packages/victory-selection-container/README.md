# VictorySelectionContainer

`victory-selection-container@^30.0.0` exports `VictorySelectionContainer`, `selectionContainerMixin` and `SelectionHelpers`

To view documentation for `VictorySelectionContainer` please see https://commerce.nearform.com/open-source/victory/docs/victory-selection-container

To suggest an addition or correction to this documentation please see https://github.com/FormidableLabs/victory/blob/main/docs/src/content/docs/victory-selection-container.md
