# VictoryStack

`victory-stack@^30.0.0` exports `VictoryStack`

To view documentation for `VictoryStack` please see https://commerce.nearform.com/open-source/victory/docs/victory-stack

To suggest an addition or correction to this documentation please see https://github.com/FormidableLabs/victory/blob/main/docs/src/content/docs/victory-stack.md
