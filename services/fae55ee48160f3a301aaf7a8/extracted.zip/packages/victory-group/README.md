# VictoryGroup

`victory-group@^30.0.0` exports `VictoryGroup`

To view documentation for `VictoryGroup` please see https://commerce.nearform.com/open-source/victory/docs/victory-group

To suggest an addition or correction to this documentation please see https://github.com/FormidableLabs/victory/blob/main/docs/src/content/docs/victory-group.md
