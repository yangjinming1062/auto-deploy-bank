# VictoryChart

`victory-chart@^30.0.0` exports `VictoryChart`

To view documentation for `VictoryChart` please see https://commerce.nearform.com/open-source/victory/docs/victory-chart

To suggest an addition or correction to this documentation please see https://github.com/FormidableLabs/victory/blob/main/docs/src/content/docs/victory-chart.md
