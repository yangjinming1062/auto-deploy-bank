import rootConfig from "../../test/jest.config";

export default {
  ...rootConfig,
};
