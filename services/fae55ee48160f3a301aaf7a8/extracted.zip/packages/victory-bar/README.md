# VictoryBar

`victory-bar@^30.0.0` exports `VictoryBar` and `Bar` components

To view documentation for `VictoryBar` please see https://commerce.nearform.com/open-source/victory/docs/victory-bar

To suggest an addition or correction to documentation for `VictoryBar` please see https://github.com/FormidableLabs/victory/blob/main/docs/src/content/docs/victory-bar.md
