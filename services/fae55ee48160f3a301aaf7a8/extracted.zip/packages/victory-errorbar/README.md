# VictoryErrorBar

`victory-errorbar@^30.0.0` exports `VictoryErrorBar` and `ErrorBar` components

To view documentation for `VictoryErrorBar` please see https://commerce.nearform.com/open-source/victory/docs/victory-error-bar

To suggest an addition or correction to this documentation please see https://github.com/FormidableLabs/victory/blob/main/docs/src/content/docs/victory-errorbar.md
