# VictoryPie

`victory-pie@^30.0.0` exports `VictoryPie` and `Slice` components

To view documentation for `VictoryPie` please see https://commerce.nearform.com/open-source/victory/docs/victory-pie

To suggest an addition or correction to this documentation please see https://github.com/FormidableLabs/victory/blob/main/docs/src/content/docs/victory-pie.md
