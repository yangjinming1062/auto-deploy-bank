# VictoryLegend

`victory-legend@^30.0.0` exports `VictoryLegend`

To view documentation for `VictoryLegend` please see https://commerce.nearform.com/open-source/victory/docs/victory-legend

To suggest an addition or correction to this documentation please see https://github.com/FormidableLabs/victory/blob/main/docs/src/content/docs/victory-legend.md
