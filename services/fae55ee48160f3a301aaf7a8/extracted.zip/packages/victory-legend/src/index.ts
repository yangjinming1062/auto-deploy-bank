export * from "./victory-legend";
