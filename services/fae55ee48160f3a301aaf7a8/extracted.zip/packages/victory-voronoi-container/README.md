# VictoryVoronoiContainer

`victory-voronoi-container@^30.0.0` exports `VictoryVoronoiContainer`, `voronoiContainerMixin` and `VoronoiHelpers`

To view documentation for `VictoryVoronoiContainer` please see https://commerce.nearform.com/open-source/victory/docs/victory-voronoi-container

To suggest an addition or correction to this documentation please see https://github.com/FormidableLabs/victory/blob/main/docs/src/content/docs/victory-voronoi-container.md
