# VictoryBoxPlot

`victory-box-plot@^30.0.0` exports `VictoryBoxPlot` component

To view documentation for `VictoryBoxPlot` please see https://commerce.nearform.com/open-source/victory/docs/victory-box-plot

To suggest an addition or correction to this documentation please see https://github.com/FormidableLabs/victory/blob/main/docs/src/content/docs/victory-boxplot.md
