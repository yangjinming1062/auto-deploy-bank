# VictoryAxis

`victory-axis@^30.0.0` exports `VictoryAxis` component

To view documentation for `VictoryAxis` please see https://commerce.nearform.com/open-source/victory/docs/victory-axis

To suggest an addition or correction to this documentation please see https://github.com/FormidableLabs/victory/blob/main/docs/src/content/docs/victory-axis.md
