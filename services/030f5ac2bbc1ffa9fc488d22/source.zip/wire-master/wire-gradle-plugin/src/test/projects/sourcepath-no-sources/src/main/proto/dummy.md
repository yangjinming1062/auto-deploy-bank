Added to keep this folder structure for a test

https://stackoverflow.com/questions/115983/how-can-i-add-an-empty-directory-to-a-git-repository/21422128#21422128