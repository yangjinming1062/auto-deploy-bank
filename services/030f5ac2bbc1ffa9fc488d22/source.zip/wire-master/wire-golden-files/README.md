Wire Golden Files
===============

This module contains golden files of generated proto types and services. This is meant to be a
replacement of `gen-tests.gradle.kts` which relies on `WireCompiler` instead of going through the
Wire Gradle plugin.
