# Wire Settings Plugin

This is a Gradle plugin applied to the root `settings.gradle` via `includeBuild`
which automatically adds the `build-support/` Gradle plugin to all projects.
