## JvmJsonTest

This module is consumed by both `jvmJsonJavaTest` and `jvmJsonKotlinTest`. This allows us to run
the same tests against code generated in both java and kotlin.
