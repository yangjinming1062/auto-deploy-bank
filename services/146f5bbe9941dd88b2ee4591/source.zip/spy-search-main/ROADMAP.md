## v0.3 
- [x] User Interface
- [x] pdf search
- [x] API
- [x] Add log
- [x] Local search
- [x] Report generation (pdf)
- [x] Docker


## v0.4
- [] Email API & Notion API & Obsidian API
- [] MCP 
- [] Google API 
- [] Refactor
- [] Support multie site search (now only do google)
- [] webhook
- [] markdown http request 

## v0.5
- [] fast search with other programming language
- [] Audio summary Agent
