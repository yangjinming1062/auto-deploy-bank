# Spy search

## Goal
The goal of Spy Search Go is to create an agentic framework that allows users to develop their spy search more easily. The current implementation of Spy Search is somewhat nested, so we will tackle this problem in two stages:

We will develop a framework in Go.
We will then use this framework to rewrite the nested code base.