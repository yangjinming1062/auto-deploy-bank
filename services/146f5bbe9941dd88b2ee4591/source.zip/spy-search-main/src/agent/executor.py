from .agent import Agent


class Executor(Agent):
    """
    Executor agent execute shell
    """

    pass
