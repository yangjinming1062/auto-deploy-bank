from .agent import Agent


class Scribe(Agent):
    """
    A short writer.  To spped up the generate report speed
    It should be done with
    """

    pass
