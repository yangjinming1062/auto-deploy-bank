"""
Models are just a folder that contine the object  (how to agent communicate with each others)
"""
