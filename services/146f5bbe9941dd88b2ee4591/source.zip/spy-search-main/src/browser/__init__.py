from .duckduckgo import DuckSearch
