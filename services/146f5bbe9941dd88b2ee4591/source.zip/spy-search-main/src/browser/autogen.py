"""
Microsoft autogen browser searchign

we want to test if the efficiency will faster than crawl4ai espically the speed of
getting url. If that's the case we could use this method to get all url
"""

# not planned
