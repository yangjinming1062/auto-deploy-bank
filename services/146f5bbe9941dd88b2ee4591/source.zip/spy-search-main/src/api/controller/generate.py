"""
Generate Response Handler
"""


def select_agent_handler():
    pass


def quicK_response_handler():
    pass


def stream_data_handler():
    pass
