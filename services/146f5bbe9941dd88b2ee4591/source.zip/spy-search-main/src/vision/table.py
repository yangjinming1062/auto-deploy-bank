"""
Give an image table extract and save to
1. numpy format
2.
"""
