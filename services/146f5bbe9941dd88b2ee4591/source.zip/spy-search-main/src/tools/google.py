"""
Support Google eco-system !
"""


class Calendar:
    pass
