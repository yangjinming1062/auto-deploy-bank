"""
main function should call a server

each agent should have a router
for deatil of router please check router.py
"""

from .router import Router
from .server import Server
