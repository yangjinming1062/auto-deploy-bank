package com.easytoolsoft.easyreport.scheduler;

public class MailSendTaskTest {
}
