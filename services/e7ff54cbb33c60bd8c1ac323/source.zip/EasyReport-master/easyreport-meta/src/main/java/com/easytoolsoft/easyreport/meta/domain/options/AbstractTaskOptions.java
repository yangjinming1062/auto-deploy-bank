package com.easytoolsoft.easyreport.meta.domain.options;

import lombok.Data;

/**
 * @author Tom Deng
 * @date 2017-03-25
 */
@Data
public abstract class AbstractTaskOptions {
    private String from;
    private String to;
}
