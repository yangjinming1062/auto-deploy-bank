package com.easytoolsoft.easyreport.mybatis.readwrite;

import com.easytoolsoft.easyreport.mybatis.BaseTest;

/**
 * 读写分离实现测试用例
 *
 * @author Tom Deng
 * @date 2017-03-25
 */
public class ReadWriteUserServiceTest extends BaseTest {
}