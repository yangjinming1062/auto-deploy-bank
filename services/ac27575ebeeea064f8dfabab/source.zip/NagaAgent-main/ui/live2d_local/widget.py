#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Live2D Widget（精简版）
基于QOpenGLWidget的Live2D显示组件
"""

import logging
from typing import Optional, Callable
from nagaagent_core.vendors.PyQt5.QtWidgets import QOpenGLWidget
from nagaagent_core.vendors.PyQt5.QtCore import Qt, QTimer, pyqtSignal, pyqtSlot
from nagaagent_core.vendors.PyQt5.QtGui import QMouseEvent

from .renderer import Live2DRenderer, RendererState
from .animator import Live2DAnimator
from .config_manager import get_config

logger = logging.getLogger("live2d.widget")


class Live2DWidget(QOpenGLWidget):
    """Live2D显示Widget（精简版）"""

    # 信号定义
    model_loaded = pyqtSignal(bool)
    error_occurred = pyqtSignal(str)
    gl_initialized = pyqtSignal(bool)

    def __init__(self, parent=None, target_fps: int = 60, scale_factor: float = 1.0):
        """
        初始化Live2D Widget

        参数:
            parent: 父Widget
            target_fps: 目标帧率
            scale_factor: 模型缩放因子
        """
        super().__init__(parent)

        # 基本设置
        self.scale_factor = scale_factor
        self.target_fps = max(30, min(120, target_fps))

        # 渲染器和动画器
        self.renderer = Live2DRenderer(scale_factor=scale_factor)
        self.animator: Optional[Live2DAnimator] = None

        # 定时器
        self.render_timer: Optional[QTimer] = None

        # 延迟加载标志
        self._pending_load_model: Optional[str] = None
        self._pending_load_callback: Optional[Callable[[float], None]] = None

        # 错误处理相关
        self._error_count = 0
        self._max_errors = 5
        self._consecutive_frame_errors = 0
        self._max_consecutive_errors = 10
        self._fallback_mode = False
        self._last_error_time = 0

        # 编辑模式相关
        self.edit_mode = False
        self.model_offset_x = 0.0
        self.model_offset_y = 0.0
        self._drag_start_pos = None
        self._drag_start_offset_x = 0.0
        self._drag_start_offset_y = 0.0

        # 编辑模式参数
        self._drag_sensitivity = 0.5  # 拖拽灵敏度
        self._zoom_sensitivity = 1200.0  # 缩放灵敏度

        # Widget属性
        self.setMinimumSize(100, 150)
        self.setStyleSheet('background: transparent; border: none;')
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setMouseTracking(True)

        logger.debug(f"Live2D Widget创建，FPS: {self.target_fps}")

    def initializeGL(self):
        """初始化OpenGL上下文"""
        try:
            # 检查OpenGL上下文是否可用
            try:
                # 尝试获取OpenGL版本信息
                from OpenGL.GL import glGetString, GL_VERSION
                version = glGetString(GL_VERSION)
                logger.debug(f"OpenGL版本: {version}")
            except Exception as gl_error:
                logger.warning(f"无法获取OpenGL版本: {gl_error}")
                # 继续尝试初始化，可能是打包环境的问题

            if self.renderer.initialize():
                # 创建动画器
                self.animator = Live2DAnimator(self.renderer)
                logger.debug("OpenGL初始化成功")
                self.gl_initialized.emit(True)

                # 检查是否有待加载的模型
                if self._pending_load_model:
                    logger.debug(f"发现待加载模型: {self._pending_load_model}")
                    QTimer.singleShot(100, self.update)
            else:
                self._handle_init_error("初始化失败")

        except Exception as e:
            self._handle_init_error(str(e))

    def _handle_init_error(self, error_msg: str):
        """处理初始化错误"""
        logger.error(f"OpenGL初始化失败: {error_msg}")
        self.error_occurred.emit(error_msg)
        self.gl_initialized.emit(False)

    def load_model(self, model_path: str, progress_callback: Optional[Callable[[float], None]] = None) -> bool:
        """加载Live2D模型"""
        # 如果渲染器还未初始化，保存请求等待初始化完成
        if self.renderer.state == RendererState.UNINITIALIZED:
            logger.debug("渲染器未初始化，保存模型加载请求")
            self._pending_load_model = model_path
            self._pending_load_callback = progress_callback
            # 如果Widget已经显示，触发更新以初始化OpenGL
            if self.isVisible():
                self.update()
            return True

        # 检查渲染器是否可用
        if not self.renderer.is_available():
            error_msg = self.renderer.get_error_reason() if hasattr(self.renderer, 'get_error_reason') else "渲染器不可用"
            logger.error(f"渲染器不可用: {error_msg}")
            self.error_occurred.emit(error_msg)
            self.model_loaded.emit(False)
            return False

        # 保存加载请求，在paintGL中执行
        self._pending_load_model = model_path
        self._pending_load_callback = progress_callback
        self.update()
        return True

    def paintGL(self):
        """绘制Live2D模型"""
        # 检查OpenGL上下文是否有效
        try:
            # 简单检查OpenGL是否可用
            from OpenGL.GL import glGetError
            error = glGetError()
            if error != 0:
                logger.debug(f"OpenGL错误状态: {error}")
        except Exception as e:
            logger.debug(f"OpenGL检查失败: {e}")
            # 如果OpenGL不可用，直接返回避免崩溃
            return

        # 获取父容器的背景透明度
        bg_alpha = 200
        if self.parent():
            bg_alpha = getattr(self.parent(), 'bg_alpha', 200)

        # 检查待加载的模型
        if self._pending_load_model:
            model_path = self._pending_load_model
            callback = self._pending_load_callback

            # 清除加载请求
            self._pending_load_model = None
            self._pending_load_callback = None

            # 加载模型
            success = self.renderer.load_model(model_path, callback)

            if success:
                self._start_render_timer()
                self.model_loaded.emit(True)
                logger.debug(f"模型加载成功: {model_path}")
            else:
                self.model_loaded.emit(False)
                self.error_occurred.emit(f"模型加载失败: {model_path}")
                logger.error(f"模型加载失败: {model_path}")
                return

        # 正常渲染
        if self.renderer and self.renderer.has_model():
            try:
                self.renderer.update()
                # 传递偏移量给渲染器
                self.renderer.draw(bg_alpha, self.model_offset_x, self.model_offset_y)
            except Exception as e:
                logger.error(f"绘制失败: {e}")
                # 尝试重置渲染器状态
                try:
                    if hasattr(self.renderer, '_reset_model_state'):
                        self.renderer._reset_model_state()
                except:
                    pass

    def resizeGL(self, width: int, height: int):
        """调整OpenGL视口大小"""
        if self.renderer:
            try:
                self.renderer.resize(width, height)
            except Exception as e:
                logger.error(f"视口调整失败: {e}")

    def _start_render_timer(self):
        """启动渲染定时器"""
        if not self.render_timer:
            self.render_timer = QTimer(self)
            self.render_timer.timeout.connect(self._update_frame)

        interval = int(1000 / self.target_fps)
        self.render_timer.start(interval)

    def _update_frame(self):
        """更新帧 - 带错误恢复机制"""
        if not self.renderer.has_model() or self._fallback_mode:
            return

        try:
            if self.animator:
                self.animator.update()
            self.update()

            # 成功更新，重置连续错误计数
            if self._consecutive_frame_errors > 0:
                self._consecutive_frame_errors = 0
                logger.debug("Live2D恢复正常渲染")

        except Exception as e:
            self._consecutive_frame_errors += 1
            self._error_count += 1

            # 记录错误但不频繁输出
            import time
            current_time = time.time()
            if current_time - self._last_error_time > 5:  # 5秒内只记录一次
                logger.error(f"帧更新失败 (连续错误: {self._consecutive_frame_errors}): {e}")
                self._last_error_time = current_time

            # 检查是否需要进入降级模式
            if self._consecutive_frame_errors >= self._max_consecutive_errors:
                self._enter_fallback_mode()

    def _enter_fallback_mode(self):
        """进入降级模式"""
        self._fallback_mode = True
        logger.warning("Live2D进入降级模式，停止动画渲染")

        # 停止渲染定时器
        if self.render_timer:
            self.render_timer.stop()

        # 发送错误信号
        self.error_occurred.emit("Live2D渲染出现持续错误，已进入降级模式")

        # 尝试在5秒后恢复
        QTimer.singleShot(5000, self._try_recover)

    def _try_recover(self):
        """尝试从降级模式恢复"""
        if not self._fallback_mode:
            return

        logger.debug("尝试从降级模式恢复...")
        self._fallback_mode = False
        self._consecutive_frame_errors = 0

        # 重置动画器缓存
        if self.animator and hasattr(self.animator, 'reset_cache'):
            self.animator.reset_cache()

        # 重启渲染定时器
        if self.render_timer and self.renderer.has_model():
            self._start_render_timer()
            logger.debug("Live2D已从降级模式恢复")

    def set_emotion(self, emotion: str, intensity: float = 1.0):
        """设置情绪"""
        if self.animator:
            self.animator.set_emotion(emotion, intensity)

    def set_eye_target(self, x: float, y: float):
        """设置眼球跟踪目标"""
        if self.animator:
            self.animator.set_eye_target(x, y)
    
    @pyqtSlot(float)
    def set_audio_volume(self, volume: float):
        """设置音频音量（用于驱动嘴部动画）

        Args:
            volume: 音量值 (0.0-1.0)
        """
        if self.animator:
            self.animator.set_audio_volume(volume)

    @pyqtSlot(float)
    def set_mouth_form(self, form: float):
        """设置嘴部形状参数（横向，用于音素识别）

        Args:
            form: 嘴形参数 (-1.0 到 1.0)
                 -1.0 = 'i' 音（嘴角拉宽）
                  0.0 = 'e' 音（中性）
                  1.0 = 'u' 音（嘴唇撮起）
        """
        if self.animator:
            self.animator.set_mouth_form(form)

    @pyqtSlot()
    def start_speaking(self):
        """开始说话（启用嘴部动画）"""
        if self.animator:
            self.animator.start_speaking()

    @pyqtSlot()
    def stop_speaking(self):
        """停止说话（关闭嘴部动画）"""
        if self.animator:
            self.animator.stop_speaking()

    @pyqtSlot(float)
    def set_mouth_smile(self, smile: float):
        """设置嘴部微笑度（情感表情）

        Args:
            smile: 微笑度 (-1.0 到 1.0)
        """
        if self.animator:
            self.animator.set_mouth_smile(smile)

    @pyqtSlot(float)
    def set_eye_brow(self, position: float):
        """设置眉毛位置（情感表情）

        Args:
            position: 眉毛位置 (-1.0 到 1.0)，正值向上
        """
        if self.animator:
            self.animator.set_eye_brow(position)

    @pyqtSlot(float)
    def set_eye_wide(self, wide: float):
        """设置眼睛睁大度（情感表情）

        Args:
            wide: 睁大度 (0.0 到 1.0)
        """
        if self.animator:
            self.animator.set_eye_wide(wide)

    def trigger_motion(self, group: str, index: int = 0, priority: int = 3):
        """触发动作"""
        if self.renderer:
            self.renderer.trigger_motion(group, index, priority)

    def trigger_expression(self, expression_id: str):
        """触发表情"""
        if self.renderer:
            self.renderer.trigger_expression(expression_id)

    def set_scale_factor(self, scale_factor: float):
        """设置模型缩放因子"""
        self.scale_factor = max(0.5, min(3.0, scale_factor))
        if self.renderer:
            self.renderer.set_scale_factor(self.scale_factor)
            self.update()

    def set_edit_mode(self, enabled: bool):
        """设置编辑模式"""
        self.edit_mode = enabled
        if enabled:
            self.setCursor(Qt.OpenHandCursor)
            logger.info("编辑模式已启用")
        else:
            self.setCursor(Qt.PointingHandCursor)
            logger.info("编辑模式已禁用")

    def is_model_loaded(self) -> bool:
        """检查是否已加载模型"""
        return self.renderer and self.renderer.has_model()

    def cleanup(self):
        """清理资源"""
        try:
            if self.render_timer:
                self.render_timer.stop()
                self.render_timer = None

            if self.animator:
                self.animator.cleanup()
                self.animator = None

            if self.renderer:
                self.renderer.cleanup()

            logger.debug("Live2D Widget资源已清理")
        except Exception as e:
            logger.error(f"资源清理失败: {e}")

    # 鼠标事件处理
    def mousePressEvent(self, event: QMouseEvent):
        """鼠标点击事件"""
        if event.button() == Qt.LeftButton and self.is_model_loaded():
            if self.edit_mode:
                # 编辑模式：开始拖拽
                self._drag_start_pos = event.pos()
                self._drag_start_offset_x = self.model_offset_x
                self._drag_start_offset_y = self.model_offset_y
                self.setCursor(Qt.ClosedHandCursor)
            else:
                # 正常模式：触发简单动作
                import random
                actions = ["tap_body", "tap_head"]
                self.trigger_motion(random.choice(actions), 0)

        super().mousePressEvent(event)

    def mouseReleaseEvent(self, event: QMouseEvent):
        """鼠标释放事件"""
        if self.edit_mode and self._drag_start_pos is not None:
            self._drag_start_pos = None
            self.setCursor(Qt.OpenHandCursor)

        super().mouseReleaseEvent(event)

    def _handle_drag(self, event: QMouseEvent):
        """处理拖拽移动"""
        delta_x = event.x() - self._drag_start_pos.x()
        delta_y = event.y() - self._drag_start_pos.y()

        # 将像素偏移转换为归一化坐标偏移
        self.model_offset_x = self._drag_start_offset_x + (delta_x / self.width()) * self._drag_sensitivity
        self.model_offset_y = self._drag_start_offset_y - (delta_y / self.height()) * self._drag_sensitivity
        self.update()

    def mouseMoveEvent(self, event: QMouseEvent):
        """鼠标移动事件（眼球跟踪或拖拽）"""
        if not self.is_model_loaded():
            return super().mouseMoveEvent(event)

        if self.edit_mode and self._drag_start_pos:
            self._handle_drag(event)
        else:
            # 正常模式：眼球跟踪
            x = (event.x() / self.width()) * 2.0 - 1.0
            y = -((event.y() / self.height()) * 2.0 - 1.0)
            self.set_eye_target(x, y)

        super().mouseMoveEvent(event)

    def wheelEvent(self, event):
        """鼠标滚轮事件（缩放）"""
        if self.edit_mode and self.is_model_loaded():
            scale_delta = event.angleDelta().y() / self._zoom_sensitivity
            self.set_scale_factor(self.scale_factor + scale_delta)

        super().wheelEvent(event)


def create_widget_from_config(parent=None, config=None):
    """从配置创建Widget"""
    if config is None:
        config = get_config()

    # 基本配置
    target_fps = 60
    scale_factor = 1.0

    if config and config.performance:
        target_fps = getattr(config.performance, 'target_fps', 60)

    if config and config.model:
        scale_factor = getattr(config.model, 'scale_factor', 1.0)

    widget = Live2DWidget(
        parent=parent,
        target_fps=target_fps,
        scale_factor=scale_factor
    )

    logger.debug(f"从配置创建Widget，FPS: {target_fps}, 缩放: {scale_factor}")
    return widget