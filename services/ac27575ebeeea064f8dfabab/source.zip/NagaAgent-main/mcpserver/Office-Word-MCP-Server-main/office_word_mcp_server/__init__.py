from word_document_server.main import run_server

__all__ = ["run_server"]
