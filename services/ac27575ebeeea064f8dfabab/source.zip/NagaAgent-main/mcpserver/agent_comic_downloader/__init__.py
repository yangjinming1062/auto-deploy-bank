"""
Comic Downloader MCP Agent
简化版的禁漫下载器，只保留下载功能，默认保存到桌面
"""

from .comic_service import ComicService

__version__ = "1.0.0"
__all__ = ["ComicService"] 