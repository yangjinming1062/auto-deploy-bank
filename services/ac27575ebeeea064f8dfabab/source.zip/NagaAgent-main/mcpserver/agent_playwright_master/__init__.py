"""
Playwright浏览器代理模块 - 简化版本
"""
from .agent_playwright import PlaywrightAgent, SimpleBrowserTool

__all__ = ['PlaywrightAgent', 'SimpleBrowserTool'] 