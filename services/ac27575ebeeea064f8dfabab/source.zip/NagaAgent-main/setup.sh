#!/bin/bash
python setup.py

