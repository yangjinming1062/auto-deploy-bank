For licensing reasons not all datasets necessary to run the JUnit test are contained in this repository. 
Please contact arx.deidentifier@gmail.com.