OGC API Support
===============

MapProxy does not support the OGC APIs natively. There are ways to combine MapProxy with pygeoapi via docker to be able
to use MapProxy through the OGC API of pygeoapi. An example project exists here:
https://github.com/mapproxy/mapproxy-pygeoapi-example.

Call for sponsors
-----------------

This feature is important to make MapProxy future-proof and it is desirable to integrate OGC APIs directly into
MapProxy. If you are interested in sponsoring this feature please contact sales@terrestris.de.
