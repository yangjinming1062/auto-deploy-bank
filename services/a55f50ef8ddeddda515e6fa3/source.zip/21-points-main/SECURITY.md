# Security Policy

## Supported Versions

This project will fix security vulnerabilities found in its current release.

| Version | Supported          |
| ------- | ------------------ |
| 7.0.x   | :white_check_mark: |
| 5.0.x   | :x:                |
| < 4.0   | :x:                |

## Reporting a Vulnerability

If you'd like to report a vulnerability found in 21-Points Health, please contact [@mraible](https://github.com/mraible).
