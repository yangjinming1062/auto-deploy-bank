export enum Units {
  KG = 'KG',
  LB = 'LB',
}
