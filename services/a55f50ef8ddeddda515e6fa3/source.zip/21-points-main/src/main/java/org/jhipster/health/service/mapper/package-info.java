/**
 * MapStruct mappers for mapping domain objects and Data Transfer Objects.
 */
package org.jhipster.health.service.mapper;
