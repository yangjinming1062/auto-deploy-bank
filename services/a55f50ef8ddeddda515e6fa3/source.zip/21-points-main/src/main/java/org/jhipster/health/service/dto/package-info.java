/**
 * Data Transfer Objects.
 */
package org.jhipster.health.service.dto;
