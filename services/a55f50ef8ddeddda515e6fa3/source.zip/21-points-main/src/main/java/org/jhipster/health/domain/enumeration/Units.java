package org.jhipster.health.domain.enumeration;

/**
 * The Units enumeration.
 */
public enum Units {
    KG,
    LB,
}
