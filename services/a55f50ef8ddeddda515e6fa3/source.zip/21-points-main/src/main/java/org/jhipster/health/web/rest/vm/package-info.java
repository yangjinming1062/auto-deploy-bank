/**
 * View Models used by Spring MVC REST controllers.
 */
package org.jhipster.health.web.rest.vm;
