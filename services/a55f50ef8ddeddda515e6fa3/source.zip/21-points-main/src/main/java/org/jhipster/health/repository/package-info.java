/**
 * Spring Data JPA repositories.
 */
package org.jhipster.health.repository;
