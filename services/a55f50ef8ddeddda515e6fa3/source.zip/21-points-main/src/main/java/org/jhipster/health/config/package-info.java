/**
 * Spring Framework configuration files.
 */
package org.jhipster.health.config;
