from backend.modules.query_controllers.types import BaseQueryInput


class MultiModalQueryInput(BaseQueryInput):
    pass
