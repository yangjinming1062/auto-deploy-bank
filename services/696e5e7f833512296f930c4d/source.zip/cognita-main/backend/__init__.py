from dotenv import load_dotenv

# load environment variables
load_dotenv()
