export enum InfoType {
  SUCCESS = 'success',
  ERROR = 'error',
  WARNING = 'warning',
  DEFAULT = 'default',
  DESCRIPTION = 'description',
}
