export interface SelectedRetrieverType {
  key: string
  name: string
  summary: string
  config: any
}
