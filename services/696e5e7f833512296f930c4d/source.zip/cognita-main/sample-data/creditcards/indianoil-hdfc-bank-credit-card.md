
# [Indianoil hdfc bank credit card](https://www.hdfcbank.com/personal/pay/cards/credit-cards/indianoil-hdfc-bank-credit-card)

## Features
#### Reward Type
Reward Type
Fuel Points
#### Key Features
Key Features
* Earn up to 50 Litres of Free fuel annually
* Earn 5% of your spends as Fuel Points at IndianOil outlets (Max 250 Fuel Points per month in first 6 months, Max 150 Fuel Points post 6 months from card issuance)
* Earn 5% of your spends as Fuel Points on Groceries and Bill Payments (Max 100 Fuel Points per month on each category)
* Earn 1 Fuel Point for every ₹150 spent on all other purchases
#### Additional Features
Additional Features
* Complimentary IndianOil XTRAREWARDSTM Program (IXRP) membership
* **Revolving Credit :** Enjoy Revolving Credit on your IndianOil HDFC Bank Credit Card at nominal interest rate. Please refer to the Fees and Charges section.
* **Zero Lost card liability :** In the unfortunate event of you losing your IndianOil HDFC Bank Credit Card, report it immediately to our 24-hour call centre. After reporting the loss, you have zero liability on any fraudulent transactions made on your Credit Card.
​​​​​​​
* **Interest Free Credit Period :** Up to 50 days of interest free period on your IndianOil HDFC Bank Credit Card from the date of purchase (subject to the submission of the charge by the Merchant)
#### Fuel Surcharge Waiver
Fuel Surcharge Waiver
1% fuel surcharge waiver at all fuel stations across India 
​​​​​​​(on minimum trasaction of ₹400. Max CashBack of ₹250 per statement cycle)
#### Renewal Offer
Renewal Offer
Spend ₹50,000 and above in the first year and get a waiver on the renewal membership fee 
#### Smart EMI
Smart EMI
IndianOil HDFC Bank Credit Card comes with an option to convert your big spends into EMI after purchase. To know more [click here](https://www.hdfcbank.com/personal/borrow/loan-against-assets/smartemi "https://www.hdfcbank.com/personal/borrow/loan-against-assets/smartemi").
#### Contactless Payment
Contactless Payment
* The IndianOil HDFC Bank Credit Card is enabled for contactless payments, facilitating fast, convenient and secure payments at retail outlets.
* To see if your credit card is contactless, look for the contactless network symbol  on your card
(Please note that in India, payment through contactless mode is allowed for a maximum of ₹5000 for a single transaction where you are not asked to input your Credit Card PIN. However, if the amount is higher than or equal to ₹5000, the Card holder has to enter the Credit Card PIN for security reasons)
#### Reward Point/CashBack Redemption & Validity
Reward Point/CashBack Redemption & Validity
**Fuel Points Accrual :**
* Fuel Point is an exclusive Rewards metric system created only for IndianOil HDFC Bank Credit Card holders.
* Earn Fuel Points on retail spends with the IndianOil HDFC Bank Credit Card
* Earn accelerated 5% Fuel Points on spends at IndianOil outlets, Groceries and Bill payments.
(Accelerated 5% Fuel Points benefit will be given only for fuel transactions on IndianOil Retail Outlets. Fuel transactions on all other Fuel Outlets will get 1 Fuel Point for every Rs. 150/- spent)
**Fuel Point Redemption :**
* Redeem Fuel Points for Free Fuel using the complimentary IndianOil XTRAREWARDSTM Program (IXRP) membership. Redemption at participating IndianOil Petrol Outlet by converting Fuel Points into XRP (where 1 FP = 96 Paise). [Click here](https://v.hdfcbank.com/htdocs/common/HTML_IOCL/LP.html "https://v.hdfcbank.com/htdocs/common/HTML_IOCL/LP.html") to know more
To locate your nearest IndianOil Petrol Outlet, [click here](https://ind01.safelinks.protection.outlook.com/?url=https%3A%2F%2Fassociates.indianoil.co.in%2FPumpLocator%2F&amp;data=05%7C01%7Ckiruthinimeshika.k%40hdfcbank.com%7C497717aec0934fb7b1cc08da38f0927a%7C827fd02205a64e57be9ccc069b6ae62d%7C0%7C0%7C637884903139660767%7CUnknown%7CTWFpbGZsb3d8eyJWIjoiMC4wLjAwMDAiLCJQIjoiV2luMzIiLCJBTiI6Ik1haWwiLCJXVCI6Mn0%3D%7C3000%7C%7C%7C&amp;sdata=usM8dGys6amPBz2DWA3CvZrqEZ1%2Ffe5yI7Ycmi80jHg%3D&amp;reserved=0 "https://ind01.safelinks.protection.outlook.com/?url=https%3A%2F%2Fassociates.indianoil.co.in%2FPumpLocator%2F&amp;data=05%7C01%7Ckiruthinimeshika.k%40hdfcbank.com%7C497717aec0934fb7b1cc08da38f0927a%7C827fd02205a64e57be9ccc069b6ae62d%7C0%7C0%7C637884903139660767%7CUnknown%7CTWFpbGZsb3d8eyJWIjoiMC4wLjAwMDAiLCJQIjoiV2luMzIiLCJBTiI6Ik1haWwiLCJXVCI6Mn0%3D%7C3000%7C%7C%7C&amp;sdata=usM8dGys6amPBz2DWA3CvZrqEZ1%2Ffe5yI7Ycmi80jHg%3D&amp;reserved=0")
* Redeem Fuel Points through NetBanking towards catalogue products (where 1 FP = upto 20 paise)
* Redeem Fuel Points as CashBack on your IndianOil HDFC Bank Credit Card. (Cashback Redemption against Statement balance where 1 FP = 20 Paise)
|  |  |
| --- | --- |
| **Cost per Point (in Rs.)** | **IOCL Fuel Points (in Rs.)** |
| **Product Catalogue** | **Cash back** |
| Upto 0.20 | 0.20 | 1 Fuel Point = 3 XtraRewards Point (XRP)1 XRP = 0.321 Fuel Point = 0.96 |
**Fuel Points Validity:**
* Fuel Points are valid for a period of 2 years.
1. Redemption of Reward Points to Cashback and Travel categories will be capped at 50,000 points per month per customer
2. Accrual of Reward Points on Grocery Spends will be capped at 1000 points per month per customer
3. There will be no Reward Points accrual on Spends made on Rental and Government category payments
4. Points + Pay - A maximum of 70% can be paid using Reward Points and the other 30% to be made by payment modes(Cash/Cards/UPI etc.)
[FAQs](/personal/need-help/faqs#/indianoil-hdfc-bank-credit-card)

## Eligibility
IndianOil HDFC Bank Credit Card Eligibility:​​​​​​​
**For Salaried Indian National:**
* Age: Min 21 years to Max 60 Years,
* Net Monthly Income> Rs 10,000
**For Self Employed Indian National:**
* Age: Min 21 years & Max 65 Years
* Annual Income: ITR > Rs 6 Lakhs per annum

## Fees and Charges
* Joining/Renewal Membership Fee – Rs. 500/- plus Applicable Taxes
* [Click here](/Personal/Pay/Cards/Credit Card/Credit Card Landing Page/Manage Your Credit Cards PDFs/MITC 1.64.pdf "/Personal/Pay/Cards/Credit Card/Credit Card Landing Page/Manage Your Credit Cards PDFs/MITC 1.64.pdf") to view details of your IndianOil HDFC Bank Credit Card fees and charges
For card sourced effective 01-11- 2020, Below T&Cs are applicable  
1. The Bank reserves the right to cancel the Card in case the Card remains inactive and is not used for effecting any transaction for a continuous period of 6 (Six) months after prior written notice sent on the email address and/or phone number and/or communication address, registered in the records of the Bank.
1% Fee on Rental transactions - from the 2nd rental transaction done every calendar month
​​​​​​​
1% Mark-Up to be applicable on all International DCC transactions
