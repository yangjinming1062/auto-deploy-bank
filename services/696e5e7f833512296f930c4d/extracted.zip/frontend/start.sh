yarn import-meta-env --example .env.example && yarn start
