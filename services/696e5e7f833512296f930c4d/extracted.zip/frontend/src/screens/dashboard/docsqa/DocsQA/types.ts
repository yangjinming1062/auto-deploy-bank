export type PreviewResource = {
  presignedUrl?: string
  externalUrl?: string
  name: string
  fileFormat?: string
}
