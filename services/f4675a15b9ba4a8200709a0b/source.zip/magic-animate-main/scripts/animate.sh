python3 -m magicanimate.pipelines.animation --config configs/prompts/animation.yaml
