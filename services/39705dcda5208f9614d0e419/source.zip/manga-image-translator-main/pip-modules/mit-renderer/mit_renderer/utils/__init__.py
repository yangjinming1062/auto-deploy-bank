from pathlib import Path

from .generic2 import *
from .textblock import *

BASE_PATH = Path.cwd()


def get_logger(name: str):
    return None
