import sys
sys.path.append('manga_translator/inpainting')
