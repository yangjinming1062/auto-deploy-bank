#!/bin/bash
git pull --quiet
python -m manga_translator $@