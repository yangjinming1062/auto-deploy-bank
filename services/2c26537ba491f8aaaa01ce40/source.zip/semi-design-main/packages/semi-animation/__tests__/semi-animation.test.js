'use strict';

const semiAnimation = require('..');

describe('@douyinfe/semi-animation', () => {
    it('needs tests');
});
