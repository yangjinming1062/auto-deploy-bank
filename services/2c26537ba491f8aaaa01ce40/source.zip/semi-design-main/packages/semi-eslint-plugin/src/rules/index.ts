import noImport from './no-import';

export default {
    'no-import': noImport,
};