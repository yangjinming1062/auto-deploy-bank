import { loops, delays, speeds } from './src/constants/times';
import * as types from './src/constants/types';

export { loops, delays, speeds, types };
