export const loops = ['1', '2', '3', '4', '5', 'infinite'];
export const delays = ['0s', '1s', '2s', '3s', '4s', '5s'];
export const speeds = ['default', 'fast', 'faster', 'slow', 'slower'];
