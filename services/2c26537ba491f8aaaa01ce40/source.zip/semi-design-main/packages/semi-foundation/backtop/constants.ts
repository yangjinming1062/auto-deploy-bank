import { BASE_CLASS_PREFIX } from '../base/constants';

const cssClasses = {
    PREFIX: `${BASE_CLASS_PREFIX}-backtop`,
};

const strings = {
};

export { cssClasses, strings };