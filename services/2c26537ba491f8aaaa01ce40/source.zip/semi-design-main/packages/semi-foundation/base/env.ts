export const BASE_CLASS_PREFIX = 'semi';
