import BaseFoundation from './foundation';

export default { BaseFoundation };
