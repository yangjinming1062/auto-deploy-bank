import semiUiReactMotion from '..';

describe('semi-ui-react-motion', () => {
    it('needs tests');
});
