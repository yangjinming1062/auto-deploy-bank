---
order: 8
category: 体验增强
title: Internationalization 国际化
icon: doc-internationalization
localeCode: zh-CN
brief: 全球化设计并非针对于某一市场，而是立足于共同点、找寻差异点，创建一种包容性的设计，以便不同国家地区的不同用户能够理解相同的设计语言，保证界面的基础体验。
---


<InternationalizationTabs locale="zh-CN" />


