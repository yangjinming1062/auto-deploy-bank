import { gluer } from 'glue-redux';

const tab = gluer(['dashboard']);
export default tab;
