import { gluer } from 'glue-redux';

const menu = gluer([]);

export default menu;
