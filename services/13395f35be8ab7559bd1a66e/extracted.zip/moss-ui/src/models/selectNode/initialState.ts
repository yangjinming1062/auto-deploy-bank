export const SELECTNODE = {
  SELECTNODE: [],
};
