import 'moment/locale/zh-cn'
import moment from 'moment'

moment.locale('zh-cn')
