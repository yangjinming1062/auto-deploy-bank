export default {
  define: {
    ENV: 'production',
    apiHost: '/',
  },
}
