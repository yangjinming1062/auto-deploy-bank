export default {
  'POST /admin/project/list': [
    {
      cname: 'cname',
      description: 'description',
      gmtCreate: 1552278469486,
      gmtModified: 1552278469487,
      id: 5,
      isDeleted: 0,
      key: 'key',
      name: 'name',
      ownerId: 'ownerId',
      ownerName: 'ownerName',
    },
  ],
}
