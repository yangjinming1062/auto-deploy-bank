# Application Properties

you can easily change the registry and backend database type by `spring.profiles.active`