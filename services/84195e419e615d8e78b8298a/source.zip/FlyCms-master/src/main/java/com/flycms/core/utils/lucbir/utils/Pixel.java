package com.flycms.core.utils.lucbir.utils;

/**
 * Created by VenyoWang on 2016/7/8.
 */
public class Pixel {
    public int red;
    public int green;
    public int blue;
}
