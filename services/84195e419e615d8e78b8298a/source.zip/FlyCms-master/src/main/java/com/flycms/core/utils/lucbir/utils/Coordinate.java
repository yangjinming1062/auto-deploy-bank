package com.flycms.core.utils.lucbir.utils;

/**
 * Created by VenyoWang on 2016/7/8.
 */
public class Coordinate {
    public double x;
    public double y;
}
