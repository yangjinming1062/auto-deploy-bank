package library_package;

/**
 *  Template Hello World for this module
 *
 */
public class TemplateHelloWorld {

    public static void main(String[] args) {
        // HelloWorld example for this library or framework
    }
}
