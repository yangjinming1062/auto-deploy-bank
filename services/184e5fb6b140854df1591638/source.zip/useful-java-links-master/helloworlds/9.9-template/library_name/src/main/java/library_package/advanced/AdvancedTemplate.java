package library_package.advanced;

/**
 *  Template Hello World examples for this module (more complex then TemplateHelloWorld)
 *
 */
public class AdvancedTemplate {

    public static void main(String[] args) {
        // HelloWorld example for this library or framework
    }
}
