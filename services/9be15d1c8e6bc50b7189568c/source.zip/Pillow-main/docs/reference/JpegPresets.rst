.. py:currentmodule:: PIL.JpegPresets

:py:mod:`~PIL.JpegPresets` module
=================================

.. automodule:: PIL.JpegPresets

    .. data:: presets
        :type: dict

        A dictionary of all supported presets.
