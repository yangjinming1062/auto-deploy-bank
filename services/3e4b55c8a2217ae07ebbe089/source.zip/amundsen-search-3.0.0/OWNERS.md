* See [CONTRIBUTING.md](CONTRIBUTING.md) for general contribution guidelines.
* See [GOVERNANCE.md](GOVERNANCE.md) for governance guidelines.

This page lists all the maintainers for Amundsen.  This can be used for
routing PRs, questions, etc. to the right place.

# Amundsen committers
- Allison Suarez Miranda (https://github.com/allisonsuarez)
- Bolke de Bruin (https://github.com/bolkedebruin)
- Daniel Won (https://github.com/danwom)
- Diksha Thakur (https://github.com/dikshathakur3119)
- Dmitriy Kunitskiy (https://github.com/dkunitsk)
- Dominik Choma (https://github.com/dechoma)
- Dorian Johnson (https://github.com/dorianj)
- Grant Seward (https://github.com/sewardgw)
- Jin Hyuk Chang (https://github.com/jinhyukchang)
- Junda Yang (https://github.com/youngyjd)
- Marcos Iglesias (https://github.com/golodhros)
- Mariusz Gorski (https://github.com/mgorsk1)
- Mark Grover (https://github.com/markgrover)
- Shenghu Yang (https://github.com/shenghuy)
- Tamika Tannis (https://github.com/ttannis)
- Tao Feng (https://github.com/feng-tao)
- Verdan Mahmood (https://github.com/verdan)
