2.1.2

- Fixed `neo4j` service name to be same everywhere 