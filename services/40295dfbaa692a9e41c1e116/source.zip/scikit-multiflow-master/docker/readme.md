# scikit-multiflow Docker
scikit-multiflow Docker images  are located in the [skmultiflow/scikit-multiflow](https://hub.docker.com/r/skmultiflow/scikit-multiflow) Docker Hub repository.

### usage :
+ Build scikit-multiflow:jupyter
```
make build-jupyter
```

+ Build scikit-multiflow:latest
```
make build-python
```

+ push scikit-multiflow:jupyter
```
make push-jupyter
```
+ push scikit-multiflow:latest
```
make push-python
```