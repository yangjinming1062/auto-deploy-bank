scikit-multiflow map
====================

The following map is provided to help users navigate the multiple methods available in
``scikit-multiflow``. Click on the image to see it in its original size.


.. image:: ../_static/images/scikit-multiflow_map.png
   :width: 700px
   :alt: scikit-multiflow_map
   :align: center

This is a rough guide to identify a method depending on the task/data at hand.
For more information, please see the `API Reference <api/api.html>`_