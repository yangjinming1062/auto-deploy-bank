.. role:: forestgreen-label
.. role:: royalblue-label
.. role:: gold-label
.. role:: crimson-label

.. |MajorFeature| replace:: :forestgreen-label:`Major Feature`
.. |Feature| replace:: :forestgreen-label:`Feature`
.. |Efficiency| replace:: :royalblue-label:`Efficiency`
.. |Enhancement| replace:: :royalblue-label:`Enhancement`
.. |Fix| replace:: :crimson-label:`Fix`
.. |API| replace:: :gold-label:`API Change`


