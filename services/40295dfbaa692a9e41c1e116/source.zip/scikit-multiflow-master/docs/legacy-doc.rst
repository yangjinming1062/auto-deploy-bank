Legacy documentation for scikit-multiflow
==========================================

Documentation files (html) for offline reference:

:download:`scikit-multiflow 0.4.1 documentation <https://github.com/scikit-multiflow/scikit-multiflow/releases/download/0.4.1/scikit-multiflow.0.4.1.documentation.zip>`

:download:`scikit-multiflow 0.4.0 documentation <https://github.com/scikit-multiflow/scikit-multiflow/releases/download/0.4.0/scikit-multiflow.0.4.0.documentation.zip>`

:download:`scikit-multiflow 0.3.0 documentation <https://github.com/scikit-multiflow/scikit-multiflow/releases/download/0.3.0/scikit-multiflow.0.3.0.documentation.zip>`

:download:`scikit-multiflow 0.2.0 documentation <https://github.com/scikit-multiflow/scikit-multiflow/releases/download/0.2.0/scikit-multiflow.0.2.0.documentation.zip>`
