import * as punycode from "punycode";
globalThis.punycode = punycode;
export * from "./index";
