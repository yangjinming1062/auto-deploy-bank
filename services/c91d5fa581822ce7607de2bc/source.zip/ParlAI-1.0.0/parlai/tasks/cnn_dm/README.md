Task: CNN/DM Summarisation
===========================
Description: Dataset collected from CNN and the Daily Mail with summaries as labels, Implemented as part of the DecaNLP taskDownloaded from https://cs.nyu.edu/~kcho/DMQA/

Tags: #cnn_dm, #All, #decanlp

