Task: BookTest
===============
Description: Sentence completion given a few sentences as context from a book. A larger version of CBT. From Bajgar et al., 16. 

Link: https://arxiv.org/abs/1610.00956

Tags: #BookTest, #All, #Cloze

