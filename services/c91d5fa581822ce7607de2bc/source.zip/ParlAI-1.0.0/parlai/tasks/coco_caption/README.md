Task: COCO_Captions
====================
Description: COCO annotations derived from the 2015 COCO Caption Competition. Link to dataset: http://cocodataset.org/#download

Tags: #COCO_Captions, #All, #Visual

