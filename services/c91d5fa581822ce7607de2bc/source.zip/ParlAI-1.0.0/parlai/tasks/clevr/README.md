Task: CLEVR
============
Description: A visual reasoning dataset that tests abilities such as attribute identification, counting, comparison, spatial relationships, and logical operations. From Johnson et al. '16. 

Link: https://arxiv.org/abs/1612.06890

Tags: #CLEVR, #All, #Visual

