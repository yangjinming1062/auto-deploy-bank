# Advanced Scripts

These are the more obscure and advanced scripts in parlai.

```{include} cli_advanced.inc
```
