# Tasks

List of ParlAI tasks defined in the file [task_list.py](https://github.com/facebookresearch/ParlAI/tree/master/parlai/tasks/task_list.py).

```{include} task_list.inc
```

