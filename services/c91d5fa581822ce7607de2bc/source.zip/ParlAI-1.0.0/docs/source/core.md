# parlai.core

This contains the full, comprehensive docstrings of all of `parlai.core`,
which powers the vast majority of ParlAI.

```{toctree}
:maxdepth: 1
:glob:

core/*
```
