# parlai.core.metrics
```{eval-rst}
.. automodule:: parlai.core.metrics
  :members:
```
