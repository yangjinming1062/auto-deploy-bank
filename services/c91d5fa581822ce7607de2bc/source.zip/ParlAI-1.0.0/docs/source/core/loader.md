# parlai.core.loader
```{eval-rst}
.. automodule:: parlai.core.loader
  :members:
```
