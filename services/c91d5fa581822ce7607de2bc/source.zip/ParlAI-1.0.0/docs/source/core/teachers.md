# parlai.core.teachers
```{eval-rst}
.. automodule:: parlai.core.teachers
  :members:
```
