# parlai.core.opt
```{eval-rst}
.. automodule:: parlai.core.opt
  :members:
```

# parlai.core.params
```{eval-rst}
.. automodule:: parlai.core.params
  :members:
```
