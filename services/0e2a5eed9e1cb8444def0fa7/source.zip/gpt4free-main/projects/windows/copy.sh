cp -r * /var/win/shared/
cp -r projects/windows/* /var/win/shared/
cp setup.py /var/win/shared/
cp README.md /var/win/shared/
#git clone https://github.com/pyinstaller/pyinstaller/ /var/win/shared/pyinstaller 