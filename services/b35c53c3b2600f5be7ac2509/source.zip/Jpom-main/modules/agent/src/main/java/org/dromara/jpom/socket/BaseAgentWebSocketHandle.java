/*
 * The MIT License (MIT)
 *
 * Copyright (c) 2019 Code Technology Studio
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of
 * this software and associated documentation files (the "Software"), to deal in
 * the Software without restriction, including without limitation the rights to
 * use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of
 * the Software, and to permit persons to whom the Software is furnished to do so,
 * subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
 * FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
 * IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package org.dromara.jpom.socket;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.exceptions.ExceptionUtil;
import cn.hutool.core.map.SafeConcurrentHashMap;
import cn.hutool.core.util.StrUtil;
import cn.hutool.core.util.URLUtil;
import com.alibaba.fastjson2.JSONObject;
import lombok.extern.slf4j.Slf4j;
import org.dromara.jpom.common.Const;
import org.dromara.jpom.configuration.AgentAuthorize;
import org.dromara.jpom.util.SocketSessionUtil;

import javax.websocket.CloseReason;
import javax.websocket.Session;
import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 插件端socket 基类
 *
 * @author bwcx_jzy
 * @since 2019/4/24
 */
@Slf4j
public abstract class BaseAgentWebSocketHandle {

    private static final ConcurrentHashMap<String, String> USER = new SafeConcurrentHashMap<>();
    protected static AgentAuthorize agentAuthorize;

    /**
     * 设置授权对象
     *
     * @param agentAuthorize 授权
     */
    protected static void setAgentAuthorize(AgentAuthorize agentAuthorize) {
        BaseAgentWebSocketHandle.agentAuthorize = agentAuthorize;
    }

    protected String getParameters(Session session, String name) {
        Map<String, List<String>> requestParameterMap = session.getRequestParameterMap();
        Map<String, String> parameters = session.getPathParameters();
        if (log.isDebugEnabled()) {
            log.debug("web socket parameters: {} {}", JSONObject.toJSONString(requestParameterMap), parameters);
        }
        List<String> strings = requestParameterMap.get(name);
        String value = CollUtil.join(strings, StrUtil.COMMA);
        if (StrUtil.isEmpty(value)) {
            value = parameters.get(name);
        }
        return URLUtil.decode(value);
    }

    /**
     * 判断授权信息是否正确
     *
     * @param session session
     * @return true 需要结束回话
     */
    public boolean checkAuthorize(Session session) {
        String authorize = this.getParameters(session, Const.JPOM_AGENT_AUTHORIZE);
        boolean ok = agentAuthorize.checkAuthorize(authorize);
        if (!ok) {
            log.warn("socket 会话建立失败,授权信息错误");
            try {
                session.close(new CloseReason(CloseReason.CloseCodes.CANNOT_ACCEPT, "授权信息错误"));
            } catch (Exception e) {
                log.error("socket 错误", e);
            }
            return true;
        }
        this.addUser(session, this.getParameters(session, "optUser"));
        return false;
    }

    /**
     * 添加用户监听的
     *
     * @param session session
     * @param name    用户名
     */
    private void addUser(Session session, String name) {
        String optUser = URLUtil.decode(name);
        if (optUser == null) {
            return;
        }
        USER.put(session.getId(), optUser);
    }

    public void onError(Session session, Throwable thr) {
        // java.io.IOException: Broken pipe
        try {
            SocketSessionUtil.send(session, "服务端发生异常" + ExceptionUtil.stacktraceToString(thr));
        } catch (IOException ignored) {
        }
        log.error(session.getId() + "socket 异常", thr);
    }

    protected String getOptUserName(Session session) {
        String name = USER.get(session.getId());
        return StrUtil.emptyToDefault(name, StrUtil.DASHED);
    }

    public void onClose(Session session, CloseReason closeReason) {
        log.debug("会话[{}]关闭原因：{}", session.getId(), closeReason);
        // 清理日志监听
        try {
            AgentFileTailWatcher.offline(session);
        } catch (Exception e) {
            log.error("关闭异常", e);
        }
        // top
        //        TopManager.removeMonitor(session);
        USER.remove(session.getId());
    }
}
