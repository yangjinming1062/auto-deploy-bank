package com.ruoyi.common.core.validate;

/**
 * 校验分组 add
 *
 * @author Lion Li
 */
public interface AddGroup {
}
