"""
Auto-generated protobuf class definitions.

Protobuf allows us to serialize/deserialize classes across languages
"""
from whylogs.core.proto.whylogs_messages_pb2 import *  # noqa
