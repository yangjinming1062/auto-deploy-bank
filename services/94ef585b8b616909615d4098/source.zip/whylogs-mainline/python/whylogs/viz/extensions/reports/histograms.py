from whylogs.viz.extensions.reports.html_report import HTMLReport


class DistributionChart(HTMLReport):
    pass


class DifferenceDistributionChart(HTMLReport):
    pass


class FeatureStatisticsReport(HTMLReport):
    pass


class DoubleHistogram(HTMLReport):
    pass
