from .profiler import fugue_profile

assert fugue_profile is not None
