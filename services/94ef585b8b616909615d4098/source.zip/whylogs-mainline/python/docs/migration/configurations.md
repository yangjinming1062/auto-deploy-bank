# Configurations

## v1 configuration

- No more YAML
- Configuring in code

## Migrating from v0

An existing configuration:

```yaml
TBD
```

In whylogs v1 configuration style:

```python
import whylogs as why


```
