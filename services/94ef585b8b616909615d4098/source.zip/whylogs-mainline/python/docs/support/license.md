# License

<h2 align="center">Apache License 2.0</h2>

```{literalinclude} ../../../LICENSE
```
