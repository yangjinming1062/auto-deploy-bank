# -*- coding: utf-8 -*-
"""Create an application instance."""
from app import create_app  # type: ignore

app = create_app()
