# -*- coding: utf-8 -*-
"""API module v1."""
# from .views import blueprint
