# Amazon SageMaker + WhyLabs integration

SageMaker custom container with scikit-learn inference example that integrates whylabs logging.

There is a whylogs 0.7.x example here:
https://github.com/whylabs/whylogs/tree/maintenance/0.7.x/examples/sagemaker_whylabs_example
