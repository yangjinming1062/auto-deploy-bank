package org.apache.spark.whylogs

class Placeholder {

}
