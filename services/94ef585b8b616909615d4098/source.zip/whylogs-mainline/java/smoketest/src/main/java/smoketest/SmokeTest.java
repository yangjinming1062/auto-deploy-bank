import com.whylogs.core.SummaryConfig;
import java.time.Instant;

public class SmokeTest {
    public static void main(String[] args) {
        System.out.println("Do nothing");
    }
}
