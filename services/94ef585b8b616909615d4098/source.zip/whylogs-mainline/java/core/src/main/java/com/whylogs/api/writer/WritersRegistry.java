package com.whylogs.api.writer;

public class WritersRegistry {
  public static <T extends Writer> T get(String name) {
    // TODO: Not implemented yet
    return null;
  }
}
