package com.whylogs.core;

public enum FrequentItemsErrorType {
  NO_FALSE_POSITIVES,
  NO_FALSE_NEGATIVES
}
