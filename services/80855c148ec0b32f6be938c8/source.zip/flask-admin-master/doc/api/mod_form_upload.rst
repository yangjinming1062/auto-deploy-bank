``flask_admin.form.upload``
===========================

.. automodule:: flask_admin.form.upload

	.. autoclass:: FileUploadField
		:class-doc-from: class
		:members: __init__

	.. autoclass:: ImageUploadField
		:class-doc-from: class
		:members: __init__

	.. autoclass:: FileUploadInput

	.. autoclass:: ImageUploadInput
