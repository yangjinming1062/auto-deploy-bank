Notable projects using Flask-Admin
----------------------------------

 * `Inventory Checkin <https://github.com/cbess/inventory-checkin>`_
 * `Parliamentary Monitoring Group (South Africa) <https://pmg.org.za/>`_

If you have open source project that uses Flask-Admin, send me a link and I will add it to the list.
