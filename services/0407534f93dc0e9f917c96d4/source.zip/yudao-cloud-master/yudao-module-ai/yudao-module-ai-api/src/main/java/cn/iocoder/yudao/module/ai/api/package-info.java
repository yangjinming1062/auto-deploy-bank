/**
 * 占位，没有特别的作用
 */
package cn.iocoder.yudao.module.ai.api;