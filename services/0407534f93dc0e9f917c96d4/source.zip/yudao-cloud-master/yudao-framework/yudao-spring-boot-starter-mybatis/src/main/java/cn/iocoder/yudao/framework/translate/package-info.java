/**
 * 使用 Easy-Trans 提升使用 VO 数据翻译的开发效率
 */
package cn.iocoder.yudao.framework.translate;
