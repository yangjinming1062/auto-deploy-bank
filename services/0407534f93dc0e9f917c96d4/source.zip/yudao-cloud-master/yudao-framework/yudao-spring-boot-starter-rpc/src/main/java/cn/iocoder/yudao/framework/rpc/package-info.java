/**
 * OpenFeign：提供 RESTful API 的调用
 *
 * @author 芋道源码
 */
package cn.iocoder.yudao.framework.rpc;
