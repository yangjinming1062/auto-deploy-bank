/**
 * 针对 infra 模块的 api 包
 */
package cn.iocoder.yudao.framework.common.biz.infra;