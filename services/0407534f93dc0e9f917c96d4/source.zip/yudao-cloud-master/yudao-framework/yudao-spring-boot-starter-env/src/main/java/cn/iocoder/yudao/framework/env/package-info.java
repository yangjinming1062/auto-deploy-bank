/**
 * 开发环境拓展，实现类似阿里的特性环境的能力
 * 1. https://segmentfault.com/a/1190000018022987
 *
 * @author 芋道源码
 */
package cn.iocoder.yudao.framework.env;
