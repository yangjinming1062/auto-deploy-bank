import React from "react"

const PageHeaderContainer = ({ children }) => (
  <div className="container page-header-container">{children}</div>
)

export default PageHeaderContainer
