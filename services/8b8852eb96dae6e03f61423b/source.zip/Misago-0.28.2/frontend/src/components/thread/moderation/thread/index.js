import ThreadModerationOptions from "./controls"

export default ThreadModerationOptions
