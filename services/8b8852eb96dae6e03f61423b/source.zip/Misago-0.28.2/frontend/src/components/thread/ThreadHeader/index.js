import ThreadHeader from "./ThreadHeader"

export default ThreadHeader
