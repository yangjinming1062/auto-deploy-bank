import React from "react"

const PageContainer = ({ children }) => (
  <div className="container page-container">{children}</div>
)

export default PageContainer
