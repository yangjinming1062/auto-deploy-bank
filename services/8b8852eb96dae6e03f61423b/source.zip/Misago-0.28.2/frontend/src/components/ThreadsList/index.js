import ThreadsList from "./ThreadsList"

export default ThreadsList
