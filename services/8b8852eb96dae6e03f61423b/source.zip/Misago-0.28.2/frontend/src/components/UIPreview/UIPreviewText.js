import React from "react"

const UIPreviewText = ({ width }) => (
  <span className="ui-preview-text" style={{ width: width + "px" }}>
    &nbsp;
  </span>
)

export default UIPreviewText
