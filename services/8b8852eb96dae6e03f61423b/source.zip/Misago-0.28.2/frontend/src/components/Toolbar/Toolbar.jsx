import React from "react"

const Toolbar = ({ children }) => <nav className="toolbar">{children}</nav>

export default Toolbar
