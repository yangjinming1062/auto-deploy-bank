export const HEADER = "HEADER"
export const RESULT = "RESULT"
export const FOOTER = "FOOTER"
