import React from "react"

export default function () {
  return (
    <li className="dropdown-search-message">
      {gettext("Search returned no results.")}
    </li>
  )
}
