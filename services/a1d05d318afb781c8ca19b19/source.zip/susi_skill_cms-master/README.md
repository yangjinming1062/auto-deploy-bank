# susi_skill_cms

[![Build Status](https://travis-ci.org/fossasia/susi_skill_cms.svg?branch=master)](https://travis-ci.org/fossasia/susi_skill_cms)

A web application framework to edit SUSI.AI Skills. We merged this component now into the SUSI.AI main web application. Development continues here: https://github.com/fossasia/susi.ai

Please join us!

## Communication

Please join our mailing list to discuss questions regarding the project: https://groups.google.com/group/susiai/

Our chat channel is on gitter here: https://gitter.im/fossasia/susi.ai
