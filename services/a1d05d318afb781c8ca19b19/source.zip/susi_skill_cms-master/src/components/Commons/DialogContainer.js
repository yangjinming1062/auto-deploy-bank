import styled from 'styled-components';

const DialogContainer = styled.div`
  padding: 1rem 1.5rem;
`;

export default DialogContainer;
