let colors = {
  header: '#4285f4',
  fabButton: '#4285f4',
  warningColor: '#f44336',
  primary: '#4285f4',
};

export default colors;
