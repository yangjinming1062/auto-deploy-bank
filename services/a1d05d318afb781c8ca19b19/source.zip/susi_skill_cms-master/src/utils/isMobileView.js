export default (value = 430) => {
  return window.innerWidth < value;
};
