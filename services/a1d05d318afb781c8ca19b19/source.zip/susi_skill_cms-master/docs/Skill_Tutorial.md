Please check here: https://github.com/fossasia/susi.ai/blob/master/docs/Skill_Tutorial.md
