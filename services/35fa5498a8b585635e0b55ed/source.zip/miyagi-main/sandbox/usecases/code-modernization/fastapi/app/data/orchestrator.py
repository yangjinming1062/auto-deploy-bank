from enum import Enum


class Orchestrator(Enum):
    LANGCHAIN = 'langchain'
    PROMPTFLOW = 'promptflow'
