from dotenv import load_dotenv
import os
import streamlit as st
from langchain_openai import AzureChatOpenAI, AzureOpenAIEmbeddings

load_dotenv()

