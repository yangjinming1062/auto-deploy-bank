# Partial Implementations of Use cases in notebooks

This folder hosts initial implementations of use cases, which evolve into microservices for the frontend. For full list see [Use cases](https://iappwksp.com/wksp/05-use-cases/)