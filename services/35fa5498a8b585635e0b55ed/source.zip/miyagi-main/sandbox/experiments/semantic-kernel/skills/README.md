# Sample skills
Miyagi use cases pertinent sample skills adopted from [Semantic Kernel's skills](https://github.com/microsoft/semantic-kernel/tree/main/samples/skills) to test sample user flows.