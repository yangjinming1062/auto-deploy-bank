# Use Langchain with Few-Shot Learning
This sub-directory has an example of using Langchain with Few-Shot Learning. It'll incorporate Chat Vector DB and prompt chaining

## How to run
```bash
pip install -r requirements.txt
python main.py
```

## Example run
![img.png](img.png)