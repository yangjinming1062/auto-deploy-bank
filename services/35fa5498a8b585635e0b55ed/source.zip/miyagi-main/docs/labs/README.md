# Miyagi Labs

This section deals with hands on labs to create an Azure Environment to deploy a full "Project Miyagi" environment.

## Sections:

1. [Infrastructure](./01-infrastructure/README.md)