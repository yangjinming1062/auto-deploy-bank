# filename: get_current_date.py
import datetime

# Get the current date
current_date = datetime.date.today()

# Print the current date
print(f"Today's date is: {current_date}")