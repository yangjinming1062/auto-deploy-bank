﻿namespace Models;

internal static class ServiceTypes
{
    internal const string OpenAI = "OPENAI";
    internal const string AzureOpenAI = "AZUREOPENAI";
}
