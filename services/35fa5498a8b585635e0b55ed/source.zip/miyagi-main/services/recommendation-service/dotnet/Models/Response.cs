namespace GBB.Miyagi.RecommendationService.Models;

public class Response
{
    public DateTime Date { get; set; }

    public int InteractionNum { get; set; }

    public string? Summary { get; set; }
}