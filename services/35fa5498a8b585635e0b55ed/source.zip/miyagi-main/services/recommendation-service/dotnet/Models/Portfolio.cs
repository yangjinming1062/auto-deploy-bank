﻿namespace GBB.Miyagi.RecommendationService.Models;

public class Portfolio
{
    public string? Name { get; set; }
    public double? Allocation { get; set; }
}