﻿namespace GBB.Miyagi.RecommendationService.Models;

public class AssetRecommendation
{
    public string Name { get; set; }
    public string GptRecommendation { get; set; }
}