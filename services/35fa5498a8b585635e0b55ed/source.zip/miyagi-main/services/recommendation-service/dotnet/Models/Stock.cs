﻿namespace GBB.Miyagi.RecommendationService.Models;

public class Stock
{
    public string? Symbol { get; set; }
    public double? Allocation { get; set; }
}