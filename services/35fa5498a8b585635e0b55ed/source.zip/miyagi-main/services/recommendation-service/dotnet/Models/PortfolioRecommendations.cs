﻿namespace GBB.Miyagi.RecommendationService.Models;

public class PortfolioRecommendations
{
    public List<AssetRecommendation> Portfolio { get; set; }
}