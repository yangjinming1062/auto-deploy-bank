﻿namespace GBB.Miyagi.RecommendationService.config;

internal static class EndpointTypes
{
    internal const string TextCompletion = "text-completion";
    internal const string ChatCompletion = "chat-completion";
}