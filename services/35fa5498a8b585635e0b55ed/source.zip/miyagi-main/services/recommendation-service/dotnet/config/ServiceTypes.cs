﻿namespace GBB.Miyagi.RecommendationService.config;

internal static class ServiceTypes
{
    internal const string OpenAI = "OPENAI";
    internal const string AzureOpenAI = "AZUREOPENAI";
}