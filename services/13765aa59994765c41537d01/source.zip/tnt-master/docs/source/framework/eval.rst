Evaluate
=======================

Evaluate Entry Point
~~~~~~~~~~~~~~~~~~~~~~

.. autofunction:: torchtnt.framework.evaluate.evaluate
