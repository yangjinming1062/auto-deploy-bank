State
=========

.. autoclass:: torchtnt.framework.state.State
   :members:
   :undoc-members:

PhaseState
~~~~~~~~~~~~~~~~~
.. autoclass:: torchtnt.framework.state.PhaseState
   :members:
   :undoc-members:
