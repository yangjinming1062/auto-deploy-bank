AutoUnit
===========

.. autoclass:: torchtnt.framework.auto_unit.AutoUnit
   :members:
   :undoc-members:

.. autoclass:: torchtnt.framework.auto_unit.AutoPredictUnit
   :members:
   :undoc-members:
