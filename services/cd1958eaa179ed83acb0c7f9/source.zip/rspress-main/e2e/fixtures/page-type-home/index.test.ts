import { expect, test } from '@playwright/test';
import { getPort, killProcess, runDevCommand } from '../../utils/runCommands';

const appDir = __dirname;

test.describe('home pageType', async () => {
  let appPort: number;
  let app: unknown;
  test.beforeAll(async () => {
    appPort = await getPort();
    app = await runDevCommand(appDir, appPort);
  });

  test.afterAll(async () => {
    if (app) {
      await killProcess(app);
    }
  });

  test('Hero', async ({ page }) => {
    await page.goto(`http://localhost:${appPort}/base/`, {
      waitUntil: 'networkidle',
    });
    await expect(page.locator('.rp-home-hero__title-brand')).toHaveText(
      'E2E case title',
    );
    await expect(page.locator('.rp-home-hero__subtitle')).toHaveText(
      'E2E case subTitle',
    );
    await expect(page.locator('.rp-home-hero__tagline')).toHaveText(
      'E2E case tagline',
    );

    const img = page.locator('.rp-home-hero__image img').first();
    await expect(img.getAttribute('src')).resolves.toBe('/base/brand.png');
    await expect(img.getAttribute('alt')).resolves.toBe('E2E case brand image');
    await expect(img.getAttribute('srcset')).resolves.toBe(
      '/brand.png, /brand@2x.png 2x',
    );
    await expect(img.getAttribute('sizes')).resolves.toBe(
      '((min-width: 50em) and (max-width: 60em)) 50em, (max-width: 30em) 20em',
    );

    const actions = page.locator('.rp-home-hero__actions a');
    await expect(actions).toHaveCount(3);
    await expect(actions.nth(0)).toHaveText('Action 1');
    await expect(actions.nth(1)).toHaveText('Action 2');
    await expect(actions.nth(2)).toHaveText('External');
    // click the first action
    const url1 = page.url();
    await actions.nth(0).click();
    await page.waitForSelector('.rspress-doc');
    expect(page.url()).toBe(`${url1}guide/action-1.html`);
  });

  test('Hero - zh', async ({ page }) => {
    await page.goto(`http://localhost:${appPort}/base/zh/`, {
      waitUntil: 'networkidle',
    });
    await expect(page.locator('.rp-home-hero__title-brand')).toHaveText(
      'E2E 用例 title',
    );
    await expect(page.locator('.rp-home-hero__subtitle')).toHaveText(
      'E2E 用例 subTitle',
    );
    await expect(page.locator('.rp-home-hero__tagline')).toHaveText(
      'E2E 用例 tagline',
    );

    const img = page.locator('.rp-home-hero__image img').first();
    await expect(img.getAttribute('src')).resolves.toBe('/base/brand.png');
    await expect(img.getAttribute('alt')).resolves.toBe('E2E 用例 brand image');
    await expect(img.getAttribute('srcset')).resolves.toBe(
      '/brand.png, /brand@2x.png 2x',
    );
    await expect(img.getAttribute('sizes')).resolves.toBe(
      '((min-width: 50em) and (max-width: 60em)) 50em, (max-width: 30em) 20em',
    );

    const actions = page.locator('.rp-home-hero__actions a');
    await expect(actions).toHaveCount(3);
    await expect(actions.nth(0)).toHaveText('操作 1');
    await expect(actions.nth(1)).toHaveText('操作 2');
    await expect(actions.nth(2)).toHaveText('External');
    // click the first action
    const url1 = page.url();
    await actions.nth(0).click();
    await page.waitForSelector('.rspress-doc');
    expect(page.url()).toBe(`${url1}guide/action-1.html`);
  });

  test('Features', async ({ page }) => {
    await page.goto(`http://localhost:${appPort}/base/`, {
      waitUntil: 'networkidle',
    });
    const features = page.locator('.rp-home-feature__card');
    await expect(features).toHaveCount(2);

    const url1 = page.url();
    await features.nth(0).click();
    expect(page.url()).toBe(url1);

    await features.nth(1).click();
    expect(page.url()).toBe('https://example.com/');
  });
});
