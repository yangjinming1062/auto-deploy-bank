---
context: 'context-index-md-convention'
---

# Index md convention
