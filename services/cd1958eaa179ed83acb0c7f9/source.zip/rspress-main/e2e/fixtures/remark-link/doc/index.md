[This is a dead link](./not-exist)

[This is a virtual link](/virtual)

[This is ignored](/ignored)
