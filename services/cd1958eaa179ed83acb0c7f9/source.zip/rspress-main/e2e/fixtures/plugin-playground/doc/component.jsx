export default function HelloWorld() {
  return <div>Hello World External</div>;
}
