---
link-rss: blog
---

Nothing but should have rss `<link>`
