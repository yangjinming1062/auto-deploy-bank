---
date: 2024-01-02 08:00:00
id: foo
summary: |
  This is summary
  Second line of summary
---

# Foo

This is content
