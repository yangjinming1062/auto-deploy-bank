---
title: Bar but Frontmatter
date: 2024-01-01 08:00:00
category: development
slug: bar
author:
  name: Lamperouge
  email: lelouch@royal.br
---

# Bar but Markdown

This is content
