import { defineConfig } from '@rspress/core';

export default defineConfig({});
