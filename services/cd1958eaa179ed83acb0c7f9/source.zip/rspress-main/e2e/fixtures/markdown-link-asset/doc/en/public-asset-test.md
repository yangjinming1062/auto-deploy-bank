# Public asset test

[svg in public folder](/arrow-down.svg)

[txt in public folder](/plain.txt)

[html in public folder](/hello.html)

[md in public folder](/test.md)

[interface.DataProcessorDefinition](/Interface.DataProcessorDefinition.md)

[interface.DataProcessorDefinition](./Interface.DataProcessorDefinition.md)
