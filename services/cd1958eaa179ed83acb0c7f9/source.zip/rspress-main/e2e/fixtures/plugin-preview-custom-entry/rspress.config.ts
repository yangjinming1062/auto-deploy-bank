import path from 'node:path';
import { pluginVue } from '@rsbuild/plugin-vue';
import { defineConfig } from '@rspress/core';
import { pluginPreview } from '@rspress/plugin-preview';
import { getPort } from '../../utils/runCommands';

export default defineConfig(async () => {
  const port = await getPort();
  return {
    root: path.join(__dirname, 'doc'),
    plugins: [
      pluginPreview({
        iframeOptions: {
          // Provide a different port for the test to avoid port conflicts and crashes.
          devPort: port,
          customEntry: ({ demoPath }) => {
            if (demoPath.endsWith('.vue')) {
              return `
import { createApp } from 'vue';
import App from ${JSON.stringify(demoPath)};
createApp(App).mount('#root');
`;
            }
            return `
import { createRoot } from 'react-dom/client';
import Demo from ${JSON.stringify(demoPath)};
const container = document.getElementById('root');
createRoot(container).render(<Demo />);
`;
          },
          builderConfig: {
            plugins: [pluginVue()],
          },
        },
        previewLanguages: ['jsx', 'tsx', 'vue'],
      }),
    ],
  };
});
