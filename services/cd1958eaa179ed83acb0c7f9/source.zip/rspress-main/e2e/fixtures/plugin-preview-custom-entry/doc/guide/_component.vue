<template>
  <div class="example">Hello World VUE</div>
</template>

<style scoped>
.example {
  color: green;
}
</style>
