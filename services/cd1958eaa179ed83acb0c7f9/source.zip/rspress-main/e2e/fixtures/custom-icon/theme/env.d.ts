declare module '*.svg' { 
  const icon: string;
  export default icon;
}