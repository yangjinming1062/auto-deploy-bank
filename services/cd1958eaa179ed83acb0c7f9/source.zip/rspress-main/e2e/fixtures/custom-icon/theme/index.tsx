import IconSearch from './assets/search.svg';

export { IconSearch };
export * from '@rspress/core/theme-original';
