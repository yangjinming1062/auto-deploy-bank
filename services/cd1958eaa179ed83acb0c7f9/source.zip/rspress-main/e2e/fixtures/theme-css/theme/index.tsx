import './index.css';

export * from '@rspress/core/theme-original';
