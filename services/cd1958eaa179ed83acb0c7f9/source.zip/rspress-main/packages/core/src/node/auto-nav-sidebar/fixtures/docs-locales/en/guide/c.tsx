export default () => {
  return <div>Page c</div>;
};
