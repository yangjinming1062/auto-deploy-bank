<picture>
  <img alt="Rspress Banner" src="https://assets.rspack.rs/rspress/rspress-banner.png">
</picture>

# @rspress/core

A fast Rsbuild-based static site generator.

## Documentation

See [Documentation](https://rspress.rs/).

## Contributing

Please read the [Contributing Guide](https://github.com/web-infra-dev/rspress/blob/main/CONTRIBUTING.md).

## License

Rspress is [MIT licensed](https://github.com/web-infra-dev/rspress/blob/main/LICENSE).
