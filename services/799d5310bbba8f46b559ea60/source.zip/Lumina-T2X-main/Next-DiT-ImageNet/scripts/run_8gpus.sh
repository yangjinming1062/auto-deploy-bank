#!/bin/bash

# run Next-DiT with single node

# run Next-DiT 600M
bash exps/600M_bs256_lr5e-4_bf16_qknorm_lognorm.sh
