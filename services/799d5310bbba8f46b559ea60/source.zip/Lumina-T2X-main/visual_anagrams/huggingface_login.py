from huggingface_hub import login
login()