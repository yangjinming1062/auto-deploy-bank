from .model import DiT_Llama_5B_patch2
