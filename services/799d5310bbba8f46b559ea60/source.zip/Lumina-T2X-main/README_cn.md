<p align="center">
 <img src="./assets/lumina-logo.png" width="40%"/>
 <br>
</p>

# $\textbf{Lumina-T2X}$ : Transform text to any modality with Flow-based Large Diffusion Transformer
