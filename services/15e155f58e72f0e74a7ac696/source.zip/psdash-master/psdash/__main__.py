from psdash.run import main

main()
