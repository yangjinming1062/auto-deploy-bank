#!/bin/bash

./c8run stop "$@"
