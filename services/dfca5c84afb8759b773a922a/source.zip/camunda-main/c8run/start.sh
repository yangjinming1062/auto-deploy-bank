#!/bin/bash

./c8run start $@
