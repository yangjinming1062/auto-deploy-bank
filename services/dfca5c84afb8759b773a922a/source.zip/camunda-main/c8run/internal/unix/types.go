package unix

type UnixC8Run struct{}
