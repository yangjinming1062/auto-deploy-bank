package windows

type WindowsC8Run struct{}
