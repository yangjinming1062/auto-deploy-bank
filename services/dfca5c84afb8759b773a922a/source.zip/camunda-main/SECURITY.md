# Reporting Security Issues

Camunda takes security issues in our software products seriously.

If you believe that you have found a security issue or vulnerability, please follow the procedure documented in our [Security page](https://camunda.com/security/).

__Please do not report security issues or vulnerabilities through public GitHub issues.__
