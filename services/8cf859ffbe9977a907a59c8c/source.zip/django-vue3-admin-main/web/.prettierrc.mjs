export { default } from '@vben/prettier-config';
