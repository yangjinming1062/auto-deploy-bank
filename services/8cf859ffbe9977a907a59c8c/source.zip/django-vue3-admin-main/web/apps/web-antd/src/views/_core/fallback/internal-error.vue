<script lang="ts" setup>
import { Fallback } from '@vben/common-ui';

defineOptions({ name: 'Fallback500Demo' });
</script>

<template>
  <Fallback status="500" />
</template>
