export const ACTION_ICON = {
  DOWNLOAD: 'lucide:download',
  UPLOAD: 'lucide:upload',
  ADD: 'lucide:plus',
  EDIT: 'lucide:edit',
  DELETE: 'lucide:trash-2',
  REFRESH: 'lucide:refresh-cw',
  SEARCH: 'lucide:search',
  FILTER: 'lucide:filter',
  MORE: 'lucide:ellipsis-vertical',
  VIEW: 'lucide:eye',
  COPY: 'lucide:copy',
};
