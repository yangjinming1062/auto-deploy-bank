export enum DICT_TYPE {
  USER_TYPE = 'user_type',

  // TEMU_ORDER_STATUS = 'temu_order_status',
}
