export default defineEventHandler(() => 'Test get handler');
