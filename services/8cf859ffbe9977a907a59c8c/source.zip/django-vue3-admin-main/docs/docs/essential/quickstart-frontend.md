---
sidebar_position: 3
---
# 快速启动-前端

以 web-antd 为例：

```bash
cd web
pnpm install
npm run dev:antd
```

其他前端（web-ele、web-naive）暂时未兼容, 未来支持web-ele 