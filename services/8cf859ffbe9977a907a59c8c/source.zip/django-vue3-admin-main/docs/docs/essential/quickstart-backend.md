---
sidebar_position: 4
---
# 快速启动（后端）

```bash
cd backend
pip install -r requirements.txt
# 如有需要代理： pip install -r requirements.txt -i https://mirrors.aliyun.com/pypi/simple
#python manage.py migrate
python manage.py runserver
```

访问 http://127.0.0.1:8000/ 进入后端管理。 