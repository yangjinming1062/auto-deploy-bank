---
sidebar_position: 2
---
# 功能列表

- 用户与权限管理
- 菜单与角色管理
- 部门管理
- 数据字典
- 日志审计
- 多端前端支持（Antd、Element、Naive）
- Docker 一键部署
- API 接口自动生成
- 多环境配置
- 任务调度（Celery）
- 代码生成器 