---
sidebar_position: 1
---
# 介绍

django-vue3-admin 是一个基于 Django 后端与 Vue3 前端的全栈管理系统解决方案，集成了权限管理、菜单管理、用户管理等常用功能，支持多种前端框架，适合中后台管理系统开发。 