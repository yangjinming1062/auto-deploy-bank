package com.clean.example.core.usecase.broadbandaccessdevice.getdetails;

public class DeviceNotFoundException extends RuntimeException {
}
