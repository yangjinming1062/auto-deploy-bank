package com.clean.example.core.usecase.broadbandaccessdevice.reconcile;

import java.util.List;

public interface GetAllDeviceHostnames {

    List<String> getAllDeviceHostnames();

}
