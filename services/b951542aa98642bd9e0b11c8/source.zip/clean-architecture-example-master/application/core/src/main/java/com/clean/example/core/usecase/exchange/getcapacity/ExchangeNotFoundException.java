package com.clean.example.core.usecase.exchange.getcapacity;

public class ExchangeNotFoundException extends RuntimeException {
}
