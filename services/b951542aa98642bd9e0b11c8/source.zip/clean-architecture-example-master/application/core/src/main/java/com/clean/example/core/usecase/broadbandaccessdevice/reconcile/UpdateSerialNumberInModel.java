package com.clean.example.core.usecase.broadbandaccessdevice.reconcile;

public interface UpdateSerialNumberInModel {

    void updateSerialNumber(String hostname, String serialNumber);

}
