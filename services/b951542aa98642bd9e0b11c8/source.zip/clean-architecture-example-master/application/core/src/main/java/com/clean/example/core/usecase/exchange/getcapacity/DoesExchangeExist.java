package com.clean.example.core.usecase.exchange.getcapacity;

public interface DoesExchangeExist {

    boolean doesExchangeExist(String exchange);

}
