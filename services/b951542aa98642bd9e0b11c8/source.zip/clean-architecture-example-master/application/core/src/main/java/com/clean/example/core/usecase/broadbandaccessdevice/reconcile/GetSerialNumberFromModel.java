package com.clean.example.core.usecase.broadbandaccessdevice.reconcile;

public interface GetSerialNumberFromModel {

    String getSerialNumber(String hostname);

}
