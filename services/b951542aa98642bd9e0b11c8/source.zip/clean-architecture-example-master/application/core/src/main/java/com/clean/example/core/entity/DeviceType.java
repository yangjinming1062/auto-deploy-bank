package com.clean.example.core.entity;

public enum DeviceType {

    ADSL,
    FIBRE;

}
