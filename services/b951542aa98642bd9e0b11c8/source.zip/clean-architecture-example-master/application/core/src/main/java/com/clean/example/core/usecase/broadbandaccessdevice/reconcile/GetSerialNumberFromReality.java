package com.clean.example.core.usecase.broadbandaccessdevice.reconcile;

public interface GetSerialNumberFromReality {

    String getSerialNumber(String hostname);

}
