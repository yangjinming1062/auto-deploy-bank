package com.clean.example.core.usecase.job;

@FunctionalInterface
public interface OnSuccess {

    void auditSuccess();

}
