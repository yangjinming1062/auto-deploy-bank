package com.clean.example.dataproviders.network.deviceclient;

public interface DeviceClient {

    String getSerialNumber(String hostname);

}
