package com.clean.example.dataproviders.network.deviceclient;

public class DeviceConnectionTimeoutException extends RuntimeException {
}
