package zemberek.phrase;

import zemberek.morphology.lexicon.DictionaryItem;

public class MultiWordToken {
  DictionaryItem item;


}
