package zemberek.phrase;

import java.util.List;
import zemberek.core.turkish.PrimaryPos;
import zemberek.morphology.lexicon.DictionaryItem;

public class MultiWordExpression {
  String id;
  PrimaryPos pos;
  List<DictionaryItem> items;



}
