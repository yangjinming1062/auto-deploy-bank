package zemberek.io;

public class AnalysisResult {


}
