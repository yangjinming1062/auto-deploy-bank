package zemberek.morphology.morphotactics;

enum Operator {
  AND,
  OR
}
