package zemberek.morphology.analysis;

public interface AnalysisFormatter {

  String format(SingleAnalysis analysis);

}
