Used only for generating a full distribution jar.


