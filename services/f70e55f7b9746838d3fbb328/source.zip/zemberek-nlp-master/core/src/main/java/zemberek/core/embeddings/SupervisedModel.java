package zemberek.core.embeddings;

public class SupervisedModel extends Model {

  SupervisedModel(Model model, int seed) {
    super(model, seed);
  }
}
