package zemberek.core.quantization;

public enum QuantizerType {
  LINEAR, KMEANS, BINNING, BINNING_WEIGHTED
}
