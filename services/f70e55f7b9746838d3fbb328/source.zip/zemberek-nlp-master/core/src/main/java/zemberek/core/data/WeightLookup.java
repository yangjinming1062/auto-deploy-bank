package zemberek.core.data;

public interface WeightLookup {

  float get(String key);

  int size();

}
