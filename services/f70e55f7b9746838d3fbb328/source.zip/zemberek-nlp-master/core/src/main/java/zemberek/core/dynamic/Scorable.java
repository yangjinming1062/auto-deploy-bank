package zemberek.core.dynamic;

public interface Scorable {

  float getScore();
}

