package zemberek.core.enums;

public interface StringEnum {

  String getStringForm();
}
