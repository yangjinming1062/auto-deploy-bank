package zemberek.core.embeddings;

public class WordVectorsModel {

  Matrix matrix;
  Dictionary dictionary;

}
