package zemberek.core;

public class IntPair {

  public final int first;
  public final int second;

  public IntPair(int first, int second) {
    this.first = first;
    this.second = second;
  }
}
