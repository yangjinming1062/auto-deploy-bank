Zemberek Core Library
============

Contains specialized data structures and helper classes.


