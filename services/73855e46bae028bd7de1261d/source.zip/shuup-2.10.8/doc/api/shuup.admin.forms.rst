shuup\.admin\.forms package
===========================

Submodules
----------

shuup\.admin\.forms\.fields module
----------------------------------

.. automodule:: shuup.admin.forms.fields
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.admin\.forms\.quick\_select module
-----------------------------------------

.. automodule:: shuup.admin.forms.quick_select
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.admin\.forms\.widgets module
-----------------------------------

.. automodule:: shuup.admin.forms.widgets
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.admin.forms
    :members:
    :undoc-members:
    :show-inheritance:
