shuup\.admin\.modules\.contacts package
=======================================

Subpackages
-----------

.. toctree::

    shuup.admin.modules.contacts.views

Submodules
----------

shuup\.admin\.modules\.contacts\.form\_parts module
---------------------------------------------------

.. automodule:: shuup.admin.modules.contacts.form_parts
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.admin\.modules\.contacts\.forms module
---------------------------------------------

.. automodule:: shuup.admin.modules.contacts.forms
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.admin\.modules\.contacts\.mass\_actions module
-----------------------------------------------------

.. automodule:: shuup.admin.modules.contacts.mass_actions
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.admin\.modules\.contacts\.sections module
------------------------------------------------

.. automodule:: shuup.admin.modules.contacts.sections
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.admin\.modules\.contacts\.utils module
---------------------------------------------

.. automodule:: shuup.admin.modules.contacts.utils
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.admin.modules.contacts
    :members:
    :undoc-members:
    :show-inheritance:
