shuup\.guide package
====================

Submodules
----------

shuup\.guide\.admin\_module module
----------------------------------

.. automodule:: shuup.guide.admin_module
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.guide\.apps module
-------------------------

.. automodule:: shuup.guide.apps
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.guide\.settings module
-----------------------------

.. automodule:: shuup.guide.settings
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.guide
    :members:
    :undoc-members:
    :show-inheritance:
