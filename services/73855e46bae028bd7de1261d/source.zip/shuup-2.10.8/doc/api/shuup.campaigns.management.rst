shuup\.campaigns\.management package
====================================

Subpackages
-----------

.. toctree::

    shuup.campaigns.management.commands

Module contents
---------------

.. automodule:: shuup.campaigns.management
    :members:
    :undoc-members:
    :show-inheritance:
