shuup\.testing\.modules\.content package
========================================

Submodules
----------

shuup\.testing\.modules\.content\.data module
---------------------------------------------

.. automodule:: shuup.testing.modules.content.data
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.testing\.modules\.content\.forms module
----------------------------------------------

.. automodule:: shuup.testing.modules.content.forms
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.testing\.modules\.content\.views module
----------------------------------------------

.. automodule:: shuup.testing.modules.content.views
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.testing.modules.content
    :members:
    :undoc-members:
    :show-inheritance:
