shuup\.front\.apps\.simple\_search package
==========================================

Submodules
----------

shuup\.front\.apps\.simple\_search\.forms module
------------------------------------------------

.. automodule:: shuup.front.apps.simple_search.forms
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.front\.apps\.simple\_search\.settings module
---------------------------------------------------

.. automodule:: shuup.front.apps.simple_search.settings
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.front\.apps\.simple\_search\.template\_helpers module
------------------------------------------------------------

.. automodule:: shuup.front.apps.simple_search.template_helpers
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.front\.apps\.simple\_search\.urls module
-----------------------------------------------

.. automodule:: shuup.front.apps.simple_search.urls
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.front\.apps\.simple\_search\.views module
------------------------------------------------

.. automodule:: shuup.front.apps.simple_search.views
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.front.apps.simple_search
    :members:
    :undoc-members:
    :show-inheritance:
