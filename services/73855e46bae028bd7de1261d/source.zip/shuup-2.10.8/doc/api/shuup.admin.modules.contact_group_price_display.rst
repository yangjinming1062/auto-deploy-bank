shuup\.admin\.modules\.contact\_group\_price\_display package
=============================================================

Subpackages
-----------

.. toctree::

    shuup.admin.modules.contact_group_price_display.views

Module contents
---------------

.. automodule:: shuup.admin.modules.contact_group_price_display
    :members:
    :undoc-members:
    :show-inheritance:
