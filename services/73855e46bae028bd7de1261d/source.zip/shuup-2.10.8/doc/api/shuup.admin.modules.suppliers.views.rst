shuup\.admin\.modules\.suppliers\.views package
===============================================

Submodules
----------

shuup\.admin\.modules\.suppliers\.views\.delete module
------------------------------------------------------

.. automodule:: shuup.admin.modules.suppliers.views.delete
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.admin\.modules\.suppliers\.views\.edit module
----------------------------------------------------

.. automodule:: shuup.admin.modules.suppliers.views.edit
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.admin\.modules\.suppliers\.views\.list module
----------------------------------------------------

.. automodule:: shuup.admin.modules.suppliers.views.list
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.admin.modules.suppliers.views
    :members:
    :undoc-members:
    :show-inheritance:
