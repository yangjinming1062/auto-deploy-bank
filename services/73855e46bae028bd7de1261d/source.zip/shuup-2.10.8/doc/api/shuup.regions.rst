shuup\.regions package
======================

Submodules
----------

shuup\.regions\.apps module
---------------------------

.. automodule:: shuup.regions.apps
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.regions\.resources module
--------------------------------

.. automodule:: shuup.regions.resources
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.regions
    :members:
    :undoc-members:
    :show-inheritance:
