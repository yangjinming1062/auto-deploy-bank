shuup\.front\.apps\.carousel\.admin\_module package
===================================================

Subpackages
-----------

.. toctree::

    shuup.front.apps.carousel.admin_module.views

Submodules
----------

shuup\.front\.apps\.carousel\.admin\_module\.forms module
---------------------------------------------------------

.. automodule:: shuup.front.apps.carousel.admin_module.forms
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.front.apps.carousel.admin_module
    :members:
    :undoc-members:
    :show-inheritance:
