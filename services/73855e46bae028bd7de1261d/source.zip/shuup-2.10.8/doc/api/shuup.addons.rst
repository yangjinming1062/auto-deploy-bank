shuup\.addons package
=====================

Subpackages
-----------

.. toctree::

    shuup.addons.admin_module

Submodules
----------

shuup\.addons\.installer module
-------------------------------

.. automodule:: shuup.addons.installer
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.addons\.manager module
-----------------------------

.. automodule:: shuup.addons.manager
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.addons\.reloader module
------------------------------

.. automodule:: shuup.addons.reloader
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.addons
    :members:
    :undoc-members:
    :show-inheritance:
