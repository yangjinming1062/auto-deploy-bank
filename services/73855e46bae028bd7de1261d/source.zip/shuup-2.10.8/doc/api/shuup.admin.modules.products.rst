shuup\.admin\.modules\.products package
=======================================

Subpackages
-----------

.. toctree::

    shuup.admin.modules.products.forms
    shuup.admin.modules.products.views

Submodules
----------

shuup\.admin\.modules\.products\.mass\_actions module
-----------------------------------------------------

.. automodule:: shuup.admin.modules.products.mass_actions
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.admin\.modules\.products\.sections module
------------------------------------------------

.. automodule:: shuup.admin.modules.products.sections
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.admin\.modules\.products\.signal\_handlers module
--------------------------------------------------------

.. automodule:: shuup.admin.modules.products.signal_handlers
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.admin\.modules\.products\.utils module
---------------------------------------------

.. automodule:: shuup.admin.modules.products.utils
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.admin.modules.products
    :members:
    :undoc-members:
    :show-inheritance:
