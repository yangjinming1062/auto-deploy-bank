shuup\.admin\.modules\.service\_providers\.views package
========================================================

Module contents
---------------

.. automodule:: shuup.admin.modules.service_providers.views
    :members:
    :undoc-members:
    :show-inheritance:
