shuup\.xtheme\.admin\_module package
====================================

Subpackages
-----------

.. toctree::

    shuup.xtheme.admin_module.views

Submodules
----------

shuup\.xtheme\.admin\_module\.utils module
------------------------------------------

.. automodule:: shuup.xtheme.admin_module.utils
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.xtheme\.admin\_module\.widgets module
--------------------------------------------

.. automodule:: shuup.xtheme.admin_module.widgets
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.xtheme.admin_module
    :members:
    :undoc-members:
    :show-inheritance:
