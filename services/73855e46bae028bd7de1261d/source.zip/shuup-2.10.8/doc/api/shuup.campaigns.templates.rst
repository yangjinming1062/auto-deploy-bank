shuup\.campaigns\.templates package
===================================

Module contents
---------------

.. automodule:: shuup.campaigns.templates
    :members:
    :undoc-members:
    :show-inheritance:
