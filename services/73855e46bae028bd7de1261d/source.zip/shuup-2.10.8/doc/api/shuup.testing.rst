shuup\.testing package
======================

Subpackages
-----------

.. toctree::

    shuup.testing.management
    shuup.testing.models
    shuup.testing.modules
    shuup.testing.supplier_pricing
    shuup.testing.themes

Submodules
----------

shuup\.testing\.admin\_main\_menu\_updater module
-------------------------------------------------

.. automodule:: shuup.testing.admin_main_menu_updater
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.testing\.basket\_middleware module
-----------------------------------------

.. automodule:: shuup.testing.basket_middleware
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.testing\.browser\_utils module
-------------------------------------

.. automodule:: shuup.testing.browser_utils
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.testing\.checkout\_with\_login\_and\_register\_urls module
-----------------------------------------------------------------

.. automodule:: shuup.testing.checkout_with_login_and_register_urls
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.testing\.extend\_classes module
--------------------------------------

.. automodule:: shuup.testing.extend_classes
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.testing\.factories module
--------------------------------

.. automodule:: shuup.testing.factories
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.testing\.image\_generator module
---------------------------------------

.. automodule:: shuup.testing.image_generator
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.testing\.importers module
--------------------------------

.. automodule:: shuup.testing.importers
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.testing\.line\_properties\_descriptor module
---------------------------------------------------

.. automodule:: shuup.testing.line_properties_descriptor
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.testing\.mock\_population module
---------------------------------------

.. automodule:: shuup.testing.mock_population
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.testing\.notify\_script\_templates module
------------------------------------------------

.. automodule:: shuup.testing.notify_script_templates
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.testing\.receivers module
--------------------------------

.. automodule:: shuup.testing.receivers
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.testing\.service\_forms module
-------------------------------------

.. automodule:: shuup.testing.service_forms
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.testing\.shop\_provider module
-------------------------------------

.. automodule:: shuup.testing.shop_provider
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.testing\.simple\_checkout\_phase module
----------------------------------------------

.. automodule:: shuup.testing.simple_checkout_phase
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.testing\.single\_page\_checkout\_test\_urls module
---------------------------------------------------------

.. automodule:: shuup.testing.single_page_checkout_test_urls
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.testing\.single\_page\_checkout\_with\_login\_and\_register\_conf module
-------------------------------------------------------------------------------

.. automodule:: shuup.testing.single_page_checkout_with_login_and_register_conf
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.testing\.soup\_utils module
----------------------------------

.. automodule:: shuup.testing.soup_utils
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.testing\.subscription\_option\_provider module
-----------------------------------------------------

.. automodule:: shuup.testing.subscription_option_provider
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.testing\.supplier\_provider module
-----------------------------------------

.. automodule:: shuup.testing.supplier_provider
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.testing\.text\_data module
---------------------------------

.. automodule:: shuup.testing.text_data
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.testing\.utils module
----------------------------

.. automodule:: shuup.testing.utils
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.testing
    :members:
    :undoc-members:
    :show-inheritance:
