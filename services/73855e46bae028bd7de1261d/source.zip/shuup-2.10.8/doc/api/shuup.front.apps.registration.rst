shuup\.front\.apps\.registration package
========================================

Submodules
----------

shuup\.front\.apps\.registration\.forms module
----------------------------------------------

.. automodule:: shuup.front.apps.registration.forms
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.front\.apps\.registration\.notify\_events module
-------------------------------------------------------

.. automodule:: shuup.front.apps.registration.notify_events
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.front\.apps\.registration\.settings module
-------------------------------------------------

.. automodule:: shuup.front.apps.registration.settings
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.front\.apps\.registration\.signals module
------------------------------------------------

.. automodule:: shuup.front.apps.registration.signals
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.front\.apps\.registration\.urls module
---------------------------------------------

.. automodule:: shuup.front.apps.registration.urls
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.front\.apps\.registration\.views module
----------------------------------------------

.. automodule:: shuup.front.apps.registration.views
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.front.apps.registration
    :members:
    :undoc-members:
    :show-inheritance:
