shuup\.campaigns\.models package
================================

Submodules
----------

shuup\.campaigns\.models\.basket\_conditions module
---------------------------------------------------

.. automodule:: shuup.campaigns.models.basket_conditions
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.campaigns\.models\.basket\_effects module
------------------------------------------------

.. automodule:: shuup.campaigns.models.basket_effects
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.campaigns\.models\.basket\_line\_effects module
------------------------------------------------------

.. automodule:: shuup.campaigns.models.basket_line_effects
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.campaigns\.models\.cache module
--------------------------------------

.. automodule:: shuup.campaigns.models.cache
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.campaigns\.models\.campaigns module
------------------------------------------

.. automodule:: shuup.campaigns.models.campaigns
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.campaigns\.models\.catalog\_filters module
-------------------------------------------------

.. automodule:: shuup.campaigns.models.catalog_filters
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.campaigns\.models\.contact\_group\_sales\_ranges module
--------------------------------------------------------------

.. automodule:: shuup.campaigns.models.contact_group_sales_ranges
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.campaigns\.models\.context\_conditions module
----------------------------------------------------

.. automodule:: shuup.campaigns.models.context_conditions
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.campaigns\.models\.matching module
-----------------------------------------

.. automodule:: shuup.campaigns.models.matching
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.campaigns\.models\.product\_effects module
-------------------------------------------------

.. automodule:: shuup.campaigns.models.product_effects
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.campaigns.models
    :members:
    :undoc-members:
    :show-inheritance:
