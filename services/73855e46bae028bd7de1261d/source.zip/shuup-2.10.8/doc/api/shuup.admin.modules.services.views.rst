shuup\.admin\.modules\.services\.views package
==============================================

Module contents
---------------

.. automodule:: shuup.admin.modules.services.views
    :members:
    :undoc-members:
    :show-inheritance:
