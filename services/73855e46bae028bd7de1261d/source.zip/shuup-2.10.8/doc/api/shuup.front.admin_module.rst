shuup\.front\.admin\_module package
===================================

Subpackages
-----------

.. toctree::

    shuup.front.admin_module.carts
    shuup.front.admin_module.checkout
    shuup.front.admin_module.companies
    shuup.front.admin_module.sorts_and_filters
    shuup.front.admin_module.translation

Submodules
----------

shuup\.front\.admin\_module\.forms module
-----------------------------------------

.. automodule:: shuup.front.admin_module.forms
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.front.admin_module
    :members:
    :undoc-members:
    :show-inheritance:
