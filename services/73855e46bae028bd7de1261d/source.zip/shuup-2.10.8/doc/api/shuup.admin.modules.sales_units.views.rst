shuup\.admin\.modules\.sales\_units\.views package
==================================================

Submodules
----------

shuup\.admin\.modules\.sales\_units\.views\.edit module
-------------------------------------------------------

.. automodule:: shuup.admin.modules.sales_units.views.edit
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.admin\.modules\.sales\_units\.views\.list module
-------------------------------------------------------

.. automodule:: shuup.admin.modules.sales_units.views.list
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.admin.modules.sales_units.views
    :members:
    :undoc-members:
    :show-inheritance:
