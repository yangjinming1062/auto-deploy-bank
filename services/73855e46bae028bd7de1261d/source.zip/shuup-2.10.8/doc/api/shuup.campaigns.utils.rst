shuup\.campaigns\.utils package
===============================

Submodules
----------

shuup\.campaigns\.utils\.campaigns module
-----------------------------------------

.. automodule:: shuup.campaigns.utils.campaigns
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.campaigns\.utils\.matcher module
---------------------------------------

.. automodule:: shuup.campaigns.utils.matcher
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.campaigns\.utils\.sales\_range module
--------------------------------------------

.. automodule:: shuup.campaigns.utils.sales_range
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.campaigns\.utils\.time\_range module
-------------------------------------------

.. automodule:: shuup.campaigns.utils.time_range
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.campaigns.utils
    :members:
    :undoc-members:
    :show-inheritance:
