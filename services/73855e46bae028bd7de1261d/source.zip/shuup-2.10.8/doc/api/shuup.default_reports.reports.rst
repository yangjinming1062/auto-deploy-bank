shuup\.default\_reports\.reports package
========================================

Submodules
----------

shuup\.default\_reports\.reports\.customer\_sales module
--------------------------------------------------------

.. automodule:: shuup.default_reports.reports.customer_sales
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.default\_reports\.reports\.new\_customers module
-------------------------------------------------------

.. automodule:: shuup.default_reports.reports.new_customers
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.default\_reports\.reports\.orders module
-----------------------------------------------

.. automodule:: shuup.default_reports.reports.orders
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.default\_reports\.reports\.product\_total\_sales module
--------------------------------------------------------------

.. automodule:: shuup.default_reports.reports.product_total_sales
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.default\_reports\.reports\.refunds module
------------------------------------------------

.. automodule:: shuup.default_reports.reports.refunds
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.default\_reports\.reports\.sales module
----------------------------------------------

.. automodule:: shuup.default_reports.reports.sales
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.default\_reports\.reports\.sales\_per\_hour module
---------------------------------------------------------

.. automodule:: shuup.default_reports.reports.sales_per_hour
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.default\_reports\.reports\.shipping module
-------------------------------------------------

.. automodule:: shuup.default_reports.reports.shipping
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.default\_reports\.reports\.taxes module
----------------------------------------------

.. automodule:: shuup.default_reports.reports.taxes
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.default\_reports\.reports\.total\_sales module
-----------------------------------------------------

.. automodule:: shuup.default_reports.reports.total_sales
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.default_reports.reports
    :members:
    :undoc-members:
    :show-inheritance:
