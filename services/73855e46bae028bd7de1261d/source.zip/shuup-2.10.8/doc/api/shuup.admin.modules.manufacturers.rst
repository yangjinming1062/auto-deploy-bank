shuup\.admin\.modules\.manufacturers package
============================================

Subpackages
-----------

.. toctree::

    shuup.admin.modules.manufacturers.views

Module contents
---------------

.. automodule:: shuup.admin.modules.manufacturers
    :members:
    :undoc-members:
    :show-inheritance:
