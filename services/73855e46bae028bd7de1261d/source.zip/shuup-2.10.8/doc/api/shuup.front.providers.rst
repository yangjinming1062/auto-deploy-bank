shuup\.front\.providers package
===============================

Submodules
----------

shuup\.front\.providers\.form\_def module
-----------------------------------------

.. automodule:: shuup.front.providers.form_def
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.front\.providers\.form\_fields module
--------------------------------------------

.. automodule:: shuup.front.providers.form_fields
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.front.providers
    :members:
    :undoc-members:
    :show-inheritance:
