shuup\.tasks\.admin\_module package
===================================

Subpackages
-----------

.. toctree::

    shuup.tasks.admin_module.views

Module contents
---------------

.. automodule:: shuup.tasks.admin_module
    :members:
    :undoc-members:
    :show-inheritance:
