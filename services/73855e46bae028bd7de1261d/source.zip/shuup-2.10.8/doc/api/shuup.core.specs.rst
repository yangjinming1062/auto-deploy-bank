shuup\.core\.specs package
==========================

Submodules
----------

shuup\.core\.specs\.product\_kind module
----------------------------------------

.. automodule:: shuup.core.specs.product_kind
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.core.specs
    :members:
    :undoc-members:
    :show-inheritance:
