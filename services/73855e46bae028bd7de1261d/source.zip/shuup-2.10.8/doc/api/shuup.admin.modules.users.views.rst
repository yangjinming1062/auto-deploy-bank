shuup\.admin\.modules\.users\.views package
===========================================

Submodules
----------

shuup\.admin\.modules\.users\.views\.detail module
--------------------------------------------------

.. automodule:: shuup.admin.modules.users.views.detail
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.admin\.modules\.users\.views\.list module
------------------------------------------------

.. automodule:: shuup.admin.modules.users.views.list
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.admin\.modules\.users\.views\.password module
----------------------------------------------------

.. automodule:: shuup.admin.modules.users.views.password
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.admin\.modules\.users\.views\.permissions module
-------------------------------------------------------

.. automodule:: shuup.admin.modules.users.views.permissions
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.admin.modules.users.views
    :members:
    :undoc-members:
    :show-inheritance:
