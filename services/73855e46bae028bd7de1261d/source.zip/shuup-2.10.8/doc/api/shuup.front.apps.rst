shuup\.front\.apps package
==========================

Subpackages
-----------

.. toctree::

    shuup.front.apps.auth
    shuup.front.apps.carousel
    shuup.front.apps.customer_information
    shuup.front.apps.personal_order_history
    shuup.front.apps.recently_viewed_products
    shuup.front.apps.registration
    shuup.front.apps.saved_carts
    shuup.front.apps.simple_order_notification
    shuup.front.apps.simple_search

Module contents
---------------

.. automodule:: shuup.front.apps
    :members:
    :undoc-members:
    :show-inheritance:
