shuup\.admin\.dashboard package
===============================

Submodules
----------

shuup\.admin\.dashboard\.blocks module
--------------------------------------

.. automodule:: shuup.admin.dashboard.blocks
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.admin\.dashboard\.charts module
--------------------------------------

.. automodule:: shuup.admin.dashboard.charts
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.admin\.dashboard\.utils module
-------------------------------------

.. automodule:: shuup.admin.dashboard.utils
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.admin.dashboard
    :members:
    :undoc-members:
    :show-inheritance:
