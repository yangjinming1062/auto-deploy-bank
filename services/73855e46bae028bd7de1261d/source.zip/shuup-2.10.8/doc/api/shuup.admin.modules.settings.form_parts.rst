shuup\.admin\.modules\.settings\.form\_parts package
====================================================

Submodules
----------

shuup\.admin\.modules\.settings\.form\_parts\.shop module
---------------------------------------------------------

.. automodule:: shuup.admin.modules.settings.form_parts.shop
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.admin.modules.settings.form_parts
    :members:
    :undoc-members:
    :show-inheritance:
