shuup\.tasks package
====================

Subpackages
-----------

.. toctree::

    shuup.tasks.admin_module

Submodules
----------

shuup\.tasks\.apps module
-------------------------

.. automodule:: shuup.tasks.apps
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.tasks\.models module
---------------------------

.. automodule:: shuup.tasks.models
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.tasks\.utils module
--------------------------

.. automodule:: shuup.tasks.utils
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.tasks
    :members:
    :undoc-members:
    :show-inheritance:
