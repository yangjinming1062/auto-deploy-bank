shuup\.admin\.modules\.system\.views package
============================================

Submodules
----------

shuup\.admin\.modules\.system\.views\.telemetry module
------------------------------------------------------

.. automodule:: shuup.admin.modules.system.views.telemetry
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.admin.modules.system.views
    :members:
    :undoc-members:
    :show-inheritance:
