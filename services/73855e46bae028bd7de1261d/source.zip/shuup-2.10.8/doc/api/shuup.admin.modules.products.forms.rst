shuup\.admin\.modules\.products\.forms package
==============================================

Submodules
----------

shuup\.admin\.modules\.products\.forms\.base\_forms module
----------------------------------------------------------

.. automodule:: shuup.admin.modules.products.forms.base_forms
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.admin\.modules\.products\.forms\.package\_forms module
-------------------------------------------------------------

.. automodule:: shuup.admin.modules.products.forms.package_forms
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.admin\.modules\.products\.forms\.parent\_forms module
------------------------------------------------------------

.. automodule:: shuup.admin.modules.products.forms.parent_forms
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.admin.modules.products.forms
    :members:
    :undoc-members:
    :show-inheritance:
