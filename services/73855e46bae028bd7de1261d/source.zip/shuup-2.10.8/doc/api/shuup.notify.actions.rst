shuup\.notify\.actions package
==============================

Submodules
----------

shuup\.notify\.actions\.debug module
------------------------------------

.. automodule:: shuup.notify.actions.debug
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.notify\.actions\.email module
------------------------------------

.. automodule:: shuup.notify.actions.email
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.notify\.actions\.notification module
-------------------------------------------

.. automodule:: shuup.notify.actions.notification
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.notify\.actions\.order module
------------------------------------

.. automodule:: shuup.notify.actions.order
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.notify.actions
    :members:
    :undoc-members:
    :show-inheritance:
