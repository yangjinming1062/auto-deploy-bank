shuup\.front\.admin\_module\.sorts\_and\_filters package
========================================================

Submodules
----------

shuup\.front\.admin\_module\.sorts\_and\_filters\.form\_parts module
--------------------------------------------------------------------

.. automodule:: shuup.front.admin_module.sorts_and_filters.form_parts
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.front.admin_module.sorts_and_filters
    :members:
    :undoc-members:
    :show-inheritance:
