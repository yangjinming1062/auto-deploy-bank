shuup\.discounts\.admin package
===============================

Subpackages
-----------

.. toctree::

    shuup.discounts.admin.modules
    shuup.discounts.admin.views

Submodules
----------

shuup\.discounts\.admin\.mass\_actions module
---------------------------------------------

.. automodule:: shuup.discounts.admin.mass_actions
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.discounts\.admin\.widgets module
---------------------------------------

.. automodule:: shuup.discounts.admin.widgets
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.discounts.admin
    :members:
    :undoc-members:
    :show-inheritance:
