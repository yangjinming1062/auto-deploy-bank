shuup\.testing\.modules\.demo package
=====================================

Module contents
---------------

.. automodule:: shuup.testing.modules.demo
    :members:
    :undoc-members:
    :show-inheritance:
