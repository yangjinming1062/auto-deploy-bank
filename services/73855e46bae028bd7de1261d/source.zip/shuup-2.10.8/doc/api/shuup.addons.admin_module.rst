shuup\.addons\.admin\_module package
====================================

Subpackages
-----------

.. toctree::

    shuup.addons.admin_module.views

Module contents
---------------

.. automodule:: shuup.addons.admin_module
    :members:
    :undoc-members:
    :show-inheritance:
