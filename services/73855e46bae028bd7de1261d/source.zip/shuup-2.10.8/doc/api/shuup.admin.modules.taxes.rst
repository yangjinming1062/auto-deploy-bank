shuup\.admin\.modules\.taxes package
====================================

Subpackages
-----------

.. toctree::

    shuup.admin.modules.taxes.views

Module contents
---------------

.. automodule:: shuup.admin.modules.taxes
    :members:
    :undoc-members:
    :show-inheritance:
