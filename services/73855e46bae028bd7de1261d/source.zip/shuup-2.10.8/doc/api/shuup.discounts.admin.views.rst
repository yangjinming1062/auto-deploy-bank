shuup\.discounts\.admin\.views package
======================================

Module contents
---------------

.. automodule:: shuup.discounts.admin.views
    :members:
    :undoc-members:
    :show-inheritance:
