shuup\.admin\.modules\.attributes\.views package
================================================

Submodules
----------

shuup\.admin\.modules\.attributes\.views\.edit module
-----------------------------------------------------

.. automodule:: shuup.admin.modules.attributes.views.edit
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.admin\.modules\.attributes\.views\.list module
-----------------------------------------------------

.. automodule:: shuup.admin.modules.attributes.views.list
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.admin.modules.attributes.views
    :members:
    :undoc-members:
    :show-inheritance:
