shuup\.reports package
======================

Subpackages
-----------

.. toctree::

    shuup.reports.admin_module

Submodules
----------

shuup\.reports\.apps module
---------------------------

.. automodule:: shuup.reports.apps
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.reports\.forms module
----------------------------

.. automodule:: shuup.reports.forms
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.reports\.report module
-----------------------------

.. automodule:: shuup.reports.report
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.reports\.settings module
-------------------------------

.. automodule:: shuup.reports.settings
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.reports\.utils module
----------------------------

.. automodule:: shuup.reports.utils
    :members:
    :undoc-members:
    :show-inheritance:

shuup\.reports\.writer module
-----------------------------

.. automodule:: shuup.reports.writer
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: shuup.reports
    :members:
    :undoc-members:
    :show-inheritance:
