// Copyright (c) 2025 Beijing Volcano Engine Technology Co., Ltd.
// SPDX-License-Identifier: Apache-2.0

// don't reorder this file, it's used to initialize the app data dir and
// other which should be run before the main process is ready
// eslint-disable-next-line
import './bootstrap'

import '@main/config'

import { app, shell, BrowserWindow, protocol } from 'electron'
import path, { join } from 'path'
import fs from 'fs'
import { electronApp, optimizer, is } from '@electron-toolkit/utils'

import { registerIpc } from './ipc'
import openInspector from './utils/inspector'
import db from './services/DatabaseService'
import screenshotService from './services/ScreenshotService'
import { isDev, isMac } from './constant'
import icon from '../../resources/icon.png?asset'
import { ensureBackendRunning, startBackendInBackground, stopBackendServerSync } from './backend'
import { powerWatcher } from './background/os/Power'
import { initLog } from '@shared/logger/init'
import { getLogger } from '@shared/logger/main'
import { monitor } from '@shared/logger/performance'
import { TrayService } from './services/TrayService'
import { ScreenMonitorTask } from './background/task/screen-monitor-task'
import { autoUpdater } from 'electron-updater'
import { IpcChannel } from '@shared/IpcChannel'
import { LatestActivityTask } from './background/task/latest-activity'

initLog()
const logger = getLogger('MainEntry')

autoUpdater.logger = logger

const isPackaged = app.isPackaged
const actuallyDev = isDev && !isPackaged // true

const gotLock = app.requestSingleInstanceLock()
if (!gotLock) {
  app.quit()
  process.exit(0)
} else {
  app.on('second-instance', () => {
    const win = BrowserWindow.getAllWindows()[0]
    if (win) {
      if (win.isMinimized()) win.restore()
      win.show()
      win.focus()
    }
  })
}

// Save the original console.log
const originalConsoleLog = console.log

// Screenshot cleanup timer
let cleanupIntervalId: NodeJS.Timeout | null = null

// Tray service instance
let trayService: TrayService | null = null

/**
 * Get tray service instance
 */
export function getTrayService(): TrayService | null {
  return trayService
}

/**
 * Start screenshot cleanup scheduled task
 * Runs once per day, cleaning up screenshots older than 15 days
 */
function startScreenshotCleanup() {
  // Clear existing timer if already running
  if (cleanupIntervalId) {
    clearInterval(cleanupIntervalId)
  }

  // Execute cleanup immediately
  performCleanup()

  // Execute cleanup every 24 hours
  const oneDayInMs = 24 * 60 * 60 * 1000
  cleanupIntervalId = setInterval(() => {
    performCleanup()
  }, oneDayInMs)

  logger.info('Screenshot cleanup task started, will run daily')
}

/**
 * Perform cleanup operation
 */
async function performCleanup() {
  try {
    logger.info('Starting screenshot cleanup...')
    const result = await screenshotService.cleanupOldScreenshots(15) // Keep 15 days
    if (result.success) {
      logger.info(
        `Screenshot cleanup completed. Deleted ${result.deletedCount} directories, freed ${((result.deletedSize || 0) / 1024 / 1024).toFixed(2)} MB`
      )
    } else {
      logger.error(`Screenshot cleanup failed: ${result.error}`)
    }
  } catch (error) {
    logger.error('Screenshot cleanup error:', error)
  }
}

/**
 * Stop screenshot cleanup scheduled task
 */
function stopScreenshotCleanup() {
  if (cleanupIntervalId) {
    clearInterval(cleanupIntervalId)
    cleanupIntervalId = null
    logger.info('Screenshot cleanup task stopped')
  }
}

function createWindow() {
  // Create the browser window.
  const mainWindow = new BrowserWindow({
    width: 1180,
    height: 660,
    show: false,
    autoHideMenuBar: true,
    icon,
    // Use frameless window with custom titlebar only on macOS
    ...(isMac
      ? {
          frame: false,
          titleBarStyle: 'hidden',
          trafficLightPosition: { x: 12, y: 12 }
        }
      : {
          // On Windows/Linux, use default frame with window controls
          frame: true
        }),
    webPreferences: {
      preload: join(__dirname, '../preload/index.js'),
      sandbox: false,
      webSecurity: false
    }
  })

  console.log = (...args) => {
    try {
      if (mainWindow && !mainWindow.isDestroyed()) {
        mainWindow.webContents.send('main-log', ...args)
      } else {
        originalConsoleLog(...args)
      }
    } catch (error) {
      originalConsoleLog(...args)
    }
  }

  mainWindow.on('ready-to-show', () => {
    mainWindow.show()

    if (!actuallyDev) {
      ensureBackendRunning(mainWindow).catch((error) => {
        logger.error('Failed to ensure backend is running:', error)
      })
    }
  })

  // Intercept window close event to hide instead of closing
  mainWindow.on('close', (event) => {
    if (!(app as any).isQuitting) {
      event.preventDefault()
      mainWindow.hide()
      logger.info('Window hidden instead of closed')
    }
  })

  mainWindow.webContents.setWindowOpenHandler((details) => {
    shell.openExternal(details.url)
    return { action: 'deny' }
  })

  // HMR for renderer base on electron-vite cli.
  // Load the remote URL for development or the local html file for production.
  if (is.dev && process.env['ELECTRON_RENDERER_URL']) {
    mainWindow.loadURL(process.env['ELECTRON_RENDERER_URL'])
  } else {
    mainWindow.loadFile(join(__dirname, '../renderer/index.html'))
  }
  return mainWindow
}

// This method will be called when Electron has finished
// initialization and is ready to create browser windows.
// Some APIs can only be used after this event occurs.
let server: any
const task = new ScreenMonitorTask()
const latestActivityTask = new LatestActivityTask()
app.whenReady().then(() => {
  logger.info('app_started', { argv: process.argv, version: app.getVersion() })
  monitor.start(5000)
  protocol.registerBufferProtocol('vikingdb', (request, callback) => {
    try {
      let filePath = request.url.replace('vikingdb://', '')
      filePath = decodeURIComponent(filePath)

      const fullPath = path.resolve(filePath)

      console.log('Reading file:', fullPath)

      if (fs.existsSync(fullPath)) {
        const data = fs.readFileSync(fullPath)
        const extension = path.extname(fullPath).toLowerCase()

        // Set MIME type based on file extension
        let mimeType = 'application/octet-stream'
        if (extension === '.png') mimeType = 'image/png'
        else if (extension === '.jpg' || extension === '.jpeg') mimeType = 'image/jpeg'
        else if (extension === '.gif') mimeType = 'image/gif'
        else if (extension === '.svg') mimeType = 'image/svg+xml'

        callback({
          mimeType: mimeType,
          data: data
        })
      } else {
        callback({ error: -6 })
      }
    } catch (error) {
      console.error('Error reading file:', error)
      callback({ error: -2 })
    }
  })

  // Set app user model id for windows
  electronApp.setAppUserModelId('com.vikingdb.desktop')

  // Default open or close DevTools by F12 in development
  // and ignore CommandOrControl + R in production.
  // see https://github.com/alex8088/electron-toolkit/tree/master/packages/utils

  app.on('browser-window-created', (_, window) => {
    optimizer.watchWindowShortcuts(window)

    // Automatically open DevTools in development environment

    if (isDev) {
      window.webContents.openDevTools()
      console.log('DevTools opened automatically in development mode')
    }
  })

  const mainWindow = createWindow()
  openInspector(mainWindow)
  powerWatcher.run()
  startBackendInBackground(mainWindow)

  // Initialize tray service
  trayService = new TrayService(mainWindow)
  trayService.create()
  logger.info('Tray service initialized')

  // Start screenshot cleanup scheduled task
  startScreenshotCleanup()
  task.init()
  latestActivityTask.init()

  app.on('activate', function () {
    // On macOS it's common to re-create a window in the app when the
    // dock icon is clicked and there are no other windows open.
    if (BrowserWindow.getAllWindows().length === 0) {
      createWindow()
    } else {
      // If window exists but is hidden, show it
      const existingWindow = BrowserWindow.getAllWindows()[0]
      if (existingWindow) {
        existingWindow.show()
        existingWindow.focus()
      }
    }
  })

  registerIpc(mainWindow, app)

  mainWindow.webContents.send(IpcChannel.Notification_Send, {
    id: '123',
    type: 'info',
    message: 'hello',
    timestamp: new Date().getTime(),
    source: 'update'
  })
})

// Quit when all windows are closed, except on macOS. There, it's common
// for applications and their menu bar to stay active until the user quits
// explicitly with Cmd + Q.
app.on('window-all-closed', () => {
  monitor.stop()
  // Don't quit the app when windows are closed - keep running in tray
  // App will only quit when user clicks "Quit" from tray menu
  task.unregister()
  logger.info('All windows closed, app continues running in tray')
})

// In this file you can include the rest of your app's specific main process
// code. You can also put them in separate files and require them here.

// in production mode, handle uncaught exception and unhandled rejection globally
if (!isDev) {
  // handle uncaught exception
  process.on('uncaughtException', (error) => {
    logger.error('Uncaught Exception:', error)
  })

  // handle unhandled rejection
  process.on('unhandledRejection', (reason, promise) => {
    logger.error(`Unhandled Rejection at: ${promise} reason: ${reason}`)
  })
}

app.on('before-quit', () => {
  // Set flag to allow windows to actually close
  ;(app as any).isQuitting = true

  // Restore the original console.log to avoid "Object has been destroyed" errors during exit
  console.log = originalConsoleLog

  // Stop screenshot cleanup scheduled task
  stopScreenshotCleanup()

  // Destroy tray
  if (trayService) {
    trayService.destroy()
    trayService = null
  }

  if (server) {
    server.close()
  }
  stopBackendServerSync()
  db.close()

  logger.info('App is quitting, all resources cleaned up')
})
