// Copyright (c) 2025 Beijing Volcano Engine Technology Co., Ltd.
// SPDX-License-Identifier: Apache-2.0

import { useCallback, useMemo } from 'react'
import { debounce } from 'lodash'
import { Card, Spin } from '@arco-design/web-react'
import { useSearchParams } from 'react-router-dom'
import { useVaults } from '@renderer/hooks/use-vault'
import MarkdownEditor from '@renderer/components/markdown-editor'
import StatusBar from '@renderer/components/status-bar/StatusBar'
import { Allotment } from 'allotment'
import { useAllotment } from '@renderer/hooks/use-allotment'
import AIToggleButton from '@renderer/components/ai-toggle-button'
import AIAssistant from '@renderer/components/ai-assistant'
import { removeMarkdownSymbols } from '@renderer/utils/vault'
import './vault.css'
import { useSelector } from 'react-redux'
import { RootState, useAppDispatch } from '@renderer/store'
import { setActiveConversationId, toggleCreationAiAssistant } from '@renderer/store/chat-history'
import { useUnmount } from 'ahooks'

const VaultPage = () => {
  const [searchParams] = useSearchParams()
  const id = searchParams.get('id')
  const loading = false
  const error = null

  const { findVaultById, saveVaultContent, saveVaultTitle, updateVault } = useVaults()
  const vault = findVaultById(Number(id))
  const content = vault?.content
  const title = vault?.title ? '## ' + vault.title : ''
  const isVisible = useSelector((state: RootState) => state.chatHistory.creation.aiAssistantVisible)
  const { controller, defaultSizes, leftMinSize, rightMinSize } = useAllotment(isVisible)
  const dispatch = useAppDispatch()
  const debouncedSave = useMemo(
    () =>
      debounce((value: string, type: 'content' | 'title' | 'summary' | 'tags') => {
        if (type === 'content') {
          saveVaultContent(Number(id), value)
        } else if (type === 'title') {
          saveVaultTitle(Number(id), removeMarkdownSymbols(value))
        } else {
          updateVault(Number(id), { [type]: value })
        }
      }, 300),
    [saveVaultContent, saveVaultTitle, id, updateVault]
  )

  const onMarkdownChange = useCallback(
    (markdown: string, type: 'content' | 'title') => {
      debouncedSave(markdown, type)
    },
    [debouncedSave]
  )

  const onSummaryChange = useCallback(
    (summary: string) => {
      debouncedSave(summary, 'summary')
    },
    [debouncedSave]
  )

  const onTagsChange = useCallback(
    (tags: string) => {
      debouncedSave(tags, 'tags')
    },
    [debouncedSave]
  )
  const activeConversationId = useSelector((state: RootState) => state.chatHistory.activeConversationId)
  useUnmount(() => {
    dispatch(setActiveConversationId(null))
    dispatch(toggleCreationAiAssistant(false))
  })
  // Status bar component
  return (
    <div className={`flex flex-row h-full allotmentContainer ${!isVisible ? 'allotment-disabled' : ''}`}>
      <Allotment separator={false} ref={controller} defaultSizes={defaultSizes}>
        <Allotment.Pane minSize={leftMinSize}>
          <div style={{ height: '8px', appRegion: 'drag' } as React.CSSProperties} />
          <div className="vault-page-container">
            <Card className="vault-card">
              {loading || !vault ? (
                <div className="flex justify-center items-center h-full text-[#333]">
                  <Spin tip="Loading..." />
                </div>
              ) : error ? (
                <div className="text-red-500">{error}</div>
              ) : (
                <>
                  <div className="vault-title-container">
                    <MarkdownEditor
                      key={`title-${vault?.id}`}
                      defaultValue={title ?? ''}
                      onChange={(markdown) => onMarkdownChange(markdown, 'title')}
                    />
                  </div>
                  <StatusBar vaultData={vault} onSummaryChange={onSummaryChange} onTagsChange={onTagsChange} />
                  <MarkdownEditor
                    key={vault?.id}
                    defaultValue={content ?? ''}
                    onChange={(markdown) => onMarkdownChange(markdown, 'content')}
                  />
                </>
              )}
            </Card>
            <AIToggleButton onClick={() => dispatch(toggleCreationAiAssistant(true))} isActive={isVisible} />
          </div>
        </Allotment.Pane>
        <Allotment.Pane minSize={rightMinSize}>
          <AIAssistant
            visible={isVisible}
            onClose={() => dispatch(toggleCreationAiAssistant(false))}
            pageName="creation"
            initConversationId={activeConversationId}
          />
        </Allotment.Pane>
      </Allotment>
    </div>
  )
}

export default VaultPage
