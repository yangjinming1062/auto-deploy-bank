export enum VaultDocumentType {
  DailyReport = 'DailyReport',
  Vaults = 'vaults'
}
export enum VaultTitle {
  Summary = 'Summary'
}
