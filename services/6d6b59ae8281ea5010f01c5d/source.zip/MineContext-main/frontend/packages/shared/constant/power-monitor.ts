export enum POWER_MONITOR_KEY {
  Suspend = 'suspend',
  Resume = 'resume',
  LockScreen = 'lock-screen',
  UnlockScreen = 'unlock-screen'
}
