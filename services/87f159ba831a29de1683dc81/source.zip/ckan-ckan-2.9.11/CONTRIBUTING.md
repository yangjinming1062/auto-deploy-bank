For contributing CKAN (whether code, bug reports, translations, documentation,
etc.) see our contributing guidelines:

http://docs.ckan.org/en/latest/contributing
