CREATE DATABASE ckan_test OWNER ckan_default ENCODING 'utf-8';
