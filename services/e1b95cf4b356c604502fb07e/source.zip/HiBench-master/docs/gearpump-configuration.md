## Gearpump Properties ##

Please configure these properties in `conf/gearpump.conf`

    cp conf/gearpump.conf.template conf/gearpump.conf

Property      | Meaning
--------------|--------------------------
hibench.streambench.gearpump.home     |           /PATH/TO/YOUR/GEARPUMP/HOME
hibench.streambench.gearpump.parallelism    |     Default parallelism in gearpump
hibench.streambench.gearpump.executors      |     Executor number in gearpump
