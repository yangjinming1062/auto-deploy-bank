`lambda-function-with-lib-0.0.1.jar` was generated using `mvn package` and 
committed to the repo. Generation of the .jar _could_ be added to the build
process, but this seems adequate.
