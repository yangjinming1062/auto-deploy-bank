import settings

constant = settings.SETTING2


def handler(event, context):
    return constant
