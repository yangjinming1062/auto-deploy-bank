`lambda(1|2).zip` was generated using `make` and committed to the repo. 
Generation of the .jar _could_ be added to the buildp rocess, but this seems adequate.
