SETTING1 = 'setting1'
