<!-- Love localstack? Please consider supporting our collective:
👉  https://opencollective.com/localstack/donate -->

# Type of request: This is a ...

[ ] bug report
[ ] feature request

# Detailed description

...

## Expected behavior

...

## Actual behavior

...

# Steps to reproduce

## Command used to start LocalStack

...

## Client code (AWS SDK code snippet, or sequence of "awslocal" commands)

...
