# Translations

Django's strength is in its global community. Similarly, MarkdownX developers come from across the world too. We are therefore commit to make the plugin as inclusive as possible. To this end, we provide translation of all messages produced by MarkdownX to various languages.

## Current languages

- English
- Polish (Polski)
- German (Deutsch)
- French (Français)
- Persian (فارسی)
- Dutch (Nederlands)

---

### Your language is not included?

**Wanna contribute?**
Why not help us with the translation of messages? It's not really that long.

**Even more?**
Help us translate the documentations.
