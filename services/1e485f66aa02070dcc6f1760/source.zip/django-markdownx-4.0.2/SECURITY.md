# Security Policy

## Reporting a Vulnerability

To report a vulnerability please send an e-mail to: zamiany-ring.02@icloud.com
