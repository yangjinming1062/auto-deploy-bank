#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
test_django-json-widget
------------

Tests for `django-json-widget` models module.
"""

from django.test import TestCase


class TestDjangoJsonWidget(TestCase):

    def setUp(self):
        pass

    def test_something(self):
        pass

    def tearDown(self):
        pass
