# -*- coding: utf-8
from django.apps import AppConfig


class DjangoJsonWidgetConfig(AppConfig):
    name = 'django_json_widget'
