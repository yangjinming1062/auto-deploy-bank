import Page from './Page';
import PageHeader from './PageHeader';
import PageContent from './PageContent';

export default Page;

export {
    PageHeader,
    PageContent
}