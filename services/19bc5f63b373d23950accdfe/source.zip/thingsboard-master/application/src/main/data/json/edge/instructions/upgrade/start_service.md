#### Start the Service

```bash
sudo systemctl tb-edge start
{:copy-code}
```
