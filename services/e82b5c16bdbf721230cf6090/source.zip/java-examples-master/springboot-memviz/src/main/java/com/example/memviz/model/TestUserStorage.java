package com.example.memviz.model;

import java.util.ArrayList;
import java.util.List;

/**
 * 存储测试User对象的静态容器
 */
public class TestUserStorage {
    public static final List<User> users = new ArrayList<>();
}