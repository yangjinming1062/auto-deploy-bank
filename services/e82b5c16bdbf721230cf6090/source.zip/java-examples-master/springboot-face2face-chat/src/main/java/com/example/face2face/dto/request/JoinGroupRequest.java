package com.example.face2face.dto.request;

public class JoinGroupRequest {
    private String invitationCode;

    // Getters and Setters
    public String getInvitationCode() {
        return invitationCode;
    }

    public void setInvitationCode(String invitationCode) {
        this.invitationCode = invitationCode;
    }
}