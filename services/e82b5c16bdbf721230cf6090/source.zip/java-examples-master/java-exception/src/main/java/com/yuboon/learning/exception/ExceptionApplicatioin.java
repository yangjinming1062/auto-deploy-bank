package com.yuboon.learning.exception;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * 启动类
 * Created by yuboon on 2019/12/11
 */
@SpringBootApplication
public class ExceptionApplicatioin {

    public static void main(String[] args) {
        SpringApplication.run(ExceptionApplicatioin.class, args);
    }

}
