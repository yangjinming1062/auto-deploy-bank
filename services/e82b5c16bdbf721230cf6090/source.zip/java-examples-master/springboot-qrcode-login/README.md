### 二维码登录

技术文章详见：

[SpringBoot扫码登录实现](https://mp.weixin.qq.com/s/_W0X7wRPjzXLn7OwZlS-Fg)

### 关注我

公众号「风象南」，持续输出优质内容

![](https://raw.githubusercontent.com/yuboon/java-examples/master/doc/images/qrcode.jpg)

