#!/usr/bin/env python
"""
Script to create user accounts programmatically.

This script creates user accounts in the Flask SaaS application.
Run this after initializing the database with `python manage.py initdb`.

Usage:
    python create_users.py --email user@example.com --first-name John --last-name Doe --phone "1234567890" --password password123 [--paid] [--confirmed]
"""

from flask import Flask
from flask.ext.sqlalchemy import SQLAlchemy
from flask.ext.bcrypt import Bcrypt
import argparse
import sys

# Initialize Flask app and extensions
app = Flask(__name__)
app.config.from_object('app.config')
db = SQLAlchemy(app)
bcrypt = Bcrypt(app)

# Import User model
from app.models import User


def create_user(email, first_name, last_name, phone, password, paid=False, confirmed=False):
    """
    Create a new user account.

    Args:
        email: User's email address (primary key)
        first_name: User's first name
        last_name: User's last name
        phone: User's phone number
        password: User's password (will be hashed)
        paid: Whether the user has a paid subscription (default: False)
        confirmed: Whether the user's email is confirmed (default: False)

    Returns:
        User object if successful, None if failed
    """
    try:
        # Check if user already exists
        existing_user = User.query.filter_by(email=email).first()
        if existing_user:
            print(f"Error: User with email {email} already exists!")
            return None

        # Create new user
        user = User(
            first_name=first_name,
            last_name=last_name,
            phone=phone,
            email=email,
            confirmation=confirmed,
            paid=paid,
            password=password  # This will be automatically hashed by the setter
        )

        # Insert the user in the database
        db.session.add(user)
        db.session.commit()

        print(f"User created successfully!")
        print(f"  Email: {email}")
        print(f"  Name: {first_name} {last_name}")
        print(f"  Phone: {phone}")
        print(f"  Paid: {paid}")
        print(f"  Confirmed: {confirmed}")

        return user

    except Exception as e:
        db.session.rollback()
        print(f"Error creating user: {str(e)}")
        return None


def list_users():
    """
    List all users in the database.
    """
    users = User.query.all()

    if not users:
        print("No users found in the database.")
        return

    print(f"\n{len(users)} user(s) found:")
    print("-" * 80)

    for user in users:
        print(f"Email: {user.email}")
        print(f"Name: {user.first_name} {user.last_name}")
        print(f"Phone: {user.phone}")
        print(f"Paid: {user.paid}")
        print(f"Confirmed: {user.confirmation}")
        print(f"Full Name: {user.full_name}")
        print("-" * 80)


def main():
    parser = argparse.ArgumentParser(description='Create or manage user accounts')

    subparsers = parser.add_subparsers(dest='command', help='Commands')

    # Create user subcommand
    create_parser = subparsers.add_parser('create', help='Create a new user')
    create_parser.add_argument('--email', required=True, help='Email address')
    create_parser.add_argument('--first-name', required=True, help='First name')
    create_parser.add_argument('--last-name', required=True, help='Last name')
    create_parser.add_argument('--phone', required=True, help='Phone number')
    create_parser.add_argument('--password', required=True, help='Password')
    create_parser.add_argument('--paid', action='store_true', help='Mark user as paid')
    create_parser.add_argument('--confirmed', action='store_true', help='Mark email as confirmed')

    # List users subcommand
    list_parser = subparsers.add_parser('list', help='List all users')

    args = parser.parse_args()

    if args.command == 'create':
        with app.app_context():
            create_user(
                email=args.email,
                first_name=args.first_name,
                last_name=args.last_name,
                phone=args.phone,
                password=args.password,
                paid=args.paid,
                confirmed=args.confirmed
            )

    elif args.command == 'list':
        with app.app_context():
            list_users()

    else:
        parser.print_help()
        sys.exit(1)


if __name__ == '__main__':
    main()