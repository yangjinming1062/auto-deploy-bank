# Alignments

These directories hold Turtle-based alignments between Brick and other ontologies, as well as the auxiliary files needed to generate those alignments where necessary.

Alignments should be distributed as Turtle files with a specific naming schema. For an ontology `X`, the alignment file should be `Brick-X-alignment.ttl`.
