from ontoenv import OntoEnv
env = OntoEnv(search_directories=["support/", "extensions/", "rec/Source/SHACL/RealEstateCore"], strict=False, offline=True, recreate=True)
