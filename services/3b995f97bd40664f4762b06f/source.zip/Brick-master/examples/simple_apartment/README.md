Simple apartment generation file emphasizing zones + spaces
