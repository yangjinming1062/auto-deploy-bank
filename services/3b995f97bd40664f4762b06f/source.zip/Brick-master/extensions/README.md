# Extensions

This folder contains extensions to the Brick schema. Extensions should be named `brick_extension_{extension name}.ttl`
