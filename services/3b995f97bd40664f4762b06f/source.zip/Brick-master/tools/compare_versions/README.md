## Brick Version Comparison

# How to use it?

```
python tools/compare_versions/compare_versions.py --oldbrick 1.3.0 https://github.com/BrickSchema/Brick/releases/download/v1.3.0/Brick.ttl --newbrick 1.4.0 https://github.com/BrickSchema/Brick/releases/download/nightly/Brick.ttl
```

This will produce the comparison results inside `./history/{old_version}-{new_version}`.

