# Future Soot core library

[Coding guidelines and contributors notice!](../../wiki/contribution-to-soot-reloaded)

[Notizen zum kick-off meeting](../../wiki/kickoff-meeting)

[Design of update mechanism](../../wiki/Design-of-update-mechanism)

[Actor model for new soot ](../../wiki/Actor-model-for-new-soot)
