---
name: Documentation
about: Something in the documentation that needs improvement
title: "[DOC]: "
labels: 'type: docs'
assignees: ''

---

## What are you missing in the docs

## Proposed text
