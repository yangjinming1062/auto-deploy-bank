# Annotations 
Used for Conductor to convert Java POJs to protobuf files.

- `protogen` Annotations
  - Original Author: Vicent Martí - https://github.com/vmg
  - Original Repo: https://github.com/vmg/protogen


