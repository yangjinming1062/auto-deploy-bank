# Build a Go Task Worker

See [conductor-sdk/conductor-go](https://github.com/conductor-oss/go-sdk/blob/main/README.md)
