Annotation processor is used to generate protobuf files from the annotations.
