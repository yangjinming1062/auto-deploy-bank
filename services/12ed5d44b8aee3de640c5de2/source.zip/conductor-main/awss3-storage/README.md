# S3 external storage support
Used by Conductor to support external payload into S3 blob.

See [https://docs.conductor-oss.org/documentation/advanced/externalpayloadstorage.html](https://docs.conductor-oss.org/documentation/advanced/externalpayloadstorage.html) for more details
