from lib.evaluators.cityscapes.rcnn_snake import Evaluator

