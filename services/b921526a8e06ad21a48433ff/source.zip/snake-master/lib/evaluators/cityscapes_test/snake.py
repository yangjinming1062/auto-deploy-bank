from lib.evaluators.cityscapes.snake import Evaluator

