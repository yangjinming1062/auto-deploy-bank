from lib.evaluators.coco.snake import Evaluator

