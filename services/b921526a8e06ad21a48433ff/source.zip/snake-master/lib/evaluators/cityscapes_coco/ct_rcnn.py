from .rcnn_snake import Evaluator
