## Demo说明

Spring Cloud 集成 Dubbo 的 demo

启动后访问：http://127.0.0.1:8091/test/abc



## 集成 Spring Cloud Gateway
[Dubbo想要个网关怎么办？试试整合Spring Cloud Gateway](https://mp.weixin.qq.com/s/_idYl39i1eQejLLLlCW2sg)


