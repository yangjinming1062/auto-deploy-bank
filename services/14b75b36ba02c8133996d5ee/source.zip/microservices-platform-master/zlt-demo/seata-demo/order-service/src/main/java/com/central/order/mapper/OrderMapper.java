package com.central.order.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.central.order.model.Order;

/**
 * @author zlt
 * @date 2019/9/14
 */
public interface OrderMapper extends BaseMapper<Order> {

}
