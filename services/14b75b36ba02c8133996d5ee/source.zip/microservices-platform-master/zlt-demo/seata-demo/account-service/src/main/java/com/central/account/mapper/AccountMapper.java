package com.central.account.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.central.account.model.Account;

/**
 * @author zlt
 * @date 2019/9/14
 */
public interface AccountMapper extends BaseMapper<Account> {

}
