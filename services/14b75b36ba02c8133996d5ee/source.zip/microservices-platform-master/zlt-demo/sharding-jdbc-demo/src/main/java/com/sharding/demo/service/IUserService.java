package com.sharding.demo.service;

import com.central.common.service.ISuperService;
import com.sharding.demo.model.User;

/**
* @author zlt
 */
public interface IUserService extends ISuperService<User> {

}
