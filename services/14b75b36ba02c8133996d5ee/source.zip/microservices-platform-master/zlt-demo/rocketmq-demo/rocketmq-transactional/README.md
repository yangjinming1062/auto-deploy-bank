## 详细步骤和原理请看下面文章：
[Spring Cloud异步场景分布式事务怎样做？试试RocketMQ](https://mp.weixin.qq.com/s/dJz63WQl7UDjcbmDy06FyA)