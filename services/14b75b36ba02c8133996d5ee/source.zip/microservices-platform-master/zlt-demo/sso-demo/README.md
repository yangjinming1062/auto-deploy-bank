* **ss-sso**：使用springSecurity来实现自动单点登录，非前后端分离
* **web-sso**：前后端分离的单点登录与单点登出
* **oidc-sso**：拥有独立用户体系的系统，使用OIDC协议的单点登录与单点登出

