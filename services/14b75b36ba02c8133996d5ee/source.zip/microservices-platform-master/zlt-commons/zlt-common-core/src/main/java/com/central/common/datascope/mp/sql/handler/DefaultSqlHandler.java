package com.central.common.datascope.mp.sql.handler;

/**
 * 示例
 *
 * @author jarvis create by 2023/1/8
 */
public class DefaultSqlHandler implements SqlHandler{


    @Override
    public String handleScopeSql() {
        return DO_NOTHING;
    }
}
