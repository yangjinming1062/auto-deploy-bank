package com.central.user.config;

import com.central.common.config.DefaultPasswordConfig;
import org.springframework.context.annotation.Configuration;

/**
 * @author zlt
 * @date 2019/1/2
 */
@Configuration
public class PasswordConfig extends DefaultPasswordConfig {
}
