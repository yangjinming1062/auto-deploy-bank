# Security Policy

## Supported Versions

As deer-flow doesn't provide an offical release yet, please use the latest version for the security updates.

## Reporting a Vulnerability

Please go to https://github.com/bytedance/deer-flow/security to report the vulnerability you find.
