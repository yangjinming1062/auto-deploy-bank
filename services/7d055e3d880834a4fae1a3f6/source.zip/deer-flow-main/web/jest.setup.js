// Jest setup file
Object.defineProperty(globalThis, '__ESM__', {
  value: true,
  writable: false,
});
