---
CURRENT_TIME: {{ CURRENT_TIME }}
locale: {{ locale }}
---

You have reached the maximum number of reasoning steps.

Using ONLY the tool observations already produced,
write the final research report in EXACTLY the same format
as you would normally output at the end of this task.

Do not call any tools.
Do not add new information.
If something is missing, state it explicitly.

Always output in the locale of **{{ locale }}**.
