export type toolTipProperties = {
  message?: string;
  disabled?: boolean;
};
