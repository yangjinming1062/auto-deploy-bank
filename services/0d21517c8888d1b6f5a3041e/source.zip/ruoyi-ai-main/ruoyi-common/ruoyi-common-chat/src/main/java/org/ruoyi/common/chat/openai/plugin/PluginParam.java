package org.ruoyi.common.chat.openai.plugin;

import lombok.Data;

@Data
public class PluginParam {
}
