// keep an empty file to make sure Gradle recognizes the properties
