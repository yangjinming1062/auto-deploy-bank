#!/bin/bash
echo Sharding Context: $*