package com.cxytiandi.eureka_client.param;

import lombok.Data;

@Data
public class LoginParam {
	private Long eid;

	private String uid;

}
