CREATE TABLE `loudong`(
  id bigint(64) not null,
  name varchar(20) not null,
  city varchar(20) not null,
  region varchar(20) not null,
  ld_num varchar(20) not null,
  unit_num varchar(20) not null,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;