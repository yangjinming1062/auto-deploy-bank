package com.cxytiandi.apollo_springboot.config;

import lombok.Data;

@Data
public class Student {

	private int id;
	
	private String name;
	
}
