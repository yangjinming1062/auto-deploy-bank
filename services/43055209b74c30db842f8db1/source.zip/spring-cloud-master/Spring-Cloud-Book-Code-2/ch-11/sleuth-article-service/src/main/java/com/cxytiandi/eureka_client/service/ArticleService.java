package com.cxytiandi.eureka_client.service;

public interface ArticleService {

	public void saveLog(String log);
	
	public void saveLog2(String log);
	
}
