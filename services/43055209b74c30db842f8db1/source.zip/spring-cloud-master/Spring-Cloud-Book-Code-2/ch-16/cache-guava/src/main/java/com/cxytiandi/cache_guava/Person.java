package com.cxytiandi.cache_guava;

import lombok.Data;

@Data
public class Person {

	private String name;
	
}
