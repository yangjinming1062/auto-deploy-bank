package com.cxytiandi.cache_data_redis.service;

import com.cxytiandi.cache_data_redis.po.Person;

public interface PersonService {
	public Person get(String id);
}
