
# 项目支持的模型
SUPPORT_MODEL = ['deepspeech2',
                 'deepspeech2_big',
                 'deepspeech2_no_stream',
                 'deepspeech2_big_no_stream']