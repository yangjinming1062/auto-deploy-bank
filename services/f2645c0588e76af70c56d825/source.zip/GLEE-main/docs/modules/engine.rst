detectron2.engine 
=========================

Related tutorial: :doc:`../tutorials/training`.

.. automodule:: detectron2.engine
    :members:
    :undoc-members:
    :show-inheritance:


detectron2.engine.defaults module
---------------------------------

.. automodule:: detectron2.engine.defaults
    :members:
    :undoc-members:
    :show-inheritance:

detectron2.engine.hooks module
---------------------------------

.. automodule:: detectron2.engine.hooks
    :members:
    :undoc-members:
    :show-inheritance:
