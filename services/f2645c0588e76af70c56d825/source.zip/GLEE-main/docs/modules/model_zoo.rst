detectron2.model_zoo 
============================

.. automodule:: detectron2.model_zoo
    :members:
    :undoc-members:
    :show-inheritance:
