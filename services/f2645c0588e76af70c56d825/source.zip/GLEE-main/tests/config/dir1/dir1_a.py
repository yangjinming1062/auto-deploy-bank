# Copyright (c) Facebook, Inc. and its affiliates.
dir1a_str = "base_a_1"
dir1a_dict = {"a": 1, "b": 2}
