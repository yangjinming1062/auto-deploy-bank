Algorithms
----------

.. currentmodule:: sklearn_genetic.algorithms

.. autosummary::
   eaMuPlusLambda
   eaMuCommaLambda
   eaSimple

.. automodule:: sklearn_genetic.algorithms
   :members: