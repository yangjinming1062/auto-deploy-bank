
GAFeatureSelectionCV
--------------------

.. currentmodule:: sklearn_genetic

.. autosummary:: GAFeatureSelectionCV
   GAFeatureSelectionCV.decision_function
   GAFeatureSelectionCV.fit
   GAFeatureSelectionCV.get_params
   GAFeatureSelectionCV.inverse_transform
   GAFeatureSelectionCV.predict
   GAFeatureSelectionCV.predict_proba
   GAFeatureSelectionCV.score
   GAFeatureSelectionCV.score_samples
   GAFeatureSelectionCV.set_params
   GAFeatureSelectionCV.transform

.. autoclass:: sklearn_genetic.GAFeatureSelectionCV
   :members:
   :inherited-members:
   :exclude-members: evaluate, mutate, n_features_in_, classes_
   :undoc-members: True