Space
-----

.. autoclass:: sklearn_genetic.space.Categorical
   :members:
   :undoc-members: False

.. autoclass:: sklearn_genetic.space.Continuous
   :members:
   :undoc-members: False

.. autoclass:: sklearn_genetic.space.Integer
   :members:
   :undoc-members: False

.. autoclass:: sklearn_genetic.space.Space
   :members:
   :undoc-members: False