Plots
----------

.. currentmodule:: sklearn_genetic.plots


.. autosummary::
   plot_fitness_evolution
   plot_search_space

.. automodule:: sklearn_genetic.plots
   :members: