MLflow
------

.. currentmodule:: sklearn_genetic

.. autoclass:: sklearn_genetic.mlflow_log.MLflowConfig
   :members:
   :undoc-members: False
