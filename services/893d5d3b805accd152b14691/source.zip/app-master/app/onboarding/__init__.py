from .views import (
    index,
    final,
    setup_done,
    account_activated,
    extension_redirect,
)

__all__ = [
    "index",
    "final",
    "setup_done",
    "account_activated",
    "extension_redirect",
]
