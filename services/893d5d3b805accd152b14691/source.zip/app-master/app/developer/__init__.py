from .views import index, new_client, client_detail

__all__ = ["index", "new_client", "client_detail"]
