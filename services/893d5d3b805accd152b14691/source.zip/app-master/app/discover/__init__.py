from .views import index

__all__ = ["index"]
