from flask import Blueprint

monitor_bp = Blueprint(name="monitor", import_name=__name__, url_prefix="/")
