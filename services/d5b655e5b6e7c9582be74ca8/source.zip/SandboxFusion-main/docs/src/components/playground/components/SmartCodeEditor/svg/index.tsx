export { default as IconOrganization } from "./organization.svg";
export { default as IconWordWrap } from "./wordwrap.svg";
