# PHP

Version: php-cli 7.4.3

For `php` language, if the code snippet doesn't start with `<?php`, the sandbox will automatically add it.

Entry command is `php -f <filename>`
