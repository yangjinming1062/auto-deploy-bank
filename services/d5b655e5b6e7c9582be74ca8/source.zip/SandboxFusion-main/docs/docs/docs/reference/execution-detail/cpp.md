# C++

Version: gcc (Ubuntu 9.4.0-1ubuntu1~20.04.2) 9.4.0

Compile command: `g++ -std=c++17 <filename> -o test -lcrypto -lssl -lpthread`

Note: The above command reflects the built-in sandbox image environment. When running in other environments, the sandbox will automatically detect and remove any missing runtime libraries.
