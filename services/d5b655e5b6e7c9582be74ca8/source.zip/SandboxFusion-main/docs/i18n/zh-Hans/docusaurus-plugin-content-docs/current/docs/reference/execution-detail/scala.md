# Scala

版本： 2.11.12

沙盒会尝试寻找传入代码的 Scala class name ，找不到会报错。 传入代码被写入某个随机文件。

编译指令 `scalac <filename>` ，执行指令 `scala <classname>` 。
