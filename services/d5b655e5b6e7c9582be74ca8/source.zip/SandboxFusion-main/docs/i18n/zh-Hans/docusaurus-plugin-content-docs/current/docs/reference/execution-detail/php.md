# PHP

版本： php-cli 7.4.3

对 `php` 语言，如果传入代码片段不以 `<?php` 开头，沙盒会自动为其补充。

入口指令为 `php -f <filename>`
