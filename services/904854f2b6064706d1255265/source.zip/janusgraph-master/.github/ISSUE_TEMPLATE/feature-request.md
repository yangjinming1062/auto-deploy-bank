---
name: Feature request
about: JanusGraph can't do all the things, but maybe it can do your things.

---
<!--
For discussion on internal implementation details of JanusGraph or proposing a [major new feature or subproject](https://docs.janusgraph.org/development/#development-decisions) use the [janusgraph-dev](https://lists.lfaidata.foundation/g/janusgraph-dev/topics) or [GitHub Discussions](https://github.com/JanusGraph/janusgraph/discussions/categories/ideas).
-->
**Describe the feature:**
[Please add a description for your feature.]

**Describe a specific use case for the feature:**
[If possible add a description of the specific use case.]
