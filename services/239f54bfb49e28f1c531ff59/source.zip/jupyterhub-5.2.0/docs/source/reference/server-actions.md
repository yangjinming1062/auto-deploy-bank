```{eval-rst}
.. jsonschema:: ../../../jupyterhub/event-schemas/server-actions/v1.yaml
```
