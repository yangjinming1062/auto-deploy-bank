# Application configuration

## Module: {mod}`jupyterhub.app`

```{eval-rst}
.. automodule:: jupyterhub.app
```

### {class}`JupyterHub`

```{eval-rst}
.. autoconfigurable:: JupyterHub
```
