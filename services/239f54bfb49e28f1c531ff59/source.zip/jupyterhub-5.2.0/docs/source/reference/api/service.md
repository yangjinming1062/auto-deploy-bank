# Services

## Module: {mod}`jupyterhub.services.service`

```{eval-rst}
.. automodule:: jupyterhub.services.service
```

### {class}`Service`

```{eval-rst}
.. autoconfigurable:: Service
   :members: name, admin, url, api_token, managed, kind, command, cwd, environment, user, oauth_client_id, server, prefix, proxy_spec
```
