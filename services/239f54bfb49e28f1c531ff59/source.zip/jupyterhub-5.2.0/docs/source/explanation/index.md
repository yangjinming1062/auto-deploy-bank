(explanation)=

# Explanation

_Explanation_ documentation provide big-picture descriptions of how JupyterHub works. This section is meant to build your understanding of particular topics.

```{toctree}
:maxdepth: 1

concepts
capacity-planning
database
websecurity
oauth
singleuser
../rbac/index
```
