# FAQs

Find answers to some of the most frequently-asked questions around JupyterHub and how it works.

```{toctree}
:maxdepth: 2

faq
institutional-faq
troubleshooting
```
