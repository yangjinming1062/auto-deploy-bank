# Collaboration accounts

An example of enabling real-time collaboration with dedicated accounts for collaborations.

See [collaboration account docs](../../docs/source/tutorial/collaboration-users.md) for details.
