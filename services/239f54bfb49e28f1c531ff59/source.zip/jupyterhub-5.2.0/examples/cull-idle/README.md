# idle-culler example

The idle culler has been moved to its own repository at
[jupyterhub/jupyterhub-idle-culler](https://github.com/jupyterhub/jupyterhub-idle-culler).
