/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.amoro.authentication;

import org.apache.amoro.exception.SignatureCheckException;

import java.security.Principal;

public interface PasswdAuthenticationProvider {
  /**
   * The authenticate method is called by the amoro Server authentication layer to authenticate
   * users for their requests. If a user is to be granted, return the identifier. When a user is to
   * be disallowed, throw an appropriate [[SignatureCheckException]].
   *
   * @param credential The credential received over the connection request
   * @return The identifier associated with the credential
   * @throws SignatureCheckException When a user is found to be invalid by the implementation
   */
  Principal authenticate(PasswordCredential credential) throws SignatureCheckException;
}
