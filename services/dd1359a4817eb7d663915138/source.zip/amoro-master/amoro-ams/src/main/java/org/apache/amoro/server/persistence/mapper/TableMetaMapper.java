/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.amoro.server.persistence.mapper;

import org.apache.amoro.ServerTableIdentifier;
import org.apache.amoro.server.persistence.converter.Map2StringConverter;
import org.apache.amoro.server.persistence.converter.TableFormatConverter;
import org.apache.amoro.server.persistence.extension.InListExtendedLanguageDriver;
import org.apache.amoro.server.table.TableMetadata;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Lang;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

public interface TableMetaMapper {

  @Insert("INSERT INTO database_metadata(catalog_name, db_name) VALUES( #{catalogName}, #{dbName})")
  void insertDatabase(@Param("catalogName") String catalogName, @Param("dbName") String dbName);

  @Select("SELECT db_name FROM database_metadata WHERE catalog_name = #{catalogName}")
  List<String> selectDatabases(@Param("catalogName") String catalogName);

  @Select(
      "SELECT db_name FROM database_metadata WHERE catalog_name = #{catalogName} AND db_name=#{dbName}")
  String selectDatabase(@Param("catalogName") String catalogName, @Param("dbName") String dbName);

  @Delete(
      "DELETE FROM database_metadata WHERE catalog_name = #{catalogName} AND db_name = #{dbName}"
          + " AND table_count = 0")
  Integer dropDb(@Param("catalogName") String catalogName, @Param("dbName") String dbName);

  @Update(
      "UPDATE database_metadata SET table_count = table_count + #{tableCount} WHERE db_name = #{databaseName}")
  Integer incTableCount(
      @Param("tableCount") Integer tableCount, @Param("databaseName") String databaseName);

  @Update(
      "UPDATE database_metadata SET table_count = table_count - #{tableCount} WHERE db_name = #{databaseName}")
  Integer decTableCount(
      @Param("tableCount") Integer tableCount, @Param("databaseName") String databaseName);

  @Select("SELECT table_count FROM database_metadata WHERE db_name = #{databaseName}")
  Integer selectTableCount(@Param("databaseName") String databaseName);

  @Select(
      "SELECT table_identifier.table_id as table_id, table_identifier.catalog_name as catalog_name, "
          + "table_identifier.db_name as db_name, table_identifier.table_name as table_name, table_identifier.format, "
          + "primary_key, "
          + "table_location, base_location, change_location, meta_store_site, hdfs_site, core_site, "
          + "auth_method, hadoop_username, krb_keytab, krb_conf, krb_principal, properties, meta_version "
          + "FROM table_metadata INNER JOIN table_identifier ON table_metadata.table_id=table_identifier.table_id "
          + "WHERE "
          + "table_identifier.catalog_name=#{catalogName} AND table_identifier.db_name=#{database}")
  @Results({
    @Result(property = "tableIdentifier.id", column = "table_id"),
    @Result(property = "tableIdentifier.catalog", column = "catalog_name"),
    @Result(property = "tableIdentifier.database", column = "db_name"),
    @Result(property = "tableIdentifier.tableName", column = "table_name"),
    @Result(
        property = "tableIdentifier.format",
        column = "format",
        typeHandler = TableFormatConverter.class),
    @Result(property = "primaryKey", column = "primary_key"),
    @Result(property = "tableLocation", column = "table_location"),
    @Result(property = "baseLocation", column = "base_location"),
    @Result(property = "changeLocation", column = "change_location"),
    @Result(property = "metaStoreSite", column = "meta_store_site"),
    @Result(property = "hdfsSite", column = "hdfs_site"),
    @Result(property = "coreSite", column = "core_site"),
    @Result(property = "authMethod", column = "auth_method"),
    @Result(property = "hadoopUsername", column = "hadoop_username"),
    @Result(property = "krbKeytab", column = "krb_keytab"),
    @Result(property = "krbConf", column = "krb_conf"),
    @Result(property = "krbPrincipal", column = "krb_principal"),
    @Result(
        property = "properties",
        column = "properties",
        typeHandler = Map2StringConverter.class),
    @Result(property = "metaVersion", column = "meta_version")
  })
  List<TableMetadata> selectTableMetasByDb(
      @Param("catalogName") String catalogName, @Param("database") String database);

  @Insert(
      "INSERT INTO table_metadata(table_id, table_name, db_name, catalog_name, primary_key,"
          + " table_location, base_location, change_location, meta_store_site, hdfs_site, core_site,"
          + " auth_method, hadoop_username, krb_keytab, krb_conf, krb_principal, properties, meta_version)"
          + " VALUES("
          + " #{tableMeta.tableIdentifier.id},"
          + " #{tableMeta.tableIdentifier.tableName},"
          + " #{tableMeta.tableIdentifier.database},"
          + " #{tableMeta.tableIdentifier.catalog},"
          + " #{tableMeta.primaryKey, jdbcType=VARCHAR},"
          + " #{tableMeta.tableLocation, jdbcType=VARCHAR},"
          + " #{tableMeta.baseLocation, jdbcType=VARCHAR},"
          + " #{tableMeta.changeLocation, jdbcType=VARCHAR},"
          + " #{tableMeta.metaStoreSite, jdbcType=VARCHAR}, "
          + " #{tableMeta.hdfsSite, jdbcType=VARCHAR},"
          + " #{tableMeta.coreSite, jdbcType=VARCHAR},"
          + " #{tableMeta.authMethod, jdbcType=VARCHAR},"
          + " #{tableMeta.hadoopUsername, jdbcType=VARCHAR},"
          + " #{tableMeta.krbKeytab, jdbcType=VARCHAR},"
          + " #{tableMeta.krbConf, jdbcType=VARCHAR},"
          + " #{tableMeta.krbPrincipal, jdbcType=VARCHAR},"
          + " #{tableMeta.properties, typeHandler=org.apache.amoro.server.persistence.converter.Map2StringConverter},"
          + " #{tableMeta.metaVersion}"
          + " )")
  void insertTableMeta(@Param("tableMeta") TableMetadata tableMeta);

  @Delete("DELETE FROM table_metadata WHERE table_id = #{tableId}")
  void deleteTableMetaById(@Param("tableId") long tableId);

  @Update(
      "UPDATE table_metadata SET properties ="
          + " #{tableMeta.properties, typeHandler=org.apache.amoro.server.persistence.converter.Map2StringConverter},"
          + " meta_version=meta_version + 1 "
          + " WHERE table_id = #{tableId} and meta_version = #{tableMeta.metaVersion} ")
  int commitTableChange(
      @Param("tableId") long tableId, @Param("tableMeta") TableMetadata tableMeta);

  @Select(
      "SELECT i.table_id, i.table_name, i.db_name, i.catalog_name, i.format, primary_key, "
          + "table_location, base_location, change_location, meta_store_site, hdfs_site, core_site, "
          + "auth_method, hadoop_username, krb_keytab, krb_conf, krb_principal, properties, meta_version FROM "
          + "table_metadata m INNER JOIN table_identifier i ON m.table_id = i.table_id "
          + "WHERE m.table_id = #{tableId}")
  @Results({
    @Result(property = "tableIdentifier.id", column = "table_id"),
    @Result(property = "tableIdentifier.catalog", column = "catalog_name"),
    @Result(property = "tableIdentifier.database", column = "db_name"),
    @Result(property = "tableIdentifier.tableName", column = "table_name"),
    @Result(
        property = "tableIdentifier.format",
        column = "format",
        typeHandler = TableFormatConverter.class),
    @Result(property = "primaryKey", column = "primary_key"),
    @Result(property = "tableLocation", column = "table_location"),
    @Result(property = "baseLocation", column = "base_location"),
    @Result(property = "changeLocation", column = "change_location"),
    @Result(property = "metaStoreSite", column = "meta_store_site"),
    @Result(property = "hdfsSite", column = "hdfs_site"),
    @Result(property = "coreSite", column = "core_site"),
    @Result(property = "authMethod", column = "auth_method"),
    @Result(property = "hadoopUsername", column = "hadoop_username"),
    @Result(property = "krbKeytab", column = "krb_keytab"),
    @Result(property = "krbConf", column = "krb_conf"),
    @Result(property = "krbPrincipal", column = "krb_principal"),
    @Result(
        property = "properties",
        column = "properties",
        typeHandler = Map2StringConverter.class),
    @Result(property = "metaVersion", column = "meta_version")
  })
  TableMetadata selectTableMetaById(@Param("tableId") long tableId);

  @Select(
      "SELECT table_identifier.table_id as table_id, table_identifier.catalog_name as catalog_name,"
          + " table_identifier.db_name as db_name, table_identifier.table_name as table_name, table_identifier.format, "
          + " primary_key,"
          + " table_location, base_location, change_location, meta_store_site, hdfs_site, core_site, auth_method,"
          + " hadoop_username, krb_keytab, krb_conf, krb_principal, properties, meta_version "
          + " FROM table_metadata INNER JOIN table_identifier ON table_metadata.table_id = table_identifier.table_id"
          + " WHERE table_identifier.catalog_name = #{catalogName} and table_identifier.db_name = #{databaseName}"
          + " AND table_identifier.table_name = #{tableName}")
  @Results({
    @Result(property = "tableIdentifier.id", column = "table_id"),
    @Result(property = "tableIdentifier.catalog", column = "catalog_name"),
    @Result(property = "tableIdentifier.database", column = "db_name"),
    @Result(property = "tableIdentifier.tableName", column = "table_name"),
    @Result(
        property = "tableIdentifier.format",
        column = "format",
        typeHandler = TableFormatConverter.class),
    @Result(property = "primaryKey", column = "primary_key"),
    @Result(property = "tableLocation", column = "table_location"),
    @Result(property = "baseLocation", column = "base_location"),
    @Result(property = "changeLocation", column = "change_location"),
    @Result(property = "metaStoreSite", column = "meta_store_site"),
    @Result(property = "hdfsSite", column = "hdfs_site"),
    @Result(property = "coreSite", column = "core_site"),
    @Result(property = "authMethod", column = "auth_method"),
    @Result(property = "hadoopUsername", column = "hadoop_username"),
    @Result(property = "krbKeytab", column = "krb_keytab"),
    @Result(property = "krbConf", column = "krb_conf"),
    @Result(property = "krbPrincipal", column = "krb_principal"),
    @Result(
        property = "properties",
        column = "properties",
        typeHandler = Map2StringConverter.class),
    @Result(property = "metaVersion", column = "meta_version")
  })
  TableMetadata selectTableMetaByName(
      @Param("catalogName") String catalogName,
      @Param("databaseName") String databaseName,
      @Param("tableName") String tableName);

  @Insert(
      "INSERT INTO table_identifier(catalog_name, db_name, table_name, format) VALUES("
          + " #{tableIdentifier.catalog}, #{tableIdentifier.database}, #{tableIdentifier.tableName}, "
          + " #{tableIdentifier.format, typeHandler=org.apache.amoro.server.persistence.converter.TableFormatConverter})")
  @Options(useGeneratedKeys = true, keyProperty = "tableIdentifier.id")
  void insertTable(@Param("tableIdentifier") ServerTableIdentifier tableIdentifier);

  @Delete("DELETE FROM table_identifier WHERE table_id = #{tableId}")
  Integer deleteTableIdById(@Param("tableId") long tableId);

  @Delete(
      "DELETE FROM table_identifier WHERE catalog_name = #{catalogName} AND db_name = #{databaseName}"
          + " AND table_name = #{tableName}")
  Integer deleteTableIdByName(
      @Param("catalogName") String catalogName,
      @Param("databaseName") String databaseName,
      @Param("tableName") String tableName);

  @Select(
      "SELECT table_id, catalog_name, db_name, table_name, format FROM table_identifier"
          + " WHERE catalog_name = #{catalogName} AND db_name = #{databaseName} AND table_name = #{tableName}")
  @Results({
    @Result(property = "id", column = "table_id"),
    @Result(property = "tableName", column = "table_name"),
    @Result(property = "database", column = "db_name"),
    @Result(property = "catalog", column = "catalog_name"),
    @Result(property = "format", column = "format", typeHandler = TableFormatConverter.class)
  })
  ServerTableIdentifier selectTableIdentifier(
      @Param("catalogName") String catalogName,
      @Param("databaseName") String databaseName,
      @Param("tableName") String tableName);

  @Select(
      "SELECT table_id, catalog_name, db_name, table_name, format FROM table_identifier"
          + " WHERE catalog_name = #{catalogName} AND db_name = #{databaseName}")
  @Results({
    @Result(property = "id", column = "table_id"),
    @Result(property = "catalog", column = "catalog_name"),
    @Result(property = "database", column = "db_name"),
    @Result(property = "tableName", column = "table_name"),
    @Result(property = "format", column = "format", typeHandler = TableFormatConverter.class)
  })
  List<ServerTableIdentifier> selectTableIdentifiersByDb(
      @Param("catalogName") String catalogName, @Param("databaseName") String databaseName);

  @Select(
      "SELECT table_id, catalog_name, db_name, table_name, format FROM table_identifier"
          + " WHERE catalog_name = #{catalogName}")
  @Results({
    @Result(property = "id", column = "table_id"),
    @Result(property = "catalog", column = "catalog_name"),
    @Result(property = "database", column = "db_name"),
    @Result(property = "tableName", column = "table_name"),
    @Result(property = "format", column = "format", typeHandler = TableFormatConverter.class)
  })
  List<ServerTableIdentifier> selectTableIdentifiersByCatalog(
      @Param("catalogName") String catalogName);

  @Select("SELECT table_id, catalog_name, db_name, table_name, format FROM table_identifier")
  @Results({
    @Result(property = "id", column = "table_id"),
    @Result(property = "catalog", column = "catalog_name"),
    @Result(property = "database", column = "db_name"),
    @Result(property = "tableName", column = "table_name"),
    @Result(property = "format", column = "format", typeHandler = TableFormatConverter.class)
  })
  List<ServerTableIdentifier> selectAllTableIdentifiers();

  @Select(
      "SELECT table_id, catalog_name, db_name, table_name, format FROM table_identifier "
          + " WHERE table_id IN (#{tableIds::number[]})")
  @Results({
    @Result(property = "id", column = "table_id"),
    @Result(property = "catalog", column = "catalog_name"),
    @Result(property = "database", column = "db_name"),
    @Result(property = "tableName", column = "table_name"),
    @Result(property = "format", column = "format", typeHandler = TableFormatConverter.class)
  })
  @Lang(InListExtendedLanguageDriver.class)
  List<ServerTableIdentifier> selectTableIdentifiers(@Param("tableIds") List<Long> tableIds);

  @Select(
      "SELECT table_id, catalog_name, db_name, table_name, format FROM table_identifier "
          + " WHERE table_id = #{tableId}")
  @Results({
    @Result(property = "id", column = "table_id"),
    @Result(property = "catalog", column = "catalog_name"),
    @Result(property = "database", column = "db_name"),
    @Result(property = "tableName", column = "table_name"),
    @Result(property = "format", column = "format", typeHandler = TableFormatConverter.class)
  })
  ServerTableIdentifier getTableIdentifier(long tableId);
}
