package tech.powerjob.remote.benchmark;

/**
 * Constant
 * 压测时需要修改的常量
 *
 * @author tjq
 * @since 2023/1/8
 */
public class Constant {

    public static final String SERVER_HOST = "127.0.0.1";

}
