"use strict";

/** @type {import("webpack").Configuration} */
const config = {
	// mode: "development" || "production",
	optimization: {
		concatenateModules: false
	}
};

module.exports = config;
