global.NO_TARGET_ARGS = true;
global.NO_PUBLIC_PATH = true;
require("../build-common");
