// ES6 Modules
import commonjs from "./commonjs";
import amd from "./amd";

export default 456;
