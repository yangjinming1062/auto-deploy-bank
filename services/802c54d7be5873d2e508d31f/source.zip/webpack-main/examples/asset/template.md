This is a very simple example that shows the usage of the asset module type.

Files can be imported like other modules without file-loader.

# example.js

```javascript
_{{example.js}}_
```

# webpack.config.js

```javascript
_{{webpack.config.js}}_
```

# js/output.js

```javascript
_{{dist/output.js}}_
```

# Info

## webpack output

```
_{{stdout}}_
```
