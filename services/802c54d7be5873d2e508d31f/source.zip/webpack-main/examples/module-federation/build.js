global.NO_TARGET_ARGS = true;
global.NO_REASONS = true;
global.NO_STATS_OPTIONS = true;
global.NO_PUBLIC_PATH = true;
require("../build-common");
