var add = require("add");
var subtract = require("subtract");

exports.exampleValue = subtract(add(42, 2), 2);