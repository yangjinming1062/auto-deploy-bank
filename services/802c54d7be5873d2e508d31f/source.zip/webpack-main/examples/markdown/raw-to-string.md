# Example headings

## Sample Section

## This'll be a _Helpful_ Section About the Greek Letter Θ!

A heading containing characters not allowed in fragments, UTF-8 characters, two consecutive spaces between the first and second words, and formatting.

## This heading is not unique in the file

TEXT 1

## This heading is not unique in the file

TEXT 2
