# example.js

```javascript
_{{example.js}}_
```

# dist/output.js

```javascript
_{{dist/output.js}}_
```

# dist/my own chunk.output.js

```javascript
_{{dist/my own chunk.output.js}}_
```

# dist/node_modules_b_js-node_modules_d_js.output.js

```javascript
_{{dist/node_modules_b_js-node_modules_d_js.output.js}}_
```

# Info

## Unoptimized

```
_{{stdout}}_
```

## Production mode

```
_{{production:stdout}}_
```
