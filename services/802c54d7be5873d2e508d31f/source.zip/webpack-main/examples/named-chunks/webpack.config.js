"use strict";

/** @type {import("webpack").Configuration} */
const config = {
	optimization: {
		chunkIds: "named"
	}
};

module.exports = config;
