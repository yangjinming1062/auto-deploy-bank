# pageA.js

```javascript
_{{pageA.js}}_
```

# pageB.js

```javascript
_{{pageB.js}}_
```

# pageC.js

```javascript
_{{pageC.js}}_
```

# common.js

a big file...

# webpack.config.js

```javascript
_{{webpack.config.js}}_
```

# Info

## Unoptimized

```
_{{stdout}}_
```

## Production mode

```
_{{production:stdout}}_
```
