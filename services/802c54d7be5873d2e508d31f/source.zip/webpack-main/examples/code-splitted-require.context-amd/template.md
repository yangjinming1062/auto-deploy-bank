# example.js

``` javascript
_{{example.js}}_
```

# dist/output.js

``` javascript
_{{dist/output.js}}_
```

# dist/require_context_templates_sync_recursive_.output.js

``` javascript
_{{dist/require_context_templates_sync_recursive_.output.js}}_
```

# Info

## Unoptimized

```
_{{stdout}}_
```

## Production mode

```
_{{production:stdout}}_
```
