# webpack Project Governance

The webpack project (and organization) follows the webpack's governance model defined within [the webpack governance repository](https://github.com/webpack/governance/blob/main/README.md).
