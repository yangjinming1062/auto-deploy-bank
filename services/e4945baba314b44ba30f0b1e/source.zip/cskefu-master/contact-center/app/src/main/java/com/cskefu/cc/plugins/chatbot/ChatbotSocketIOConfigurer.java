/* 
 * Copyright (C) 2023 Beijing Huaxia Chunsong Technology Co., Ltd. 
 * <https://www.chatopera.com>, Licensed under the Chunsong Public 
 * License, Version 1.0  (the "License"), https://docs.cskefu.com/licenses/v1.html
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * Copyright (C) 2019-Jun. 2023 Chatopera Inc, <https://www.chatopera.com>, 
 * Licensed under the Apache License, Version 2.0, 
 * http://www.apache.org/licenses/LICENSE-2.0
 */
package com.cskefu.cc.plugins.chatbot;

import com.cskefu.cc.basic.MainContext;
import com.cskefu.cc.socketio.SocketIOServing;
import com.corundumstudio.socketio.SocketIONamespace;
import com.corundumstudio.socketio.SocketIOServer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import jakarta.annotation.PostConstruct;

@Configuration
public class ChatbotSocketIOConfigurer {
    private final static Logger logger = LoggerFactory.getLogger(ChatbotSocketIOConfigurer.class);
    private SocketIONamespace socketIONameSpace;

    @Autowired
    private SocketIOServing socketIOServing;

    @PostConstruct
    public void setup() {
        socketIONameSpace = socketIOServing.getServer().addNamespace(MainContext.NameSpaceEnum.CHATBOT.getNamespace());
    }

    @Bean(name = "chatbotNamespace")
    public SocketIONamespace getSocketIONameSpace(SocketIOServer server) {
        socketIONameSpace.addListeners(new ChatbotEventHandler(server));
        return socketIONameSpace;
    }
}
