# Contributors

Thank you to all the wonderful people who have contributed to axios!

## Core Team

- [Jay](https://github.com/jasonsaayman) - Lead Maintainer
- [Dmitriy Mozgovoy](https://github.com/DigitalBrainJS) - Core Contributor  
- [Matt Zabriskie](https://github.com/mzabriskie) - Creator

## Notable Contributors

<!-- Add contributors here in alphabetical order by GitHub username -->

## How to Contribute

We welcome contributions! Please see our [Contributing Guide](CONTRIBUTING.md) for details.

---

*This list is manually maintained. If you've contributed and would like to be added, please submit a pull request!*