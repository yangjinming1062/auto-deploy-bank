Thank you for sending your pull request. 
But first, have you included unit tests, and is your code PEP8 conformant? [More details](https://github.com/Drakkar-Software/OctoBot/blob/dev/CONTRIBUTING.md)

## Summary
Explain in one sentence the goal of this PR

Solve the issue: #___

## Changelog

  - _____
  - _____
  - _____

## What's new?
*Explain in details what this PR solve or improve.* 
