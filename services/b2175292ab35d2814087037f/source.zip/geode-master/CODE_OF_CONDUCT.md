# Code of Conduct

* [Code of Conduct for The Apache Software Foundation][1]
* [Code of Conduct for the Geode Project][2]

[1]: https://www.apache.org/foundation/policies/conduct.html
[2]: https://cwiki.apache.org/confluence/display/GEODE/Code+of+Conduct
