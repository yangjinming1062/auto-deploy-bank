
mkdir weights

wget https://web.ece.ucsb.edu/~ekta/projects/PieAPPv0.1/weights/PieAPPv0.1_TF.tar.gz --no-check-certificate

tar -xzf PieAPPv0.1_TF.tar.gz -C weights
rm PieAPPv0.1_TF.tar.gz
