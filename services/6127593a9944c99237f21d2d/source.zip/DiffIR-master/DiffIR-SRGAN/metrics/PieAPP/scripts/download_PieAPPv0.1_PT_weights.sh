
mkdir weights

wget https://web.ece.ucsb.edu/~ekta/projects/PieAPPv0.1/weights/PieAPPv0.1.pth --no-check-certificate

mv PieAPPv0.1.pth weights/PieAPPv0.1.pth