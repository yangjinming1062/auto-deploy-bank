



python3  DiffIR/test.py -opt options/test_DiffIRS2_GAN_x4.yml  