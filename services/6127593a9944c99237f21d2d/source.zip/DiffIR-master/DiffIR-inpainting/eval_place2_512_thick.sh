python3 bin/evaluate_predicts.py \
$(pwd)/configs/eval2_gpu.yaml \
/mnt/bn/xiabinpaint/dataset/inpainting/place2/evaluation/random_thick_512/ \
$(pwd)/inference/random_thick_512 \
$(pwd)/inference/random_thick_512_metrics.csv