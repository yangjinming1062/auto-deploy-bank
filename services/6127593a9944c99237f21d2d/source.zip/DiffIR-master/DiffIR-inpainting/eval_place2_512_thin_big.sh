python3 bin/evaluate_predicts.py \
$(pwd)/configs/eval2_gpu.yaml \
/mnt/bn/xiabinpaint/dataset/inpainting/place2/evaluation/random_thin_512/ \
$(pwd)/inference/random_thin_512_big \
$(pwd)/inference/random_thin_512_big_metrics.csv