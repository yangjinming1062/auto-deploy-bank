python3 bin/evaluate_predicts.py \
$(pwd)/configs/eval2_gpu.yaml \
/mnt/bn/xiabinpaint/dataset/celeba-hq-dataset/val_256/random_thick_256/ \
$(pwd)/inference/celeba_random_thick_256 \
$(pwd)/inference/celeba_random_thick_256_metrics.csv