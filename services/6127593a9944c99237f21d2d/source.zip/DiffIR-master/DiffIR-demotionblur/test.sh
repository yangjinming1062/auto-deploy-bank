



CUDA_VISIBLE_DEVICES=2 python3  DiffIR/test.py -opt options/test_DiffIRS2.yml  