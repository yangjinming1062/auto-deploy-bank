pip install lpips --index-url http://pypi.douban.com/simple --trusted-host pypi.douban.com
pip install basicsr --index-url http://pypi.douban.com/simple --trusted-host pypi.douban.com
