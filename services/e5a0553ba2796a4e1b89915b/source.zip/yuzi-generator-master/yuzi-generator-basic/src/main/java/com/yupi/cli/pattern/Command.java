package com.yupi.cli.pattern;

public interface Command {
    void execute();
}