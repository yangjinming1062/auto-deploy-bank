package com.yupi.springbootinit.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.yupi.springbootinit.model.entity.Post;

/**
 * 帖子数据库操作
 */
public interface PostMapper extends BaseMapper<Post> {

}




