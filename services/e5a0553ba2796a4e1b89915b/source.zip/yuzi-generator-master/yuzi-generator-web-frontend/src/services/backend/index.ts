// @ts-ignore
/* eslint-disable */
// API 更新时间：
// API 唯一标识：
import * as fileController from './fileController';
import * as generatorController from './generatorController';
import * as userController from './userController';
export default {
  fileController,
  generatorController,
  userController,
};
