export default () =>
    import(/* webpackChunkName: "datepicker" */ '../../fragments/DatePickerRange.react');


