export default () => import(/* webpackChunkName: "upload" */ '../../fragments/Upload.react');
