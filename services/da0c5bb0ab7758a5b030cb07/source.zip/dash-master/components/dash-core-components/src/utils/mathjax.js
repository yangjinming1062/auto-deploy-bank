import 'mathjax/es5/tex-svg';

window.MathJax.config.startup.typeset = false;
