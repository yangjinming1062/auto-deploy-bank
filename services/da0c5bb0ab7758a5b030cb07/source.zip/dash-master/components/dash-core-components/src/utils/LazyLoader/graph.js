export default () => import(/* webpackChunkName: "graph" */ '../../fragments/Graph.react');

