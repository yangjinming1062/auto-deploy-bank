export default () => import(/* webpackChunkName: "datepicker" */ '../../fragments/DatePickerSingle.react');

