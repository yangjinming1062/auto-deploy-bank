enum LogLevel {
    TRACE = 0,
    INFO = 1,
    WARNING = 2,
    ERROR = 3,
    FATAL = 4,
    NONE = 5
}
export default LogLevel;
