enum DebugLevel {
    DEBUG = 6,
    NONE = 7
}

export default DebugLevel;
