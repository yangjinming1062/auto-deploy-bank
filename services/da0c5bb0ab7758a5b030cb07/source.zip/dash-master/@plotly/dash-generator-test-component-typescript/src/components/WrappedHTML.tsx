import React from 'react';
import {WrappedHTMLProps} from '../props';

/**
 * Component docstring
 */
const WrappedHTML = (props: WrappedHTMLProps) => {
    return null;
};

export default WrappedHTML;
