ignore_props = ['ignored_prop']
