module.exports = {
    tabWidth: 4,
    singleQuote: true,
    jsxSingleQuote: true,
    arrowParens: 'avoid',
    bracketSpacing: false,
    trailingComma: 'none'
};