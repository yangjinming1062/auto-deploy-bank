# @plotly/prettier-config-dash

Shareable Prettier configuration for Dash projects.