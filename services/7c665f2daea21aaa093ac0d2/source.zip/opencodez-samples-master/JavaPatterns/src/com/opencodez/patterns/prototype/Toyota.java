package com.opencodez.patterns.prototype;

public class Toyota extends Car {

	public Toyota() {
		this.carName = "Etios";
	}

	void modelname() {
		System.out.println("Etios V");
	}
}
