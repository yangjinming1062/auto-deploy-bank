package com.opencodez.patterns.nullobject;

public abstract class Shop {
	
	public abstract void discountedProduct();

	public abstract boolean noDiscount();

}
