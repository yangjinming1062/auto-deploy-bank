package com.opencodez.patterns.bridge;

public interface Workshop 
{
	abstract public void work();
}

