package com.opencodez.patterns.prototype;

public class Maruti extends Car {

	public Maruti() {
		this.carName = "Suzuki";
	}

	void modelname() {
		System.out.println("Suzuki D");
	}
}
