package com.opencodez.patterns.command;

//Command Interface
public interface Command {
	public void execute();
}
