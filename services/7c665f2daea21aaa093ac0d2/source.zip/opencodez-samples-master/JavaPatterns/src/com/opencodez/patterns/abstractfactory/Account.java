package com.opencodez.patterns.abstractfactory;

public interface Account {
	public void getInterestRate();
}
