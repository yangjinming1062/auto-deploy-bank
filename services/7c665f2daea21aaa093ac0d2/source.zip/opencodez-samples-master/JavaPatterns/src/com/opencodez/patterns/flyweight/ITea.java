package com.opencodez.patterns.flyweight;

public interface ITea {
	public void serveTea(TeaContext context);
}
