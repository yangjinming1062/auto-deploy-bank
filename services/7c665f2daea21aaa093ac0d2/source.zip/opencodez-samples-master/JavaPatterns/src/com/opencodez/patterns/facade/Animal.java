package com.opencodez.patterns.facade;

public interface Animal {
	public void speak();
}
