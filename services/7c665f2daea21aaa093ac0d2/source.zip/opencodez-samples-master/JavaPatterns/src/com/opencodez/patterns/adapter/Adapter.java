package com.opencodez.patterns.adapter;

public interface Adapter {
	public void conntect();
}
