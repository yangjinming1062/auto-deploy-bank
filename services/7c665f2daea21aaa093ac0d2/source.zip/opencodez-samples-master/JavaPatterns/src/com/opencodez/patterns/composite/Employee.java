package com.opencodez.patterns.composite;

public interface Employee {
	public void print();
}
