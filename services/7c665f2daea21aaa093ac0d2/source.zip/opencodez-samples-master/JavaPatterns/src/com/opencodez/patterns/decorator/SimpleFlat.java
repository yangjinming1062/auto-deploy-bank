package com.opencodez.patterns.decorator;

public class SimpleFlat implements Flat {

	@Override
	public String getSpecification() {
		return "1BHK Flat";
	}

}
