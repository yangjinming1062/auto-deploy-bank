package com.opencodez.patterns.abstractfactory;

public abstract class AbstractFactory {
	abstract Account getAccount(String type) ;
}
