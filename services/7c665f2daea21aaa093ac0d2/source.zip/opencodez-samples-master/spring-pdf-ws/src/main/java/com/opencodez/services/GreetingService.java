package com.opencodez.services;

import org.springframework.ws.server.endpoint.annotation.Endpoint;

@Endpoint
public class GreetingService {

}
