package com.opencodez.actuators.beans;

import org.springframework.stereotype.Component;

@Component
public class SampleBean {
	
	public void sayHello() {
		System.out.println("Hello, I am sample Bean!!");
	}

}
