CREATE TABLE `example` (
  `ex_id` int NOT NULL AUTO_INCREMENT,  
  `ex_value` int NOT NULL,
  PRIMARY KEY (`ex_id`)
) ;

COMMIT;
