This folder contains the public images used to demonstrate the pose detection
model capability. They were downloaded and modified from the public domain
website: https://www.pexels.com/


Original download links:

  - Main squating: https://images.pexels.com/photos/4384679/pexels-photo-4384679.jpeg
  - Girl dancing: https://vod-progressive.akamaized.net/exp=1620954535~acl=%2Fvimeo-prod-skyfire-std-us%2F01%2F1880%2F19%2F484400309%2F2169124688.mp4~hmac=07b3b179eaeeb59d5afbda79f59a8420644048402bdc6ca113f03bf58f9a62f0/vimeo-prod-skyfire-std-us/01/1880/19/484400309/2169124688.mp4?download=1&filename=pexels-artem-podrez-6003772.mp4
