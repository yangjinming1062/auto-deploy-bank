## Note: This package is deprecated in favor of the new [body-segmentation package](https://github.com/tensorflow/tfjs-models/blob/master/body-segmentation).
