python scripts/merge_lora_weights.py \
--model-path path_to_lora \
--model-base path_to_base_model \
--save-model-path path_to_save_merged_model