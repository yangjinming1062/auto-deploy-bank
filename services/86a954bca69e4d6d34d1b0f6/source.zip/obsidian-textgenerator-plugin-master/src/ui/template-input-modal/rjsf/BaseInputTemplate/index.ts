export { default } from "./BaseInputTemplate";
export * from "./BaseInputTemplate";
