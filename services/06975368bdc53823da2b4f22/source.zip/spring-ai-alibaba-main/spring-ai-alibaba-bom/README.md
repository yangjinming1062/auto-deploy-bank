# Spring AI Alibaba Bom

Bill of Materials POM (BOM) for the Spring AI Alibaba modules.
