/*
 * Copyright 2024-2025 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.alibaba.cloud.ai.graph.serializer.std;

import com.alibaba.cloud.ai.graph.serializer.Serializer;

import org.springframework.ai.chat.messages.SystemMessage;

import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.util.Objects;

class SystemMessageSerializer implements Serializer<SystemMessage> {

	@Override
	public void write(SystemMessage object, ObjectOutput out) throws IOException {
		var text = Objects.requireNonNull(object.getText(), "text cannot be null");
		Serializer.writeUTF(text, out);

	}

	@Override
	public SystemMessage read(ObjectInput in) throws IOException, ClassNotFoundException {
		var text = Serializer.readUTF(in);
		return new SystemMessage(text);
	}

}
