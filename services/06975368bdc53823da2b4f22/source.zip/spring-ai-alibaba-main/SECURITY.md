## Reporting a Vulnerability

Please report any security issue or Higress crash report to [ASRC](https://security.alibaba.com/)(Alibaba Security Response Center) where the issue will be triaged appropriately.

Thank you in advance for helping to keep Spring AI Alibaba secure.
