# Project Management Committee (PMC) Members

## Members

| &nbsp;                                                         | Member          | Organization  | Profile                                              | Term Start |
| -------------------------------------------------------------- |-----------------| ------------  | ---------------------------------------------------- | ---------- |
| <img width="30px" src="https://github.com/chickenlj.png">      | Jun Liu         | Alibaba       | [@chikenlj](https://github.com/chickenlj)             | 23rd Sep 2024  |
| <img width="30px" src="https://github.com/Cirilla-zmh.png">    | Minghui Zhang   | Alibaba       | [@Cirilla-zmh](https://github.com/Cirilla-zmh)        | 16th Dec 2024  |
| <img width="30px" src="https://github.com/CZJCC.png">          | Jianchuan Zhang | Alibaba       | [@CZJCC](https://github.com/CZJCC)                    | 16th Dec 2024  |
| <img width="30px" src="https://github.com/robinyeeh.png">      | Tianbing Ye     | Alibaba       | [@robinyeeh](https://github.com/robinyeeh)            | 9th Apr 2025   |
| <img width="30px" src="https://github.com/yuluo-yx.png">       | Shown Ji        | ~             | [@yuluo-yx](https://github.com/yuluo-yx)              | 9th Apr 2025   |

## Emeritus members

None.
