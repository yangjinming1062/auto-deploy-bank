Guidelines for contributing to libra will come soon.
