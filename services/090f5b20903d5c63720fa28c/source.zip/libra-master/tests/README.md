`tests.py` hosts all of the tests for the queries. More will be coming soon. 
