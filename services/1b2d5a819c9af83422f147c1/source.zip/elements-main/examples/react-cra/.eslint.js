module.exports = {
    extends: ["@stoplight"],
  };
