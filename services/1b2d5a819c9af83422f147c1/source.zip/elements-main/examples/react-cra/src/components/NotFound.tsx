import React from 'react';

export const NotFound = () => {
  return (
    <div>
      <p>Error: Page does not exist!</p>
    </div>
  );
};
