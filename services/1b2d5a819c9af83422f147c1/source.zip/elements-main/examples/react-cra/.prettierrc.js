module.exports = {
    ...require("@stoplight/eslint-config/prettier.config"),
  };
