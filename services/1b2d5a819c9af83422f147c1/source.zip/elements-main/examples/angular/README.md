# Stoplight Elements - Angular Example

Stoplight Elements can be used in any framework using the Web Components distribution.
This example project demonstrates usage in an Angular 11 application.

## Try the example

For instructions on how to run this example, please refer to the [root README file](../../README.md#-examples)

## Elements in your own Angular app

You can find a guide on integrating Elements into your own Angular application [on our website](https://elements.stoplight.io/docs/elements/docs/guides/angular.md).
