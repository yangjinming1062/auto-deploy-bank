export const environment = {
  production: true,
  basePath: '',
};
