import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['../app.component.css'],
})
export class HomeComponent {
  public title = 'Elements Starter Angular';
}
