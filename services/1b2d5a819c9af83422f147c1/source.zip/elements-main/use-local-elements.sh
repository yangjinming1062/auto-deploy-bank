#!/bin/bash
example=$1

cd ./examples-dev/$example

npx json -I -f package.json -e "this.resolutions=this.resolutions || {}"
npx json -I -f package.json -e "this.resolutions[\"@stoplight/elements\"]=\"file:../../packages/elements/dist\""
npx json -I -f package.json -e "this.resolutions[\"@stoplight/elements-dev-portal\"]=\"file:../../packages/elements-dev-portal/dist\""
npx json -I -f package.json -e "this.resolutions[\"@stoplight/elements-core\"]=\"file:../../packages/elements-core/dist\""

npx json -I -f package.json -e "this.dependencies[\"@stoplight/elements\"]=\"file:../../packages/elements/dist\""
npx json -I -f package.json -e "this.dependencies[\"@stoplight/elements-dev-portal\"]=\"file:../../packages/elements-dev-portal/dist\""

npx json -I -f package.json -e "this.scripts.reinstall=\"rm -rf node_modules && yarn install\""
