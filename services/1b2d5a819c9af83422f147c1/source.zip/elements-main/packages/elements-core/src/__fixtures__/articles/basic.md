---
title: Stoplight Flavored Markdown
---

# Stoplight Flavored Markdown (smd)

### The Two Laws

1. smd is human readable. A human with a simple text editor can easily read and comprehend smd.
2. smd degrades gracefully. An smd document rendered on `github.com` should be readable and clean.
