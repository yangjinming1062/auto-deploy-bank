import '@testing-library/jest-dom';

import { screen } from '@testing-library/dom';
import { cleanup, render, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import * as React from 'react';
import { TextDecoder, TextEncoder } from 'util';

import { withPersistenceBoundary } from '../../../context/Persistence';
import { withMosaicProvider } from '../../../hoc/withMosaicProvider';
import { RequestSamples as RequestSamplesWithoutPersistence } from '../RequestSamples';

const RequestSamples = withMosaicProvider(withPersistenceBoundary(RequestSamplesWithoutPersistence));

const sampleRequest = {
  method: 'POST',
  url: 'https://google.com',
  httpVersion: 'HTTP/1.1',
  headers: [
    {
      name: 'Cache-Control',
      value: 'max-age=0',
    },
  ],
  queryString: [],
  cookies: [],
  postData: {
    mimeType: 'multipart/form-data',
    params: [
      {
        name: 'file',
        fileName: 'example.jpeg',
        contentType: 'image.jpeg',
      },
    ],
  },
  headersSize: 678,
  bodySize: -1,
};

globalThis.TextEncoder = TextEncoder;
// @ts-ignore
globalThis.TextDecoder = TextDecoder;

describe('RequestSend', () => {
  beforeEach(() => {
    localStorage.clear();
  });

  it('Displays basic CURL request', async () => {
    const { container } = render(<RequestSamples request={sampleRequest} />);

    await waitFor(() => expect(container).toHaveTextContent('curl'));
    expect(container).toHaveTextContent('POST');
    expect(container).toHaveTextContent('https://google.com');
    expect(container).toHaveTextContent('max-age=0');
  });

  it('Allows language switching', async () => {
    const { container } = render(<RequestSamples request={sampleRequest} />);
    await chooseLanguage('JavaScript', 'Axios');

    await waitFor(() => expect(container).toHaveTextContent('axios'));
    expect(container).toHaveTextContent('POST');
    expect(container).toHaveTextContent('https://google.com');
    expect(container).toHaveTextContent('max-age=0');
  });

  it('preserves language and library between renders', async () => {
    render(<RequestSamples request={sampleRequest} />);
    await chooseLanguage('JavaScript', 'Axios');

    cleanup();

    const { container } = render(<RequestSamples request={sampleRequest} />);
    const langSelector = getLanguageSelectorButton();
    expect(langSelector).toHaveTextContent(/axios/i);
    await waitFor(() => expect(container).toHaveTextContent('axios'));
  });

  it('allows to change lang/lib after rerender', async () => {
    render(<RequestSamples request={sampleRequest} />);
    await chooseLanguage('JavaScript', 'Axios');

    cleanup();

    render(<RequestSamples request={sampleRequest} />);
    const langSelector = getLanguageSelectorButton();
    await chooseLanguage('JavaScript', 'Fetch');

    expect(langSelector).toHaveTextContent(/javascript/i);
    expect(langSelector).toHaveTextContent(/fetch/i);
  });

  it('switches to language with no library', async () => {
    const { container } = render(<RequestSamples request={sampleRequest} />);
    const langSelector = getLanguageSelectorButton();
    await chooseLanguage('Obj-C');

    expect(langSelector).toHaveTextContent(/obj-c/i);
    await waitFor(() => expect(container).toHaveTextContent('#import <Foundation/Foundation.h>'));
  });

  it('adds multipart form data to js/fetch request', async () => {
    const { container } = render(<RequestSamples request={sampleRequest} />);
    const langSelector = getLanguageSelectorButton();
    await chooseLanguage('JavaScript', 'Fetch');

    expect(langSelector).toHaveTextContent(/javascript/i);
    expect(langSelector).toHaveTextContent(/fetch/i);
    await waitFor(() => expect(container).toHaveTextContent('options.body = form;'));
  });
});

function getLanguageSelectorButton() {
  return screen.getByRole('button', { name: /Request Sample/i });
}

async function chooseLanguage(language: string, library?: string) {
  const langSelector = getLanguageSelectorButton();
  userEvent.click(langSelector);

  const menuItem = await screen.findByRole('menuitemcheckbox', { name: language });
  if (!library) {
    userEvent.click(menuItem);
  } else {
    userEvent.hover(menuItem);
    const subMenuItem = await screen.findByRole('menuitemcheckbox', { name: library });
    userEvent.click(subMenuItem);
  }
}
