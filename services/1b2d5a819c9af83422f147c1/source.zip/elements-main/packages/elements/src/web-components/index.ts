import { ApiElement } from './components';

window.customElements.define('elements-api', ApiElement);
