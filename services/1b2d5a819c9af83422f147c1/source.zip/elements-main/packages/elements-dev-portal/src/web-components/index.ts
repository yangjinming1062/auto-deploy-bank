import { StoplightProjectElement } from './components';

window.customElements.define('elements-stoplight-project', StoplightProjectElement);
