// auto-updated during build
export const appVersion = '3.0.10';
