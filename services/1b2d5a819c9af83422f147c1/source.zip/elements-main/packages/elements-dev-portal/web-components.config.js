module.exports = require('../../web-components.webpack.config');
