# Elements Release PR Template

Before releasing a new version of elements: (check the boxes to acknowledge you've followed this template)

- [ ] [Read the release section of `CONTRIBUTING.md`](../blob/main/CONTRIBUTING.md#releasing-elements)
