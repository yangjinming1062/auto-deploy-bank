import sys
sys.path.append('../')
from imagepy.app import startup
startup.start()