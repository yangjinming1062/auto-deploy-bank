### TODO: Fixme! In this directory, many path should be corrected?!
catlog = ['new_plg', '-', 'open_plg', 'save_plg', '-', 'Open Recent', 'Samples Local', 'Samples Online',  
	'Samples ImageJ', '-', 'Import', 'Export', '-', 'BMP', 'JPG', 'PNG', 'TIF', 'GIF', 'DICOM', 'DAT', 'Numpy', 'MAT', '-', 'MarkDown', '-', 'exit_plg']