catlog = ['cluster_plgs', '-', 'statistic_plgs','-','kmeans_plgs']
