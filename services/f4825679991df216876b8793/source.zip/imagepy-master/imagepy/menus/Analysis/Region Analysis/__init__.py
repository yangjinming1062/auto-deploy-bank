#
catlog = ['regionprops_plgs', 'connect_plg', '-', 'statistic_plgs']