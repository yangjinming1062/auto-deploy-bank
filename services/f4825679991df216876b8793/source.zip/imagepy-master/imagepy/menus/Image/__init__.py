catlog = ['Type', '-', 'Adjust', 'Color', 'Stack', 'Channels', 'Transform', '-', 
		  'duplicate_plg', 'crop_plg', 'canvassize_plg', 'resize_plg', '-', 
		  'setscale_plg', 'background_plg', '-', 'Mark', 'Lookup table']