# Gratitude for StackReg

You'll be free to use this software for research purposes, but you
should not redistribute it without our consent. In addition, we expect
you to include a citation or acknowledgment whenever you present or
publish results that are based on it.

**Additional help available at [http://bigwww.epfl.ch/thevenaz/turboreg](http://bigwww.epfl.ch/thevenaz/turboreg/)**

![befor](http://bigwww.epfl.ch/thevenaz/turboreg/before.gif)
![after](http://bigwww.epfl.ch/thevenaz/turboreg/after.gif)

