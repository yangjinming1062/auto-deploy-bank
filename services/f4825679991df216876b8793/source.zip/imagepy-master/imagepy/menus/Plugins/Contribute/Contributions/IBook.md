# IBook

**Path:** https://gitee.com/imagepy/IBook

**Version:** 0.1

**Author:** YXDragon

**Email:** yxdragon@imagepy.org

**Keyword:** book, tutorial

**Description:** ImagePy's plugins to show some image processing method, which is friendly to beginner.

you must fill the information upon, and you can not remove or insert line, you can write free below.

## Document
...