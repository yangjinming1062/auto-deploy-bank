# FluidSurface

**Path:** https://github.com/Image-Py/FluidSurface.git

**Version:** 0.1

**Author:** YXDragon、Prevalenter

**Email:** yxdragon@imagepy.org

**Keyword:** predict, fluid

**Description:** The predict plug-ins of imagepy

## Document
...