catlog = ['coordinate_tol', 'distance_tol', 
          'angle2_tol', 'angle_tol', 
          'area_tol', 'setting_tol']