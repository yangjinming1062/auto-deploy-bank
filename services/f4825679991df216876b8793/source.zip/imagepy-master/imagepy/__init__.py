import os.path as osp
root_dir = osp.abspath(osp.dirname(__file__))
