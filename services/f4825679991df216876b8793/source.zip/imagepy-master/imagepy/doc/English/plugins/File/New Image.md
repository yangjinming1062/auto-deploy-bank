# New

**Description:** create a new Image


## Parameter

**name:** the new image's title

**width:** image's width

**height:** image's height

**type:** image's type

1. 8-bit: create a 8-bit one channel image
2. rgb: create a 24-bit three channel image

**slice:** the z thickness