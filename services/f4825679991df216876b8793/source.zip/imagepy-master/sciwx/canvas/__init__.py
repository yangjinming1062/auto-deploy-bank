#from .canvas import Canvas
from .mcanvas import MCanvas, ICanvas, VCanvas, Canvas
from .widget import CanvasFrame, CanvasNoteBook, CanvasNoteFrame
from .vwidget import VectorFrame, VectorNoteBook, VectorNoteFrame