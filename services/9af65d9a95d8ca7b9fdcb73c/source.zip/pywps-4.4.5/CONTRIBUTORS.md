# Contributors to PyWPS

* @jachym Jachym Cepicky
* @jorgejesus Jorge Samuel Mendes de Jesus
* @ldesousa Luís de Sousa
* @tomkralidis Tom Kralidis
* @mgax Alex Morega
* @Noctalin Calin Ciociu
* @SiggyF Fedor Baart
* @jonas-eberle Jonas Eberle
* @cehbrecht Carsten Ehbrecht
* @idanmiara Idan Miara

# Contributor to older versions of PyWPS (< 4.x)

* @ricardogsilva Ricardo Garcia Silva
* @gschwind Benoit Gschwind
* @khosrow Khosrow Ebrahimpour
* @TobiasKipp Tobias Kipp
* @kalxas Angelos Tzotsos
* @Kruecke Florian Klemme
* @slarosa Salvatore Larosa
* @ominiverdi (Lorenzo Becchi)
* @lucacasagrande (doktoreas - Luca Casagrande)
* @sigmapi (pana - Panagiotis Skintzos)
* @fpl Francesco P. Lovergine
* @giohappy Giovanni Allegri
* sebastianh Sebastian Holler

# NOTE

This file is kept manually. Feel free to contact us, if your contribution is
missing here.
