# 1.2.2

-   Fix selector for lists showing as grid per default, e.g. /actor/tom-hanks/

# 1.2.1

-   Unify selectors for regular list and popular list (Thank you @benjroy)

# 1.2.0

-   Throw 404 error on empty lists by default.
-   Add `errorOnEmpty` query parameter to disable 404 error on empty lists.
-   Implement fix for letterboxd list page structure change (Thank you @szymon-romanko)
