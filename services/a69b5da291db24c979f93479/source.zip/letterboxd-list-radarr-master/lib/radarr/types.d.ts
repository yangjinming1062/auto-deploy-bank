export interface RadarrMovieDetails {
    id: number?;
    imdb_id: string?;
    title: string;
    release_year: string;
    clean_title: string;
    adult: boolean;
}
