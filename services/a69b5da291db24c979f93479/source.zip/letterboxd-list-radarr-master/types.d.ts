declare module 'robots-parser' {
    export default function(url: string, content: string): any;
}
