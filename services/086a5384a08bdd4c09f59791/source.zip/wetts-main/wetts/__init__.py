from wetts.cli.model import load_model  # noqa
