.. Wenet documentation master file, created by
   sphinx-quickstart on Thu Dec  3 11:43:53 2020.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to WeTTS's documentation!
=================================

Production First and Production Ready End-to-End Text-to-Speech Toolkit

.. toctree::
   :maxdepth: 1
   :caption: Tutorial:


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
