public class D {
    public Integer getZero() {
        // should report DM_NUMBER_CTOR (Dm)
        return new Integer(0);
    }
}
