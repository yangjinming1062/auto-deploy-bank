# FindBugs is now SpotBugs

[Old FindBugs site](http://findbugs.sourceforge.net).

[New SpotBugs site](https://spotbugs.github.io).

Project development continues here: https://github.com/spotbugs/spotbugs

Please read this for details: 

- https://mailman.cs.umd.edu/pipermail/findbugs-discuss/2016-November/004321.html
- https://mailman.cs.umd.edu/pipermail/findbugs-discuss/2017-September/004383.html
