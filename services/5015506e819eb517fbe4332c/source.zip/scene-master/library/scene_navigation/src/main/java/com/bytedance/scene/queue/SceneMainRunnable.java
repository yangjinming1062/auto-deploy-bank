package com.bytedance.scene.queue;

/**
 * Created by jiangqi on 2023/11/3
 *
 * @author jiangqi@bytedance.com
 */
interface SceneMainRunnable extends Runnable {

}
