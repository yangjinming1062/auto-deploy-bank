package com.bytedance.scene.launchmode;

/**
 * Created by jiangqi on 2024/5/20
 *
 * @author jiangqi@bytedance.com
 */
public enum LaunchMode {
    STANDARD, SINGLE_TOP, SINGLE_TASK
}
