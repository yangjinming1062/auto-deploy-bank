/*
 * Copyright (C) 2019 ByteDance Inc
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.bytedance.scene.animation.interaction.progressanimation;

import android.graphics.Path;
import android.graphics.PathMeasure;
import android.view.View;

public class PathInteractionAnimation extends InteractionAnimation {
    private Path mPath;
    private View mView;
    private final PathMeasure mPathMeasure;
    private float aCoordinates[] = {0f, 0f};

    public PathInteractionAnimation(float endProgress, Path path, View view) {
        super(endProgress);
        this.mPath = path;
        this.mView = view;
        this.mPathMeasure = new PathMeasure(this.mPath, false);
    }

    @Override
    public void onProgress(float progress) {
        this.mPathMeasure.getPosTan(this.mPathMeasure.getLength() * progress, aCoordinates, null);
        this.mView.setTranslationX(aCoordinates[0]);
        this.mView.setTranslationY(aCoordinates[1]);
    }
}
