package com.bytedance.scene.queue;

/**
 * Created by jiangqi on 2023/11/5
 *
 * @author jiangqi@bytedance.com
 */
public abstract class NavigationRunnable implements Runnable {

}
