package com.bytedance.scene.navigation.utility;

/**
 * Created by jiangqi on 2023/11/23
 *
 * @author jiangqi@bytedance.com
 */
public class LogUtility {
    public static void clear(StringBuilder log){
        log.delete(0, log.length());
    }
}
