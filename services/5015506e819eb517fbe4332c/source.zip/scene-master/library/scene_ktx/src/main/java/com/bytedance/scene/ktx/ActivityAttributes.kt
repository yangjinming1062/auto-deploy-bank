package com.bytedance.scene.ktx

data class ActivityAttributes(var configChanges: Int = -1)