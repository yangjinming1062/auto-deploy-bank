
```
|-- ckpts
|   |-- aniportrait
|   |   `-- motion_module.pth
|   |   `-- audio2mesh.pt
|   |   `-- film_net_fp16.pt
|   |   |-- sd-vae-ft-mse
|   |   |   `-- diffusion_pytorch_model.safetensors
|   |   |   `-- config.json
|   |   |   `-- diffusion_pytorch_model.bin
|   |   `-- denoising_unet.pth
|   |   `-- audio2pose.pt
|   |   `-- pose_guider.pth
|   |   |-- sd-image-variations-diffusers
|   |   |   `-- v1-montage.jpg
|   |   |   |-- scheduler
|   |   |   |   `-- scheduler_config.json
|   |   |   `-- README.md
|   |   |   `-- model_index.json
|   |   |   |-- unet
|   |   |   |   `-- config.json
|   |   |   |   `-- diffusion_pytorch_model.bin
|   |   |   |-- feature_extractor
|   |   |   |   `-- preprocessor_config.json
|   |   |   `-- v2-montage.jpg
|   |   |   |-- vae
|   |   |   |   `-- config.json
|   |   |   |   `-- diffusion_pytorch_model.bin
|   |   |   `-- alias-montage.jpg
|   |   |   `-- inputs.jpg
|   |   |   |-- safety_checker
|   |   |   |   `-- pytorch_model.bin
|   |   |   |   `-- config.json
|   |   |   `-- earring.jpg
|   |   |   `-- default-montage.jpg
|   |   |-- image_encoder
|   |   |   `-- pytorch_model.bin
|   |   |   `-- config.json
|   |   |-- stable-diffusion-v1-5
|   |   |   `-- model_index.json
|   |   |   `-- v1-inference.yaml
|   |   |   |-- unet
|   |   |   |   `-- config.json
|   |   |   |   `-- diffusion_pytorch_model.bin
|   |   |   |-- feature_extractor
|   |   |   |   `-- preprocessor_config.json
|   |   `-- reference_unet.pth
|   |   |-- wav2vec2-base-960h
|   |   |   `-- pytorch_model.bin
|   |   |   `-- README.md
|   |   |   `-- vocab.json
|   |   |   `-- config.json
|   |   |   `-- tf_model.h5
|   |   |   `-- tokenizer_config.json
|   |   |   `-- model.safetensors
|   |   |   `-- special_tokens_map.json
|   |   |   `-- preprocessor_config.json
|   |   |   `-- feature_extractor_config.json
|   |-- mofa
|   |   |-- traj_controlnet
|   |   |   `-- diffusion_pytorch_model.safetensors
|   |   |   `-- config.json
|   |   |-- stable-video-diffusion-img2vid-xt-1-1
|   |   |   |-- scheduler
|   |   |   |   `-- scheduler_config.json
|   |   |   `-- README.md
|   |   |   `-- model_index.json
|   |   |   |-- unet
|   |   |   |   `-- diffusion_pytorch_model.fp16.safetensors
|   |   |   |   `-- config.json
|   |   |   |-- feature_extractor
|   |   |   |   `-- preprocessor_config.json
|   |   |   |-- vae
|   |   |   |   `-- diffusion_pytorch_model.fp16.safetensors
|   |   |   |   `-- config.json
|   |   |   `-- LICENSE
|   |   |   `-- svd11.webp
|   |   |   |-- image_encoder
|   |   |   |   `-- config.json
|   |   |   |   `-- model.fp16.safetensors
|   |   |-- ldmk_controlnet
|   |   |   `-- diffusion_pytorch_model.safetensors
|   |   |   `-- config.json
|   |-- sad_talker
|   |   `-- SadTalker_V0.0.2_256.safetensors
|   |   |-- hub
|   |   `-- mapping_00229-model.pth.tar
|   |   |-- BFM_Fitting
|   |   |   `-- select_vertex_id.mat
|   |   |   `-- facemodel_info.mat
|   |   |   `-- BFM_exp_idx.mat
|   |   |   `-- BFM_model_front.mat
|   |   |   `-- 01_MorphableModel.mat
|   |   |   `-- similarity_Lm3D_all.mat
|   |   |   `-- BFM_front_idx.mat
|   |   |   `-- Exp_Pca.bin
|   |   |   `-- std_exp.txt
|   |   `-- SadTalker_V0.0.2_512.safetensors
|   |   `-- similarity_Lm3D_all.mat
|   |   `-- epoch_00190_iteration_000400000_checkpoint.pt
|   |   `-- mapping_00109-model.pth.tar
|   |-- gfpgan
|   |   `-- alignment_WFLW_4HG.pth
|   |   `-- parsing_parsenet.pth
|   |   `-- detection_Resnet50_Final.pth

```