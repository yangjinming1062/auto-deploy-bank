Upgrade Guides
==============

Learn how to upgrade Authlib from version to version.

.. toctree::
    :maxdepth: 2

    jose
