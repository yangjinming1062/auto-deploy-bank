Token Endpoints
===============

Flask OAuth 2.0 authorization server has a method to register other token
endpoints: ``authorization_server.register_endpoint``. Find the available
endpoints:

- :ref:`register_revocation_endpoint`
- :ref:`register_introspection_endpoint`
