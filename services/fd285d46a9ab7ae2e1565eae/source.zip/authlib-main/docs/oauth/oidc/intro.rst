Introduce OpenID Connect
========================

OpenID Connect is an identity layer on top of the OAuth 2.0 framework.

(TBD)
