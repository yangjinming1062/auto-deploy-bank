See http://docs.alerta.io
