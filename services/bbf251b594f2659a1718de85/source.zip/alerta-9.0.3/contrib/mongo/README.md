MongoDB Contrib
===============

  * countTags.js - Report the number of times each tag is used
  * housekeepingAlerts.js - [DEPRECATED] expire timed-out alerts and delete stale ones
    (invoke the /management/housekeeping URL instead)
