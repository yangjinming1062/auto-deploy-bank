module.exports = {
    i18n: {
       // providing the locales supported by your application
      locales: ["en-US"],
      //  default locale used when the non-locale paths are visited
      defaultLocale: "en-US",
    },
}