<!--
 * @Date: 2021-01-17 14:26:41
 * @LastEditors: chentianshang
 * @LastEditTime: 2021-01-17 21:49:18
 * @FilePath: /github-h5-Dooring/doc/zh/guide/functionRealization/pagePreview.md
-->

# 网页预览

我们看看网页预览的工作流程：

<img src="../../../img/functionRealization/preview-flow.png" alt="foo">

前端预览界面：

<img src="../../../img/functionRealization/preview-page.png" alt="foo">
