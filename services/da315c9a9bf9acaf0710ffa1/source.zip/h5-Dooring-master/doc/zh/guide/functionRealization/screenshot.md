<!--
 * @Date: 2021-01-17 14:27:49
 * @LastEditors: chentianshang
 * @LastEditTime: 2021-01-17 21:49:46
 * @FilePath: /github-h5-Dooring/doc/zh/guide/functionRealization/screenshot.md
-->

# 截图功能

截图功能这里我们主要使用了 dom-to-image 这个库，来将 html 转化为图片，并进行分享。

<img src="../../../img/functionRealization/screenshot.png" alt="foo">
