<!--
 * @Date: 2021-01-17 14:27:13
 * @LastEditors: chentianshang
 * @LastEditTime: 2021-01-17 21:49:26
 * @FilePath: /github-h5-Dooring/doc/zh/guide/functionRealization/machinePreview.md
-->

# 真机预览

真机预览和网页预览的流程类似，工作流程如下：

<img src="../../../img/functionRealization/preview-machine.png" alt="foo">

由于不同机型预览的效果有些许不同，最终效果以实际看到的为主。
