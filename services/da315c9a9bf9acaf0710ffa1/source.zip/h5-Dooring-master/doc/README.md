---
content: Home
home: true
#heroImage: ../imgs/common/logo.svg
heroText: 一款所见即所得的H5编辑器
features:
  - title: 简洁方便
    details: 任何人只需傻瓜式拖拽或进行简单编辑即可生成精美的H5页面
  - title: 插拔式体验
    details: 产品以GPL协议开源, 授权后可植入任何系统，并支持二次开发
  - title: 持续迭代，无限可能
    details: 目前正在持续迭代中，后续可根据需求开发功能更强大的可视化系统
actionText: 快速上手 →
actionLink: /zh/guide/
footer: GPL Licensed | Copyright © 2020-present H5-Dooring
---
