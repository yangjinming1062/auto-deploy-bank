const template = {
  type: "CardLabel",
  h: 40,
  displayName: "商品标签"
};
export default template;
