const template = {
  type: "Tab",
  h: 130,
  displayName: "切换页组件"
};
export default template;
