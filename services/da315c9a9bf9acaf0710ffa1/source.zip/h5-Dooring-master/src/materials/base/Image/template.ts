const template = {
  type: "Image",
  h: 80,
  displayName: "图片组件"
};
export default template;
