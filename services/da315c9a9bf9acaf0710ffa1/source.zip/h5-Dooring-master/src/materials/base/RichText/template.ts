const template = {
  type: "RichText",
  h: 120,
  displayName: "富文本组件"
};
export default template;
