const template = {
  type: "Notice",
  h: 20,
  displayName: "通知组件"
};
export default template;
