const template = {
  type: "Qrcode",
  h: 150,
  displayName: "二维码组件"
};
export default template;
