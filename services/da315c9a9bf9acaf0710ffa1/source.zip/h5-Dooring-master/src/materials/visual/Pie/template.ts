const template = {
  type: "Pie",
  h: 106,
  displayName: "饼图组件"
};
export default template;
