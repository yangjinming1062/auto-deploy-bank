const template = {
  type: "XProgress",
  h: 102,
  displayName: "进度条组件"
};
export default template;
