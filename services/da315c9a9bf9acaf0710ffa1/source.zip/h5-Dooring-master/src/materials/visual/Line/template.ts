const template = {
  type: "Line",
  h: 104,
  displayName: "折线图组件"
};
export default template;
