const template = {
  type: "Area",
  h: 108,
  displayName: "面积图组件"
};
export default template;
