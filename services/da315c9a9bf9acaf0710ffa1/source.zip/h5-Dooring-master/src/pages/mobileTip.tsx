import React from "react";
import { Result } from "antd";

function MobileTip() {
  return (
    <div>
      <Result
        status="500"
        title="Dooring热情❤️提示"
        subTitle="你好，客官，请在PC端使用Dooring哦～"
      />
    </div>
  );
}

export default MobileTip;
