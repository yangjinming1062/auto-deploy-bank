import org.junit.Test;
import static org.junit.Assert.*;

public class MyTest {
    @Test
    public void test() {
        assertEquals(2, 1+1);
    }
}