export enum Themes {
  System = 'system',
  Light = 'light',
  Dark = 'dark'
}

export enum Closer {
  Minimize = 'minimize',
  Close = 'close'
}
