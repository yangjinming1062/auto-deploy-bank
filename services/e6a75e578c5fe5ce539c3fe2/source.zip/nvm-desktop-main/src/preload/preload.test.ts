import("wdio-electron-service/preload");

import("./index");
