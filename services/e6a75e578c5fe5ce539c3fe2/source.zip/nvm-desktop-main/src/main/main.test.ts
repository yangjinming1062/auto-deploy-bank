import("wdio-electron-service/main");

import("./main");
