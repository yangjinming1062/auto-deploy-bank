# MLOPS

## Setup

To run the notebooks please install the dependencies from [requirements.txt](requirements.txt)
