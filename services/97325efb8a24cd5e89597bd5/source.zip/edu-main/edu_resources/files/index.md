# Files

Resources needed for the `edu_resources` section belong here: images, etc.
