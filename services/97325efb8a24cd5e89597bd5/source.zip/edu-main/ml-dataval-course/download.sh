wget https://storage.yandexcloud.net/yandex-research/shifts/weather/canonical-partitioned-dataset.tar
tar -xvf canonical-partitioned-dataset.tar