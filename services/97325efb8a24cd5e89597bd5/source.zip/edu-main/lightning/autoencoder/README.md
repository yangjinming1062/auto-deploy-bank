| Notebook    | Link                                                                                                                                                                              |
|-------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| MNIST Autoencoders | [![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](http://wandb.me/lit-ae-colab) |
| Fashion-MNIST Autoencoders | [![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](http://wandb.me/lit-fashion-ae-colab) |
