# Click the badges below to access the notebooks

| Notebook    | Link                                                                                                                                                                              |
|-------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Dataloading | [![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/wandb/edu/blob/main/lightning/perceptron/dataloading.ipynb) |
| Predicting Fives | [![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/wandb/edu/blob/main/lightning/perceptron/perceptron_fives.ipynb) |
| MLP         | [![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/wandb/edu/blob/main/lightning/perceptron/mlp.ipynb) |
