# Changelog

## pdk@0.0.6-beta.2 (2025-12-15)

## What's Changed

### Bug Fixes 🐛

* fix(pdk): support mixed tag formats in changelog generation by @ulivz in d7e6016
* fix(pdk): support custom git tag formats in changelog generation by @ulivz in 70a427f

### Other Changes

* chore: tweaks by @ulivz in a777b4d
* chore(pdk): update changelog for 0.0.6-beta.1 by @ulivz in 7a5645c
* : Revert "fix(pdk): support mixed tag formats in changelog generation" by @ulivz in d2d9cb7

**Full Changelog**: [pdk@0.0.6-beta.1...pdk@0.0.6-beta.2](https://github.com/bytedance/UI-TARS-desktop/compare/pdk@0.0.6-beta.1...pdk@0.0.6-beta.2)
## vpdk@0.0.5 (2025-12-09)

## What's Changed

Release pdk@0.0.5
