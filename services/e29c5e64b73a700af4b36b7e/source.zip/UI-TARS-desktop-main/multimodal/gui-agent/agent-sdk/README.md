# @multimodal/seed-gui-agent

Seed GUI Agent.

## Installation

```bash
npm install @multimodal/seed-gui-agent
```

## Usage

// TODO