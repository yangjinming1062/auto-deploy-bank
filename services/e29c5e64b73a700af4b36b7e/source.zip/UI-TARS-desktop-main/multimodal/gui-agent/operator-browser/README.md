# @gui-agent/operator-browser

WIP

## Roadmap

- [x] Support UI-TARS and Seed-1.5 VL Model
- [ ] Support Claude Model