# @agent-tars/interface

Standard protocol, types design, api design for Agent TARS ecology (core, server, cli, app etc.)

