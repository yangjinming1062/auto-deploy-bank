import { agent } from '../default';
export { agent };
export const runOptions = {
  input: `帮我调研一下 ByteDance 大模型的发展情况，给出一份完整的报告

我期待覆盖的信息： 

1. Seed 大模型现状；
2. 大模型应用场景；
3. 开源项目；
4. 行业影响力；
5. 未来发展；

要求报告输出中文。`,
};
