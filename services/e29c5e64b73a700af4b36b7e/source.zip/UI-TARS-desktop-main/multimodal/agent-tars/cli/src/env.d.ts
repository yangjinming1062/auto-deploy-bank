declare const __BUILD_TIME__: number;
declare const __GIT_HASH__: string;
