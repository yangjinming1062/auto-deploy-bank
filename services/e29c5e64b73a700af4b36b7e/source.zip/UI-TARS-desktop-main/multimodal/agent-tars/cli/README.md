# @agent-tars/cli

A command-line interface for Agent TARS.

## Installation

```bash
# Install globally
npm install -g @agent-tars/cli

# Or use directly via npx
npx @agent-tars/cli
