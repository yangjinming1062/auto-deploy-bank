// IMPORTANT: can't change the name of the chunk, avoid private key leak
export const appPrivateKeyBase64 = process.env.UI_TARS_APP_PRIVATE_KEY_BASE64;
