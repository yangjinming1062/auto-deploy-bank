🔔 We apologize, but the deployment guide for UI-TARS-1.0 has been deprecated and is no longer maintained. For deploying UI-TARS-1.0, please refer to [archive/deployment.md](./archive-1.0/deployment.md).

However, we have great news! ✨ UI-TARS-1.5 is now available with significant improvements. For the latest deployment instructions, please refer to our official deployment guide:

- [UI-TARS-1.5 Deployment Guide](https://github.com/bytedance/UI-TARS/blob/main/README_deploy.md)
- [UI-TARS 模型部署教程](https://bytedance.sg.larkoffice.com/docx/TCcudYwyIox5vyxiSDLlgIsTgWf)

Thank you for your understanding and continued support as we strive to provide better performance and user experience! 🙌
