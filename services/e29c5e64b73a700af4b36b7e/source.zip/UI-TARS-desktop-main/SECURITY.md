# Security Policy

## Supported Versions

Here are the versions are currently being supported with security updates.

| Version | Supported          |
| ------- | ------------------ |
| 0.0.x   | :white_check_mark: |

## Reporting a Vulnerability

If you find any vulnerability issue, please report it to https://github.com/bytedance/UI-TARS-desktop/security.
We will get touch with you shortly.

## Security Advisories

We will publish security advisories for the latest version.

