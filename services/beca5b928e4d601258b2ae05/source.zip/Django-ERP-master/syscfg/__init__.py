
default_app_config = 'syscfg.apps.SysConfig'