/**
 * Created by Administrator on 15-5-23.
 */
(function($) {
            $(document).ready(function() {
                /**
                set operation type
                */
                $("#woextravalue_set-group select").attr('readonly','true')
            });
})(django.jQuery);
