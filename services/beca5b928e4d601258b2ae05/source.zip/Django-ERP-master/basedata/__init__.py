
default_app_config = 'basedata.apps.BaseDataConfig'