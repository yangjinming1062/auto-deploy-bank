import sys
sys.path.append("./")
from llava.train.train import train

if __name__ == "__main__":
    train()
