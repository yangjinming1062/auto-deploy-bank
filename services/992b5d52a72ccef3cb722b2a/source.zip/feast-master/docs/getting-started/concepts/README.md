# Concepts

{% content-ref url="overview.md" %}
[overview.md](overview.md)
{% endcontent-ref %}

{% content-ref url="project.md" %}
[project.md](project.md)
{% endcontent-ref %}

{% content-ref url="data-ingestion.md" %}
[data-ingestion.md](data-ingestion.md)
{% endcontent-ref %}

{% content-ref url="entity.md" %}
[entity.md](entity.md)
{% endcontent-ref %}

{% content-ref url="feature-view.md" %}
[feature-view.md](feature-view.md)
{% endcontent-ref %}

{% content-ref url="batch-feature-view.md" %}
[batch-feature-view.md](batch-feature-view.md)
{% endcontent-ref %}

{% content-ref url="stream-feature-view.md" %}
[stream-feature-view.md](stream-feature-view.md)
{% endcontent-ref %}

{% content-ref url="tiling.md" %}
[tiling.md](tiling.md)
{% endcontent-ref %}

{% content-ref url="feature-retrieval.md" %}
[feature-retrieval.md](feature-retrieval.md)
{% endcontent-ref %}

{% content-ref url="point-in-time-joins.md" %}
[point-in-time-joins.md](point-in-time-joins.md)
{% endcontent-ref %}

{% content-ref url="dataset.md" %}
[dataset.md](dataset.md)
{% endcontent-ref %}

{% content-ref url="permission.md" %}
[permission.md](permission.md)
{% endcontent-ref %}

{% content-ref url="tags.md" %}
[tags.md](tags.md)
{% endcontent-ref %}
