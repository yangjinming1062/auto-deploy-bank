# Registies

Please see [Registry](../../getting-started/components/registry.md) for a conceptual explanation of registries.

{% content-ref url="metadata.md" %}
[metadata.md](metadata.md)
{% endcontent-ref %}

{% content-ref url="local.md" %}
[local.md](local.md)
{% endcontent-ref %}

{% content-ref url="s3.md" %}
[s3.md](s3.md)
{% endcontent-ref %}

{% content-ref url="gcs.md" %}
[gcs.md](gcs.md)
{% endcontent-ref %}

{% content-ref url="sql.md" %}
[sql.md](sql.md)
{% endcontent-ref %}

{% content-ref url="snowflake.md" %}
[snowflake.md](snowflake.md)
{% endcontent-ref %}

{% content-ref url="hdfs.md" %}
[hdfs.md](hdfs.md)
{% endcontent-ref %}

{% content-ref url="remote.md" %}
[remote.md](remote.md)
{% endcontent-ref %}
