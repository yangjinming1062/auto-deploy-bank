# Providers

Please see [Provider](../../getting-started/components/provider.md) for an explanation of providers.

{% page-ref page="local.md" %}

{% page-ref page="google-cloud-platform.md" %}

{% page-ref page="amazon-web-services.md" %}

{% page-ref page="azure.md" %}
