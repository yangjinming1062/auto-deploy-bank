# Blog Posts

Welcome to the Feast blog! Here you'll find articles about feature store development, new features, and community updates.

## Featured Posts

{% content-ref url="what-is-a-feature-store.md" %}
[what-is-a-feature-store.md](what-is-a-feature-store.md)
{% endcontent-ref %}

{% content-ref url="the-future-of-feast.md" %}
[the-future-of-feast.md](the-future-of-feast.md)
{% endcontent-ref %}

{% content-ref url="feast-supports-vector-database.md" %}
[feast-supports-vector-database.md](feast-supports-vector-database.md)
{% endcontent-ref %}

{% content-ref url="rbac-role-based-access-controls.md" %}
[rbac-role-based-access-controls.md](rbac-role-based-access-controls.md)
{% endcontent-ref %}
