# Role Creation and Cloning

ConsoleMe allows your cloud administrators to create and clone roles across your accounts. The role creation feature will create an empty role and provide the user with a link to that role's policy editor within ConsoleMe after creation.

ConsoleMe can clone a role's inline policies, managed policies, assume role policy document, tags, and description.

![](../../.gitbook/assets/image%20%286%29.png)

