# AWS Credential Broker

ConsoleMe provides an AWS credential broker that serves temporary IAM credentials for your IAM roles. Please take a look at [Weep](../../weep-cli/aws-credentials-in-the-cli-using-weep.md), our CLI utility, for examples of the different ways your users can retrieve and use credentials locally.

