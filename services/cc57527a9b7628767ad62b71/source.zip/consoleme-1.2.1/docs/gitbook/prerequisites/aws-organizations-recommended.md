# AWS Organizations \(Recommended\)

Organizations is the preferred way to index your account information.
