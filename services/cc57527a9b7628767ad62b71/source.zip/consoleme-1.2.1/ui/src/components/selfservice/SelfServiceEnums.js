const SelfServiceStepEnum = Object.freeze({
  STEP1: 1,
  STEP2: 2,
  STEP3: 3,
});

export { SelfServiceStepEnum };
