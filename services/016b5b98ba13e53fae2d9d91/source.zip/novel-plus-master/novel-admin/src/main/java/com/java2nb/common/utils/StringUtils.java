package com.java2nb.common.utils;

/**
 * @author xiongxy
 */
public class StringUtils extends org.apache.commons.lang3.StringUtils{
}
