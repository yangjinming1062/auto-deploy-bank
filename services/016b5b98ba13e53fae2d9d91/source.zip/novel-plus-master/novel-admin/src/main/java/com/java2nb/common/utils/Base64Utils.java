package com.java2nb.common.utils;

public class Base64Utils {
	
}
