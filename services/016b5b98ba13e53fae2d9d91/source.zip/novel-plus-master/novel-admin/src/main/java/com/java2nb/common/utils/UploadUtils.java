package com.java2nb.common.utils;

public class UploadUtils {

}
