alter table book_comment add column location varchar(50) DEFAULT NULL COMMENT '地理位置' after comment_content ;


