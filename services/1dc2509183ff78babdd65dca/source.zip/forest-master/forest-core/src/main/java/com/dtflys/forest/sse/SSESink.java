package com.dtflys.forest.sse;

public interface SSESink {
    
    SSESink next(Object data);
    
}
