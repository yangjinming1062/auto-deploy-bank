package com.dtflys.forest.http;

public enum ForestProxyType {

    /**
     * HTTP协议的代理
     */
    HTTP,

    /**
     * SOCKS协议的代理
     */
    SOCKS,

}
