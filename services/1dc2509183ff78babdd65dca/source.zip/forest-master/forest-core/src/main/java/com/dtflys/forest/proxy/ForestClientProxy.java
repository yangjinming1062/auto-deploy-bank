package com.dtflys.forest.proxy;

/**
 * @author gongjun[jun.gong@thebeastshop.com]
 * @since 2018-09-25 17:26
 */
public interface ForestClientProxy {

    InterfaceProxyHandler getProxyHandler();

}
