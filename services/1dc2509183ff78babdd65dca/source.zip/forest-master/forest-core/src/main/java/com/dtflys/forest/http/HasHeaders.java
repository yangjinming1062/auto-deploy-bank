package com.dtflys.forest.http;

public interface HasHeaders {

    ForestHeaderMap getHeaders();

}
