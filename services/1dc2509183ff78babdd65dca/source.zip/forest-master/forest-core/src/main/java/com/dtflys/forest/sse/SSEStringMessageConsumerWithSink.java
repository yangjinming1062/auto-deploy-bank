package com.dtflys.forest.sse;

/**
 * 字符串类型 SSE 消息消费者
 * 
 * @since 1.6.0
 */
@FunctionalInterface
public interface SSEStringMessageConsumerWithSink extends SSEMessageConsumerWithSink<String> {


}
