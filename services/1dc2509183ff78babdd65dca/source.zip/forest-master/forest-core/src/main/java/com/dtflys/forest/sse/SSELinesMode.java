package com.dtflys.forest.sse;

public enum SSELinesMode {
    
    SINGLE_LINE,

    MULTI_LINES,
    
    AUTO,
    
}
