package com.dtflys.forest.mapping;

/**
 * @author gongjun
 * @since 2016-05-12
 */
public class MappingNameValue {

    private String name;

    private MappingTemplate value;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public MappingTemplate getValue() {
        return value;
    }

    public void setValue(MappingTemplate value) {
        this.value = value;
    }

}
