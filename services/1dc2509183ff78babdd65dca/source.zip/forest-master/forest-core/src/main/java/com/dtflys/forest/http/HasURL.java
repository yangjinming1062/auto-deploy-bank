package com.dtflys.forest.http;

public interface HasURL {

    ForestURL url();
}
