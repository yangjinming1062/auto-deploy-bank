package com.dtflys.forest.mapping;

public class MappingCompileContext {

    int readIndex = -1;

    int argumentIndex = -1;
}
