package com.dtflys.forest.backend;

import java.util.concurrent.ThreadPoolExecutor;

public class AsyncCallerRunsPolicy extends ThreadPoolExecutor.CallerRunsPolicy {

}
