package com.dtflys.forest.interceptor;

public enum ResponseResultStatus {

    // 响应成功
    SUCCESS,

    // 响应时发生错误
    ERROR,

    // 继续执行
    PROCEED,

    // 结束执行
    STOP,

}
