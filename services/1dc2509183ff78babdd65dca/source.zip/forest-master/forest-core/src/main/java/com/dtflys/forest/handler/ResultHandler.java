package com.dtflys.forest.handler;

import com.dtflys.forest.backend.ContentType;
import com.dtflys.forest.converter.ForestConverter;
import com.dtflys.forest.exceptions.ForestHandlerException;
import com.dtflys.forest.result.ByteArrayResultHandler;
import com.dtflys.forest.result.FutureResultHandler;
import com.dtflys.forest.result.InputStreamResultHandler;
import com.dtflys.forest.result.ResponseResultHandler;
import com.dtflys.forest.result.ResultTypeHandler;
import com.dtflys.forest.result.ResultTypeHandlerManager;
import com.dtflys.forest.result.SSEResultHandler;
import com.dtflys.forest.http.ForestRequest;
import com.dtflys.forest.http.ForestResponse;
import com.dtflys.forest.http.Res;
import com.dtflys.forest.lifecycles.file.DownloadLifeCycle;
import com.dtflys.forest.utils.ForestDataType;
import com.dtflys.forest.utils.ReflectUtils;

import java.io.File;
import java.io.InputStream;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Optional;

/**
 * @author gongjun[jun.gong@thebeastshop.com]
 * @since 2016-05-04
 */
public class ResultHandler {

    protected boolean isReceivedResponseData(Res response) {
        if (response == null) {
            return false;
        }
        return response.isReceivedResponseData();
    }

    /**
     * 进行转换并获取结果
     *
     * @param request Forest 请求对象
     * @param response Forest 响应对象
     * @param resultType {@link Type} 实例
     * @return 转换后的对象
     * @since 1.5.27
     */
    public Object getResult(ForestRequest request, Res response, Type resultType) {
        final Class<?> clazz = ReflectUtils.toClass(resultType);
        return getResult(null, request, response, resultType, clazz);
    }

    public Object getResult(Optional<?> resultOpt, ForestRequest request, Res response, Type resultType) {
        final Class<?> clazz = ReflectUtils.toClass(resultType);
        return getResult(resultOpt, request, response, resultType, clazz);
    }


    /**
     * 进行转换并获取结果
     *
     * @param request Forest 请求对象
     * @param response Forest 响应对象
     * @param resultClass {@link Class} 实例
     * @return 转换后的对象
     * @since 1.5.27
     */
    public Object getResult(ForestRequest request, Res response, Class resultClass) {
        final Type type = ReflectUtils.toType(resultClass);
        return getResult(null, request, response, type, resultClass);
    }

    public Object getResult(Optional<?> resultOpt, ForestRequest request, Res response, Class resultClass) {
        final Type type = ReflectUtils.toType(resultClass);
        return getResult(resultOpt, request, response, type, resultClass);
    }



    public Object getResult(Optional<?> resultOpt, ForestRequest request, Res response, Type resultType, Class resultClass) {
        String optStringValue = null;
        if (resultOpt != null) {
            if (Optional.class.isAssignableFrom(resultClass)) {
                return resultOpt;
            }
            final Object optValue = resultOpt.orElse(null);
            if (optValue == null) {
                return null;
            }
            final Class<?> optValueClass = optValue.getClass();
            if (ReflectUtils.isAssignableFrom(resultClass, optValueClass)) {
                return optValue;
            }
            if (Res.class.isAssignableFrom(resultClass)) {
                final ParameterizedType parameterizedType = ReflectUtils.toParameterizedType(resultType);
                if (parameterizedType == null) {
                    response.setResult(optValue);
                    return response;
                }
                final Type[] argTypes = parameterizedType.getActualTypeArguments();
                if (argTypes.length == 0) {
                    response.setResult(optValue);
                    return response;
                }
                final Type argType = argTypes[0];
                final Class argClass = ReflectUtils.toClass(argType);
                if (argClass.isAssignableFrom(optValueClass)) {
                    response.setResult(optValue);
                    return response;
                }
            }
            if (ReflectUtils.isPrimaryType(optValueClass)) {
                optStringValue = String.valueOf(optValue);
            }
        }
        if (request.isDownloadFile()) {
            return null;
        }
        if (isReceivedResponseData(response)) {
            try {
                if (void.class.isAssignableFrom(resultClass) || Void.class.isAssignableFrom(resultClass)) {
                    return null;
                }
                // 处理特殊类型
                final ResultTypeHandlerManager resultTypeHandlerManager = request.getConfiguration().getResultTypeHandlerManager();
                final ResultTypeHandler resultTypeHandler = resultTypeHandlerManager.matchHandler(resultClass, resultType);
                if (resultTypeHandler != null) {
                    return resultTypeHandler.getResult(resultOpt, request, response, resultType, resultClass, this);
                }
                
                final Object attFile = request.getAttachment(DownloadLifeCycle.ATTACHMENT_NAME_FILE);
                if (attFile != null && attFile instanceof File) {
                    final ForestConverter converter = request.getConfiguration().getConverter(ForestDataType.JSON);
                    return converter.convertToJavaObject(attFile, resultClass);
                }
                String responseText = null;
                if (CharSequence.class.isAssignableFrom(resultClass)) {
                    try {
                        responseText = optStringValue != null ? optStringValue : response.readAsString();
                    } catch (Throwable th) {
                        request.getLifeCycleHandler().handleError(request, (ForestResponse) response, th);
                    }
                }
                else {
                    try {
                        responseText = optStringValue != null ? optStringValue : null;
                    } catch (Throwable th) {
                        request.getLifeCycleHandler().handleError(request, (ForestResponse) response, th);
                    }
                }
//                if (responseText != null) {
//                    response.setContent(responseText);
//                }
//                if (InputStream.class.isAssignableFrom(resultClass)) {
//                    return response.getInputStream();
//                }
                final ContentType contentType = response.getContentType();
                final ForestConverter decoder = request.getDecoder();

                if (responseText != null && CharSequence.class.isAssignableFrom(resultClass)) {
                    return responseText;
                }

                final ForestDataType dataType = request.getDataType();
                final ForestConverter converter = decoder != null ? decoder : request.getConfiguration().getConverter(dataType);
                if (responseText != null && contentType != null && contentType.canReadAsString()) {
                    return converter.convertToJavaObject(responseText, resultType);
                }
                Charset charset = null; 
                String resCharset = response.getCharset();
                if (resCharset != null) {
                    charset = Charset.forName(resCharset);
                }
                if (optStringValue != null) {
                    return converter.convertToJavaObject(optStringValue.getBytes(StandardCharsets.UTF_8), resultType, charset);
                }

                try (InputStream inputStream = response.getInputStream()) {
                    return converter.convertToJavaObject(inputStream, resultType, charset);
                } finally {
                    response.close();
                }
            } catch (Exception e) {
                throw new ForestHandlerException(e, request, (ForestResponse) response);
            }
        }
        else if (Res.class.isAssignableFrom(resultClass)) {
            return response;
        }
        return null;
    }

}
