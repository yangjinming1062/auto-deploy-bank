package com.dtflys.forest.sse;

public enum SSEMessageResult {

    PROCEED,

    CLOSE,

}
