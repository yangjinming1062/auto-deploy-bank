package com.fc.v2.common.dataSources;

/**
 * 列出所有数据源
 * @ClassName: DataSourceType
 * @author fuce
 * @date 2019-12-06 21:02
 */
public enum DataSourceType {
	MASTER,
	SLAVE
}