package mirror.tasks;

public interface TaskHandle {

  void stop();

}
