package mirror.watchman;

public class WatchmanOverflowException extends RuntimeException {

  private static final long serialVersionUID = 1L;

}
