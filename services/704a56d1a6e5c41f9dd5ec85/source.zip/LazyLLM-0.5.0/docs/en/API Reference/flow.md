::: lazyllm.flow.FlowBase
    members: is_root, ancestor, for_each
    exclude-members:

::: lazyllm.flow.Pipeline
    members: 
    exclude-members:

::: lazyllm.flow.Parallel
    members: 
    exclude-members:

::: lazyllm.flow.Diverter
    members: 
    exclude-members:

::: lazyllm.flow.Warp
    members: 
    exclude-members:

::: lazyllm.flow.IFS
    members: 
    exclude-members:

::: lazyllm.flow.Switch
    members: 
    exclude-members:

::: lazyllm.flow.Loop
    members: 
    exclude-members: