from lazynote.parser.base import BaseParser

__all__ = [
    'BaseParser',
]
