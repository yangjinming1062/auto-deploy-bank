from .serve import InferServer
from .client import InferClient

__all__ = [
    'InferServer',
    'InferClient',
]
