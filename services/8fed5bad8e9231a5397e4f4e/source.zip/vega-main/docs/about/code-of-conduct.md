---
layout: about
title: Code of Conduct
permalink: /about/code-of-conduct/index.html
---

Moved to [GitHub](https://github.com/vega/.github/blob/master/CODE_OF_CONDUCT.md).
