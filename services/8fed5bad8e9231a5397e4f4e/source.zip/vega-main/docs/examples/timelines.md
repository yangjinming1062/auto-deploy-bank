---
layout: example
title: Timelines Example
permalink: /examples/timelines/index.html
spec: timelines
image: /examples/img/timelines.png
---

A custom timeline visualization showing the lifespans of the first five U.S. presidents, including the years each held office. The timeline is additionally annotated with selected historical events.

{% include example spec=page.spec %}
