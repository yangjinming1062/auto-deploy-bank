---
layout: example
title: Area Chart Example
permalink: /examples/area-chart/index.html
spec: area-chart
image: /examples/img/area-chart.png
---

An area chart uses a filled shape to show changes in a quantitative value.

{% include example spec=page.spec %}
