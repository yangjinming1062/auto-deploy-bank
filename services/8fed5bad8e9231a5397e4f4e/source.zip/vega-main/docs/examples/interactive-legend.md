---
layout: example
title: Interactive Legend Example
permalink: /examples/interactive-legend/index.html
spec: interactive-legend
image: /examples/img/interactive-legend.png
---

A scatter plot with interactive guides. Shift-click legend entries to select subsets of the data, or drag along the x-axis to create a 1D brush. Click the chart background to clear all selections.

{% include example spec=page.spec %}
