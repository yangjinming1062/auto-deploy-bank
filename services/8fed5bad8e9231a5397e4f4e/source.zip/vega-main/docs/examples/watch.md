---
layout: example
title: Watch Example
permalink: /examples/watch/index.html
spec: watch
image: /examples/img/watch.png
---

A watch face by [@domoritz](http://github.com/domoritz/), inspired by [Braun](https://en.wikipedia.org/wiki/Braun_(company))'s design and [@mathiastiberghien](https://github.com/mathiastiberghien)'s clock example.

{% include example spec=page.spec %}
