---
layout: example
title: Labelled Donut Chart Example
permalink: /examples/donut-chart-labelled/index.html
spec: donut-chart-labelled
image: /examples/img/donut-chart-labelled.png
---

A donut chart with non overlapping labels using native Vega transforms. 

This Vega example made by David Bacci [@PBI-David](https://github.com/PBI-David).

{% include example spec=page.spec %}
