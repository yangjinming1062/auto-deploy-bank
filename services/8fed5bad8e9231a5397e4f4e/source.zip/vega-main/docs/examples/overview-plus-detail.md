---
layout: example
title: Overview Plus Detail Example
permalink: /examples/overview-plus-detail/index.html
spec: overview-plus-detail
image: /examples/img/overview-plus-detail.png
---

An overview + detail interaction: click and drag in the overview to zoom the larger detail view. Based on a [D3 example](http://bl.ocks.org/mbostock/1667367) by Mike Bostock.

{% include example spec=page.spec %}
