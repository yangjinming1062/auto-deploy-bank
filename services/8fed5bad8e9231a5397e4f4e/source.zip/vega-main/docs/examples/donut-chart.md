---
layout: example
title: Donut Chart Example
permalink: /examples/donut-chart/index.html
spec: donut-chart
image: /examples/img/donut-chart.png
---

A donut chart encodes proportional differences among a set of numeric values using angular extents.

{% include example spec=page.spec %}
