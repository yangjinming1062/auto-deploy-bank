---
layout: example
title: Grouped Bar Chart Example
permalink: /examples/grouped-bar-chart/index.html
spec: grouped-bar-chart
image: /examples/img/grouped-bar-chart.png
---

This grouped bar chart facets the data into groups, then creates a bar chart for each sub-group.

{% include example spec=page.spec %}
