---
layout: example
title: Zoomable Scatter Plot Example
permalink: /examples/zoomable-scatter-plot/index.html
spec: zoomable-scatter-plot
image: /examples/img/zoomable-scatter-plot.png
---

Interactive scatter plot that can pan and zoom. Click and drag to pan, use the scroll wheel to zoom. Scatter plot points also adjust their size in response to the zoom level.

{% include example spec=page.spec %}
