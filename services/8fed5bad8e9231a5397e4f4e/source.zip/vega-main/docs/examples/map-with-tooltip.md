---
layout: example
title: Custom Tooltip
permalink: /examples/map-with-tooltip/index.html
spec: map-with-tooltip
image: /examples/img/map-with-tooltip.png
---

An example of a custom tooltip: a map featuring a circular, semi-transparent tooltip that displays information about the county under the cursor.

This Vega example made by Andrzej Leszkiewicz [@avatorl](https://github.com/avatorl)

{% include example spec=page.spec %}
