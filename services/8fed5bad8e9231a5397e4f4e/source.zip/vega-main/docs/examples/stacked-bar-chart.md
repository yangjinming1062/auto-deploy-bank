---
layout: example
title: Stacked Bar Chart Example
permalink: /examples/stacked-bar-chart/index.html
spec: stacked-bar-chart
image: /examples/img/stacked-bar-chart.png
---

A stacked bar chart depicts the sum of series of quantitative values using layered bars, while still enabling inspection of individual series.

{% include example spec=page.spec %}
