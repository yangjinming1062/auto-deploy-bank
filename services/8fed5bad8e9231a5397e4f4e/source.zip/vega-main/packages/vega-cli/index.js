export { default } from 'vega';
