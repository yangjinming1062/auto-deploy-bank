https://www.sqlchat.ai/
to do:
- code refractoring