https://chat.gpt.bz

to do:
- code refractoring