"""
Simple Echo Bot LLM - echoes back user input for testing purposes
No external dependencies required
"""

def load_model():
    """Load the echo model - no actual loading needed"""
    print("Echo Bot model loaded successfully")


def chat_init(history):
    """Initialize chat history"""
    return history


def chat_one(prompt, history_formatted, max_length, top_p, temperature, data):
    """Echo back the user's input with a prefix"""
    response = f"Echo: {prompt}\n\n[This is a test echo response. Please configure a real LLM model for actual functionality.]"
    full_response = ""
    for char in response:
        full_response += char
        yield full_response


class Lock:
    """Dummy lock for compatibility"""
    def __init__(self):
        pass

    def get_waiting_threads(self):
        return 0

    def __enter__(self):
        pass

    def __exit__(self, exc_type, exc_val, exc_tb):
        pass