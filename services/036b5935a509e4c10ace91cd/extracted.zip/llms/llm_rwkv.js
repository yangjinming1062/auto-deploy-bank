app.temperature=1.3
app.top_p=0.5
app.llm_type='rwkv'
// app.history_on=true
app.history_limit=0