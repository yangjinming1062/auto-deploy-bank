// ==UserScript==
// @name         rtst知识库
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  调试rtst知识库功能
// @author       lyyyyy
// @match        http://127.0.0.1:17860/
// @icon         https://www.google.com/s2/favicons?sz=64&domain=0.1
// @run-at document-idle
// @grant        none
// ==/UserScript==
app.plugins.push({ icon:'book-education-outline', url: "static/st.html" })