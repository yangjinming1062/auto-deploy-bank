app.llm_type='openai'
app.history_limit=0