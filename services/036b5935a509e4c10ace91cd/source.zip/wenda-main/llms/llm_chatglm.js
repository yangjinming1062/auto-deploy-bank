app.llm_type='glm6b'
