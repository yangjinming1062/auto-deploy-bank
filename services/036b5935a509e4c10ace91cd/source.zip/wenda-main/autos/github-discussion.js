// ==UserScript==
// @name         交流界面
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  提供闻达交流讨论链接
// @author       You
// @match        http://127.0.0.1:17860/
// @icon         https://www.google.com/s2/favicons?sz=64&domain=0.1
// @grant        none
// ==/UserScript==
app.plugins.push({ icon:"chat-alert-outline", url: "static/tl.html" })