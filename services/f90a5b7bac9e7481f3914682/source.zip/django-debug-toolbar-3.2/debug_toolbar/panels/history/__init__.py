from debug_toolbar.panels.history.panel import HistoryPanel  # noqa
