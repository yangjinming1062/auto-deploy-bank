package org.kohsuke.github;

// TODO: Auto-generated Javadoc
/**
 * The enum GHMilestoneState.
 *
 * @author Yusuke Kokubo
 */
public enum GHMilestoneState {

    /** The closed. */
    CLOSED,
    /** The open. */
    OPEN
}
