package org.kohsuke.github;

// TODO: Auto-generated Javadoc
/**
 * Sort direction.
 *
 * @author Kohsuke Kawaguchi
 */
public enum GHDirection {

    /** The asc. */
    ASC,
    /** The desc. */
    DESC
}
