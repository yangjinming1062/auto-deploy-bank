#!/usr/bin/env bash

# the key used for debugging
test_key="sk-___"

# one or multiple keys used for running experiments
declare -a keys=(
    "sk-____"
    "sk-____"
    "sk-____"
)
