### Standalong WSGI example

This directory contains a simple Python wrapper that runs the sqlite-web WSGI
application under a different WSGI server.
