package com.baomidou.mybatisplus.test.h2.issues.genericid.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.test.h2.issues.genericid.entity.LongEntity;

/**
 * long mapper
 *
 * @author nieqiuqiu
 * @date 2019-12-20
 */
public interface LongEntityMapper extends BaseMapper<LongEntity> {

}
