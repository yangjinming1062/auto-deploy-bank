package com.baomidou.mybatisplus.test.enums;

import lombok.Getter;

/**
 * @author miemie
 * @since 2020-07-21
 */
@Getter
public enum EnumOrdinal {
    ONE,
    TWO,
}
