package com.baomidou.mybatisplus.test.h2.fillperformance.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.test.h2.fillperformance.model.PerformanceModel;

public interface PerformanceModelMapper extends BaseMapper<PerformanceModel> {

}
