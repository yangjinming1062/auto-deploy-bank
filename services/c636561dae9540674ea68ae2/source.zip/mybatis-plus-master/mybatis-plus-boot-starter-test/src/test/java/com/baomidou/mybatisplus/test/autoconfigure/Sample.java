package com.baomidou.mybatisplus.test.autoconfigure;

import lombok.Data;

/**
 * @author miemie
 * @since 2020-05-27
 */
@Data
public class Sample {
    private Long id;
    private String name;
}
