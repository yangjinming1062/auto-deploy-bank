Please consult https://docs.bokeh.org/en/latest/docs/dev_guide.html for more
information about contributing to BokehJS.
