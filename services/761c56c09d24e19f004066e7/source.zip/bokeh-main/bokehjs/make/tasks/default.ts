import {task} from "../task"

task("default", ["build"])
