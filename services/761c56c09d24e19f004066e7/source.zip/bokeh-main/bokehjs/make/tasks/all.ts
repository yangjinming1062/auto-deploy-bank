import {task} from "../task"

task("all", ["build", "examples", "test"])
