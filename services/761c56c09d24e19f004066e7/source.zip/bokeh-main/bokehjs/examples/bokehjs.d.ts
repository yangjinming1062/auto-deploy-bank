declare module "*/bokeh.esm.js" {
  export * from "index"
  export * from "api"
}
