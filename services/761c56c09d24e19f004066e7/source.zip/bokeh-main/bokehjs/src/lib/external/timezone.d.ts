declare module "timezone" {
  export default function timezone(value: unknown, format?: string): string
}
