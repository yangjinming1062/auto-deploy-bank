declare module "*.vert" {
  declare const shader: string
  export default shader
}

declare module "*.frag" {
  declare const shader: string
  export default shader
}
