BokehJS is a subproject of Bokeh. Please consult the CHANGELOG at

    https://github.com/bokeh/bokeh/blob/master/CHANGELOG

for full information.
