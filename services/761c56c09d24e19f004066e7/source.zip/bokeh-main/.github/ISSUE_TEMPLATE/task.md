---
name: Task (Dev Team only)
about: Tasks - for Dev Team members only
title: ""
labels: TRIAGE
assignees: ""

---

### Development Team members only

This template is for use only by [Development Team members (@bokeh/dev)](https://github.com/bokeh/bokeh/wiki/BEP-4:-Project-Roles#development-team) to quickly add issues for tasks (Dev Team members are still encouraged to use the regular issue templates, if possible).

If you want to report a bug or request a feature, please [go back](https://github.com/bokeh/bokeh/issues/new/choose) and click on "Bug report" or "Feature request".
