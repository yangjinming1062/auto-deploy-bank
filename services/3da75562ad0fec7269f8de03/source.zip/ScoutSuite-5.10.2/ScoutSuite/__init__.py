__author__ = 'NCC Group'
__version__ = '5.10.2'

ERRORS_LIST = []

DEFAULT_REPORT_DIRECTORY = 'scoutsuite-report'
DEFAULT_REPORT_RESULTS_DIRECTORY = 'scoutsuite-results'
DEFAULT_INCLUDES_DIRECTORY = 'inc-scoutsuite'
