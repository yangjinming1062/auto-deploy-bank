COLLECTION_NAME = 'Homepage Assets'
