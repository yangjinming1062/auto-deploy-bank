import _ from 'underscore';
import Backbone from 'backbone';

var girderEvents = _.clone(Backbone.Events);

export default girderEvents;
