function jQuery(arg1, arg2) {}
jQuery.prototype.velocity = function() {};
