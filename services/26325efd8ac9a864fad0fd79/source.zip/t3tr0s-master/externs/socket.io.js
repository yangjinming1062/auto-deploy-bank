function io() {};
io.prototype.connect = function() {};
io.prototype.emit = function() {};
io.prototype.on = function() {};
io.prototype.removeListener = function() {};
io.prototype.removeAllListeners = function() {};