import styled from 'styled-components';

export default styled;

export * from 'styled-components';
