export const CLOSE_SIGN = 'modern_close_server';
