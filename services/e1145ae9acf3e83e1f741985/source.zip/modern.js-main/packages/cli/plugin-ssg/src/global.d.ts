declare module 'normalize-path';
