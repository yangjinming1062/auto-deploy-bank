export const LOADER_ID_PARAM = '__loader';
export const DIRECT_PARAM = '__ssrDirect';
export const CONTENT_TYPE_DEFERRED = 'text/modernjs-deferred';
