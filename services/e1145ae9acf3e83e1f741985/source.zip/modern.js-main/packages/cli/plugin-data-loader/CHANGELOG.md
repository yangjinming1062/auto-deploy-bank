# @modern-js/plugin-data-loader

## 3.0.0-alpha.1

### Patch Changes

- @modern-js/runtime-utils@3.0.0-alpha.1
- @modern-js/utils@3.0.0-alpha.1

## 3.0.0-alpha.0

### Patch Changes

- @modern-js/runtime-utils@3.0.0-alpha.0
- @modern-js/utils@3.0.0-alpha.0

## 2.68.1

### Patch Changes

- @modern-js/runtime-utils@2.68.1
- @modern-js/utils@2.68.1

## 2.68.0

### Patch Changes

- @modern-js/runtime-utils@2.68.0
- @modern-js/utils@2.68.0

## 2.67.11

### Patch Changes

- @modern-js/runtime-utils@2.67.11
- @modern-js/utils@2.67.11

## 2.67.10

### Patch Changes

- @modern-js/runtime-utils@2.67.10
- @modern-js/utils@2.67.10

## 2.67.9

### Patch Changes

- @modern-js/runtime-utils@2.67.9
- @modern-js/utils@2.67.9

## 2.67.8

### Patch Changes

- Updated dependencies [23c8201]
  - @modern-js/utils@2.67.8
  - @modern-js/runtime-utils@2.67.8

## 2.67.7

### Patch Changes

- @modern-js/runtime-utils@2.67.7
- @modern-js/utils@2.67.7

## 2.67.6

### Patch Changes

- @modern-js/runtime-utils@2.67.6
- @modern-js/utils@2.67.6

## 2.67.5

### Patch Changes

- @modern-js/runtime-utils@2.67.5
- @modern-js/utils@2.67.5

## 2.67.4

### Patch Changes

- b00922e: feat: support plugin-router-v7
  feat: support plugin-router-v7
- Updated dependencies [3a66335]
- Updated dependencies [03cf233]
- Updated dependencies [446939a]
- Updated dependencies [446939a]
- Updated dependencies [b00922e]
- Updated dependencies [446939a]
  - @modern-js/runtime-utils@2.67.4
  - @modern-js/utils@2.67.4

## 2.67.3

### Patch Changes

- @modern-js/runtime-utils@2.67.3
- @modern-js/utils@2.67.3

## 2.67.2

### Patch Changes

- Updated dependencies [8f97aae]
  - @modern-js/runtime-utils@2.67.2
  - @modern-js/utils@2.67.2

## 2.67.1

### Patch Changes

- Updated dependencies [1d96265]
  - @modern-js/utils@2.67.1
  - @modern-js/runtime-utils@2.67.1

## 2.67.0

### Patch Changes

- @modern-js/runtime-utils@2.67.0
- @modern-js/utils@2.67.0

## 2.66.0

### Patch Changes

- @modern-js/runtime-utils@2.66.0
- @modern-js/utils@2.66.0

## 2.65.5

### Patch Changes

- Updated dependencies [90a3c1c]
- Updated dependencies [58a1afd]
  - @modern-js/runtime-utils@2.65.5
  - @modern-js/utils@2.65.5

## 2.65.4

### Patch Changes

- Updated dependencies [0d47cb8]
- Updated dependencies [f1cd095]
  - @modern-js/utils@2.65.4
  - @modern-js/runtime-utils@2.65.4

## 2.65.3

### Patch Changes

- Updated dependencies [087ae7c]
  - @modern-js/runtime-utils@2.65.3
  - @modern-js/utils@2.65.3

## 2.65.2

### Patch Changes

- 793be44: feat: support get monitors in Data Loader and Component
  feat: 在 Data Loader 和组件中支持获取 monitors
- 1fe923c: chore: use monitors instead of reporter to report Data Loader cost
  chore: 使用 monitors 代替 reporter 来上报 Data Loader 耗时
- 8837b85: feat(runtime): support cache function & getRequest function
  feat(runtime): 支持 cache 函数 和 getRequest 函数
- Updated dependencies [793be44]
- Updated dependencies [1fe923c]
- Updated dependencies [8837b85]
- Updated dependencies [1f83d96]
  - @modern-js/runtime-utils@2.65.2
  - @modern-js/utils@2.65.2

## 2.65.1

### Patch Changes

- @modern-js/runtime-utils@2.65.1
- @modern-js/utils@2.65.1

## 2.65.0

### Patch Changes

- @modern-js/runtime-utils@2.65.0
- @modern-js/utils@2.65.0

## 2.64.3

### Patch Changes

- @modern-js/runtime-utils@2.64.3
- @modern-js/utils@2.64.3

## 2.64.2

### Patch Changes

- @modern-js/runtime-utils@2.64.2
- @modern-js/utils@2.64.2

## 2.64.1

### Patch Changes

- @modern-js/runtime-utils@2.64.1
- @modern-js/utils@2.64.1

## 2.64.0

### Patch Changes

- @modern-js/runtime-utils@2.64.0
- @modern-js/utils@2.64.0

## 2.63.7

### Patch Changes

- 09a91c2: feat: unify the response logic of the Loader in SSR
  feat: 统一 SSR 中 Loader 的响应逻辑
  - @modern-js/runtime-utils@2.63.7
  - @modern-js/utils@2.63.7

## 2.63.6

### Patch Changes

- @modern-js/runtime-utils@2.63.6
- @modern-js/utils@2.63.6

## 2.63.5

### Patch Changes

- @modern-js/runtime-utils@2.63.5
- @modern-js/utils@2.63.5

## 2.63.4

### Patch Changes

- @modern-js/runtime-utils@2.63.4
- @modern-js/utils@2.63.4

## 2.63.3

### Patch Changes

- @modern-js/runtime-utils@2.63.3
- @modern-js/utils@2.63.3

## 2.63.2

### Patch Changes

- Updated dependencies [5fc95f7]
- Updated dependencies [53e3ae0]
  - @modern-js/utils@2.63.2
  - @modern-js/runtime-utils@2.63.2

## 2.63.1

### Patch Changes

- @modern-js/runtime-utils@2.63.1
- @modern-js/utils@2.63.1

## 2.63.0

### Patch Changes

- @modern-js/runtime-utils@2.63.0
- @modern-js/utils@2.63.0

## 2.62.1

### Patch Changes

- 86213ae: chore: add a server directory for universal server utils
  chore: 添加一个 server 目录用于存放通用的服务端工具函数
- Updated dependencies [86213ae]
  - @modern-js/runtime-utils@2.62.1
  - @modern-js/utils@2.62.1

## 2.62.0

### Patch Changes

- @modern-js/runtime-utils@2.62.0
- @modern-js/utils@2.62.0

## 2.61.0

### Patch Changes

- Updated dependencies [45230e2]
  - @modern-js/utils@2.61.0
  - @modern-js/runtime-utils@2.61.0

## 2.60.6

### Patch Changes

- Updated dependencies [c4894e6]
  - @modern-js/runtime-utils@2.60.6
  - @modern-js/utils@2.60.6

## 2.60.5

### Patch Changes

- @modern-js/runtime-utils@2.60.5
- @modern-js/utils@2.60.5

## 2.60.4

### Patch Changes

- a9e3eb7: fix(server): should get context from unstable middleware correctly
  fix(server): 应该正确地获取到 loaderContext
- Updated dependencies [c87813e]
  - @modern-js/runtime-utils@2.60.4
  - @modern-js/utils@2.60.4

## 2.60.3

### Patch Changes

- Updated dependencies [303331c]
  - @modern-js/utils@2.60.3
  - @modern-js/runtime-utils@2.60.3

## 2.60.2

### Patch Changes

- Updated dependencies [8a709bc]
  - @modern-js/utils@2.60.2
  - @modern-js/runtime-utils@2.60.2

## 2.60.1

### Patch Changes

- @modern-js/runtime-utils@2.60.1
- @modern-js/utils@2.60.1

## 2.60.0

### Patch Changes

- @modern-js/runtime-utils@2.60.0
- @modern-js/utils@2.60.0

## 2.59.0

### Patch Changes

- @modern-js/runtime-utils@2.59.0
- @modern-js/utils@2.59.0

## 2.58.3

### Patch Changes

- @modern-js/runtime-utils@2.58.3
- @modern-js/utils@2.58.3

## 2.58.2

### Patch Changes

- Updated dependencies [7715b6d]
- Updated dependencies [44c1bc4]
- Updated dependencies [a1a9373]
  - @modern-js/runtime-utils@2.58.2
  - @modern-js/utils@2.58.2

## 2.58.1

### Patch Changes

- @modern-js/runtime-utils@2.58.1
- @modern-js/utils@2.58.1

## 2.58.0

### Patch Changes

- @modern-js/runtime-utils@2.58.0
- @modern-js/utils@2.58.0

## 2.57.1

### Patch Changes

- @modern-js/runtime-utils@2.57.1
- @modern-js/utils@2.57.1

## 2.57.0

### Patch Changes

- 2515b00: feat(ssr): support server.ssrByRouteIds
  feat(ssr): 支持 server.ssrByRouteIds
- ce9c43a: fix: data loader support async-node target
- Updated dependencies [2515b00]
- Updated dependencies [916559a]
- Updated dependencies [dc736ef]
  - @modern-js/utils@2.57.0
  - @modern-js/runtime-utils@2.57.0

## 2.56.2

### Patch Changes

- @modern-js/runtime-utils@2.56.2
- @modern-js/utils@2.56.2

## 2.56.1

### Patch Changes

- @modern-js/runtime-utils@2.56.1
- @modern-js/utils@2.56.1

## 2.56.0

### Patch Changes

- @modern-js/runtime-utils@2.56.0
- @modern-js/utils@2.56.0

## 2.55.0

### Patch Changes

- Updated dependencies [bbcf55a]
  - @modern-js/utils@2.55.0
  - @modern-js/runtime-utils@2.55.0

## 2.54.6

### Patch Changes

- @modern-js/runtime-utils@2.54.6
- @modern-js/utils@2.54.6

## 2.54.5

### Patch Changes

- @modern-js/runtime-utils@2.54.5
- @modern-js/utils@2.54.5

## 2.54.4

### Patch Changes

- @modern-js/runtime-utils@2.54.4
- @modern-js/utils@2.54.4

## 2.54.3

### Patch Changes

- @modern-js/runtime-utils@2.54.3
- @modern-js/utils@2.54.3

## 2.54.2

### Patch Changes

- @modern-js/runtime-utils@2.54.2
- @modern-js/utils@2.54.2

## 2.54.1

### Patch Changes

- @modern-js/runtime-utils@2.54.1
- @modern-js/utils@2.54.1

## 2.54.0

### Minor Changes

- a8d8f0c: feat: support new server plugin & discard server plugin some hooks
  feat: 支持新 server plugin & 减少 server plugin 钩子
- 9da873c: feat(ssr): support for loaderFailureMode configure
  feat(ssr): 支持 loaderFailureMode 配置

### Patch Changes

- Updated dependencies [15a090c]
- Updated dependencies [a8d8f0c]
- Updated dependencies [09798ac]
  - @modern-js/utils@2.54.0
  - @modern-js/runtime-utils@2.54.0

## 2.53.0

### Patch Changes

- @modern-js/runtime-utils@2.53.0
- @modern-js/utils@2.53.0

## 2.52.0

### Minor Changes

- 85ac453: feat: support control status code by data loader
  feat: 支持通过 data loader 控制页面状态码

### Patch Changes

- Updated dependencies [85ac453]
  - @modern-js/runtime-utils@2.52.0
  - @modern-js/utils@2.52.0

## 2.51.0

### Patch Changes

- @modern-js/runtime-utils@2.51.0
- @modern-js/utils@2.51.0

## 2.50.0

### Patch Changes

- @modern-js/runtime-utils@2.50.0
- @modern-js/utils@2.50.0

## 2.49.4

### Patch Changes

- @modern-js/runtime-utils@2.49.4
- @modern-js/utils@2.49.4

## 2.49.3

### Patch Changes

- @modern-js/runtime-utils@2.49.3
- @modern-js/utils@2.49.3

## 2.49.2

### Patch Changes

- @modern-js/runtime-utils@2.49.2
- @modern-js/utils@2.49.2

## 2.49.1

### Patch Changes

- @modern-js/runtime-utils@2.49.1
- @modern-js/utils@2.49.1

## 2.49.0

### Minor Changes

- e8c8c5d: refactor: refactor server
  refactor: 重构 server

### Patch Changes

- Updated dependencies [e8c8c5d]
  - @modern-js/runtime-utils@2.49.0
  - @modern-js/utils@2.49.0

## 2.48.6

### Patch Changes

- @modern-js/runtime-utils@2.48.6
- @modern-js/utils@2.48.6

## 2.48.5

### Patch Changes

- Updated dependencies [4ca9f4c]
  - @modern-js/utils@2.48.5
  - @modern-js/runtime-utils@2.48.5

## 2.48.4

### Patch Changes

- Updated dependencies [7d2d433]
  - @modern-js/utils@2.48.4
  - @modern-js/runtime-utils@2.48.4

## 2.48.3

### Patch Changes

- @modern-js/runtime-utils@2.48.3
- @modern-js/utils@2.48.3

## 2.48.2

### Patch Changes

- @modern-js/runtime-utils@2.48.2
- @modern-js/utils@2.48.2

## 2.48.1

### Patch Changes

- Updated dependencies [8942b90]
- Updated dependencies [ce426f7]
- Updated dependencies [74749ae]
  - @modern-js/utils@2.48.1
  - @modern-js/runtime-utils@2.48.1

## 2.48.0

### Patch Changes

- Updated dependencies [c323a23]
  - @modern-js/utils@2.48.0
  - @modern-js/runtime-utils@2.48.0

## 2.47.1

### Patch Changes

- @modern-js/runtime-utils@2.47.1
- @modern-js/utils@2.47.1

## 2.47.0

### Patch Changes

- Updated dependencies [a5386ab]
- Updated dependencies [9464c9c]
  - @modern-js/utils@2.47.0
  - @modern-js/runtime-utils@2.47.0

## 2.46.1

### Patch Changes

- @modern-js/runtime-utils@2.46.1
- @modern-js/utils@2.46.1

## 2.46.0

### Patch Changes

- Updated dependencies [78e2722]
  - @modern-js/runtime-utils@2.46.0
  - @modern-js/utils@2.46.0

## 2.45.0

### Patch Changes

- @modern-js/runtime-utils@2.45.0
- @modern-js/utils@2.45.0

## 2.44.0

### Patch Changes

- Updated dependencies [0ed968c]
  - @modern-js/runtime-utils@2.44.0
  - @modern-js/utils@2.44.0

## 2.43.0

### Patch Changes

- Updated dependencies [9e749d8]
- Updated dependencies [d959200]
  - @modern-js/runtime-utils@2.43.0
  - @modern-js/utils@2.43.0

## 2.42.2

### Patch Changes

- @modern-js/runtime-utils@2.42.2
- @modern-js/utils@2.42.2

## 2.42.1

### Patch Changes

- @modern-js/runtime-utils@2.42.1
- @modern-js/utils@2.42.1

## 2.42.0

### Patch Changes

- Updated dependencies [103cf92]
  - @modern-js/runtime-utils@2.42.0
  - @modern-js/utils@2.42.0

## 2.41.0

### Patch Changes

- c4d396a: chore(swc): bump swc and helpers
  chore(swc): 升级 swc 以及 helpers
- Updated dependencies [c4d396a]
  - @modern-js/runtime-utils@2.41.0
  - @modern-js/utils@2.41.0

## 2.40.0

### Patch Changes

- ce7d45c: fix: add client data into dependencies
  fix: 添加 client data 文件到 dependencies 中
- Updated dependencies [95f15d2]
  - @modern-js/utils@2.40.0
  - @modern-js/runtime-utils@2.40.0

## 2.39.2

### Patch Changes

- @modern-js/runtime-utils@2.39.2
- @modern-js/utils@2.39.2

## 2.39.1

### Patch Changes

- f397649: chore: upgrade react-router and remix
  chore: 更新 react-router 和 remix
- Updated dependencies [f397649]
  - @modern-js/runtime-utils@2.39.1
  - @modern-js/utils@2.39.1

## 2.39.0

### Patch Changes

- @modern-js/runtime-utils@2.39.0
- @modern-js/utils@2.39.0

## 2.38.0

### Patch Changes

- 3304d33: chore(deps): bump @babel/core to v7.23.2

  chore(deps): 升级 @babel/core 至 v7.23.2

  - @modern-js/runtime-utils@2.38.0
  - @modern-js/utils@2.38.0

## 2.37.2

### Patch Changes

- @modern-js/runtime-utils@2.37.2
- @modern-js/utils@2.37.2

## 2.37.1

### Patch Changes

- @modern-js/runtime-utils@2.37.1
- @modern-js/utils@2.37.1

## 2.37.0

### Patch Changes

- Updated dependencies [383b636]
- Updated dependencies [ce0a14e]
- Updated dependencies [708f248]
  - @modern-js/utils@2.37.0
  - @modern-js/runtime-utils@2.37.0

## 2.36.0

### Patch Changes

- Updated dependencies [3473bee]
- Updated dependencies [b98f8aa]
- Updated dependencies [eb602d2]
  - @modern-js/utils@2.36.0
  - @modern-js/runtime-utils@2.36.0

## 2.35.1

### Patch Changes

- 6a1d46e: refactor: split runtime utils into a seperate package
  refactor: runtime utils 单独拆分成一个包
- Updated dependencies [ea3fe18]
- Updated dependencies [9dd3151]
- Updated dependencies [4980480]
- Updated dependencies [6a1d46e]
  - @modern-js/utils@2.35.1
  - @modern-js/runtime-utils@2.35.1

## 2.35.0

### Patch Changes

- Updated dependencies [15b834f]
  - @modern-js/utils@2.35.0

## 2.34.0

### Patch Changes

- Updated dependencies [a77b82a]
- Updated dependencies [c8b448b]
  - @modern-js/utils@2.34.0

## 2.33.1

### Patch Changes

- @modern-js/utils@2.33.1

## 2.33.0

### Patch Changes

- Updated dependencies [fd82137]
- Updated dependencies [bc1f8da]
  - @modern-js/utils@2.33.0

## 2.32.1

### Patch Changes

- @modern-js/utils@2.32.1

## 2.32.0

### Minor Changes

- a030aff: feat: support loader context
  feat: 支持 loader context
- 4323e68: feat: support client-data file
  feat: 支持 client-data 文件

### Patch Changes

- 6076166: fix: packaging errors found by publint

  fix: 修复 publint 检测到的 packaging 问题

- 3c91100: chore(builder): using unified version of webpack-chain

  chore(builder): 使用统一的 webpack-chain 版本

- 5255eba: feat: report time for server loader
  feat: 上报 server loader 执行的时间
- Updated dependencies [e5a3fb4]
- Updated dependencies [6076166]
- Updated dependencies [a030aff]
- Updated dependencies [3c91100]
- Updated dependencies [5255eba]
  - @modern-js/utils@2.32.0

## 2.31.2

### Patch Changes

- Updated dependencies [15d30abdc66]
  - @modern-js/utils@2.31.2

## 2.31.1

### Patch Changes

- @modern-js/utils@2.31.1

## 2.31.0

### Patch Changes

- Updated dependencies [1882366]
  - @modern-js/utils@2.31.0

## 2.30.0

### Patch Changes

- @modern-js/utils@2.30.0

## 2.29.0

### Patch Changes

- Updated dependencies [e6b5355]
- Updated dependencies [93db783]
- Updated dependencies [cba7675]
- Updated dependencies [99052ea]
- Updated dependencies [1d71d2e]
  - @modern-js/utils@2.29.0

## 2.28.0

### Patch Changes

- Updated dependencies [00b58a7]
  - @modern-js/utils@2.28.0

## 2.27.0

### Patch Changes

- Updated dependencies [91d14b8]
- Updated dependencies [6d7104d]
  - @modern-js/utils@2.27.0

## 2.26.0

### Patch Changes

- @modern-js/utils@2.26.0

## 2.25.2

### Patch Changes

- 272646c: feat(builder): bump webpack v5.88, support top level await

  feat(builder): 升级 webpack v5.88, 支持 top level await

- Updated dependencies [63d8247]
- Updated dependencies [6651684]
- Updated dependencies [272646c]
- Updated dependencies [358ed24]
  - @modern-js/utils@2.25.2

## 2.25.1

### Patch Changes

- Updated dependencies [9f78d0c]
  - @modern-js/utils@2.25.1

## 2.25.0

### Patch Changes

- Updated dependencies [5732c6a]
  - @modern-js/utils@2.25.0

## 2.24.0

### Patch Changes

- 4a82c3b: fix: export `@remix-run/router` cjs instead of `react-router-dom`
  fix: 暴露 `@remix-run/router` 的 cjs 导出代替 `react-router-dom`
- Updated dependencies [c882fbd]
- Updated dependencies [4a82c3b]
  - @modern-js/utils@2.24.0

## 2.23.1

### Patch Changes

- Updated dependencies [f08bbfc]
- Updated dependencies [a6b313a]
- Updated dependencies [8f2cab0]
  - @modern-js/utils@2.23.1

## 2.23.0

### Patch Changes

- 7e6fb5f: chore: publishConfig add provenance config

  chore: publishConfig 增加 provenance 配置

- a7a7ad7: chore: move some public code to the utils package
  chore: 移动一些公共的代码到 utils 包
- 6dec7c2: test(utils): reuse the snapshot serializer of vitest config

  test(utils): 复用 vitest 的 snapshot serializer

- e5259fb: fix: absoluteEntryDir should support directory entry
  fix: absoluteEntryDir 应该支持配置目录 entry，这里 document 会使用
- Updated dependencies [7e6fb5f]
- Updated dependencies [a7a7ad7]
- Updated dependencies [6dec7c2]
- Updated dependencies [c3216b5]
  - @modern-js/utils@2.23.0

## 2.22.1

### Patch Changes

- Updated dependencies [e2848a2]
- Updated dependencies [d4045ed]
  - @modern-js/utils@2.22.1

## 2.22.0

### Patch Changes

- 3d48836: chore(deps): fix all missing peer dependencies

  chore(deps): 修复缺少的 peer dependencies

- Updated dependencies [3d48836]
- Updated dependencies [5050e8e]
  - @modern-js/utils@2.22.0

## 2.21.1

### Patch Changes

- @modern-js/utils@2.21.1

## 2.21.0

### Patch Changes

- e81eeaf: refactor: guard react-router version consistency
  refactor: 保证 react-router 相关包的版本一致性
- 26dcf3a: chore: bump typescript to v5 in devDependencies

  chore: 升级 devDependencies 中的 typescript 版本到 v5

- ad78387: chore(deps): bump babel-related dependencies to latest version

  chore(deps): 升级 babel 相关依赖到最新版本

- Updated dependencies [e81eeaf]
- Updated dependencies [26dcf3a]
- Updated dependencies [056627f]
- Updated dependencies [0fc15ca]
- Updated dependencies [43b4e83]
- Updated dependencies [ad78387]
  - @modern-js/utils@2.21.0

## 2.20.0

### Patch Changes

- 6b9d90a: chore: remove @babel/runtime. add @swc/helper and enable `externalHelper` config.
  chore: 移除 @babel/runtime 依赖. 增加 @swc/helpers 依赖并且开启 `externalHelpers` 配置
- Updated dependencies [3c4e0a5]
- Updated dependencies [6b9d90a]
  - @modern-js/utils@2.20.0

## 2.19.1

### Patch Changes

- @modern-js/utils@2.19.1

## 2.19.0

### Patch Changes

- 1134fe2: chore(deps): bump webpack from 5.76.2 to 5.82.1

  chore(deps): 将 webpack 从 5.76.2 升级至 5.82.1

- Updated dependencies [1134fe2]
  - @modern-js/utils@2.19.0

## 2.18.1

### Patch Changes

- @modern-js/utils@2.18.1

## 2.18.0

### Patch Changes

- @modern-js/utils@2.18.0

## 2.17.1

### Patch Changes

- @modern-js/utils@2.17.1

## 2.17.0

### Patch Changes

- @modern-js/utils@2.17.0

## 2.16.0

### Patch Changes

- 4e876ab: chore: package.json include the monorepo-relative directory

  chore: 在 package.json 中声明 monorepo 的子路径

- Updated dependencies [5954330]
- Updated dependencies [7596520]
- Updated dependencies [4e876ab]
  - @modern-js/utils@2.16.0

## 2.15.0

### Patch Changes

- @modern-js/utils@2.15.0

## 2.14.0

### Patch Changes

- d05651a: fix: set encoding for defered loader
  fix: 为 defer loader 设置 encoding
- Updated dependencies [4779152]
- Updated dependencies [9321bef]
- Updated dependencies [9b45c58]
- Updated dependencies [52d0cb1]
- Updated dependencies [60a81d0]
- Updated dependencies [dacef96]
- Updated dependencies [16399fd]
  - @modern-js/utils@2.14.0

## 2.13.4

### Patch Changes

- @modern-js/utils@2.13.4

## 2.13.3

### Patch Changes

- @modern-js/utils@2.13.3

## 2.13.2

### Patch Changes

- @modern-js/utils@2.13.2

## 2.13.1

### Patch Changes

- @modern-js/utils@2.13.1

## 2.13.0

### Minor Changes

- 3d5086b: feat: the rspack unsupport inline loader, so we move data-loader to bundler.module.rules
  feat: rspack 不支持 inline loader, 所以我们将 data-loader 移动到 bundler.module.rules 配置中去。

### Patch Changes

- @modern-js/utils@2.13.0

## 2.12.0

### Patch Changes

- Updated dependencies [c2ca6c8]
- Updated dependencies [6d86e34]
  - @modern-js/utils@2.12.0

## 2.11.0

### Patch Changes

- 5d624fd: feat: assets and data prefetching is supported
  feat: 支持资源和数据预加载
- e2466a1: fix: remove nestedRoutes file from @modern-js/utils
  fix: 将 nestedRoutes 从 @modern-js/utils 中移除
- 381a3b9: feat(utils): move universal utils to the universal folder

  feat(utils): 将运行时使用的 utils 移动到 universal 目录

- Updated dependencies [cfb058f]
- Updated dependencies [0bd018b]
- Updated dependencies [5d624fd]
- Updated dependencies [e2466a1]
- Updated dependencies [02bb383]
- Updated dependencies [381a3b9]
- Updated dependencies [7a60f10]
- Updated dependencies [274b2e5]
- Updated dependencies [b9e1c54]
  - @modern-js/utils@2.11.0

## 2.10.0

### Patch Changes

- 3e0bd50: feat: when enable bff handle render, support use `useContext` to get framework plugin context in data loader.
  feat: 当开启 BFF 托管渲染时，支持在 data loader 中使用 `useContext` 获取框架插件提供的上下文。
- 0da32d0: chore: upgrade jest and puppeteer
  chore: 升级 jest 和 puppeteer 到 latest
- 0d9962b: fix: add types field in package.json
  fix: 添加 package.json 中的 types 字段
- fbefa7e: chore(deps): bump webpack from 5.75.0 to 5.76.2

  chore(deps): 将 webpack 从 5.75.0 升级至 5.76.2

- d6b6e29: fix: split server and runtime code in plugin-data-loader
  fix: 分离 plugin-data-loader 中服务端和客户端运行时的代码
- Updated dependencies [0da32d0]
- Updated dependencies [fbefa7e]
- Updated dependencies [4d54233]
- Updated dependencies [6db4864]
  - @modern-js/utils@2.10.0

## 2.9.0

### Patch Changes

- @modern-js/utils@2.9.0

## 2.8.0

### Patch Changes

- 0cf8540ffe: fix: should match the most similar entry
  fix: 应该匹配最相似的 entry
- Updated dependencies [1104a9f18b]
- Updated dependencies [1f6ca2c7fb]
  - @modern-js/utils@2.8.0
