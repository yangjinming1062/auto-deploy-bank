export const API_APP_NAME = '_app';

export const BUILD_FILES = [
  '**/*.[tj]sx?',
  '!**/*.test.jsx?',
  '!**/*.test.tsx?',
  '!**/*.spec.jsx?',
  '!**/*.spec.tsx?',
  '!__tests__/*.tsx?',
  '!__tests__/*.jsx?',
];
