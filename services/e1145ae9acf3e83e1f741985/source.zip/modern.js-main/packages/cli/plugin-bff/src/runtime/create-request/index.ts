/* @modern-js/create-request will auto select server or client implementation */
import {
  configure,
  createRequest,
  createUploader,
} from '@modern-js/create-request';

export { configure, createRequest, createUploader };
