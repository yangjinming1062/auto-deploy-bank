module.exports = require('./dist/cjs/cli');
