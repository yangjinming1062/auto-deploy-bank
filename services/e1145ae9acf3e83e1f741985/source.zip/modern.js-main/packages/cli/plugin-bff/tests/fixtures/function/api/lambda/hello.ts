export const get = ({ query }: { query: Record<string, unknown> }) => ({
  query,
});
