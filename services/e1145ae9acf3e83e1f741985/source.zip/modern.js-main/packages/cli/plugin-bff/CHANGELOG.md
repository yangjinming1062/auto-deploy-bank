# @modern-js/plugin-bff

## 3.0.0-alpha.1

### Patch Changes

- Updated dependencies [eecb927]
- Updated dependencies [952f6fe]
- Updated dependencies [79f0efd]
  - @modern-js/server-core@3.0.0-alpha.1
  - @modern-js/server-utils@3.0.0-alpha.1
  - @modern-js/builder@3.0.0-alpha.1
  - @modern-js/bff-core@3.0.0-alpha.1
  - @modern-js/create-request@3.0.0-alpha.1
  - @modern-js/utils@3.0.0-alpha.1

## 3.0.0-alpha.0

### Patch Changes

- Updated dependencies [eecb927]
- Updated dependencies [952f6fe]
  - @modern-js/server-core@3.0.0-alpha.0
  - @modern-js/server-utils@3.0.0-alpha.0
  - @modern-js/builder@3.0.0-alpha.0
  - @modern-js/bff-core@3.0.0-alpha.0
  - @modern-js/create-request@3.0.0-alpha.0
  - @modern-js/utils@3.0.0-alpha.0

## 2.68.1

### Patch Changes

- e64d5f9: feat: hono bff supports return custom res
  feat: hono bff 支持返回自定义响应
- Updated dependencies [e64d5f9]
- Updated dependencies [0d98723]
- Updated dependencies [0d98723]
  - @modern-js/create-request@2.68.1
  - @modern-js/server-core@2.68.1
  - @modern-js/server-utils@2.68.1
  - @modern-js/bff-core@2.68.1
  - @modern-js/utils@2.68.1

## 2.68.0

### Patch Changes

- @modern-js/bff-core@2.68.0
- @modern-js/server-core@2.68.0
- @modern-js/create-request@2.68.0
- @modern-js/server-utils@2.68.0
- @modern-js/utils@2.68.0

## 2.67.11

### Patch Changes

- @modern-js/bff-core@2.67.11
- @modern-js/server-core@2.67.11
- @modern-js/create-request@2.67.11
- @modern-js/server-utils@2.67.11
- @modern-js/utils@2.67.11

## 2.67.10

### Patch Changes

- @modern-js/bff-core@2.67.10
- @modern-js/server-core@2.67.10
- @modern-js/create-request@2.67.10
- @modern-js/server-utils@2.67.10
- @modern-js/utils@2.67.10

## 2.67.9

### Patch Changes

- 8a07b69: fix: hono bff params order
  fix: 修复 hono 运行是框架获取 params 顺序问题
  - @modern-js/server-core@2.67.9
  - @modern-js/server-utils@2.67.9
  - @modern-js/bff-core@2.67.9
  - @modern-js/create-request@2.67.9
  - @modern-js/utils@2.67.9

## 2.67.8

### Patch Changes

- Updated dependencies [23c8201]
  - @modern-js/utils@2.67.8
  - @modern-js/bff-core@2.67.8
  - @modern-js/server-core@2.67.8
  - @modern-js/create-request@2.67.8
  - @modern-js/server-utils@2.67.8

## 2.67.7

### Patch Changes

- @modern-js/bff-core@2.67.7
- @modern-js/server-core@2.67.7
- @modern-js/create-request@2.67.7
- @modern-js/server-utils@2.67.7
- @modern-js/utils@2.67.7

## 2.67.6

### Patch Changes

- Updated dependencies [67a21da]
- Updated dependencies [e67b6d0]
  - @modern-js/server-core@2.67.6
  - @modern-js/server-utils@2.67.6
  - @modern-js/bff-core@2.67.6
  - @modern-js/create-request@2.67.6
  - @modern-js/utils@2.67.6

## 2.67.5

### Patch Changes

- @modern-js/bff-core@2.67.5
- @modern-js/server-core@2.67.5
- @modern-js/create-request@2.67.5
- @modern-js/server-utils@2.67.5
- @modern-js/utils@2.67.5

## 2.67.4

### Patch Changes

- Updated dependencies [35e9786]
- Updated dependencies [2b65e0c]
  - @modern-js/server-core@2.67.4
  - @modern-js/server-utils@2.67.4
  - @modern-js/create-request@2.67.4
  - @modern-js/bff-core@2.67.4
  - @modern-js/utils@2.67.4

## 2.67.3

### Patch Changes

- f6b81dd: feat: bff supports hono runtime framework
  feat: bff 支持 hono 运行时框架
- Updated dependencies [f6b81dd]
- Updated dependencies [f6b81dd]
  - @modern-js/create-request@2.67.3
  - @modern-js/server-core@2.67.3
  - @modern-js/server-utils@2.67.3
  - @modern-js/bff-core@2.67.3
  - @modern-js/utils@2.67.3

## 2.67.2

### Patch Changes

- Updated dependencies [b310249]
- Updated dependencies [23a111f]
- Updated dependencies [6a5f36c]
- Updated dependencies [c964f07]
  - @modern-js/server-core@2.67.2
  - @modern-js/create-request@2.67.2
  - @modern-js/server-utils@2.67.2
  - @modern-js/bff-core@2.67.2
  - @modern-js/utils@2.67.2

## 2.67.1

### Patch Changes

- Updated dependencies [1d96265]
  - @modern-js/utils@2.67.1
  - @modern-js/server-core@2.67.1
  - @modern-js/bff-core@2.67.1
  - @modern-js/create-request@2.67.1
  - @modern-js/server-utils@2.67.1

## 2.67.0

### Patch Changes

- Updated dependencies [7503f22]
  - @modern-js/server-core@2.67.0
  - @modern-js/server-utils@2.67.0
  - @modern-js/bff-core@2.67.0
  - @modern-js/create-request@2.67.0
  - @modern-js/utils@2.67.0

## 2.66.0

### Minor Changes

- e48a5ae: feat: server plugin use plugin v2

  feat: server 插件使用 plugin v2 实现

### Patch Changes

- Updated dependencies [e48a5ae]
  - @modern-js/server-core@2.66.0
  - @modern-js/server-utils@2.66.0
  - @modern-js/bff-core@2.66.0
  - @modern-js/create-request@2.66.0
  - @modern-js/utils@2.66.0

## 2.65.5

### Patch Changes

- Updated dependencies [fb6bf9e]
  - @modern-js/server-core@2.65.5
  - @modern-js/server-utils@2.65.5
  - @modern-js/create-request@2.65.5
  - @modern-js/bff-core@2.65.5
  - @modern-js/utils@2.65.5

## 2.65.4

### Patch Changes

- Updated dependencies [0d47cb8]
- Updated dependencies [f1cd095]
  - @modern-js/utils@2.65.4
  - @modern-js/server-core@2.65.4
  - @modern-js/bff-core@2.65.4
  - @modern-js/create-request@2.65.4
  - @modern-js/server-utils@2.65.4

## 2.65.3

### Patch Changes

- @modern-js/bff-core@2.65.3
- @modern-js/server-core@2.65.3
- @modern-js/create-request@2.65.3
- @modern-js/utils@2.65.3
- @modern-js/server-utils@2.65.3

## 2.65.2

### Patch Changes

- Updated dependencies [793be44]
- Updated dependencies [1fe923c]
- Updated dependencies [f3fc1db]
- Updated dependencies [1f83d96]
  - @modern-js/create-request@2.65.2
  - @modern-js/server-core@2.65.2
  - @modern-js/utils@2.65.2
  - @modern-js/bff-core@2.65.2
  - @modern-js/server-utils@2.65.2

## 2.65.1

### Patch Changes

- @modern-js/bff-core@2.65.1
- @modern-js/server-core@2.65.1
- @modern-js/create-request@2.65.1
- @modern-js/server-utils@2.65.1
- @modern-js/utils@2.65.1

## 2.65.0

### Patch Changes

- b43988e: feat: BFF 跨项目调用支持配置域名，补充文档
  feat: BFF cross-project-invocation supports configuration of domain, add doc
- b854d7b: fix(bff): fixed path issue of generating package.json attribute
  fix(bff): 修复生成 package.json 属性的路径问题
- Updated dependencies [b43988e]
- Updated dependencies [4c0aca6]
  - @modern-js/create-request@2.65.0
  - @modern-js/server-core@2.65.0
  - @modern-js/server-utils@2.65.0
  - @modern-js/bff-core@2.65.0
  - @modern-js/utils@2.65.0

## 2.64.3

### Patch Changes

- Updated dependencies [d77a6df]
  - @modern-js/server-core@2.64.3
  - @modern-js/server-utils@2.64.3
  - @modern-js/bff-core@2.64.3
  - @modern-js/create-request@2.64.3
  - @modern-js/utils@2.64.3

## 2.64.2

### Patch Changes

- Updated dependencies [4ae943d]
- Updated dependencies [02ca983]
  - @modern-js/server-core@2.64.2
  - @modern-js/server-utils@2.64.2
  - @modern-js/bff-core@2.64.2
  - @modern-js/create-request@2.64.2
  - @modern-js/utils@2.64.2

## 2.64.1

### Patch Changes

- @modern-js/bff-core@2.64.1
- @modern-js/server-core@2.64.1
- @modern-js/create-request@2.64.1
- @modern-js/server-utils@2.64.1
- @modern-js/utils@2.64.1

## 2.64.0

### Patch Changes

- @modern-js/bff-core@2.64.0
- @modern-js/server-core@2.64.0
- @modern-js/create-request@2.64.0
- @modern-js/server-utils@2.64.0
- @modern-js/utils@2.64.0

## 2.63.7

### Patch Changes

- fdcb0ee: feat: bff support independent project

  feat: bff 支持跨项目调用

- Updated dependencies [39f955f]
- Updated dependencies [fdcb0ee]
  - @modern-js/bff-core@2.63.7
  - @modern-js/create-request@2.63.7
  - @modern-js/server-core@2.63.7
  - @modern-js/server-utils@2.63.7
  - @modern-js/utils@2.63.7

## 2.63.6

### Patch Changes

- Updated dependencies [a7a4573]
  - @modern-js/server-core@2.63.6
  - @modern-js/server-utils@2.63.6
  - @modern-js/bff-core@2.63.6
  - @modern-js/create-request@2.63.6
  - @modern-js/utils@2.63.6

## 2.63.5

### Patch Changes

- @modern-js/bff-core@2.63.5
- @modern-js/server-core@2.63.5
- @modern-js/create-request@2.63.5
- @modern-js/server-utils@2.63.5
- @modern-js/utils@2.63.5

## 2.63.4

### Patch Changes

- Updated dependencies [95b026d]
  - @modern-js/server-core@2.63.4
  - @modern-js/server-utils@2.63.4
  - @modern-js/bff-core@2.63.4
  - @modern-js/create-request@2.63.4
  - @modern-js/utils@2.63.4

## 2.63.3

### Patch Changes

- Updated dependencies [5c97ec2]
- Updated dependencies [e5b16df]
  - @modern-js/server-core@2.63.3
  - @modern-js/server-utils@2.63.3
  - @modern-js/bff-core@2.63.3
  - @modern-js/create-request@2.63.3
  - @modern-js/utils@2.63.3

## 2.63.2

### Patch Changes

- Updated dependencies [5fc95f7]
- Updated dependencies [524d6af]
- Updated dependencies [53e3ae0]
- Updated dependencies [3d2bf55]
- Updated dependencies [bc1670a]
- Updated dependencies [30f89d5]
  - @modern-js/utils@2.63.2
  - @modern-js/server-core@2.63.2
  - @modern-js/bff-core@2.63.2
  - @modern-js/create-request@2.63.2
  - @modern-js/server-utils@2.63.2

## 2.63.1

### Patch Changes

- @modern-js/bff-core@2.63.1
- @modern-js/server-core@2.63.1
- @modern-js/create-request@2.63.1
- @modern-js/server-utils@2.63.1
- @modern-js/utils@2.63.1

## 2.63.0

### Patch Changes

- @modern-js/bff-core@2.63.0
- @modern-js/server-core@2.63.0
- @modern-js/create-request@2.63.0
- @modern-js/server-utils@2.63.0
- @modern-js/utils@2.63.0

## 2.62.1

### Patch Changes

- @modern-js/bff-core@2.62.1
- @modern-js/server-core@2.62.1
- @modern-js/create-request@2.62.1
- @modern-js/server-utils@2.62.1
- @modern-js/utils@2.62.1

## 2.62.0

### Patch Changes

- @modern-js/bff-core@2.62.0
- @modern-js/server-core@2.62.0
- @modern-js/create-request@2.62.0
- @modern-js/server-utils@2.62.0
- @modern-js/utils@2.62.0

## 2.61.0

### Patch Changes

- Updated dependencies [8bd7799]
- Updated dependencies [45230e2]
- Updated dependencies [a7ff13f]
  - @modern-js/bff-core@2.61.0
  - @modern-js/utils@2.61.0
  - @modern-js/server-core@2.61.0
  - @modern-js/create-request@2.61.0
  - @modern-js/server-utils@2.61.0

## 2.60.6

### Patch Changes

- Updated dependencies [2beacbb]
- Updated dependencies [e6daf22]
  - @modern-js/create-request@2.60.6
  - @modern-js/bff-core@2.60.6
  - @modern-js/server-core@2.60.6
  - @modern-js/server-utils@2.60.6
  - @modern-js/utils@2.60.6

## 2.60.5

### Patch Changes

- @modern-js/bff-core@2.60.5
- @modern-js/server-core@2.60.5
- @modern-js/create-request@2.60.5
- @modern-js/server-utils@2.60.5
- @modern-js/utils@2.60.5

## 2.60.4

### Patch Changes

- Updated dependencies [518b783]
- Updated dependencies [a4160c7]
- Updated dependencies [a9e3eb7]
- Updated dependencies [75ff77f]
  - @modern-js/server-core@2.60.4
  - @modern-js/bff-core@2.60.4
  - @modern-js/server-utils@2.60.4
  - @modern-js/create-request@2.60.4
  - @modern-js/utils@2.60.4

## 2.60.3

### Patch Changes

- Updated dependencies [303331c]
  - @modern-js/utils@2.60.3
  - @modern-js/bff-core@2.60.3
  - @modern-js/server-core@2.60.3
  - @modern-js/create-request@2.60.3
  - @modern-js/server-utils@2.60.3

## 2.60.2

### Patch Changes

- Updated dependencies [8a709bc]
- Updated dependencies [0a31d31]
  - @modern-js/utils@2.60.2
  - @modern-js/server-core@2.60.2
  - @modern-js/bff-core@2.60.2
  - @modern-js/create-request@2.60.2
  - @modern-js/server-utils@2.60.2

## 2.60.1

### Patch Changes

- Updated dependencies [3a973a2]
  - @modern-js/server-utils@2.60.1
  - @modern-js/bff-core@2.60.1
  - @modern-js/server-core@2.60.1
  - @modern-js/create-request@2.60.1
  - @modern-js/utils@2.60.1

## 2.60.0

### Patch Changes

- Updated dependencies [d6e0118]
  - @modern-js/server-core@2.60.0
  - @modern-js/server-utils@2.60.0
  - @modern-js/bff-core@2.60.0
  - @modern-js/create-request@2.60.0
  - @modern-js/utils@2.60.0

## 2.59.0

### Patch Changes

- Updated dependencies [539d72b]
- Updated dependencies [ef1ec44]
- Updated dependencies [80237dc]
  - @modern-js/server-core@2.59.0
  - @modern-js/bff-core@2.59.0
  - @modern-js/create-request@2.59.0
  - @modern-js/utils@2.59.0
  - @modern-js/server-utils@2.59.0

## 2.58.3

### Patch Changes

- Updated dependencies [36ccad3]
- Updated dependencies [0b581a4]
- Updated dependencies [610554c]
- Updated dependencies [59fba90]
- Updated dependencies [9e82b00]
  - @modern-js/server-core@2.58.3
  - @modern-js/server-utils@2.58.3
  - @modern-js/bff-core@2.58.3
  - @modern-js/create-request@2.58.3
  - @modern-js/utils@2.58.3

## 2.58.2

### Patch Changes

- Updated dependencies [1ff0304]
- Updated dependencies [a1a9373]
  - @modern-js/server-core@2.58.2
  - @modern-js/utils@2.58.2
  - @modern-js/server-utils@2.58.2
  - @modern-js/create-request@2.58.2
  - @modern-js/bff-core@2.58.2

## 2.58.1

### Patch Changes

- Updated dependencies [c904ee2]
- Updated dependencies [a214ea8]
  - @modern-js/server-core@2.58.1
  - @modern-js/bff-core@2.58.1
  - @modern-js/create-request@2.58.1
  - @modern-js/utils@2.58.1
  - @modern-js/server-utils@2.58.1

## 2.58.0

### Patch Changes

- @modern-js/bff-core@2.58.0
- @modern-js/server-core@2.58.0
- @modern-js/create-request@2.58.0
- @modern-js/server-utils@2.58.0
- @modern-js/utils@2.58.0

## 2.57.1

### Patch Changes

- Updated dependencies [bc565cd]
  - @modern-js/server-core@2.57.1
  - @modern-js/server-utils@2.57.1
  - @modern-js/bff-core@2.57.1
  - @modern-js/create-request@2.57.1
  - @modern-js/utils@2.57.1

## 2.57.0

### Patch Changes

- 0e906a1: feat: inject renderHandler to appContext & add default serverPlugins
  feat: 注入 renderHandler 到 appContext & 新增默认 serverPlugins
- Updated dependencies [2515b00]
- Updated dependencies [0e906a1]
- Updated dependencies [6cec127]
- Updated dependencies [b5a48a8]
- Updated dependencies [203c9eb]
- Updated dependencies [604ad3a]
  - @modern-js/utils@2.57.0
  - @modern-js/server-core@2.57.0
  - @modern-js/bff-core@2.57.0
  - @modern-js/create-request@2.57.0
  - @modern-js/server-utils@2.57.0

## 2.56.2

### Patch Changes

- @modern-js/bff-core@2.56.2
- @modern-js/server-core@2.56.2
- @modern-js/create-request@2.56.2
- @modern-js/server-utils@2.56.2
- @modern-js/utils@2.56.2

## 2.56.1

### Patch Changes

- Updated dependencies [e0e29b3]
  - @modern-js/server-core@2.56.1
  - @modern-js/server-utils@2.56.1
  - @modern-js/bff-core@2.56.1
  - @modern-js/create-request@2.56.1
  - @modern-js/utils@2.56.1

## 2.56.0

### Patch Changes

- Updated dependencies [bedbbb3]
- Updated dependencies [9eee52a]
  - @modern-js/server-core@2.56.0
  - @modern-js/bff-core@2.56.0
  - @modern-js/create-request@2.56.0
  - @modern-js/utils@2.56.0
  - @modern-js/server-utils@2.56.0

## 2.55.0

### Patch Changes

- 380c4a3: fix: add bff/tailwindcss/swc plugin exported types
  fix: 添加 bff/tailwindcss/swc 插件的导出类型
- Updated dependencies [bbcf55a]
- Updated dependencies [e0c2384]
  - @modern-js/utils@2.55.0
  - @modern-js/server-core@2.55.0
  - @modern-js/bff-core@2.55.0
  - @modern-js/create-request@2.55.0
  - @modern-js/server-utils@2.55.0

## 2.54.6

### Patch Changes

- @modern-js/bff-core@2.54.6
- @modern-js/server-core@2.54.6
- @modern-js/create-request@2.54.6
- @modern-js/server-utils@2.54.6
- @modern-js/utils@2.54.6

## 2.54.5

### Patch Changes

- Updated dependencies [5525a23]
  - @modern-js/server-core@2.54.5
  - @modern-js/server-utils@2.54.5
  - @modern-js/bff-core@2.54.5
  - @modern-js/create-request@2.54.5
  - @modern-js/utils@2.54.5

## 2.54.4

### Patch Changes

- @modern-js/bff-core@2.54.4
- @modern-js/server-core@2.54.4
- @modern-js/create-request@2.54.4
- @modern-js/server-utils@2.54.4
- @modern-js/utils@2.54.4

## 2.54.3

### Patch Changes

- b9ca86d: fix: move @modern-js/server-core to bff/koa/express plugin dependencies
  fix: 将 @modern-js/server-core 作为 bff/koa/express 插件的 dependencies
- Updated dependencies [b50d7ec]
  - @modern-js/server-core@2.54.3
  - @modern-js/server-utils@2.54.3
  - @modern-js/bff-core@2.54.3
  - @modern-js/create-request@2.54.3
  - @modern-js/utils@2.54.3

## 2.54.2

### Patch Changes

- @modern-js/bff-core@2.54.2
- @modern-js/create-request@2.54.2
- @modern-js/server-utils@2.54.2
- @modern-js/utils@2.54.2

## 2.54.1

### Patch Changes

- @modern-js/server-utils@2.54.1
- @modern-js/bff-core@2.54.1
- @modern-js/create-request@2.54.1
- @modern-js/utils@2.54.1

## 2.54.0

### Minor Changes

- a8d8f0c: feat: support new server plugin & discard server plugin some hooks
  feat: 支持新 server plugin & 减少 server plugin 钩子

### Patch Changes

- Updated dependencies [15a090c]
- Updated dependencies [a8d8f0c]
- Updated dependencies [09798ac]
  - @modern-js/utils@2.54.0
  - @modern-js/bff-core@2.54.0
  - @modern-js/create-request@2.54.0
  - @modern-js/server-utils@2.54.0

## 2.53.0

### Patch Changes

- @modern-js/server-utils@2.53.0
- @modern-js/bff-core@2.53.0
- @modern-js/create-request@2.53.0
- @modern-js/utils@2.53.0

## 2.52.0

### Patch Changes

- @modern-js/create-request@2.52.0
- @modern-js/server-utils@2.52.0
- @modern-js/bff-core@2.52.0
- @modern-js/utils@2.52.0

## 2.51.0

### Patch Changes

- @modern-js/server-utils@2.51.0
- @modern-js/bff-core@2.51.0
- @modern-js/create-request@2.51.0
- @modern-js/utils@2.51.0

## 2.50.0

### Patch Changes

- @modern-js/server-utils@2.50.0
- @modern-js/bff-core@2.50.0
- @modern-js/create-request@2.50.0
- @modern-js/utils@2.50.0

## 2.49.4

### Patch Changes

- @modern-js/server-utils@2.49.4
- @modern-js/bff-core@2.49.4
- @modern-js/create-request@2.49.4
- @modern-js/utils@2.49.4

## 2.49.3

### Patch Changes

- @modern-js/server-utils@2.49.3
- @modern-js/bff-core@2.49.3
- @modern-js/create-request@2.49.3
- @modern-js/utils@2.49.3

## 2.49.2

### Patch Changes

- @modern-js/bff-core@2.49.2
- @modern-js/create-request@2.49.2
- @modern-js/server-utils@2.49.2
- @modern-js/utils@2.49.2

## 2.49.1

### Patch Changes

- @modern-js/server-utils@2.49.1
- @modern-js/bff-core@2.49.1
- @modern-js/create-request@2.49.1
- @modern-js/utils@2.49.1

## 2.49.0

### Minor Changes

- e8c8c5d: refactor: refactor server
  refactor: 重构 server

### Patch Changes

- Updated dependencies [e8c8c5d]
- Updated dependencies [805e021]
  - @modern-js/utils@2.49.0
  - @modern-js/bff-core@2.49.0
  - @modern-js/server-utils@2.49.0
  - @modern-js/create-request@2.49.0

## 2.48.6

### Patch Changes

- @modern-js/bff-core@2.48.6
- @modern-js/create-request@2.48.6
- @modern-js/server-utils@2.48.6
- @modern-js/utils@2.48.6

## 2.48.5

### Patch Changes

- Updated dependencies [4ca9f4c]
  - @modern-js/utils@2.48.5
  - @modern-js/bff-core@2.48.5
  - @modern-js/create-request@2.48.5
  - @modern-js/server-utils@2.48.5

## 2.48.4

### Patch Changes

- Updated dependencies [7d2d433]
  - @modern-js/utils@2.48.4
  - @modern-js/bff-core@2.48.4
  - @modern-js/create-request@2.48.4
  - @modern-js/server-utils@2.48.4

## 2.48.3

### Patch Changes

- @modern-js/bff-core@2.48.3
- @modern-js/create-request@2.48.3
- @modern-js/server-utils@2.48.3
- @modern-js/utils@2.48.3

## 2.48.2

### Patch Changes

- Updated dependencies [ac586f1]
  - @modern-js/create-request@2.48.2
  - @modern-js/bff-core@2.48.2
  - @modern-js/server-utils@2.48.2
  - @modern-js/utils@2.48.2

## 2.48.1

### Patch Changes

- Updated dependencies [8942b90]
- Updated dependencies [488ec21]
- Updated dependencies [ce426f7]
  - @modern-js/utils@2.48.1
  - @modern-js/bff-core@2.48.1
  - @modern-js/create-request@2.48.1
  - @modern-js/server-utils@2.48.1

## 2.48.0

### Patch Changes

- Updated dependencies [c323a23]
  - @modern-js/utils@2.48.0
  - @modern-js/bff-core@2.48.0
  - @modern-js/create-request@2.48.0
  - @modern-js/server-utils@2.48.0

## 2.47.1

### Patch Changes

- @modern-js/bff-core@2.47.1
- @modern-js/create-request@2.47.1
- @modern-js/server-utils@2.47.1
- @modern-js/utils@2.47.1

## 2.47.0

### Patch Changes

- Updated dependencies [a5386ab]
  - @modern-js/utils@2.47.0
  - @modern-js/server-utils@2.47.0
  - @modern-js/bff-core@2.47.0
  - @modern-js/create-request@2.47.0

## 2.46.1

### Patch Changes

- @modern-js/bff-core@2.46.1
- @modern-js/create-request@2.46.1
- @modern-js/server-utils@2.46.1
- @modern-js/utils@2.46.1

## 2.46.0

### Patch Changes

- Updated dependencies [00b4639]
- Updated dependencies [4699e22]
  - @modern-js/create-request@2.46.0
  - @modern-js/server-utils@2.46.0
  - @modern-js/bff-core@2.46.0
  - @modern-js/utils@2.46.0

## 2.45.0

### Patch Changes

- @modern-js/server-utils@2.45.0
- @modern-js/bff-core@2.45.0
- @modern-js/create-request@2.45.0
- @modern-js/utils@2.45.0

## 2.44.0

### Patch Changes

- @modern-js/create-request@2.44.0
- @modern-js/bff-core@2.44.0
- @modern-js/utils@2.44.0
- @modern-js/server-utils@2.44.0

## 2.43.0

### Patch Changes

- 4b4d08a: chore: remove Rsbuild unsupported CHAIN_ID

  chore: 移除在 Rsbuild 中不支持的 CHAIN_ID

  - @modern-js/create-request@2.43.0
  - @modern-js/bff-core@2.43.0
  - @modern-js/utils@2.43.0
  - @modern-js/server-utils@2.43.0

## 2.42.2

### Patch Changes

- Updated dependencies [07c56c0]
  - @modern-js/server-utils@2.42.2
  - @modern-js/bff-core@2.42.2
  - @modern-js/create-request@2.42.2
  - @modern-js/utils@2.42.2

## 2.42.1

### Patch Changes

- @modern-js/bff-core@2.42.1
- @modern-js/create-request@2.42.1
- @modern-js/server-utils@2.42.1
- @modern-js/utils@2.42.1

## 2.42.0

### Patch Changes

- Updated dependencies [a3f2269]
  - @modern-js/bff-core@2.42.0
  - @modern-js/create-request@2.42.0
  - @modern-js/server-utils@2.42.0
  - @modern-js/utils@2.42.0

## 2.41.0

### Patch Changes

- c4d396a: chore(swc): bump swc and helpers
  chore(swc): 升级 swc 以及 helpers
- Updated dependencies [c4d396a]
  - @modern-js/create-request@2.41.0
  - @modern-js/bff-core@2.41.0
  - @modern-js/utils@2.41.0
  - @modern-js/server-utils@2.41.0

## 2.40.0

### Minor Changes

- 95f15d2: chore: remove ajv schema verification of configuration
  chore: 移除 ajv 对项目配置的校验

### Patch Changes

- Updated dependencies [95f15d2]
  - @modern-js/utils@2.40.0
  - @modern-js/bff-core@2.40.0
  - @modern-js/create-request@2.40.0
  - @modern-js/server-utils@2.40.0

## 2.39.2

### Patch Changes

- @modern-js/bff-core@2.39.2
- @modern-js/create-request@2.39.2
- @modern-js/server-utils@2.39.2
- @modern-js/utils@2.39.2

## 2.39.1

### Patch Changes

- @modern-js/create-request@2.39.1
- @modern-js/bff-core@2.39.1
- @modern-js/server-utils@2.39.1
- @modern-js/utils@2.39.1

## 2.39.0

### Patch Changes

- @modern-js/bff-core@2.39.0
- @modern-js/create-request@2.39.0
- @modern-js/server-utils@2.39.0
- @modern-js/utils@2.39.0

## 2.38.0

### Patch Changes

- 3304d33: chore(deps): bump @babel/core to v7.23.2

  chore(deps): 升级 @babel/core 至 v7.23.2

- Updated dependencies [3304d33]
  - @modern-js/server-utils@2.38.0
  - @modern-js/bff-core@2.38.0
  - @modern-js/create-request@2.38.0
  - @modern-js/utils@2.38.0

## 2.37.2

### Patch Changes

- @modern-js/bff-core@2.37.2
- @modern-js/create-request@2.37.2
- @modern-js/server-utils@2.37.2
- @modern-js/utils@2.37.2

## 2.37.1

### Patch Changes

- @modern-js/bff-core@2.37.1
- @modern-js/create-request@2.37.1
- @modern-js/server-utils@2.37.1
- @modern-js/utils@2.37.1

## 2.37.0

### Patch Changes

- Updated dependencies [383b636]
- Updated dependencies [ce0a14e]
- Updated dependencies [708f248]
  - @modern-js/utils@2.37.0
  - @modern-js/server-utils@2.37.0
  - @modern-js/bff-core@2.37.0
  - @modern-js/create-request@2.37.0

## 2.36.0

### Patch Changes

- f59b6f9: feat: support custom sdk in BFF
  feat: 在 BFF 中支持自定义 SDK
- Updated dependencies [3473bee]
- Updated dependencies [f59b6f9]
- Updated dependencies [b98f8aa]
- Updated dependencies [eb602d2]
  - @modern-js/utils@2.36.0
  - @modern-js/create-request@2.36.0
  - @modern-js/bff-core@2.36.0
  - @modern-js/server-utils@2.36.0

## 2.35.1

### Patch Changes

- Updated dependencies [ea3fe18]
- Updated dependencies [9dd3151]
- Updated dependencies [4980480]
- Updated dependencies [6a1d46e]
  - @modern-js/utils@2.35.1
  - @modern-js/create-request@2.35.1
  - @modern-js/bff-core@2.35.1
  - @modern-js/server-utils@2.35.1

## 2.35.0

### Patch Changes

- Updated dependencies [15b834f]
  - @modern-js/utils@2.35.0
  - @modern-js/bff-core@2.35.0
  - @modern-js/create-request@2.35.0
  - @modern-js/server-utils@2.35.0

## 2.34.0

### Patch Changes

- Updated dependencies [a77b82a]
- Updated dependencies [c8b448b]
  - @modern-js/utils@2.34.0
  - @modern-js/server-utils@2.34.0
  - @modern-js/bff-core@2.34.0
  - @modern-js/create-request@2.34.0

## 2.33.1

### Patch Changes

- @modern-js/bff-core@2.33.1
- @modern-js/create-request@2.33.1
- @modern-js/server-utils@2.33.1
- @modern-js/utils@2.33.1

## 2.33.0

### Patch Changes

- 01f3ca4: fix: should passthrough the requestCreator
  fix: 应该传 requestCreator
- 01f3ca4: fix: should passthrough the requestCreator
  fix: 应该透传 requestCreator
- Updated dependencies [fd82137]
- Updated dependencies [bc1f8da]
  - @modern-js/utils@2.33.0
  - @modern-js/bff-core@2.33.0
  - @modern-js/create-request@2.33.0
  - @modern-js/server-utils@2.33.0

## 2.32.1

### Patch Changes

- @modern-js/bff-core@2.32.1
- @modern-js/create-request@2.32.1
- @modern-js/utils@2.32.1
- @modern-js/server-utils@2.32.1

## 2.32.0

### Patch Changes

- 6076166: fix: packaging errors found by publint

  fix: 修复 publint 检测到的 packaging 问题

- 3c91100: chore(builder): using unified version of webpack-chain

  chore(builder): 使用统一的 webpack-chain 版本

- Updated dependencies [e5a3fb4]
- Updated dependencies [6076166]
- Updated dependencies [a030aff]
- Updated dependencies [3c91100]
- Updated dependencies [5255eba]
  - @modern-js/utils@2.32.0
  - @modern-js/create-request@2.32.0
  - @modern-js/bff-core@2.32.0
  - @modern-js/server-utils@2.32.0

## 2.31.2

### Patch Changes

- Updated dependencies [15d30abdc66]
  - @modern-js/utils@2.31.2
  - @modern-js/bff-core@2.31.2
  - @modern-js/create-request@2.31.2
  - @modern-js/server-utils@2.31.2

## 2.31.1

### Patch Changes

- @modern-js/bff-core@2.31.1
- @modern-js/create-request@2.31.1
- @modern-js/server-utils@2.31.1
- @modern-js/utils@2.31.1

## 2.31.0

### Patch Changes

- Updated dependencies [0a85bae]
- Updated dependencies [1882366]
  - @modern-js/create-request@2.31.0
  - @modern-js/utils@2.31.0
  - @modern-js/bff-core@2.31.0
  - @modern-js/server-utils@2.31.0

## 2.30.0

### Patch Changes

- Updated dependencies [cc5f49e]
  - @modern-js/server-utils@2.30.0
  - @modern-js/bff-core@2.30.0
  - @modern-js/create-request@2.30.0
  - @modern-js/utils@2.30.0

## 2.29.0

### Patch Changes

- Updated dependencies [e6b5355]
- Updated dependencies [93db783]
- Updated dependencies [cba7675]
- Updated dependencies [99052ea]
- Updated dependencies [1d71d2e]
  - @modern-js/utils@2.29.0
  - @modern-js/bff-core@2.29.0
  - @modern-js/create-request@2.29.0
  - @modern-js/server-utils@2.29.0

## 2.28.0

### Patch Changes

- Updated dependencies [00b58a7]
  - @modern-js/utils@2.28.0
  - @modern-js/bff-core@2.28.0
  - @modern-js/create-request@2.28.0
  - @modern-js/server-utils@2.28.0

## 2.27.0

### Patch Changes

- Updated dependencies [7d94d03]
- Updated dependencies [91d14b8]
- Updated dependencies [6d7104d]
  - @modern-js/bff-core@2.27.0
  - @modern-js/utils@2.27.0
  - @modern-js/create-request@2.27.0
  - @modern-js/server-utils@2.27.0

## 2.26.0

### Patch Changes

- Updated dependencies [1fb5804]
- Updated dependencies [22acfda]
  - @modern-js/server-utils@2.26.0
  - @modern-js/create-request@2.26.0
  - @modern-js/bff-core@2.26.0
  - @modern-js/utils@2.26.0

## 2.25.2

### Patch Changes

- 272646c: feat(builder): bump webpack v5.88, support top level await

  feat(builder): 升级 webpack v5.88, 支持 top level await

- 358ed24: fix: support configuration ts-node and avoid to register ts-node unnecessarily
  fix: 支持配置 ts-node，避免对 ts-node 不必要的注册
- Updated dependencies [63d8247]
- Updated dependencies [6651684]
- Updated dependencies [272646c]
- Updated dependencies [358ed24]
  - @modern-js/utils@2.25.2
  - @modern-js/create-request@2.25.2
  - @modern-js/bff-core@2.25.2
  - @modern-js/server-utils@2.25.2

## 2.25.1

### Patch Changes

- Updated dependencies [9f78d0c]
  - @modern-js/utils@2.25.1
  - @modern-js/bff-core@2.25.1
  - @modern-js/create-request@2.25.1
  - @modern-js/server-utils@2.25.1

## 2.25.0

### Patch Changes

- 4c4c0ad: feat: add named exports for all CLI plugins

  feat: 为各个 CLI 插件添加 named 导出

- Updated dependencies [5732c6a]
  - @modern-js/utils@2.25.0
  - @modern-js/bff-core@2.25.0
  - @modern-js/create-request@2.25.0
  - @modern-js/server-utils@2.25.0

## 2.24.0

### Patch Changes

- Updated dependencies [c882fbd]
- Updated dependencies [36f5bdf]
- Updated dependencies [4a82c3b]
  - @modern-js/utils@2.24.0
  - @modern-js/server-utils@2.24.0
  - @modern-js/bff-core@2.24.0
  - @modern-js/create-request@2.24.0

## 2.23.1

### Patch Changes

- Updated dependencies [f08bbfc]
- Updated dependencies [a6b313a]
- Updated dependencies [8f2cab0]
  - @modern-js/utils@2.23.1
  - @modern-js/bff-core@2.23.1
  - @modern-js/create-request@2.23.1
  - @modern-js/server-utils@2.23.1

## 2.23.0

### Patch Changes

- 7e6fb5f: chore: publishConfig add provenance config

  chore: publishConfig 增加 provenance 配置

- 6dec7c2: test(utils): reuse the snapshot serializer of vitest config

  test(utils): 复用 vitest 的 snapshot serializer

- c3216b5: chore: split the scheme into the plugin

  chore: 拆分 scheme 到插件内部

- Updated dependencies [7e6fb5f]
- Updated dependencies [a7a7ad7]
- Updated dependencies [6dec7c2]
- Updated dependencies [c3216b5]
  - @modern-js/create-request@2.23.0
  - @modern-js/bff-core@2.23.0
  - @modern-js/utils@2.23.0
  - @modern-js/server-utils@2.23.0

## 2.22.1

### Patch Changes

- Updated dependencies [e2848a2]
- Updated dependencies [4be1da5]
- Updated dependencies [d4045ed]
  - @modern-js/utils@2.22.1
  - @modern-js/server-utils@2.22.1
  - @modern-js/bff-core@2.22.1
  - @modern-js/create-request@2.22.1

## 2.22.0

### Patch Changes

- Updated dependencies [3d48836]
- Updated dependencies [5050e8e]
  - @modern-js/utils@2.22.0
  - @modern-js/bff-core@2.22.0
  - @modern-js/create-request@2.22.0
  - @modern-js/server-utils@2.22.0

## 2.21.1

### Patch Changes

- @modern-js/bff-core@2.21.1
- @modern-js/create-request@2.21.1
- @modern-js/server-utils@2.21.1
- @modern-js/utils@2.21.1

## 2.21.0

### Patch Changes

- 26dcf3a: chore: bump typescript to v5 in devDependencies

  chore: 升级 devDependencies 中的 typescript 版本到 v5

- ad78387: chore(deps): bump babel-related dependencies to latest version

  chore(deps): 升级 babel 相关依赖到最新版本

- Updated dependencies [e81eeaf]
- Updated dependencies [26dcf3a]
- Updated dependencies [056627f]
- Updated dependencies [0fc15ca]
- Updated dependencies [43b4e83]
- Updated dependencies [ad78387]
  - @modern-js/utils@2.21.0
  - @modern-js/create-request@2.21.0
  - @modern-js/bff-core@2.21.0
  - @modern-js/server-utils@2.21.0

## 2.20.0

### Patch Changes

- 6b9d90a: chore: remove @babel/runtime. add @swc/helper and enable `externalHelper` config.
  chore: 移除 @babel/runtime 依赖. 增加 @swc/helpers 依赖并且开启 `externalHelpers` 配置
- Updated dependencies [3c4e0a5]
- Updated dependencies [6b9d90a]
  - @modern-js/utils@2.20.0
  - @modern-js/create-request@2.20.0
  - @modern-js/bff-core@2.20.0
  - @modern-js/server-utils@2.20.0

## 2.19.1

### Patch Changes

- @modern-js/bff-core@2.19.1
- @modern-js/create-request@2.19.1
- @modern-js/server-utils@2.19.1
- @modern-js/utils@2.19.1

## 2.19.0

### Patch Changes

- 1134fe2: chore(deps): bump webpack from 5.76.2 to 5.82.1

  chore(deps): 将 webpack 从 5.76.2 升级至 5.82.1

- Updated dependencies [1134fe2]
  - @modern-js/utils@2.19.0
  - @modern-js/bff-core@2.19.0
  - @modern-js/create-request@2.19.0
  - @modern-js/server-utils@2.19.0

## 2.18.1

### Patch Changes

- @modern-js/bff-core@2.18.1
- @modern-js/create-request@2.18.1
- @modern-js/server-utils@2.18.1
- @modern-js/utils@2.18.1

## 2.18.0

### Patch Changes

- @modern-js/bff-core@2.18.0
- @modern-js/create-request@2.18.0
- @modern-js/server-utils@2.18.0
- @modern-js/utils@2.18.0

## 2.17.1

### Patch Changes

- @modern-js/bff-core@2.17.1
- @modern-js/create-request@2.17.1
- @modern-js/server-utils@2.17.1
- @modern-js/utils@2.17.1

## 2.17.0

### Patch Changes

- @modern-js/bff-core@2.17.0
- @modern-js/create-request@2.17.0
- @modern-js/server-utils@2.17.0
- @modern-js/utils@2.17.0

## 2.16.0

### Patch Changes

- 4e876ab: chore: package.json include the monorepo-relative directory

  chore: 在 package.json 中声明 monorepo 的子路径

- Updated dependencies [5954330]
- Updated dependencies [7596520]
- Updated dependencies [4e876ab]
  - @modern-js/utils@2.16.0
  - @modern-js/create-request@2.16.0
  - @modern-js/bff-core@2.16.0
  - @modern-js/server-utils@2.16.0

## 2.15.0

### Patch Changes

- @modern-js/bff-core@2.15.0
- @modern-js/create-request@2.15.0
- @modern-js/server-utils@2.15.0
- @modern-js/utils@2.15.0

## 2.14.0

### Patch Changes

- 8a3c693: chore(server): no longer replace globalVars when compiler is babel

  chore(server): 进行 babel compile 时不再替换 globalVars

- Updated dependencies [4779152]
- Updated dependencies [8a3c693]
- Updated dependencies [9321bef]
- Updated dependencies [9b45c58]
- Updated dependencies [52d0cb1]
- Updated dependencies [60a81d0]
- Updated dependencies [dacef96]
- Updated dependencies [16399fd]
  - @modern-js/utils@2.14.0
  - @modern-js/server-utils@2.14.0
  - @modern-js/bff-core@2.14.0
  - @modern-js/create-request@2.14.0

## 2.13.4

### Patch Changes

- @modern-js/bff-core@2.13.4
- @modern-js/create-request@2.13.4
- @modern-js/server-utils@2.13.4
- @modern-js/utils@2.13.4

## 2.13.3

### Patch Changes

- @modern-js/bff-core@2.13.3
- @modern-js/create-request@2.13.3
- @modern-js/server-utils@2.13.3
- @modern-js/utils@2.13.3

## 2.13.2

### Patch Changes

- @modern-js/bff-core@2.13.2
- @modern-js/create-request@2.13.2
- @modern-js/server-utils@2.13.2
- @modern-js/utils@2.13.2

## 2.13.1

### Patch Changes

- @modern-js/bff-core@2.13.1
- @modern-js/create-request@2.13.1
- @modern-js/server-utils@2.13.1
- @modern-js/utils@2.13.1

## 2.13.0

### Patch Changes

- 8c853c7: hotfix: support bffPlugin when use rspack

  hotfix: 在使用 Rspack 构建时，支持 BFF 插件

  - @modern-js/server-utils@2.13.0
  - @modern-js/bff-core@2.13.0
  - @modern-js/create-request@2.13.0
  - @modern-js/utils@2.13.0

## 2.12.0

### Patch Changes

- Updated dependencies [c2ca6c8]
- Updated dependencies [6d86e34]
- Updated dependencies [05493a7]
  - @modern-js/utils@2.12.0
  - @modern-js/server-utils@2.12.0
  - @modern-js/bff-core@2.12.0
  - @modern-js/create-request@2.12.0

## 2.11.0

### Patch Changes

- Updated dependencies [5898210]
- Updated dependencies [cfb058f]
- Updated dependencies [0bd018b]
- Updated dependencies [5d624fd]
- Updated dependencies [e2466a1]
- Updated dependencies [02bb383]
- Updated dependencies [381a3b9]
- Updated dependencies [7a60f10]
- Updated dependencies [274b2e5]
- Updated dependencies [b9e1c54]
  - @modern-js/create-request@2.11.0
  - @modern-js/utils@2.11.0
  - @modern-js/bff-core@2.11.0
  - @modern-js/server-utils@2.11.0

## 2.10.0

### Patch Changes

- 0da32d0: chore: upgrade jest and puppeteer
  chore: 升级 jest 和 puppeteer 到 latest
- 0d9962b: fix: add types field in package.json
  fix: 添加 package.json 中的 types 字段
- fbefa7e: chore(deps): bump webpack from 5.75.0 to 5.76.2

  chore(deps): 将 webpack 从 5.75.0 升级至 5.76.2

- Updated dependencies [0da32d0]
- Updated dependencies [0d9962b]
- Updated dependencies [fbefa7e]
- Updated dependencies [4d54233]
- Updated dependencies [6db4864]
  - @modern-js/create-request@2.10.0
  - @modern-js/bff-core@2.10.0
  - @modern-js/utils@2.10.0
  - @modern-js/server-utils@2.10.0

## 2.9.0

### Patch Changes

- @modern-js/bff-core@2.9.0
- @modern-js/create-request@2.9.0
- @modern-js/server-utils@2.9.0
- @modern-js/utils@2.9.0

## 2.8.0

### Patch Changes

- 1a8d0ffef0: fix: remove require.cache first when the bff loader execute
  fix: 当 bff.loader 执行时，移除 require.cache
- Updated dependencies [1a8d0ffef0]
- Updated dependencies [1104a9f18b]
- Updated dependencies [2c1151271d]
- Updated dependencies [4cfea8ce49]
- Updated dependencies [1f6ca2c7fb]
  - @modern-js/create-request@2.8.0
  - @modern-js/utils@2.8.0
  - @modern-js/server-utils@2.8.0
  - @modern-js/bff-core@2.8.0

## 2.7.0

### Minor Changes

- 84bfb439b8: feat: support custom apiDir, lambdaDir and style of writing for bff
  feat: 支持定制 api 目录，lambda 目录，bff 的写法

### Patch Changes

- 7bb1554194: fix: remove process.env.PORT from the bff generate client code
  fix: 从 bff 的 generate client code 中移除 process.env.PORT
- 1eea234fdd: chore: make test files naming consistent

  chore: 统一测试文件命名为小驼峰格式

- Updated dependencies [0f15fc597c]
- Updated dependencies [dcad887024]
- Updated dependencies [a4672f7c16]
- Updated dependencies [7bb1554194]
- Updated dependencies [7fff9020e1]
- Updated dependencies [1eea234fdd]
- Updated dependencies [84bfb439b8]
  - @modern-js/utils@2.7.0
  - @modern-js/bff-core@2.7.0
  - @modern-js/server-utils@2.7.0
  - @modern-js/create-request@2.7.0

## 2.6.0

### Patch Changes

- Updated dependencies [ba6db6e]
- Updated dependencies [e1f799e]
- Updated dependencies [7915ab3]
- Updated dependencies [0fe658a]
  - @modern-js/create-request@2.6.0
  - @modern-js/utils@2.6.0
  - @modern-js/bff-core@2.6.0
  - @modern-js/server-utils@2.6.0

## 2.5.0

### Patch Changes

- 89ca6cc: refactor: merge build-config into scripts/build

  refactor: 把 build-config 合并进 scripts/build

- 6fca567: feat: support bff handle complete server, include page render
  feat: 支持 bff 处理整个服务，包括页面渲染
- 30614fa: chore: modify package.json entry fields and build config
  chore: 更改 package.json entry 字段以及构建配置
- Updated dependencies [89ca6cc]
- Updated dependencies [30614fa]
- Updated dependencies [1b0ce87]
- Updated dependencies [11c053b]
  - @modern-js/bff-core@2.5.0
  - @modern-js/create-request@2.5.0
  - @modern-js/server-utils@2.5.0
  - @modern-js/utils@2.5.0

## 2.4.0

### Patch Changes

- Updated dependencies [98a2733]
- Updated dependencies [8c2db5f]
  - @modern-js/utils@2.4.0
  - @modern-js/bff-core@2.4.0
  - @modern-js/create-request@2.4.0
  - @modern-js/server-utils@2.4.0

## 2.3.0

### Patch Changes

- Updated dependencies [fd5a3ed]
- Updated dependencies [6ca1c0b]
- Updated dependencies [89b6739]
- Updated dependencies [b4dd017]
  - @modern-js/utils@2.3.0
  - @modern-js/create-request@2.3.0
  - @modern-js/bff-core@2.3.0
  - @modern-js/server-utils@2.3.0

## 2.2.0

### Patch Changes

- cb12ee7: chore: remove some unused deps, bump postcss version

  chore: 移除未使用的依赖, 升级 postcss 版本

- Updated dependencies [cb12ee7]
- Updated dependencies [49eff0c]
  - @modern-js/server-utils@2.2.0
  - @modern-js/utils@2.2.0
  - @modern-js/bff-core@2.2.0
  - @modern-js/create-request@2.2.0

## 2.1.0

### Patch Changes

- Updated dependencies [837620c]
- Updated dependencies [8a9482c]
  - @modern-js/utils@2.1.0
  - @modern-js/bff-core@2.1.0
  - @modern-js/create-request@2.1.0
  - @modern-js/server-utils@2.1.0
  - @modern-js/babel-compiler@2.1.0

## 2.0.2

### Patch Changes

- @modern-js/utils@2.0.2
- @modern-js/bff-core@2.0.2
- @modern-js/create-request@2.0.2
- @modern-js/server-utils@2.0.2
- @modern-js/babel-compiler@2.0.2

## 2.0.1

### Patch Changes

- @modern-js/bff-core@2.0.1
- @modern-js/create-request@2.0.1
- @modern-js/server-utils@2.0.1
- @modern-js/babel-compiler@2.0.1
- @modern-js/utils@2.0.1

## 2.0.0

### Major Changes

- dda38c9c3e: chore: v2

### Patch Changes

- Updated dependencies [edd1cfb1af]
- Updated dependencies [dda38c9c3e]
- Updated dependencies [ffb2ed4]
- Updated dependencies [bbe4c4ab64]
  - @modern-js/utils@2.0.0
  - @modern-js/bff-core@2.0.0
  - @modern-js/create-request@2.0.0
  - @modern-js/server-utils@2.0.0
  - @modern-js/babel-compiler@2.0.0

## 2.0.0-beta.7

### Major Changes

- dda38c9c3e: chore: v2

### Patch Changes

- Updated dependencies [edd1cfb1af]
- Updated dependencies [dda38c9c3e]
- Updated dependencies [bbe4c4ab64]
  - @modern-js/utils@2.0.0-beta.7
  - @modern-js/bff-core@2.0.0-beta.7
  - @modern-js/create-request@2.0.0-beta.7
  - @modern-js/server-utils@2.0.0-beta.7
  - @modern-js/babel-compiler@2.0.0-beta.7

## 2.0.0-beta.6

### Major Changes

- dda38c9c3e: chore: v2

### Minor Changes

- df7ee2d: feat: runtime user config types extends
  feat: runtime 用户配置类型扩展

### Patch Changes

- 8ff2cf4c71: fix: bff api loader should run before babel loader
  fix: bff 一体化调用的 loader 应该在 babel loader 前执行
- ea7cf06257: chore: bump webpack/babel-loader/postcss-loader/tsconfig-paths

  chore: 升级 webpack/babel-loader/postcss-loader/tsconfig-paths 版本

- Updated dependencies [9b915e0c10]
- Updated dependencies [7879e8f711]
- Updated dependencies [d4e8e6fb90]
- Updated dependencies [6aca875011]
- Updated dependencies [2e6031955e]
- Updated dependencies [2344eb26ed]
- Updated dependencies [a2509bfbdb]
- Updated dependencies [7b7d12cf8f]
- Updated dependencies [7efeed4]
- Updated dependencies [92f0eade39]
- Updated dependencies [edd1cfb1af]
- Updated dependencies [cc971eabfc]
- Updated dependencies [5b9049f2e9]
- Updated dependencies [a8642da58f]
- Updated dependencies [92004d1906]
- Updated dependencies [b8bbe036c7]
- Updated dependencies [c2bb0f1745]
- Updated dependencies [d5a31df781]
- Updated dependencies [dda38c9c3e]
- Updated dependencies [3bbea92b2a]
- Updated dependencies [b710adb843]
- Updated dependencies [ea7cf06257]
- Updated dependencies [bbe4c4ab64]
- Updated dependencies [e4558a0bc4]
- Updated dependencies [abf3421a75]
- Updated dependencies [543be9558e]
- Updated dependencies [14b712da84]
  - @modern-js/server-utils@2.0.0-beta.6
  - @modern-js/utils@2.0.0-beta.6
  - @modern-js/bff-core@2.0.0-beta.6
  - @modern-js/create-request@2.0.0-beta.6
  - @modern-js/babel-compiler@2.0.0-beta.6

## 2.0.0-beta.4

### Major Changes

- dda38c9c3e: chore: v2

### Patch Changes

- 8ff2cf4c71: fix: bff api loader should run before babel loader
  fix: bff 一体化调用的 loader 应该在 babel loader 前执行
- ea7cf06: chore: bump webpack/babel-loader/postcss-loader/tsconfig-paths

  chore: 升级 webpack/babel-loader/postcss-loader/tsconfig-paths 版本

- Updated dependencies [9b915e0c10]
- Updated dependencies [7879e8f]
- Updated dependencies [d4e8e6fb90]
- Updated dependencies [6aca875]
- Updated dependencies [2e6031955e]
- Updated dependencies [2344eb26ed]
- Updated dependencies [a2509bfbdb]
- Updated dependencies [7b7d12c]
- Updated dependencies [92f0eade39]
- Updated dependencies [edd1cfb1af]
- Updated dependencies [cc971eabfc]
- Updated dependencies [5b9049f2e9]
- Updated dependencies [a8642da58f]
- Updated dependencies [92004d1906]
- Updated dependencies [b8bbe036c7]
- Updated dependencies [c2bb0f1745]
- Updated dependencies [d5a31df781]
- Updated dependencies [dda38c9c3e]
- Updated dependencies [3bbea92b2a]
- Updated dependencies [b710adb843]
- Updated dependencies [ea7cf06]
- Updated dependencies [bbe4c4a]
- Updated dependencies [e4558a0]
- Updated dependencies [abf3421a75]
- Updated dependencies [543be9558e]
- Updated dependencies [14b712da84]
  - @modern-js/server-utils@2.0.0-beta.4
  - @modern-js/utils@2.0.0-beta.4
  - @modern-js/bff-core@2.0.0-beta.4
  - @modern-js/create-request@2.0.0-beta.4
  - @modern-js/babel-compiler@2.0.0-beta.4

## 2.0.0-beta.3

### Major Changes

- dda38c9c3e: chore: v2

### Patch Changes

- 8ff2cf4c71: fix: bff api loader should run before babel loader
  fix: bff 一体化调用的 loader 应该在 babel loader 前执行
- ea7cf06: chore: bump webpack/babel-loader/postcss-loader/tsconfig-paths

  chore: 升级 webpack/babel-loader/postcss-loader/tsconfig-paths 版本

- Updated dependencies [9b915e0c10]
- Updated dependencies [d4e8e6f]
- Updated dependencies [6aca875]
- Updated dependencies [2e60319]
- Updated dependencies [2344eb26ed]
- Updated dependencies [a2509bfbdb]
- Updated dependencies [92f0eade39]
- Updated dependencies [edd1cfb1af]
- Updated dependencies [cc971eabfc]
- Updated dependencies [5b9049f2e9]
- Updated dependencies [a8642da58f]
- Updated dependencies [92004d1906]
- Updated dependencies [b8bbe036c7]
- Updated dependencies [c2bb0f1]
- Updated dependencies [d5a31df781]
- Updated dependencies [dda38c9c3e]
- Updated dependencies [3bbea92b2a]
- Updated dependencies [b710adb]
- Updated dependencies [ea7cf06]
- Updated dependencies [bbe4c4a]
- Updated dependencies [e4558a0]
- Updated dependencies [abf3421a75]
- Updated dependencies [543be9558e]
- Updated dependencies [14b712da84]
  - @modern-js/server-utils@2.0.0-beta.3
  - @modern-js/utils@2.0.0-beta.3
  - @modern-js/bff-core@2.0.0-beta.3
  - @modern-js/create-request@2.0.0-beta.3
  - @modern-js/babel-compiler@2.0.0-beta.3

## 2.0.0-beta.2

### Major Changes

- dda38c9c3e: chore: v2

### Patch Changes

- 8ff2cf4c71: fix: bff api loader should run before babel loader
  fix: bff 一体化调用的 loader 应该在 babel loader 前执行
- Updated dependencies [9b915e0c10]
- Updated dependencies [2344eb2]
- Updated dependencies [a2509bfbdb]
- Updated dependencies [92f0ead]
- Updated dependencies [edd1cfb1af]
- Updated dependencies [cc971eabfc]
- Updated dependencies [5b9049f2e9]
- Updated dependencies [a8642da58f]
- Updated dependencies [92004d1]
- Updated dependencies [b8bbe036c7]
- Updated dependencies [c2bb0f1]
- Updated dependencies [d5a31df781]
- Updated dependencies [dda38c9c3e]
- Updated dependencies [3bbea92b2a]
- Updated dependencies [abf3421a75]
- Updated dependencies [543be9558e]
- Updated dependencies [14b712da84]
  - @modern-js/server-utils@2.0.0-beta.2
  - @modern-js/bff-core@2.0.0-beta.2
  - @modern-js/utils@2.0.0-beta.2
  - @modern-js/create-request@2.0.0-beta.2
  - @modern-js/babel-compiler@2.0.0-beta.2

## 2.0.0-beta.1

### Major Changes

- dda38c9: chore: v2

### Patch Changes

- 8ff2cf4c71: fix: bff api loader should run before babel loader
  fix: bff 一体化调用的 loader 应该在 babel loader 前执行
- Updated dependencies [9b915e0c10]
- Updated dependencies [2344eb2]
- Updated dependencies [a2509bfbdb]
- Updated dependencies [92f0ead]
- Updated dependencies [edd1cfb1af]
- Updated dependencies [cc971eabfc]
- Updated dependencies [5b9049f]
- Updated dependencies [a8642da]
- Updated dependencies [92004d1]
- Updated dependencies [b8bbe036c7]
- Updated dependencies [d5a31df781]
- Updated dependencies [dda38c9]
- Updated dependencies [3bbea92b2a]
- Updated dependencies [abf3421]
- Updated dependencies [543be9558e]
- Updated dependencies [14b712d]
  - @modern-js/server-utils@2.0.0-beta.1
  - @modern-js/bff-core@2.0.0-beta.1
  - @modern-js/utils@2.0.0-beta.1
  - @modern-js/create-request@2.0.0-beta.1
  - @modern-js/babel-compiler@2.0.0-beta.1

## 2.0.0-beta.0

### Major Changes

- dda38c9: chore: v2

### Patch Changes

- 8ff2cf4: fix: bff api loader should run before babel loader
  fix: bff 一体化调用的 loader 应该在 babel loader 前执行
- Updated dependencies [9b915e0c1]
- Updated dependencies [a2509bf]
- Updated dependencies [edd1cfb1a]
- Updated dependencies [cc971eabf]
- Updated dependencies [5b9049f]
- Updated dependencies [a8642da]
- Updated dependencies [b8bbe036c]
- Updated dependencies [d5a31df78]
- Updated dependencies [dda38c9]
- Updated dependencies [3bbea92b2]
- Updated dependencies [abf3421]
- Updated dependencies [543be95]
- Updated dependencies [14b712d]
  - @modern-js/server-utils@2.0.0-beta.0
  - @modern-js/bff-core@2.0.0-beta.0
  - @modern-js/utils@2.0.0-beta.0
  - @modern-js/create-request@2.0.0-beta.0
  - @modern-js/babel-compiler@2.0.0-beta.0

## 1.21.2

### Patch Changes

- Updated dependencies [9d4c0ba]
  - @modern-js/bff-core@1.21.2
  - @modern-js/server-utils@1.21.2
  - @modern-js/create-request@1.21.2
  - @modern-js/babel-compiler@1.21.2
  - @modern-js/utils@1.21.2

## 1.21.1

### Patch Changes

- @modern-js/bff-core@1.21.1
- @modern-js/create-request@1.21.1
- @modern-js/server-utils@1.21.1
- @modern-js/babel-compiler@1.21.1
- @modern-js/utils@1.21.1

## 1.21.0

### Patch Changes

- cc3cab0: fix: modify the parameters passed to the compile function of server-utils
  fix: 修改传入 server-utils 的 compile 函数的参数
- Updated dependencies [8f3674a]
  - @modern-js/server-utils@1.21.0
  - @modern-js/utils@1.21.0
  - @modern-js/bff-core@1.21.0
  - @modern-js/create-request@1.21.0
  - @modern-js/babel-compiler@1.21.0

## 1.20.1

### Patch Changes

- Updated dependencies [49515c5]
  - @modern-js/utils@1.20.1
  - @modern-js/bff-core@1.20.1
  - @modern-js/create-request@1.20.1
  - @modern-js/server-utils@1.20.1
  - @modern-js/babel-compiler@1.20.1

## 1.20.0

### Patch Changes

- 4ddc185: chore(builder): bump webpack to 5.74.0

  chore(builder): 升级 webpack 到 5.74.0 版本

- Updated dependencies [d5d570b]
- Updated dependencies [4ddc185]
- Updated dependencies [df8ee7e]
- Updated dependencies [8c05089]
  - @modern-js/utils@1.20.0
  - @modern-js/bff-core@1.20.0
  - @modern-js/create-request@1.20.0
  - @modern-js/server-utils@1.20.0
  - @modern-js/babel-compiler@1.20.0

## 1.19.0

### Patch Changes

- @modern-js/server-utils@1.19.0
- @modern-js/bff-core@1.19.0
- @modern-js/create-request@1.19.0
- @modern-js/babel-compiler@1.19.0
- @modern-js/utils@1.19.0

## 1.18.1

### Patch Changes

- Updated dependencies [fb02c81]
- Updated dependencies [9fcfbd4]
- Updated dependencies [6c2c745]
  - @modern-js/server-utils@1.18.1
  - @modern-js/utils@1.18.1
  - @modern-js/bff-core@1.18.1
  - @modern-js/create-request@1.18.1
  - @modern-js/babel-compiler@1.18.1

## 1.18.0

### Patch Changes

- 3d5e3a5: chore: get api mode from bff core
  chore: 从 bff core 中获取 api mode
- 2b7406d: feat: use typescript instead of babel as typescript compiler in server
  feat: 服务端，增加 typescript 作为 typescipt 编译器
- Updated dependencies [8280920]
- Updated dependencies [3d5e3a5]
- Updated dependencies [2b7406d]
- Updated dependencies [0a4d622]
- Updated dependencies [60a2e3a]
- Updated dependencies [5227370]
- Updated dependencies [7928bae]
  - @modern-js/utils@1.18.0
  - @modern-js/bff-core@1.18.0
  - @modern-js/server-utils@1.18.0
  - @modern-js/create-request@1.18.0
  - @modern-js/babel-compiler@1.18.0

## 1.17.0

### Patch Changes

- Updated dependencies [1b9176f]
- Updated dependencies [77d3a38]
- Updated dependencies [151329d]
- Updated dependencies [5af9472]
- Updated dependencies [6b6a534]
- Updated dependencies [6b43a2b]
- Updated dependencies [a7be124]
- Updated dependencies [31547b4]
  - @modern-js/utils@1.17.0
  - @modern-js/bff-core@1.17.0
  - @modern-js/create-request@1.17.0
  - @modern-js/server-utils@1.17.0
  - @modern-js/babel-compiler@1.17.0

## 1.16.0

### Minor Changes

- 020b9bd52: feat: support frame mode without lambda directories
  feat: 支持无 lambda 目录的框架模式

### Patch Changes

- Updated dependencies [641592f52]
- Updated dependencies [3904b30a5]
- Updated dependencies [1100dd58c]
- Updated dependencies [e04e6e76a]
- Updated dependencies [81c66e4a4]
- Updated dependencies [2c305b6f5]
- Updated dependencies [020b9bd52]
  - @modern-js/utils@1.16.0
  - @modern-js/create-request@1.16.0
  - @modern-js/server-utils@1.16.0
  - @modern-js/bff-core@1.16.0
  - @modern-js/babel-compiler@1.16.0

## 1.15.0

### Patch Changes

- c0d8dac: fix: remove package adapter-helpers and bff runtime export
- Updated dependencies [c0d8dac]
- Updated dependencies [8658a78]
- Updated dependencies [05d4a4f]
- Updated dependencies [7bfaaf9]
- Updated dependencies [b1f7000]
- Updated dependencies [ad05af9]
- Updated dependencies [5d53d1c]
- Updated dependencies [37cd159]
  - @modern-js/bff-core@1.15.0
  - @modern-js/utils@1.15.0
  - @modern-js/create-request@1.15.0
  - @modern-js/server-utils@1.15.0
  - @modern-js/babel-compiler@1.15.0

## 1.6.2

### Patch Changes

- a27ab8d: feat: add onApiChange hook for bff hot reload
  feat: 为 BFF 热更新优化，添加 onApiChange 钩子
- Updated dependencies [a27ab8d]
  - @modern-js/bff-core@1.1.2
  - @modern-js/server-utils@1.2.11
  - @modern-js/utils@1.7.12

## 1.6.1

### Patch Changes

- d86f009: feat: optimize implentation of registerModernRuntimePath
- Updated dependencies [dc4676b]
- Updated dependencies [d86f009]
  - @modern-js/utils@1.7.12
  - @modern-js/bff-core@1.1.1

## 1.6.0

### Minor Changes

- 77a8e9e: feat: support bff operators

### Patch Changes

- f29e9ba: feat: simplify context usage, no longer depend on containers
- 6eebd9c: fix: resolve server runtime alias for esbuild-register
- Updated dependencies [77a8e9e]
- Updated dependencies [77a8e9e]
- Updated dependencies [b220f1d]
- Updated dependencies [7b9e302]
- Updated dependencies [a90bc96]
  - @modern-js/bff-core@1.1.0
  - @modern-js/create-request@1.3.0
  - @modern-js/utils@1.7.9
  - @modern-js/server-utils@1.2.11

## 1.5.2

### Patch Changes

- a1198d509: feat: bump babel 7.18.0
- c1a4ead09: fix: plugin-bff should compile shared directory
- Updated dependencies [a1198d509]
  - @modern-js/bff-utils@1.2.9
  - @modern-js/create-request@1.2.11
  - @modern-js/server-utils@1.2.10
  - @modern-js/babel-compiler@1.2.6

## 1.5.1

### Patch Changes

- 6451a098: fix: cyclic dependencies of @modern-js/core and @moden-js/webpack
- Updated dependencies [d57e7622]
- Updated dependencies [6451a098]
- Updated dependencies [bfccb4c8]
- Updated dependencies [d5a2cfd8]
- Updated dependencies [437367c6]
  - @modern-js/bff-utils@1.2.8
  - @modern-js/utils@1.7.6
  - @modern-js/create-request@1.2.10
  - @modern-js/server-utils@1.2.9

## 1.5.0

### Minor Changes

- f66fa0e98: feat: support tools.webpackChain config

### Patch Changes

- 1dfe08fcd: feat(webpack): add CHAIN_ID constants for webpack chain
- 41dc62010: fix: remove typings from ignore directories
- Updated dependencies [77917e355]
- Updated dependencies [33de0f7ec]
  - @modern-js/server-utils@1.2.9
  - @modern-js/utils@1.7.5

## 1.4.5

### Patch Changes

- d32f35134: chore: add modern/jest/eslint/ts config files to .npmignore
- Updated dependencies [d32f35134]
- Updated dependencies [6ae4a34ae]
- Updated dependencies [b80229c79]
- Updated dependencies [1a30be07b]
- Updated dependencies [948cc4436]
  - @modern-js/bff-utils@1.2.6
  - @modern-js/create-request@1.2.8
  - @modern-js/server-utils@1.2.6
  - @modern-js/babel-compiler@1.2.5
  - @modern-js/utils@1.7.3

## 1.4.4

### Patch Changes

- 0e0537005: fix: unlock @babel/core version
- 69a728375: fix: remove exports.jsnext:source after publish
- Updated dependencies [cd7346b0d]
- Updated dependencies [0e0537005]
- Updated dependencies [69a728375]
  - @modern-js/utils@1.7.2
  - @modern-js/server-utils@1.2.5
  - @modern-js/babel-compiler@1.2.4
  - @modern-js/bff-utils@1.2.5
  - @modern-js/create-request@1.2.7

## 1.4.3

### Patch Changes

- 0ee4bb4e: fix: remove loader-utils from dependencies
- Updated dependencies [4697d1db]
- Updated dependencies [0ee4bb4e]
- Updated dependencies [6fa74d5f]
  - @modern-js/create-request@1.2.6
  - @modern-js/utils@1.7.0
  - @modern-js/server-utils@1.2.4

## 1.4.2

### Patch Changes

- 895fa0ff: chore: using "workspace:\*" in devDependencies
- Updated dependencies [2d155c4c]
- Updated dependencies [123e432d]
- Updated dependencies [e5a9b26d]
- Updated dependencies [0b26b93b]
- Updated dependencies [123e432d]
- Updated dependencies [f9f66ef9]
- Updated dependencies [592edabc]
- Updated dependencies [895fa0ff]
- Updated dependencies [3578913e]
- Updated dependencies [0fccff68]
- Updated dependencies [1c3beab3]
  - @modern-js/utils@1.6.0
  - @modern-js/bff-utils@1.2.4
  - @modern-js/server-utils@1.2.4
  - @modern-js/create-request@1.2.5

## 1.4.1

### Patch Changes

- 04ae5262: chore: bump @modern-js/utils to v1.4.1 in dependencies
- 60f7d8bf: feat: add tests dir to npmignore
- e4cec1ce: types: fix config hook type
- Updated dependencies [b8599d09]
- Updated dependencies [6cffe99d]
- Updated dependencies [04ae5262]
- Updated dependencies [60f7d8bf]
- Updated dependencies [3bf4f8b0]
  - @modern-js/utils@1.5.0
  - @modern-js/bff-utils@1.2.3
  - @modern-js/server-utils@1.2.3
  - @modern-js/babel-compiler@1.2.3
  - @modern-js/create-request@1.2.4

## 1.4.0

### Minor Changes

- d2d1d6b2: feat: support server config

### Patch Changes

- d2d1d6b2: feat: add prepare hook
- Updated dependencies [77ff9754]
- Updated dependencies [d2d1d6b2]
- Updated dependencies [07a4887e]
- Updated dependencies [ea2ae711]
- Updated dependencies [17d0cc46]
- Updated dependencies [d2d1d6b2]
  - @modern-js/utils@1.4.0
  - @modern-js/server-utils@1.2.2

## 1.3.9

### Patch Changes

- bebb39b6: chore: improve devDependencies and peerDependencies
- 132f7b53: feat: move config declarations to @modern-js/core
- Updated dependencies [bebb39b6]
- Updated dependencies [132f7b53]
  - @modern-js/server-utils@1.2.2
  - @modern-js/utils@1.3.7

## 1.3.8

### Patch Changes

- c1b8fa0a: feat: convert to new server plugin
- Updated dependencies [c2046f37]
  - @modern-js/utils@1.3.6

## 1.3.6

### Patch Changes

- 3eee457b: fix: move some peerDependencies to dependecies
- Updated dependencies [cc5e8001]
- Updated dependencies [2520ea86]
- Updated dependencies [3eee457b]
- Updated dependencies [db43dce6]
- Updated dependencies [e81fd9b7]
- Updated dependencies [1c411e71]
  - @modern-js/core@1.4.6
  - @modern-js/create-request@1.2.2
  - @modern-js/utils@1.3.4

## 1.3.5

### Patch Changes

- 55e18278: chore: remove unused dependencies and devDependencies
- bdcf0865: fix: add default types for plugin bff
- bdcf0865: fix: Ignore \*.test.ts files for api dir build
- Updated dependencies [969f172f]
- Updated dependencies [4c792f68]
- Updated dependencies [4b5d4bf4]
- Updated dependencies [62f5b8c8]
- Updated dependencies [55e18278]
- Updated dependencies [4499a674]
- Updated dependencies [403f5169]
- Updated dependencies [a7f42f48]
  - @modern-js/core@1.4.4
  - @modern-js/utils@1.3.3
  - @modern-js/babel-compiler@1.2.2

## 1.3.4

### Patch Changes

- 8f24a514: fix: allow reference typings to index file
- Updated dependencies [deeaa602]
- Updated dependencies [54786e58]
  - @modern-js/utils@1.3.2
  - @modern-js/core@1.4.3

## 1.3.3

### Patch Changes

- 272cab15: refactor server plugin manager
- Updated dependencies [d9cc5ea9]
- Updated dependencies [bd819a8d]
- Updated dependencies [ec4dbffb]
- Updated dependencies [d099e5c5]
- Updated dependencies [bada2879]
- Updated dependencies [24f616ca]
- Updated dependencies [bd819a8d]
- Updated dependencies [272cab15]
  - @modern-js/core@1.4.0
  - @modern-js/utils@1.3.0
  - @modern-js/server-core@1.2.2

## 1.3.2

### Patch Changes

- 83166714: change .npmignore
- Updated dependencies [83166714]
- Updated dependencies [c3de9882]
- Updated dependencies [33ff48af]
  - @modern-js/babel-preset-lib@1.2.1
  - @modern-js/core@1.3.2
  - @modern-js/bff-utils@1.2.2
  - @modern-js/create-request@1.2.1
  - @modern-js/server-plugin@1.2.1
  - @modern-js/server-utils@1.2.1
  - @modern-js/babel-chain@1.2.1
  - @modern-js/babel-compiler@1.2.1
  - @modern-js/utils@1.2.2

## 1.3.1

### Patch Changes

- e2d3a575: fix extending core config interface
- Updated dependencies [823809c6]
- Updated dependencies [4584cc04]
- Updated dependencies [7c19fd94]
  - @modern-js/bff-utils@1.2.1
  - @modern-js/utils@1.2.1
  - @modern-js/core@1.3.1

## 1.3.0

### Minor Changes

- cfe11628: Make Modern.js self bootstraping

### Patch Changes

- 8e7603ee: fix custom requestCreator path
- 1ebc7ee2: fix: @babel/core version
- Updated dependencies [2da09c69]
- Updated dependencies [5597289b]
- Updated dependencies [fc71e36f]
- Updated dependencies [146dcd85]
- Updated dependencies [c3d46ee4]
- Updated dependencies [cfe11628]
- Updated dependencies [146dcd85]
- Updated dependencies [8e7603ee]
- Updated dependencies [146dcd85]
- Updated dependencies [1ebc7ee2]
  - @modern-js/utils@1.2.0
  - @modern-js/create-request@1.2.0
  - @modern-js/core@1.3.0
  - @modern-js/server-utils@1.2.0
  - @modern-js/babel-preset-lib@1.2.0
  - @modern-js/bff-utils@1.2.0
  - @modern-js/server-plugin@1.2.0
  - @modern-js/babel-chain@1.2.0
  - @modern-js/babel-compiler@1.2.0

## 1.2.1

### Patch Changes

- e51b1db3: feat: support custom sdk, interceptor, headers for bff request
- Updated dependencies [e51b1db3]
- Updated dependencies [b37f78c8]
- Updated dependencies [2da27d3b]
- Updated dependencies [b7fb82ec]
  - @modern-js/create-request@1.1.2
  - @modern-js/server-plugin@1.1.4
  - @modern-js/babel-chain@1.1.2
  - @modern-js/babel-compiler@1.1.4
  - @modern-js/utils@1.1.6

## 1.2.0

### Minor Changes

- 5a4c557e: feat: support bff test

### Patch Changes

- Updated dependencies [90eeb72c]
- Updated dependencies [e04914ce]
- Updated dependencies [5a4c557e]
- Updated dependencies [e04914ce]
- Updated dependencies [ca7dcb32]
- Updated dependencies [ca7dcb32]
- Updated dependencies [ecb344dc]
  - @modern-js/core@1.2.0
  - @modern-js/server-plugin@1.1.3
  - @modern-js/babel-preset-lib@1.1.4
  - @modern-js/babel-compiler@1.1.3
  - @modern-js/utils@1.1.5

## 1.1.2

### Patch Changes

- 085a6a58: refactor server plugin
- 39e8137d: fix: support prefix array & webpack loader should read requestCreator & adjust runtime path to relative
- 085a6a58: refactor server plugin
- 085a6a58: refactor server conifg
- 085a6a58: support server runtime
- 085a6a58: feat: refactor server plugin
- Updated dependencies [085a6a58]
- Updated dependencies [085a6a58]
- Updated dependencies [085a6a58]
- Updated dependencies [d280ea33]
- Updated dependencies [d4fcc73a]
- Updated dependencies [085a6a58]
- Updated dependencies [ed1f6b12]
- Updated dependencies [a5ebbb00]
- Updated dependencies [085a6a58]
  - @modern-js/core@1.1.3
  - @modern-js/server-plugin@1.1.2
  - @modern-js/server-utils@1.1.2
  - @modern-js/utils@1.1.3

## 1.1.1

### Patch Changes

- 0fa83663: support more .env files
- Updated dependencies [6f7fe574]
- Updated dependencies [b011e0c5]
- Updated dependencies [0fa83663]
- Updated dependencies [f594fbc8]
- Updated dependencies [395beb1e]
  - @modern-js/core@1.1.2
  - @modern-js/babel-preset-lib@1.1.1
  - @modern-js/server-utils@1.1.1
  - @modern-js/bff-utils@1.1.1
  - @modern-js/create-request@1.1.1
  - @modern-js/server-plugin@1.1.1
  - @modern-js/babel-chain@1.1.1
  - @modern-js/babel-compiler@1.1.2
  - @modern-js/utils@1.1.2

## 1.1.0

### Minor Changes

- 96119db2: Relese v1.1.0### Patch Changes

- Updated dependencies [96119db2]
  - @modern-js/babel-preset-lib@1.1.0
  - @modern-js/core@1.1.0
  - @modern-js/bff-utils@1.1.0
  - @modern-js/create-request@1.1.0
  - @modern-js/server-plugin@1.1.0
  - @modern-js/server-utils@1.1.0
  - @modern-js/babel-chain@1.1.0
  - @modern-js/babel-compiler@1.1.0
  - @modern-js/utils@1.1.0

## 1.0.0

### Patch Changes

- 224f7fe: fix server route match
- 30ac27c: feat: add generator package description
- 0fd196e: feat: fix bugs
- 204c626: feat: initial
- 63be0a5: fix: #118 #104
- Updated dependencies [224f7fe]
- Updated dependencies [30ac27c]
- Updated dependencies [0fd196e]
- Updated dependencies [204c626]
- Updated dependencies [63be0a5]
  - @modern-js/babel-preset-lib@1.0.0
  - @modern-js/core@1.0.0
  - @modern-js/bff-utils@1.0.0
  - @modern-js/server-plugin@1.0.0
  - @modern-js/server-utils@1.0.0
  - @modern-js/babel-chain@1.0.0
  - @modern-js/babel-compiler@1.0.0
  - @modern-js/utils@1.0.0

## 1.0.0-rc.23

### Patch Changes

- 224f7fe: fix server route match
- 30ac27c: feat: add generator package description
- 0fd196e: feat: fix bugs
- 204c626: feat: initial
- 63be0a5: fix: #118 #104
- Updated dependencies [224f7fe]
- Updated dependencies [30ac27c]
- Updated dependencies [0fd196e]
- Updated dependencies [204c626]
- Updated dependencies [63be0a5]
  - @modern-js/babel-preset-lib@1.0.0-rc.23
  - @modern-js/core@1.0.0-rc.23
  - @modern-js/bff-utils@1.0.0-rc.23
  - @modern-js/server-plugin@1.0.0-rc.23
  - @modern-js/server-utils@1.0.0-rc.23
  - @modern-js/babel-chain@1.0.0-rc.23
  - @modern-js/babel-compiler@1.0.0-rc.23
  - @modern-js/utils@1.0.0-rc.23

## 1.0.0-rc.22

### Patch Changes

- 224f7fe: fix server route match
- 30ac27c: feat: add generator package description
- 0fd196e: feat: fix bugs
- 204c626: feat: initial
- 63be0a5: fix: #118 #104
- Updated dependencies [224f7fe]
- Updated dependencies [30ac27c]
- Updated dependencies [0fd196e]
- Updated dependencies [204c626]
- Updated dependencies [63be0a5]
  - @modern-js/babel-preset-lib@1.0.0-rc.22
  - @modern-js/core@1.0.0-rc.22
  - @modern-js/bff-utils@1.0.0-rc.22
  - @modern-js/server-plugin@1.0.0-rc.22
  - @modern-js/server-utils@1.0.0-rc.22
  - @modern-js/babel-chain@1.0.0-rc.22
  - @modern-js/babel-compiler@1.0.0-rc.22
  - @modern-js/utils@1.0.0-rc.22

## 1.0.0-rc.21

### Patch Changes

- 224f7fe: fix server route match
- 30ac27c: feat: add generator package description
- 0fd196e: feat: fix bugs
- 204c626: feat: initial
- 63be0a5: fix: #118 #104
- Updated dependencies [224f7fe]
- Updated dependencies [30ac27c]
- Updated dependencies [0fd196e]
- Updated dependencies [204c626]
- Updated dependencies [63be0a5]
  - @modern-js/babel-preset-lib@1.0.0-rc.21
  - @modern-js/core@1.0.0-rc.21
  - @modern-js/bff-utils@1.0.0-rc.21
  - @modern-js/server-plugin@1.0.0-rc.21
  - @modern-js/server-utils@1.0.0-rc.21
  - @modern-js/babel-chain@1.0.0-rc.21
  - @modern-js/babel-compiler@1.0.0-rc.21
  - @modern-js/utils@1.0.0-rc.21

## 1.0.0-rc.20

### Patch Changes

- 224f7fe: fix server route match
- 30ac27c: feat: add generator package description
- feat: fix bugs
- 204c626: feat: initial
- 63be0a5: fix: #118 #104
- Updated dependencies [224f7fe]
- Updated dependencies [30ac27c]
- Updated dependencies [undefined]
- Updated dependencies [204c626]
- Updated dependencies [63be0a5]
  - @modern-js/babel-preset-lib@1.0.0-rc.20
  - @modern-js/core@1.0.0-rc.20
  - @modern-js/bff-utils@1.0.0-rc.20
  - @modern-js/server-plugin@1.0.0-rc.20
  - @modern-js/server-utils@1.0.0-rc.20
  - @modern-js/babel-chain@1.0.0-rc.20
  - @modern-js/babel-compiler@1.0.0-rc.20
  - @modern-js/utils@1.0.0-rc.20

## 1.0.0-rc.19

### Patch Changes

- 224f7fe: fix server route match
- 30ac27c: feat: add generator package description
- 204c626: feat: initial
- 63be0a5: fix: #118 #104
- Updated dependencies [224f7fe]
- Updated dependencies [30ac27c]
- Updated dependencies [204c626]
- Updated dependencies [63be0a5]
  - @modern-js/babel-preset-lib@1.0.0-rc.19
  - @modern-js/core@1.0.0-rc.19
  - @modern-js/bff-utils@1.0.0-rc.19
  - @modern-js/server-plugin@1.0.0-rc.19
  - @modern-js/server-utils@1.0.0-rc.19
  - @modern-js/babel-chain@1.0.0-rc.19
  - @modern-js/babel-compiler@1.0.0-rc.19
  - @modern-js/utils@1.0.0-rc.19

## 1.0.0-rc.18

### Patch Changes

- 224f7fe: fix server route match
- 30ac27c: feat: add generator package description
- 204c626: feat: initial
- 63be0a5: fix: #118 #104
- Updated dependencies [224f7fe]
- Updated dependencies [30ac27c]
- Updated dependencies [204c626]
- Updated dependencies [63be0a5]
  - @modern-js/babel-preset-lib@1.0.0-rc.18
  - @modern-js/core@1.0.0-rc.18
  - @modern-js/bff-utils@1.0.0-rc.18
  - @modern-js/server-plugin@1.0.0-rc.18
  - @modern-js/server-utils@1.0.0-rc.18
  - @modern-js/babel-chain@1.0.0-rc.18
  - @modern-js/babel-compiler@1.0.0-rc.18
  - @modern-js/utils@1.0.0-rc.18

## 1.0.0-rc.17

### Patch Changes

- 224f7fe: fix server route match
- 30ac27c: feat: add generator package description
- 204c626: feat: initial
- fix: #118 #104
- Updated dependencies [224f7fe]
- Updated dependencies [30ac27c]
- Updated dependencies [204c626]
- Updated dependencies [undefined]
  - @modern-js/babel-preset-lib@1.0.0-rc.17
  - @modern-js/core@1.0.0-rc.17
  - @modern-js/bff-utils@1.0.0-rc.17
  - @modern-js/server-plugin@1.0.0-rc.17
  - @modern-js/server-utils@1.0.0-rc.17
  - @modern-js/babel-chain@1.0.0-rc.17
  - @modern-js/babel-compiler@1.0.0-rc.17
  - @modern-js/utils@1.0.0-rc.17

## 1.0.0-rc.16

### Patch Changes

- 224f7fe: fix server route match
- 30ac27c: feat: add generator package description
- 204c626: feat: initial
- Updated dependencies [224f7fe]
- Updated dependencies [30ac27c]
- Updated dependencies [204c626]
  - @modern-js/babel-preset-lib@1.0.0-rc.16
  - @modern-js/core@1.0.0-rc.16
  - @modern-js/bff-utils@1.0.0-rc.16
  - @modern-js/server-plugin@1.0.0-rc.16
  - @modern-js/server-utils@1.0.0-rc.16
  - @modern-js/babel-chain@1.0.0-rc.16
  - @modern-js/babel-compiler@1.0.0-rc.16
  - @modern-js/utils@1.0.0-rc.16

## 1.0.0-rc.15

### Patch Changes

- 224f7fe: fix server route match
- 30ac27c: feat: add generator package description
- 204c626: feat: initial
- Updated dependencies [224f7fe]
- Updated dependencies [30ac27c]
- Updated dependencies [204c626]
  - @modern-js/babel-preset-lib@1.0.0-rc.15
  - @modern-js/core@1.0.0-rc.15
  - @modern-js/bff-utils@1.0.0-rc.15
  - @modern-js/server-plugin@1.0.0-rc.15
  - @modern-js/server-utils@1.0.0-rc.15
  - @modern-js/babel-chain@1.0.0-rc.15
  - @modern-js/babel-compiler@1.0.0-rc.15
  - @modern-js/utils@1.0.0-rc.15

## 1.0.0-rc.14

### Patch Changes

- 224f7fe: fix server route match
- 204c626: feat: initial
- Updated dependencies [224f7fe]
- Updated dependencies [204c626]
  - @modern-js/babel-preset-lib@1.0.0-rc.14
  - @modern-js/core@1.0.0-rc.14
  - @modern-js/bff-utils@1.0.0-rc.14
  - @modern-js/server-plugin@1.0.0-rc.14
  - @modern-js/server-utils@1.0.0-rc.14
  - @modern-js/babel-chain@1.0.0-rc.14
  - @modern-js/babel-compiler@1.0.0-rc.14
  - @modern-js/utils@1.0.0-rc.14

## 1.0.0-rc.13

### Patch Changes

- 224f7fe: fix server route match
- 204c626: feat: initial
- Updated dependencies [224f7fe]
- Updated dependencies [204c626]
  - @modern-js/babel-preset-lib@1.0.0-rc.13
  - @modern-js/core@1.0.0-rc.13
  - @modern-js/bff-utils@1.0.0-rc.13
  - @modern-js/server-plugin@1.0.0-rc.13
  - @modern-js/server-utils@1.0.0-rc.13
  - @modern-js/babel-chain@1.0.0-rc.13
  - @modern-js/babel-compiler@1.0.0-rc.13
  - @modern-js/utils@1.0.0-rc.13

## 1.0.0-rc.12

### Patch Changes

- 224f7fe: fix server route match
- 204c626: feat: initial
- Updated dependencies [224f7fe]
- Updated dependencies [204c626]
  - @modern-js/babel-preset-lib@1.0.0-rc.12
  - @modern-js/core@1.0.0-rc.12
  - @modern-js/bff-utils@1.0.0-rc.12
  - @modern-js/server-plugin@1.0.0-rc.12
  - @modern-js/server-utils@1.0.0-rc.12
  - @modern-js/babel-chain@1.0.0-rc.12
  - @modern-js/babel-compiler@1.0.0-rc.12
  - @modern-js/utils@1.0.0-rc.12

## 1.0.0-rc.11

### Patch Changes

- 224f7fe: fix server route match
- 204c626: feat: initial
- Updated dependencies [224f7fe]
- Updated dependencies [204c626]
  - @modern-js/babel-preset-lib@1.0.0-rc.11
  - @modern-js/core@1.0.0-rc.11
  - @modern-js/bff-utils@1.0.0-rc.11
  - @modern-js/server-plugin@1.0.0-rc.11
  - @modern-js/server-utils@1.0.0-rc.11
  - @modern-js/babel-chain@1.0.0-rc.11
  - @modern-js/babel-compiler@1.0.0-rc.11
  - @modern-js/utils@1.0.0-rc.11

## 1.0.0-rc.10

### Patch Changes

- 224f7fe: fix server route match
- 204c626: feat: initial
- Updated dependencies [224f7fe]
- Updated dependencies [204c626]
  - @modern-js/babel-preset-lib@1.0.0-rc.10
  - @modern-js/core@1.0.0-rc.10
  - @modern-js/bff-utils@1.0.0-rc.10
  - @modern-js/server-plugin@1.0.0-rc.10
  - @modern-js/server-utils@1.0.0-rc.10
  - @modern-js/babel-chain@1.0.0-rc.10
  - @modern-js/babel-compiler@1.0.0-rc.10
  - @modern-js/utils@1.0.0-rc.10

## 1.0.0-rc.9

### Patch Changes

- 224f7fe: fix server route match
- 204c626: feat: initial
- Updated dependencies [224f7fe]
- Updated dependencies [204c626]
  - @modern-js/babel-preset-lib@1.0.0-rc.9
  - @modern-js/core@1.0.0-rc.9
  - @modern-js/bff-utils@1.0.0-rc.9
  - @modern-js/server-plugin@1.0.0-rc.9
  - @modern-js/server-utils@1.0.0-rc.9
  - @modern-js/babel-chain@1.0.0-rc.9
  - @modern-js/babel-compiler@1.0.0-rc.9
  - @modern-js/utils@1.0.0-rc.9

## 1.0.0-rc.8

### Patch Changes

- 224f7fe: fix server route match
- 204c626: feat: initial
- Updated dependencies [224f7fe]
- Updated dependencies [204c626]
  - @modern-js/babel-preset-lib@1.0.0-rc.8
  - @modern-js/core@1.0.0-rc.8
  - @modern-js/bff-utils@1.0.0-rc.8
  - @modern-js/server-plugin@1.0.0-rc.8
  - @modern-js/server-utils@1.0.0-rc.8
  - @modern-js/babel-chain@1.0.0-rc.8
  - @modern-js/babel-compiler@1.0.0-rc.8
  - @modern-js/utils@1.0.0-rc.8

## 1.0.0-rc.7

### Patch Changes

- 224f7fe: fix server route match
- 204c626: feat: initial
- Updated dependencies [224f7fe]
- Updated dependencies [204c626]
  - @modern-js/babel-preset-lib@1.0.0-rc.7
  - @modern-js/core@1.0.0-rc.7
  - @modern-js/bff-utils@1.0.0-rc.7
  - @modern-js/server-plugin@1.0.0-rc.7
  - @modern-js/server-utils@1.0.0-rc.7
  - @modern-js/babel-chain@1.0.0-rc.7
  - @modern-js/babel-compiler@1.0.0-rc.7
  - @modern-js/utils@1.0.0-rc.7

## 1.0.0-rc.6

### Patch Changes

- 224f7fe: fix server route match
- 204c626: feat: initial
- Updated dependencies [224f7fe]
- Updated dependencies [204c626]
  - @modern-js/babel-preset-lib@1.0.0-rc.6
  - @modern-js/core@1.0.0-rc.6
  - @modern-js/bff-utils@1.0.0-rc.6
  - @modern-js/server-plugin@1.0.0-rc.6
  - @modern-js/server-utils@1.0.0-rc.6
  - @modern-js/babel-chain@1.0.0-rc.6
  - @modern-js/babel-compiler@1.0.0-rc.6
  - @modern-js/utils@1.0.0-rc.6

## 1.0.0-rc.5

### Patch Changes

- 224f7fe: fix server route match
- 204c626: feat: initial
- Updated dependencies [224f7fe]
- Updated dependencies [204c626]
  - @modern-js/babel-preset-lib@1.0.0-rc.5
  - @modern-js/core@1.0.0-rc.5
  - @modern-js/bff-utils@1.0.0-rc.5
  - @modern-js/server-plugin@1.0.0-rc.5
  - @modern-js/server-utils@1.0.0-rc.5
  - @modern-js/babel-chain@1.0.0-rc.5
  - @modern-js/babel-compiler@1.0.0-rc.5
  - @modern-js/utils@1.0.0-rc.5

## 1.0.0-rc.4

### Patch Changes

- fix server route match
- 204c626: feat: initial
- Updated dependencies [undefined]
- Updated dependencies [204c626]
  - @modern-js/babel-preset-lib@1.0.0-rc.4
  - @modern-js/core@1.0.0-rc.4
  - @modern-js/bff-utils@1.0.0-rc.4
  - @modern-js/server-plugin@1.0.0-rc.4
  - @modern-js/server-utils@1.0.0-rc.4
  - @modern-js/babel-chain@1.0.0-rc.4
  - @modern-js/babel-compiler@1.0.0-rc.4
  - @modern-js/utils@1.0.0-rc.4

## 1.0.0-rc.3

### Patch Changes

- feat: initial
- Updated dependencies [undefined]
  - @modern-js/babel-preset-lib@1.0.0-rc.3
  - @modern-js/core@1.0.0-rc.3
  - @modern-js/bff-utils@1.0.0-rc.3
  - @modern-js/server-plugin@1.0.0-rc.3
  - @modern-js/server-utils@1.0.0-rc.3
  - @modern-js/babel-chain@1.0.0-rc.3
  - @modern-js/babel-compiler@1.0.0-rc.3
  - @modern-js/utils@1.0.0-rc.3
