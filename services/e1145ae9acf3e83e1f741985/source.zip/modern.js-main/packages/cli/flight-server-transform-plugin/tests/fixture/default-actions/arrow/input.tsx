import { z } from 'zod';

export default () => {
  'use server';
  return `default`;
}
