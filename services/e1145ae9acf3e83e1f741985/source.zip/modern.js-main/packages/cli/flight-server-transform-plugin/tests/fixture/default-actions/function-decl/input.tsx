import { z } from 'zod';

export default async function(){
  'use server';
  return `default`;
}
