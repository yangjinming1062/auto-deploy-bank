/* @modern-js-rsc-metadata
{"directive":null,"exportNames":[{"exportName":"default"}]}*/
import { registerServerReference } from "@modern-js/runtime/rsc/server";
import { z } from 'zod';

const $$ACTION_0 = () => {
  'use server';
  return `default`;
}

registerServerReference($$ACTION_0, module.id, "default");
export default $$ACTION_0;
