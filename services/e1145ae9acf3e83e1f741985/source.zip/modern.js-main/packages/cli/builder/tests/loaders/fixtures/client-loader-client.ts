export async function foo() {
  return 'foo';
}

export const bar = async () => 'bar';

export const baz = async () => 'baz';

export default foo;
