// Empty fallback module for react-server-dom-webpack when RSC is disabled
export default {};
