export * from '@rsbuild-image/core/shared';
export { Image } from '@rsbuild-image/react';
