import '@rsbuild-image/core/types';
