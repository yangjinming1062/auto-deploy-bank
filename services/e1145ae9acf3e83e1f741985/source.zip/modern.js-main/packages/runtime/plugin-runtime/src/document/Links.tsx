import React from 'react';
import { DOCUMENT_LINKS_PLACEHOLDER } from './constants';

export function Links() {
  return <>{DOCUMENT_LINKS_PLACEHOLDER}</>;
}
