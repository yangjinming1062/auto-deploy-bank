import { defaultMonitors } from './default';

export const getMonitors = () => {
  return defaultMonitors;
};
