declare module '@modern-js/runtime/document' {
  export * from '@modern-js/runtime/document';
}
