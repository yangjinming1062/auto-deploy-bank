export { getClientRoutes } from './getRoutes';
