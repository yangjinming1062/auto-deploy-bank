export const HTML_PLACEHOLDER = '<!--<?- html ?>-->';

export const SSR_DATA_PLACEHOLDER = '<!--<?- SSRDataScript ?>-->';

export const CHUNK_JS_PLACEHOLDER = '<!--<?- chunksMap.js ?>-->';

export const CHUNK_CSS_PLACEHOLDER = '<!--<?- chunksMap.css ?>-->';
