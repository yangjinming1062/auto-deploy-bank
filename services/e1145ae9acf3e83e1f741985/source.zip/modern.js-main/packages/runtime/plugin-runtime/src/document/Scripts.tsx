import React from 'react';
import { DOCUMENT_SCRIPTS_PLACEHOLDER } from './constants';

export function Scripts() {
  return <>{`${DOCUMENT_SCRIPTS_PLACEHOLDER}`}</>;
}
