import React from 'react';

export const DefaultNotFound = () => (
  <div
    style={{
      margin: '150px auto',
      textAlign: 'center',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
    }}
  >
    404
  </div>
);
