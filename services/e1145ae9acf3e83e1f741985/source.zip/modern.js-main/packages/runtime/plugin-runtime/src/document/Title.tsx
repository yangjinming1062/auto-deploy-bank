import { DOCUMENT_TITLE_PLACEHOLDER } from './constants';

export function Title() {
  return <title>{DOCUMENT_TITLE_PLACEHOLDER}</title>;
}
