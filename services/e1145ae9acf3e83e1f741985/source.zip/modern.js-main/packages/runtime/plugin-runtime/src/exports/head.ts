import head from 'react-helmet';

export default head;

export * from 'react-helmet';
