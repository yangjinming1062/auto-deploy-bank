import loadable from '@loadable/component';

export default loadable;

export * from '@loadable/component';
