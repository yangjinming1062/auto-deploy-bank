// used for client bundle, avoid to import node env related packages in client bundle.
export default () => {
  return null;
};
