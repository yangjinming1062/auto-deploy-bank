const loader = () => {};

// biome-ignore lint/style/noVar: <explanation>
export var action = () => {};

export { loader };
