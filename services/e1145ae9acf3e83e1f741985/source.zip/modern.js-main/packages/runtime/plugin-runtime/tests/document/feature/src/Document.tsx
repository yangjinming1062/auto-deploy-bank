const Document = () => {
  return '<div>/src</div>';
};
export default Document;
