export const handle = {
  'user.page': 'user.page',
};
