export const handle = {
  'user.profile.name.page': 'user.profile.name.page',
};
