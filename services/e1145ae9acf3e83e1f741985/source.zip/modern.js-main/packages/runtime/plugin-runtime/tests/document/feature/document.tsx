const Document = () => {
  return '<div></div>';
};
export default Document;
