export const handle = {
  'user.profile.name.layout': 'user.profile.name.layout',
};
