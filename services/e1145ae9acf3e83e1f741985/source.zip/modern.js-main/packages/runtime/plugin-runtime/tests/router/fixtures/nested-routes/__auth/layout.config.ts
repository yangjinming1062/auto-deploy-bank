export const handle = {
  'auth.layout': 'auth.layout',
};
