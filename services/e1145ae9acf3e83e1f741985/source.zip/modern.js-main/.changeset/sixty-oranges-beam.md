---
'@modern-js/runtime': patch
'@modern-js/render': patch
---

refactor: update rsc, streaming ssr runtime code
refactor: 更新 rsc, streeaming ssr 运行时代码
