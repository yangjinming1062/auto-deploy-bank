---
'@modern-js/server-core': patch
---

fix: should read html templates only in getHtmlTemplates function
fix: 在 getHtmlTemplates 函数中读取 html 模板
