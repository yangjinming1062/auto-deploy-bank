---
'@modern-js/app-tools': patch
---

feat(app-tools): add info command to display project entries information
feat(app-tools): 新增 info 命令，用于展示项目的 entries 信息
