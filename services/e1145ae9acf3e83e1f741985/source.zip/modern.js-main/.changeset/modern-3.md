---
'@modern-js/app-tools': major
---

feat: release Modern.js 3.0

feat: 发布 Modern.js 3.0
