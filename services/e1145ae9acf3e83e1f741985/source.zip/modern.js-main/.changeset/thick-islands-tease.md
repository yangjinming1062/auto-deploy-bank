---
'@modern-js/server-core': patch
---

fix: MPA should apply csrRender function for every single page
fix: MPA 项目一个为每个单页面应用不同的 csrRender 逻辑
