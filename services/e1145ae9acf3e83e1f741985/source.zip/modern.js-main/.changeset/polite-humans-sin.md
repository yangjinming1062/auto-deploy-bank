---
'@modern-js/runtime': minor
'@modern-js/runtime-utils': minor
'@modern-js/plugin-i18n': minor
'@modern-js/app-tools': minor
'@modern-js/i18n-utils': minor
'@modern-js/bff-core': minor
'@modern-js/plugin-bff': minor
'@modern-js/render': minor
---

feat: esm runtime
