---
'@modern-js/plugin-bff': patch
'@modern-js/server-core': patch
---

fix: dev hono context error
fix: 修复 dev 环境 hono context
