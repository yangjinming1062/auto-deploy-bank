---
'@modern-js/types': patch
'@modern-js/server-core': patch
---

perf: server monitor add more tags for timing/counter event
perf: server monitor 为 timing/couter 事件添加更多的 tags
