# Modern.js Contributing Guide

- [English Version](./packages/document/docs/en/community/contributing-guide.mdx)
- [中文版](./packages/document/docs/zh/community/contributing-guide.mdx)
