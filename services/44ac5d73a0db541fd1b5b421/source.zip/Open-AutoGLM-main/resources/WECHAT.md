<div align="center">
<img src=wechat.jpeg width="60%"/>

<p> 扫码关注公众号，加入「Open-AutoGLM 交流群」 </p>
<p> Scan the QR code to follow the official account and join the "Open-AutoGLM Discussion Group" </p>
</div>
