package org.springframework.cloud.function.grpc;

public class GrpcClientTemplate {

}
