package com.example.azure.di.azureblobtriggerdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AzureBlobTriggerDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
