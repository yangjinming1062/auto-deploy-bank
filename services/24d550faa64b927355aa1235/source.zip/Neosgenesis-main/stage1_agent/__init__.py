"""Package for the Stage 1 metacognitive analysis agent."""


