# 工具目录

本文档维护项目当前可用的外部工具清单，供各阶段 Agent 在生成规划或执行
时引用。新增或下线工具时，请同步更新本目录。

## Tavily MCP

- search: 调用 Tavily 在线搜索服务，获取实时网页摘要与引用，适用于事实核验、资讯检索。

## Code Interpreter MCP

- python: 在受控沙箱中执行 Python 代码，适用于脚本编写、数据处理、算法验证，也可运行 finish_form 文档同步脚本以更新协作表内容。


