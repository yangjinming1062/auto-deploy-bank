/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package org.kie.kogito.explainability;

import java.util.Collection;
import java.util.List;

import org.kie.kogito.Application;
import org.kie.kogito.explainability.model.PredictInput;
import org.kie.kogito.explainability.model.PredictOutput;

import static java.util.Collections.singletonList;
import static java.util.stream.Collectors.toList;

public class ExplainabilityService {

    public static final ExplainabilityService INSTANCE = new ExplainabilityService(singletonList(new DecisionExplainabilityResourceExecutor()));

    private Collection<ExplainabilityResourceExecutor> executors;

    public ExplainabilityService(Collection<ExplainabilityResourceExecutor> executors) {
        this.executors = executors;
    }

    public List<PredictOutput> processRequest(Application application, List<PredictInput> predictInputs) {
        return predictInputs.stream().map(predictInput -> executors.stream()
                .filter(r -> r.acceptRequest(predictInput))
                .map(r -> r.processRequest(application, predictInput))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("Malformed resourceType " + predictInput.getModelIdentifier().getResourceType())))
                .collect(toList());
    }
}
