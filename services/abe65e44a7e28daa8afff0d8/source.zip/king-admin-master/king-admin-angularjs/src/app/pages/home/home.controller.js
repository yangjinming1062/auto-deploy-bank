(function () {
    'use strict';

    angular.module('KingAdmin.pages.home')
        .controller('HomeControlller', HomeControlller);

    /** @ngInject */
    function HomeControlller($scope,$rootScope,$window, UserService) {

        var kt = this;

    }
})();

