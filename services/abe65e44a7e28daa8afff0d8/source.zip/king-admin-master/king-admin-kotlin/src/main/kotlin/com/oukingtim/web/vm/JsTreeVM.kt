package com.oukingtim.web.vm

/**
 * Created by oukingtim
 */
class JsTreeVM {
    var id: String? = null
    var text: String? = null
    var icon: String? = null
    var state: TreeStateVM? = null
    var parent: String? = null
}