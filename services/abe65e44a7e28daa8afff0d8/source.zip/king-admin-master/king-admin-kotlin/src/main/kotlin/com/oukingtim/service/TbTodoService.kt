package com.oukingtim.service

import com.baomidou.mybatisplus.service.IService
import com.oukingtim.domain.TbTodo

/**
 * Created by oukingtim
 */
interface TbTodoService : IService<TbTodo> {
}