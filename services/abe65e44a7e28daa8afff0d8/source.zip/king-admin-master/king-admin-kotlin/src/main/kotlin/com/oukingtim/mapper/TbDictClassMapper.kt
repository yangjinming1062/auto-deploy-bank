package com.oukingtim.mapper

import com.baomidou.mybatisplus.mapper.BaseMapper
import com.oukingtim.domain.TbDictClass

/**
 * Created by oukingtim
 */
interface TbDictClassMapper : BaseMapper<TbDictClass> {
}