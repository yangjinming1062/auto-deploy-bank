package com.oukingtim.mapper

import com.baomidou.mybatisplus.mapper.BaseMapper
import com.oukingtim.domain.SysUser

/**
 * Created by oukingtim
 */
interface SysUserMapper :BaseMapper<SysUser>{

}