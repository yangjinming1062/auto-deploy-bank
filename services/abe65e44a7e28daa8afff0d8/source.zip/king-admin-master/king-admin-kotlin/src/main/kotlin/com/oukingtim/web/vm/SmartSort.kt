package com.oukingtim.web.vm

/**
 * Created by oukingtim
 */
class SmartSort {
    var predicate: String? = null

    var reverse: Boolean = false
}