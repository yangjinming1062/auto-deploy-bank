package com.oukingtim.service

import com.baomidou.mybatisplus.service.IService
import com.oukingtim.domain.TbCalendar

/**
 * Created by oukingtim
 */
interface TbCalendarService :IService<TbCalendar>{
}