package com.oukingtim

import org.springframework.boot.SpringApplication
import org.springframework.boot.autoconfigure.SpringBootApplication

@SpringBootApplication
class KingAdminKotlinApplication

fun main(args: Array<String>) {
    SpringApplication.run(KingAdminKotlinApplication::class.java, *args)
}
