package com.oukingtim.service

import com.baomidou.mybatisplus.service.IService
import com.oukingtim.domain.TbDictClass

/**
 * Created by oukingtim
 */
interface TbDictClassService : IService<TbDictClass> {
}