package com.oukingtim.web.vm

/**
 * Created by oukingtim
 */
class TreeStateVM {
    var selected: Boolean? = null

    var opened: Boolean? = true

    var disabled: Boolean? = null
}