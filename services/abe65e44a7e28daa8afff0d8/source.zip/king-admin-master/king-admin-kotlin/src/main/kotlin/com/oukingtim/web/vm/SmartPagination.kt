package com.oukingtim.web.vm

/**
 * Created by oukingtim
 */
class SmartPagination {
    var start: Int? = null

    var number: Int? = null

    var numberOfPages: Int? = null

    var totalItemCount: Int? = null
}