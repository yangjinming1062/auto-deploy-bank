package com.oukingtim.service

import com.baomidou.mybatisplus.service.IService
import com.oukingtim.domain.SysRoleMenu

/**
 * Created by oukingtim
 */
interface SysRoleMenuService : IService<SysRoleMenu> {
}