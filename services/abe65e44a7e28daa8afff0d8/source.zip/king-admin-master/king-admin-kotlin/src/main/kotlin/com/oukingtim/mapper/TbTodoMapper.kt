package com.oukingtim.mapper

import com.baomidou.mybatisplus.mapper.BaseMapper
import com.oukingtim.domain.TbTodo

/**
 * Created by oukingtim
 */
interface TbTodoMapper : BaseMapper<TbTodo> {
}