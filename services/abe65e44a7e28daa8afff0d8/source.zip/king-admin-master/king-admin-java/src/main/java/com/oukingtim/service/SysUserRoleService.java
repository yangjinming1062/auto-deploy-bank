package com.oukingtim.service;

import com.baomidou.mybatisplus.service.IService;
import com.oukingtim.domain.SysUserRole;

/**
 * Created by oukingtim
 */
public interface SysUserRoleService extends IService<SysUserRole> {
}
