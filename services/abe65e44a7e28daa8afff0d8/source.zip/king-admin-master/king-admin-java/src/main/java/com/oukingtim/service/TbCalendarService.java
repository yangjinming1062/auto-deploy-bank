package com.oukingtim.service;

import com.baomidou.mybatisplus.service.IService;
import com.oukingtim.domain.TbCalendar;


/**
 * Created by oukingtim
 */
public interface TbCalendarService extends IService<TbCalendar> {
    
}
