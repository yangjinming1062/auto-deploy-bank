package com.oukingtim.service;

import com.baomidou.mybatisplus.service.IService;
import com.oukingtim.domain.SysRoleMenu;

/**
 * Created by oukingtim
 */
public interface SysRoleMenuService extends IService<SysRoleMenu> {
}
