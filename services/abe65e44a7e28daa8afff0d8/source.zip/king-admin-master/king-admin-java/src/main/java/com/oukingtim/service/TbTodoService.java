package com.oukingtim.service;

import com.baomidou.mybatisplus.service.IService;
import com.oukingtim.domain.TbTodo;


/**
 * Created by oukingtim
 */
public interface TbTodoService extends IService<TbTodo> {
    
}
