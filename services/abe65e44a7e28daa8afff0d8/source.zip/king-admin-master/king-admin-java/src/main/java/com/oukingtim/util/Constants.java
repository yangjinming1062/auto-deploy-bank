package com.oukingtim.util;

/**
 * Created by oukingtim
 */
public final class Constants {

    public static final String SPRING_PROFILE_DEVELOPMENT = "dev";

}
