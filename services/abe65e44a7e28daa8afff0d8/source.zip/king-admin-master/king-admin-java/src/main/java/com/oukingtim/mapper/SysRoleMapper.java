package com.oukingtim.mapper;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.oukingtim.domain.SysRole;

/**
 * Created by oukingtim
 */
public interface SysRoleMapper extends BaseMapper<SysRole> {
}
