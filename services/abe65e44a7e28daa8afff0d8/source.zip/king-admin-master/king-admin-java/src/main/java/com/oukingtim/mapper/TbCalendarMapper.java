package com.oukingtim.mapper;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.oukingtim.domain.TbCalendar;


/**
 * Created by oukingtim
 */
public interface TbCalendarMapper extends BaseMapper<TbCalendar> {

}
