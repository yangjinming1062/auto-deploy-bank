OmegaT makes use of Azure Devops continuous integration services provided by Microsoft
For building and testing OmegaT master, releases branches and Pull-Requests (nightly builds, release build, PR check).

Scripts and data used for these tasks are stored in this directory to serve as canonical sources.

As of April 2023, CI functions are maintained by Hiroshi Miura
