/*
 *
 *  Copyright 2018 Netflix, Inc.
 *
 *     Licensed under the Apache License, Version 2.0 (the "License");
 *     you may not use this file except in compliance with the License.
 *     You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *     Unless required by applicable law or agreed to in writing, software
 *     distributed under the License is distributed on an "AS IS" BASIS,
 *     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *     See the License for the specific language governing permissions and
 *     limitations under the License.
 *
 */
package com.netflix.genie.common.internal.dtos;

import jakarta.annotation.Nullable;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Size;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.ToString;

import java.io.Serializable;
import java.time.Instant;

/**
 * Fields common to every Genie v4 resource (cluster, command, etc).
 *
 * @author tgianos
 * @since 4.0.0
 */
@Getter
@EqualsAndHashCode(doNotUseGetters = true)
@ToString(doNotUseGetters = true)
public abstract class CommonResource implements Serializable {

    private static final long serialVersionUID = -2939351280830204953L;

    @NotEmpty(message = "An id is required")
    @Size(max = 255, message = "Max length for the ID is 255 characters")
    private final String id;
    private final Instant created;
    private final Instant updated;
    private final ExecutionEnvironment resources;

    CommonResource(
        final String id,
        final Instant created,
        final Instant updated,
        @Nullable final ExecutionEnvironment resources
    ) {
        this.id = id;
        this.created = created;
        this.updated = updated;
        this.resources = resources == null
            ? new ExecutionEnvironment(null, null, null)
            : resources;
    }
}
