/*
 *
 *  Copyright 2016 Netflix, Inc.
 *
 *     Licensed under the Apache License, Version 2.0 (the "License");
 *     you may not use this file except in compliance with the License.
 *     You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *     Unless required by applicable law or agreed to in writing, software
 *     distributed under the License is distributed on an "AS IS" BASIS,
 *     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *     See the License for the specific language governing permissions and
 *     limitations under the License.
 *
 */
package com.netflix.genie.client.interceptors;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.netflix.genie.client.exceptions.GenieClientException;
import com.netflix.genie.client.exceptions.GenieClientTooManyRequestsException;
import com.netflix.genie.common.external.util.GenieObjectMapper;
import okhttp3.Interceptor;
import okhttp3.Response;
import okhttp3.ResponseBody;

import java.io.IOException;
import java.io.Reader;

/**
 * Class that evaluates the retrofit response code and maps it to an appropriate Genie Exception.
 *
 * @author amsharma
 * @since 3.0.0
 */
public class ResponseMappingInterceptor implements Interceptor {

    private static final String NO_MESSAGE_FALLBACK = "No error detailed message in server response";
    private static final String ERROR_MESSAGE_KEY = "message";
    private static final int HTTP_TOO_MANY_REQUESTS = 429;

    /**
     * Constructor.
     */
    public ResponseMappingInterceptor() {
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Response intercept(final Chain chain) throws IOException {
        final Response response = chain.proceed(chain.request());

        if (response.isSuccessful()) {
            return response;
        } else {
            final ResponseBody body = response.body();
            if (body != null) {
                final Reader bodyReader = body.charStream();

                if (bodyReader != null) {
                    try {
                        final JsonNode responseBody = GenieObjectMapper.getMapper().readTree(bodyReader);
                        final String errorMessage =
                            responseBody == null || !responseBody.has(ERROR_MESSAGE_KEY)
                                ? NO_MESSAGE_FALLBACK
                                : responseBody.get(ERROR_MESSAGE_KEY).asText();
                        final int responseCode = response.code();
                        if (responseCode == HTTP_TOO_MANY_REQUESTS) {
                            throw new GenieClientTooManyRequestsException(errorMessage);
                        }
                        throw new GenieClientException(
                            responseCode,
                            errorMessage
                        );
                    } catch (final JsonProcessingException jpe) {
                        throw new GenieClientException("Failed to parse server response as JSON", jpe);
                    }
                }
            }

            throw new GenieClientException(response.code(), "Server response body is empty");
        }
    }
}
