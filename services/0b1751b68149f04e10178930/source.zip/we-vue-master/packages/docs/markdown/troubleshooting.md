问题解答

1. 对于按需引入，推荐使用 `babel-plugin-import` 插件。

2. 如果使用 cnpm 安装依赖，出现一些类似模块无法加载（例如 `Module not found: Error: Can't resolve 'vue-style-loader'`）的问题。可使用 npm 或 yarn 重装安装依赖。

3. 图标无法显示 [issue #46](https://github.com/tianyong90/we-vue/issues/46)

