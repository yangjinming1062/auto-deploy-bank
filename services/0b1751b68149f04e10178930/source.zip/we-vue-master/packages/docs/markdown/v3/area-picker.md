---
title: AreaPicker
keywords: 'we-vue, area-picker'
description: ''
demo_url: //demo.wevue.org/area-picker
---

Picker

中国省市区选择器。

**完善中...**
