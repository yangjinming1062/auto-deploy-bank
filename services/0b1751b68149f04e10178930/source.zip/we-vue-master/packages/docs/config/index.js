/* eslint-disable camelcase */

import v2 from './nav_v2'
import v3 from './nav_v3'

const nav = {
  v2,
  v3,
}

export { nav }
