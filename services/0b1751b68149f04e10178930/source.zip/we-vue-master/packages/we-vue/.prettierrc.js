module.exports = {
  printWidth: 100,
  useTabs: false,
  tabWidth: 2,
  trailingComma: 'es5',
  semi: false,
  singleQuote: true,
}
