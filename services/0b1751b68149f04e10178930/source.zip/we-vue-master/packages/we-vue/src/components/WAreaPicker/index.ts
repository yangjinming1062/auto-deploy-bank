import WAreaPicker from './WAreaPicker'

export { WAreaPicker }
export default WAreaPicker
