import WSwitchCell from './WSwitchCell'

export { WSwitchCell }
export default WSwitchCell
