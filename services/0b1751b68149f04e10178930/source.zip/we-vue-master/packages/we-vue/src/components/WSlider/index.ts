import WSlider from './WSlider'

export { WSlider }
export default WSlider
