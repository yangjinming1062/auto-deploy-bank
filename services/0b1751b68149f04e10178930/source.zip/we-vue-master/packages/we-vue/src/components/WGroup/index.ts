import WGroup from './WGroup'

export { WGroup }
export default WGroup
