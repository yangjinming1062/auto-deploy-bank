import WPicker from './WPicker'

export { WPicker }
export default WPicker
