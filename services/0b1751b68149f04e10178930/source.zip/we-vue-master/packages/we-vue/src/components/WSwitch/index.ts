import WSwitch from './WSwitch'

export { WSwitch }
export default WSwitch
