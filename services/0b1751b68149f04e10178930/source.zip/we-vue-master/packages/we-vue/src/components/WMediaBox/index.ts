import WMediaBox from './WMediaBox'

export { WMediaBox }
export default WMediaBox
