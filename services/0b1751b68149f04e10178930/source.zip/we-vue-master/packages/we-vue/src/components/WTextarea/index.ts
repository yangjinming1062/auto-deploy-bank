import WTextarea from './WTextarea'

export { WTextarea }
export default WTextarea
