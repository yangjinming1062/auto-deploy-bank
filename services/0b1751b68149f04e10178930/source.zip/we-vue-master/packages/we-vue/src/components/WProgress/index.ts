import WProgress from './WProgress'

export { WProgress }
export default WProgress
