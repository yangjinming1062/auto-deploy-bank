import WBadge from './WBadge'

export { WBadge }
export default WBadge
