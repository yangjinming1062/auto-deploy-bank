import WPanel from './WPanel'

export { WPanel }
export default WPanel
