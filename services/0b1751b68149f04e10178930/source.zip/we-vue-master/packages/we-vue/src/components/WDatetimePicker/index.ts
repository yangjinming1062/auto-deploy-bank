import WDatetimePicker from './WDatetimePicker'

export { WDatetimePicker }
export default WDatetimePicker
