import WInput from './WInput'

export { WInput }
export default WInput
