import WFlex from './WFlex'

export { WFlex }
export default WFlex
