import WHeader from './WHeader'

export { WHeader }
export default WHeader
