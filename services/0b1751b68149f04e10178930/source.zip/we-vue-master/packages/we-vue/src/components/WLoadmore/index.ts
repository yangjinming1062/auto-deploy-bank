import WLoadmore from './WLoadmore'

export { WLoadmore }
export default WLoadmore
