import WTabs from './WTabs'

export { WTabs }
export default WTabs
