import WNumberSpinner from './WNumberSpinner'

export { WNumberSpinner }
export default WNumberSpinner
