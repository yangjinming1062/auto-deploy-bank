import WSearchBar from './WSearchBar'

export { WSearchBar }
export default WSearchBar
