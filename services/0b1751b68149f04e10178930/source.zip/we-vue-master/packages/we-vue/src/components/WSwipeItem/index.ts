import WSwipeItem from './WSwipeItem'

export { WSwipeItem }
export default WSwipeItem
