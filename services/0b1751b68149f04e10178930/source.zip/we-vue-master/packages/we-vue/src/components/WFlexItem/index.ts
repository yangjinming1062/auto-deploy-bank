import WFlexItem from './WFlexItem'

export { WFlexItem }
export default WFlexItem
