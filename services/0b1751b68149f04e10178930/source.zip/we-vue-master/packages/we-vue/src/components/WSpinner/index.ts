import WSpinner from './WSpinner'

export { WSpinner }
export default WSpinner
