import WIcon from './WIcon'

export { WIcon }
export default WIcon
