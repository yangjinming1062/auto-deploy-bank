import WSwipe from './WSwipe'

export { WSwipe }
export default WSwipe
