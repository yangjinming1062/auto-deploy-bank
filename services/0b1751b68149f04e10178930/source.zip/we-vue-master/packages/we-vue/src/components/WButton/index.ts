import WButton from './WButton'

export { WButton }
export default WButton
