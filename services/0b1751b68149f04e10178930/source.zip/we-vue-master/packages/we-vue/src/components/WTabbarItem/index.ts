import WTabbarItem from './WTabbarItem'

export { WTabbarItem }
export default WTabbarItem
