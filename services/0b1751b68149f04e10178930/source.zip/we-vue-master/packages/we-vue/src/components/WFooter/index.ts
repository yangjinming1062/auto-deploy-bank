import WFooter from './WFooter'

export { WFooter }
export default WFooter
