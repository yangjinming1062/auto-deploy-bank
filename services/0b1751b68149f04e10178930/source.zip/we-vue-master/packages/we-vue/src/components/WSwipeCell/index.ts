import WSwipeCell from './WSwipeCell'

export { WSwipeCell }
export default WSwipeCell
