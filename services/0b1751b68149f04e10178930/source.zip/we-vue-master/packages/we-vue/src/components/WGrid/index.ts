import WGrid from './WGrid'

export { WGrid }
export default WGrid
