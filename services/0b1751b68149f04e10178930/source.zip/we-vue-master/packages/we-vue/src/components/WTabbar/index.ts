import WTabbar from './WTabbar'

export { WTabbar }
export default WTabbar
