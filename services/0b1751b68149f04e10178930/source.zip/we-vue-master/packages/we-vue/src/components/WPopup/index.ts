import WPopup from './WPopup'

export { WPopup }
export default WPopup
