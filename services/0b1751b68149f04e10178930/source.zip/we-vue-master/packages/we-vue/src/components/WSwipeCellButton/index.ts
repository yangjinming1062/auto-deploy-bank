import WSwipeCellButton from './WSwipeCellButton'

export { WSwipeCellButton }
export default WSwipeCellButton
