import WGridItem from './WGridItem'

export { WGridItem }
export default WGridItem
