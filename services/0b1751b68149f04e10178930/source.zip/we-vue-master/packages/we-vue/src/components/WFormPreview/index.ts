import WFormPreview from './WFormPreview'

export { WFormPreview }
export default WFormPreview
