import WTab from './WTab'

export { WTab }
export default WTab
