import WCircle from './WCircle'

export { WCircle }
export default WCircle
