import WCell from './WCell'

export { WCell }
export default WCell
