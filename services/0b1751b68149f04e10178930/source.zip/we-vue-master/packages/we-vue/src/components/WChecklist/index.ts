import WChecklist from './WChecklist'

export { WChecklist }
export default WChecklist
