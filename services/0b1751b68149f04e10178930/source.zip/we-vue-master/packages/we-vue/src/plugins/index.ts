import Lazyload from './lazyload'

export {
  Lazyload,
}
