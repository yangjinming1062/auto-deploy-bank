import { Lazyload } from '@/plugins'

describe('lazyload', () => {
  test('lazyload type', () => {
    expect(typeof Lazyload).toBe('object')
  })
})
