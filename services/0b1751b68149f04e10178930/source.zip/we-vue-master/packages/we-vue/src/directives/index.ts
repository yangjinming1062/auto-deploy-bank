import ClickOutside from './click-outside'
import InfiniteScroll from './infinite-scroll'

export {
  ClickOutside,
  InfiniteScroll,
}

export default {
  ClickOutside,
  InfiniteScroll,
}
