// https://docs.cypress.io/api/introduction/api.html

describe('Test demo', () => {
  it('Visits root url', () => {
    cy.visit('/')
  })
})
