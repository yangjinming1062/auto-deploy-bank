<template>
  <div class="page">
    <h1 class="error-code">404</h1>
  </div>
</template>

<style scoped lang="scss">
.error-code {
  display: block;
  color: #666;
  font-size: 4rem;
  font-weight: 200;
  text-align: center;
}
</style>
