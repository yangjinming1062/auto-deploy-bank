<template>
  <div class="page">
    <w-loadmore/>
    <w-loadmore type="line" text="loading"/>
    <w-loadmore type="lineDot" text="loading"/>
  </div>
</template>

<style scoped lang="scss">
.page {
  background-color: white;
}
</style>
