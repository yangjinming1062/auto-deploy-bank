module.exports = {
  printWidth: 100,
  useTabs: false,
  tabWidth: 2,
  trailingComma: 'none',
  semi: false,
  singleQuote: true,
}
