package com.jd.wego.entity;

import lombok.Data;

/**
 * @author hbquan
 * @date 2021/4/7 20:28
 */
@Data
public class Category {

    int categoryId;

    String categoryName;
}
