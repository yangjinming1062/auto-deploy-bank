package com.jd.wego.redis;

/**
 * @author hbquan
 * @date 2021/4/14 15:45
 */
public class CommonKey {

    public static final String EVENT_LIKE_QUEUE = "EVENT_LIKE_QUEUE";
}
