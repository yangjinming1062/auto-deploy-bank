package com.jd.wego;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WegoApplicationTests {

    @Test
    void contextLoads() {
    }

}
