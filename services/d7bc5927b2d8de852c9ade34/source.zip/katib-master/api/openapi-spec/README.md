# Kubeflow Katib OpenAPI Specification

This folder contains an [OpenAPI specification](https://github.com/OAI/OpenAPI-Specification)
for the Kubeflow Katib APIs.
