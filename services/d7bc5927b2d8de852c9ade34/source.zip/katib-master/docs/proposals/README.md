# Proposals

Kubeflow uses the KEP process to document large scale changes to the project.

Details on the process (including the KEP template, recommendations, etc.) can be found at
[kubeflow/community/proposals](https://github.com/kubeflow/community/blob/master/proposals/README.md)
