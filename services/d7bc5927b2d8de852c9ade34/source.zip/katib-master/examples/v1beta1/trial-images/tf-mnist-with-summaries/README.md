# Tensorflow MNIST Classification With Summaries Example

This is Tensorflow MNIST image classification training container that outputs TF summaries.
It uses convolutional neural network to train the model.

If you want to read more about this example, visit the official
[tensorflow](https://www.tensorflow.org/tutorials/quickstart/advanced)
documentation.

Katib uses this training container in some Experiments, for instance in the
[TFJob example](../../kubeflow-training-operator/tfjob-mnist-with-summaries.yaml#L54-L62).
