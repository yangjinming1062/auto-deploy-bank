# Spell Checker Client

This is the client side of the spell checker extension.
