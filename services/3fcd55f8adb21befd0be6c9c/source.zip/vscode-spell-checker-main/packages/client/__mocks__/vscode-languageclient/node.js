const DiagnosticSeverity = {
    Error: 1,
    Warning: 2,
    Information: 3,
    Hint: 4,
};

module.exports = {
    DiagnosticSeverity,
};
