/* eslint-disable @typescript-eslint/no-require-imports */

module.exports = require('jest-mock-vscode').createVSCodeMock(jest);
