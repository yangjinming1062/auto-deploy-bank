export interface Disposable {
    dispose: () => unknown;
}
