# JSON-RPC-Api

Wrapper for creating a client server api over .
