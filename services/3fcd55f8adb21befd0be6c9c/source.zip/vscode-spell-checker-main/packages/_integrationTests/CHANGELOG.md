# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

# [2.0.0-alpha.1](https://github.com/streetsidesoftware/vscode-spell-checker/compare/v2.0.0-alpha.0...v2.0.0-alpha.1) (2021-03-15)

**Note:** Version bump only for package vscode-spell-checker-integration-tests





# [1.11.0-alpha.3](https://github.com/streetsidesoftware/vscode-spell-checker/compare/v1.11.0-alpha.2...v1.11.0-alpha.3) (2021-03-06)


### Features

* Upgrade to cspell 5.3.x ([#717](https://github.com/streetsidesoftware/vscode-spell-checker/issues/717)) ([fc3552c](https://github.com/streetsidesoftware/vscode-spell-checker/commit/fc3552c6ba94d0922cad83585921b69fa0b01255))





# [1.11.0-alpha.0](https://github.com/streetsidesoftware/vscode-spell-checker/compare/v1.10.2...v1.11.0-alpha.0) (2021-01-06)

**Note:** Version bump only for package vscode-spell-checker-integration-tests





## [1.9.3](https://github.com/streetsidesoftware/vscode-spell-checker/compare/v1.9.3-alpha.3...v1.9.3) (2020-11-09)

**Note:** Version bump only for package vscode-spell-checker-integration-tests





## [1.9.3-alpha.3](https://github.com/streetsidesoftware/vscode-spell-checker/compare/v1.9.3-alpha.2...v1.9.3-alpha.3) (2020-11-09)

**Note:** Version bump only for package vscode-spell-checker-integration-tests





## [1.9.3-alpha.2](https://github.com/streetsidesoftware/vscode-spell-checker/compare/v1.9.3-alpha.0...v1.9.3-alpha.2) (2020-11-01)


### Bug Fixes

* Update cspell ([#564](https://github.com/streetsidesoftware/vscode-spell-checker/issues/564)) ([3c1b28d](https://github.com/streetsidesoftware/vscode-spell-checker/commit/3c1b28deb96cd2d9745b38ad7ff5e18c4d0abbd1))





## [1.9.3-alpha.1](https://github.com/streetsidesoftware/vscode-spell-checker/compare/v1.9.3-alpha.0...v1.9.3-alpha.1) (2020-11-01)


### Bug Fixes

* Update cspell ([#564](https://github.com/streetsidesoftware/vscode-spell-checker/issues/564)) ([3c1b28d](https://github.com/streetsidesoftware/vscode-spell-checker/commit/3c1b28deb96cd2d9745b38ad7ff5e18c4d0abbd1))





## [1.9.1](https://github.com/streetsidesoftware/vscode-spell-checker/compare/v1.9.1-alpha.2...v1.9.1) (2020-09-23)

**Note:** Version bump only for package vscode-spell-checker-integration-tests





## [1.9.1-alpha.1](https://github.com/streetsidesoftware/vscode-spell-checker/compare/v1.9.1-alpha.0...v1.9.1-alpha.1) (2020-09-17)


### Bug Fixes

* Settings Viewer Packages by Migrating to Material-UI ([#542](https://github.com/streetsidesoftware/vscode-spell-checker/issues/542)) ([8793be3](https://github.com/streetsidesoftware/vscode-spell-checker/commit/8793be3da43dd1d738719e792486c365d44572ff))





# [1.9.0](https://github.com/streetsidesoftware/vscode-spell-checker/compare/v1.9.0-alpha.5...v1.9.0) (2020-05-20)

**Note:** Version bump only for package vscode-spell-checker-integration-tests





## [1.8.1-alpha.0](https://github.com/streetsidesoftware/vscode-spell-checker/compare/v1.8.0...v1.8.1-alpha.0) (2020-05-02)

**Note:** Version bump only for package vscode-spell-checker-integration-tests





# [1.8.0](https://github.com/streetsidesoftware/vscode-spell-checker/compare/v1.8.0-alpha.2...v1.8.0) (2020-02-23)

**Note:** Version bump only for package vscode-spell-checker-integration-tests





# [1.8.0-alpha.1](https://github.com/streetsidesoftware/vscode-spell-checker/compare/v1.8.0-alpha.0...v1.8.0-alpha.1) (2020-02-22)


### Features

* Support enableFileTypes ([#439](https://github.com/streetsidesoftware/vscode-spell-checker/issues/439)) ([2fde3bc](https://github.com/streetsidesoftware/vscode-spell-checker/commit/2fde3bc5c658ee51da5a56580aa1370bf8174070))





# [1.8.0-alpha.0](https://github.com/streetsidesoftware/vscode-spell-checker/compare/v1.7.24...v1.8.0-alpha.0) (2020-02-21)

**Note:** Version bump only for package vscode-spell-checker-integration-tests





## [1.7.24](https://github.com/streetsidesoftware/vscode-spell-checker/compare/v1.7.24-alpha.1...v1.7.24) (2020-02-19)


### Bug Fixes

* Update cspell and other packages ([2a12c03](https://github.com/streetsidesoftware/vscode-spell-checker/commit/2a12c03f88babf9ba38a76b2ab5e54215f9436af))





## [1.7.23](https://github.com/streetsidesoftware/vscode-spell-checker/compare/v1.7.23-alpha.2...v1.7.23) (2020-02-15)

**Note:** Version bump only for package vscode-spell-checker-integration-tests
