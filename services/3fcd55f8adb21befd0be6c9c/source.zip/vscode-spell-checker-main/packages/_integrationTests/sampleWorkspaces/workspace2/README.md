# Workspace 2

This workspace has a `package.json` with a `cspell` section.

Custom words:

- Workspacetwo
