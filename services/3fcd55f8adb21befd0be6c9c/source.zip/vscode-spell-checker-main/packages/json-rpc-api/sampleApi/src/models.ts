export interface Todo {
    id: string;
    name: string;
    done: boolean;
}

export type DateString = string;

export type TodoList = Todo[];
