# JSON-RPC-Api

This is a helper for creating a JSON-RPC API.

## Usage

### Define the API

### Create Client Side

### Create Server Side
