# Spell Checker Server

This extension performs spellchecking in source code files.
