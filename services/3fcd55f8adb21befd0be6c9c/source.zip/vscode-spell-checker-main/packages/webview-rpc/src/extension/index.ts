export { createConnectionToWebview } from './json-rpc.js';
export type { MessageConnection } from 'json-rpc-api';
