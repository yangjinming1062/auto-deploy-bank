
export declare const main: string;
export declare const css: string[];
export declare const assetsDir: string;
