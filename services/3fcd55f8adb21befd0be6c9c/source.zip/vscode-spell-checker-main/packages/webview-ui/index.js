export * from './dist/index.js';
export const assetsDir = 'dist/assets';
