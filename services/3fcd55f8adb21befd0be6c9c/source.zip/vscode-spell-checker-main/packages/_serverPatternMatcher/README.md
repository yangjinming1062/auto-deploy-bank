# Pattern Matcher Server

This extension performs RegExp pattern matching on TextDocuments.
