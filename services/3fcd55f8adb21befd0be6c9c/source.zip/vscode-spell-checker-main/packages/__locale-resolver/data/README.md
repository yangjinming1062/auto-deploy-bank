# Data

- [ISO Script Names.tsv) from [wiki/ISO_15924](https://en.wikipedia.org/wiki/ISO_15924#List_of_codes)
