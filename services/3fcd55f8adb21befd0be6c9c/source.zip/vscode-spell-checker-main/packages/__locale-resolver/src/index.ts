export type { Locale, LocaleInfo, ScriptInfo } from './iso639-1/index.js';
export { formatLocale, isValidCode, lookupLocaleInfo, normalizeCode, parseLocale } from './iso639-1/index.js';
