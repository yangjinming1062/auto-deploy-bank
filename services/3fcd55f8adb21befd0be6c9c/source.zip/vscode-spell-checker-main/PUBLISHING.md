# Publishing the Extension

This file contains the steps to publish the extension.

It assumes that the `main` branch is stable.

Use the following steps:

1. Merge [Pull request: release code-spell-checker](https://github.com/streetsidesoftware/vscode-spell-checker/pulls?q=is%3Apr+is%3Aopen+release+code-spell-checker)

    ![image](https://user-images.githubusercontent.com/3740137/183303675-00115b4c-4be1-49a5-8931-2f471a6eeb01.png)
