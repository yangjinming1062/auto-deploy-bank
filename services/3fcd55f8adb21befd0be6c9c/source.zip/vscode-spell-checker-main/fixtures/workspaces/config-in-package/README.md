# Workspace with package.json

The CSpell settings are stored in the `package.json` file.
