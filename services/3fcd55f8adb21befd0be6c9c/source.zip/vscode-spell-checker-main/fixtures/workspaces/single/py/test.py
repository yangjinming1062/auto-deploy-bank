foo: str = "A Parrot"

print(foo.lower())
print(foo.islower())
print(foo.isupper())
print(foo.isprintable())

# Stop the execution of the script
