# Single Workspace

This Workspace only contains the current directory as a folder.

WORKSPACEWORD - a word only in the workspace.

Terms:
customterm - Added to Custom Terms.
