# Exmaple on Reporting Unknown Words

This is an exaple with some common errors:

- recieve -> receive
- simpel -> simple
- comon -> common
- thiswodshaserrors: but it isn't reported.

This is a peom about recieving incorect words. Not all of them are highlited or hilighted or even highlighted.
More comon mispellings like polution are flaged.

controlable, anouncement, and transfered are flagged. Even with a megafone we have issues.

this is anotter exemple of a speling issu.
