# Single Root Workspace

This workspace has a common root for all the folders.

PROJECTA and PROJECTB as custom workspace words.
