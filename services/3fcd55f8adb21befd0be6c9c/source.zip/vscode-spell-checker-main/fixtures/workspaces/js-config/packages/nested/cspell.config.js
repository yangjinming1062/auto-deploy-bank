'use strict';

/** @type { import("@cspell/cspell-types").CSpellUserSettings } */
const cspell = {
    description: 'nested js-config example',
};

module.exports = cspell;
