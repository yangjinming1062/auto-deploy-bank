# Config in `package.json` folder

This is a nested folder with `cspell` config stored in the `package.json` file.

customterm - A custom word.
