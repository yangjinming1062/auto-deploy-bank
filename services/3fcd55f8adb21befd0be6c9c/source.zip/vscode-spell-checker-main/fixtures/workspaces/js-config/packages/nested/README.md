# Nested folder

This is a nested folder with its own `cspell.config.js` file.

customterm - Added to Custom Terms.
