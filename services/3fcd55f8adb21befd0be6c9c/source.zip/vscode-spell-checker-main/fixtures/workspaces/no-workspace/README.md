# No Workspace

This Workspace is designed to be open as a folder. It does NOT have a workspace file.

CUSTOMTERM - a custom term that is in the custom dictionary.
