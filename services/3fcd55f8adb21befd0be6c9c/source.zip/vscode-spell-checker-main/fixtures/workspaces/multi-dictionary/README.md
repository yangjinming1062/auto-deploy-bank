# Multi-Dictionary

This workspace demonstrates using multiple dictionaries based upon file location.
