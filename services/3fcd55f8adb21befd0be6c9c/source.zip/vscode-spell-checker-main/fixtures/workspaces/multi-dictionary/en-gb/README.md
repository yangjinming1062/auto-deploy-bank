# British English Words

Only British words should be allowed here.

Colour is ok.

So is behaviour but not behavior.

color vs colour.

<!---
cspell:ignore behavior color
--->
