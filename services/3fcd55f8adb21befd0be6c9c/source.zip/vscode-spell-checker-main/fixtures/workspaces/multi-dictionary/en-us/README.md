# American English Files

This directory contains American English files.

Words like favor and behavior are correct.

But colour, favour, and behaviour is not.

<!---
Ignoring the forbidden words will prevent the spell checker errors:
cspell:ignore colour favour behaviour
--->
