# Sample Repository using Yarn 2

## Installation

Make sure to run `yarn` from this directory otherwise the `.pnp.js` and module cache will not exist.

## Sample scientific terms

The following terms should be considered correct because they are in `@cspell/dict-scientific-terms-us`

Acrepis
Acria
Acrias
Acricotopus
Acrida
Acridarachnea
Acrideumerus
Acrididae
AcrididaeChian
AcrididaeKorea
AcrididaeKuwait
Acridium
Acridocarpus
Acridocephala
Acridocera
Acridocryptus
Acridoderes
Acridomastax
Acridomyia
Acridophaea
Acridophagus
Acridoschema
Acridotarsa
Acridotheres
Acridoxena
Acridurus
Acrimea
