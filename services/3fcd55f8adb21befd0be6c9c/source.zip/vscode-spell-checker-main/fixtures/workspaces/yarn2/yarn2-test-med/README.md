# Sample Repository using Yarn 2

## Installation

Make sure to run `yarn` from this directory otherwise the `.pnp.js` and module cache will not exist.

The following terms should be considered correct because they are in `@cspell/dict-medicalterms`

# Medical Terms Test

This file contains some medical terms to be spell checked.

Sampled full list

abiana
abiate
abiatrophy
abiatus
abid
abidi
abidochromis
abience
abient
abietene
abietic
abietine
abietite
abigeat
abigei
Abilify
abinoxylan
abio
AbioCor
abiogeneses
abiogenesis
abiogenetic
abiogenic
abiogenist
abiogenous
abiogeny
Abiological
Abiomed
AbioMed
abionergy
abioseston
abiosis
abiotic
abiotically

ZUMI
Zung
Zunrisa
Zuntz's
Zuplenz
Zweifel
zwitterion
Zyban
Zybit
Zyderm
Zydis
Zydone
Zyflo
zygal
zygapophyseal
zygapophyseales
zygapophysial
zygapophysiales
zygapophysis
zygia
zygion
Zygocotyle
zygodactyly
zygoma
zygomas
zygomatic
zygomatica
zygomatici
zygomatico
zygomaticoauricular
zygomaticofacial
zygomaticofacialis
zygomaticofrontal
zygomaticofrontalis
zygomaticomaxillaris
zygomaticomaxillary
zygomaticosphenoid
zygomaticotemporal
zygomaticotemporalis
