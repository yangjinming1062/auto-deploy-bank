# Remote Dictionaries

It is possible to define a remote dictionary file using `https://` url.

This directory contains an example
