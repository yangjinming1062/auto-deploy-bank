# No Workspace and No cspell config

This Workspace is designed to be open as a folder. It does NOT have a workspace file. It also does NOT have a config file.

Words added to the workspace should get added to `.vscode/settings.json`

CUSTOMTERM - a custom term that is in the custom dictionary.
