# Primt Hello, world!

print('Hello, world!')

# More commentss the Uuse.

# With

# Some errrors and on some lines.
# We have lines without errors.
# It is important for checking the minimap.
# But it is not obvious what should happen.

# mycodingproject is in our own dictionary.
# codding errors.
