# Sample Jupyter Notebook

Thesse are wordz to livve by.

Whaat do youu thinkk?

How about trying it agaain?

forbidd

I'm hungry, lets go to the cafë

Does this auto-correct
