# Sample Jupyter Notebooks

The samples in this directory contain deliberate errors to test out error detection.

It is important to be able to correctly detect spelling errors in Jupyter Notebooks and to correctly report on them.
