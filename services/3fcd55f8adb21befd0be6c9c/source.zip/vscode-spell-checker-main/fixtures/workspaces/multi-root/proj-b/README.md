# Project B

This is Project B under a multi-root workspace.

PROJECTA and PROJECTB are workspace words.
