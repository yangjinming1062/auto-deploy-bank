# Multi-Root Workspace

This workspace contains multiple folders. They do not have a common root.
