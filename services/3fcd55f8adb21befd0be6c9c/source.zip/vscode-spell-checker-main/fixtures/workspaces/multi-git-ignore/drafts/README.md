This is a bit of texxt.
