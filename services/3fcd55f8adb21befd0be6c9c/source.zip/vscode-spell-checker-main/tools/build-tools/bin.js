#!/usr/bin/env node

import './dist/bin.js';
