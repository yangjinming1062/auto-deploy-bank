# Normalized JSON

Normalized JSON is a data structure that normalizes duplicate values. It handles circular references as well as multiple reverences to the same object.
