# Design Docs

This directory contains design documentation and ideas. Many of them are half baked. Its purpose is to capture thoughts for future use.
