# Security Policy

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| 1.9.x   | :white_check_mark: |
| 1.8.x   | :white_check_mark: |

## Reporting a Vulnerability

Please create an issue at: [Spell Checker Issues](https://github.com/streetsidesoftware/vscode-spell-checker/issues)
