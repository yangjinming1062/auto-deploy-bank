# Release Notes

For detailed release notes see [Spell Checker Releases](https://github.com/streetsidesoftware/vscode-spell-checker/releases).

## v4.0.0

Starting with v4, the release notes for major features will be included in the extension.
