# Test UTF16 word lists.

mywordd
otherword

mywordbe

mywordle
