<?php

namespace Revinate\SequenceBundle\Lib;

/**
 * Class MappedSequence
 * For namespace backwards compatibility
 * @deprecated
 */
class MappedSequence extends \Revinate\Sequence\MappedSequence {}
