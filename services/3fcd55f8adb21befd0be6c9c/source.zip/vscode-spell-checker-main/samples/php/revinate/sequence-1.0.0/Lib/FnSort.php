<?php

namespace Revinate\SequenceBundle\Lib;

/**
 * Class FnSort
 * For namespace backwards compatibility
 * @deprecated
 */
class FnSort extends \Revinate\Sequence\FnSort {}

