<?php

namespace Revinate\SequenceBundle\Lib;

/**
 * Class FnSequence
 * For namespace backwards compatibility
 * @deprecated
 */
class FnSequence extends \Revinate\Sequence\FnSequence {}
