<?php
/**
 * Created by PhpStorm.
 * User: jasondent
 * Date: 24/07/2015
 * Time: 16:54
 */

namespace Revinate\SequenceBundle\Lib;


/**
 * Class OnDemandIterator
 * For namespace backwards compatibility
 * @deprecated
 */
class OnDemandIterator extends \Revinate\Sequence\OnDemandIterator {}

