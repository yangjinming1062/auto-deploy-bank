<?php

namespace Revinate\SequenceBundle\Lib;

/**
 * Class FilteredSequence
 * For namespace backwards compatibility
 * @deprecated
 */
class FilteredSequence extends \Revinate\Sequence\FilteredSequence {}
