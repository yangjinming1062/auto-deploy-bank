<?php
/**
 * Created by PhpStorm.
 * User: jasondent
 * Date: 23/07/2015
 * Time: 20:51
 */

namespace Revinate\SequenceBundle\Lib;

/**
 * Class FnReduce
 * For namespace backwards compatibility
 * @deprecated
 */
class FnReduce extends \Revinate\Sequence\FnReduce {}
