<?php
/**
 * Created by PhpStorm.
 * User: jasondent
 * Date: 23/07/2015
 * Time: 16:41
 */

namespace Revinate\SequenceBundle\Lib;

/**
 * Class FnMap
 * For namespace backwards compatibility
 * @deprecated
 */
class FnMap extends \Revinate\Sequence\FnMap {}
