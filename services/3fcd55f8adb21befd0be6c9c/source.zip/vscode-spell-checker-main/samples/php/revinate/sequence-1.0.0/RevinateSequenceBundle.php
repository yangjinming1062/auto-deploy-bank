<?php

namespace Revinate\SequenceBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class RevinateSequenceBundle extends Bundle {}