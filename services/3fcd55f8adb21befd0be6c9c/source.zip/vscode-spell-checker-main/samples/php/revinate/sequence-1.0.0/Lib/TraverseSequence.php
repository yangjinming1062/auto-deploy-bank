<?php

namespace Revinate\SequenceBundle\Lib;

/**
 * Class RecursiveSequence
 * For namespace backwards compatibility
 * @deprecated
 */
class TraverseSequence extends \Revinate\Sequence\TraverseSequence {}

