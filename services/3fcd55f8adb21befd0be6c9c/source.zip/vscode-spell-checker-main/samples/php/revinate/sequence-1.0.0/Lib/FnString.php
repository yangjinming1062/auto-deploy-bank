<?php
/**
 * Created by PhpStorm.
 * User: jasondent
 * Date: 29/06/15
 * Time: 15:35
 */

namespace Revinate\SequenceBundle\Lib;

/**
 * Class FnString
 * For namespace backwards compatibility
 * @deprecated
 */
class FnString extends \Revinate\Sequence\FnString {}

