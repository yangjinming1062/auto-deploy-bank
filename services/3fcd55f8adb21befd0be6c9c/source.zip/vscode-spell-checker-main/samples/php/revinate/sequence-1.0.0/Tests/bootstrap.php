<?php
require __DIR__ . '/../vendor/autoload.php';

require 'FancyArray.php';
require 'TestData.php';
