<?php

namespace Revinate\SequenceBundle\Lib;

/**
 * Class IterationTraits
 * For namespace backwards compatibility
 * @deprecated
 */
class IterationTraits extends \Revinate\Sequence\IterationTraits {}

