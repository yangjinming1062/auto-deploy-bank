<?php
/**
 * Created by PhpStorm.
 * User: jasondent
 * Date: 26/07/2015
 * Time: 17:07
 */

namespace Revinate\SequenceBundle\Lib;


/**
 * Class FnBind
 * For namespace backwards compatibility
 * @deprecated
 */
class FnBind extends \Revinate\Sequence\FnBind {}

