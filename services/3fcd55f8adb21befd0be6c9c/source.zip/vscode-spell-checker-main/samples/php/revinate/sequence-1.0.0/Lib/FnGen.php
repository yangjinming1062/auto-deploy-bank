<?php

namespace Revinate\SequenceBundle\Lib;

/**
 * Class FnGen
 * For namespace backwards compatibility
 * @deprecated
 */
class FnGen extends \Revinate\Sequence\FnGen {}
