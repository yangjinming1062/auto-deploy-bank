<?php

namespace Revinate\SequenceBundle\Lib;

/**
 * Class RecursiveSequence
 * For namespace backwards compatibility
 * @deprecated
 */
class Sequence extends \Revinate\Sequence\Sequence {}

