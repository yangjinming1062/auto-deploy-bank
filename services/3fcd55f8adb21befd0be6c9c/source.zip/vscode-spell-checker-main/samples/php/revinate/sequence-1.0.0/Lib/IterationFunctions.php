<?php

namespace Revinate\SequenceBundle\Lib;

/**
 * Class IterationFunctions
 * For namespace backwards compatibility
 * @deprecated
 */
interface IterationFunctions extends \Revinate\Sequence\IterationFunctions {}

