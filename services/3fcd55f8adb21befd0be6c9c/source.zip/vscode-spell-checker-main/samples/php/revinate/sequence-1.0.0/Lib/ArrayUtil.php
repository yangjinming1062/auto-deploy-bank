<?php
/**
 * Created by PhpStorm.
 * User: jasondent
 * Date: 24/07/2015
 * Time: 18:32
 */

namespace Revinate\SequenceBundle\Lib;

/**
 * Class ArrayUtil
 * For namespace backwards compatibility
 * @deprecated
 */
class ArrayUtil extends \Revinate\Sequence\ArrayUtil {}
