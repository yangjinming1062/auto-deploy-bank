<?php
namespace Revinate\SequenceBundle\Lib;

/**
 * Class RecursiveSequence
 * For namespace backwards compatibility
 * @deprecated
 */
class RecursiveSequence extends \Revinate\Sequence\RecursiveSequence {}

