# Test out having custom dictionaries.

Here is some text.

worda
wordb
wordc
wordd
worde

terma
termb
termc
aterm

white

Here is text from `dict`:

Compaknee.
