/v2/shutdown
------------------------------------------------------------------------------------------------------------------------------------------

.. contents::

POST /v2/shutdown
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Shutdown the local server

Response status codes
**********************
- **201**: Server is shutting down
- **403**: Server shutdown refused

Sample session
***************


.. literalinclude:: ../../../examples/controller_post_shutdown.txt

