Template
-----------------------------

.. toctree::
   :glob:
   :maxdepth: 2

   template/*
