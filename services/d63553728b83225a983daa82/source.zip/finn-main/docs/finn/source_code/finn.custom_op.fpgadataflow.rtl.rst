*****************************
Custom Op - fpgadataflow.rtl
*****************************

RTL Custom Op Nodes
===================

finn.custom\_op.fpgadataflow.convolutioninputgenerator\_rtl
------------------------------------------------------------

.. automodule:: finn.custom_op.fpgadataflow.rtl.convolutioninputgenerator_rtl
   :members:
   :undoc-members:
   :show-inheritance:

finn.custom\_op.fpgadataflow.fmpadding\_rtl
---------------------------------------------

.. automodule:: finn.custom_op.fpgadataflow.rtl.fmpadding_rtl
   :members:
   :undoc-members:
   :show-inheritance:

finn.custom\_op.fpgadataflow.matrixvectoractivation\_rtl
---------------------------------------------------------------

.. automodule:: finn.custom_op.fpgadataflow.rtl.matrixvectoractivation_rtl
   :members:
   :undoc-members:
   :show-inheritance:

finn.custom\_op.fpgadataflow.streamingdatawidthconverter\_rtl
---------------------------------------------------------------

.. automodule:: finn.custom_op.fpgadataflow.rtl.streamingdatawidthconverter_rtl
   :members:
   :undoc-members:
   :show-inheritance:

finn.custom\_op.fpgadataflow.streamingfifo\_rtl
-------------------------------------------------

.. automodule:: finn.custom_op.fpgadataflow.rtl.streamingfifo_rtl
   :members:
   :undoc-members:
   :show-inheritance:

finn.custom\_op.fpgadataflow.thresholding\_rtl
-------------------------------------------------------

.. automodule:: finn.custom_op.fpgadataflow.rtl.thresholding_rtl
   :members:
   :undoc-members:
   :show-inheritance:

finn.custom\_op.fpgadataflow.vectorvectoractivation\_rtl
---------------------------------------------------------------

.. automodule:: finn.custom_op.fpgadataflow.rtl.vectorvectoractivation_rtl
   :members:
   :undoc-members:
   :show-inheritance:
