**************************
Custom Op - Channels Last
**************************

Channels Last Custom Ops
=========================

qonnx.custom\_op.channels\_last.base\_wrapped\_op
--------------------------------------------------

.. automodule:: qonnx.custom_op.channels_last.base_wrapped_op
   :members:
   :undoc-members:
   :show-inheritance:


qonnx.custom\_op.channels\_last.batch\_normalization
------------------------------------------------------

.. automodule:: qonnx.custom_op.channels_last.batch_normalization
   :members:
   :undoc-members:
   :show-inheritance:


qonnx.custom\_op.channels\_last.conv
--------------------------------------

.. automodule:: qonnx.custom_op.channels_last.conv
   :members:
   :undoc-members:
   :show-inheritance:


qonnx.custom\_op.channels\_last.max\_pool
------------------------------------------

.. automodule:: qonnx.custom_op.channels_last.max_pool
   :members:
   :undoc-members:
   :show-inheritance:
