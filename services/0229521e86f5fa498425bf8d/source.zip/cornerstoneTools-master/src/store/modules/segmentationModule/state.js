// Internal state of the brush module.
const state = {
  series: {},
  colorLutTables: [],
};

export default state;
