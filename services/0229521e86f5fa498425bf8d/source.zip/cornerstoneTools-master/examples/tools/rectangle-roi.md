---
layout: tool-simple
title: RectangleRoi Tool
toolName: RectangleRoi
toolType: annotation
---

{% include tool-simple-code-snippet.md %}
