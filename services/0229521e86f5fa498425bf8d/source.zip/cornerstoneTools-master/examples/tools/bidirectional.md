---
layout: tool-simple
title: Bidirectional Tool
toolName: Bidirectional
toolType: annotation
---

{% include tool-simple-code-snippet.md %}
