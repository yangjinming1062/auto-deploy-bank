---
layout: needs-example
title: Rotate MultiTouch Tool
toolName: RotateMultiTouch
toolType: general
---
