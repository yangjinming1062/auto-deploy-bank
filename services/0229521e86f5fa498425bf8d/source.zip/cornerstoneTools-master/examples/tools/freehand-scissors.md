---
layout: segmentation-tool
title: Freehand Scissors Tool
toolName: FreehandScissors
toolType: segmentation
customButtons: segmentationStrategiesButtons.html
---

{% include tool-simple-code-snippet.md %}

<h2 class="title is-2">🚧 Under Construction 🚧</h2>
