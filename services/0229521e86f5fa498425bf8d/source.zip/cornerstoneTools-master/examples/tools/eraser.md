---
layout: needs-example
title: Eraser Tool
toolName: Eraser
toolType: general
---
