---
layout: tool-simple
title: WWWC Tool
toolName: Wwwc
toolType: general
---

{% include tool-simple-code-snippet.md %}
