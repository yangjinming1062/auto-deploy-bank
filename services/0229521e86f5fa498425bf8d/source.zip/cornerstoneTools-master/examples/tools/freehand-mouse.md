---
layout: tool-simple
title: FreehandRoi Tool
toolName: FreehandRoi
toolType: annotation
---

<!--
  TODO: Demo should include:
  - FreehandRoiTool
  - FreehandRoiSculptorTool
-->

{% include tool-simple-code-snippet.md %}
