---
layout: tool-simple
title: Double Tap Fit To Window Tool
toolName: DoubleTapFitToWindow
toolType: general
---

"Double Tap" Fit to Window Tool is a touch tool. This tool can only be demonstrated on a device with touch support, or using touch emulation.
