---
layout: needs-example
title: Zoom TouchPinch Tool
toolName: ZoomTouchPinch
toolType: general
---

{% include tool-simple-code-snippet.md %}
