---
layout: needs-example
title: Pan MultiTouch Tool
toolName: PanMultiTouch
toolType: general
---
