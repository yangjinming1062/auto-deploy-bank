---
layout: segmentation-tool
title: Rectangle Scissors Tool
toolName: RectangleScissors
toolType: segmentation
customButtons: segmentationStrategiesButtons.html
---

{% include tool-simple-code-snippet.md %}

<h2 class="title is-2">🚧 Under Construction 🚧</h2>
