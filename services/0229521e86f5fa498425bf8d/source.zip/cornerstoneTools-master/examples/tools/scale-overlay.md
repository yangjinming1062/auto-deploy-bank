---
layout: tool-simple
title: Scale Overlay Tool
toolName: ScaleOverlay
toolType: general
---

<!-- TODO:
  - Ability to scale canvas to see scale overlay update
-->

{% include tool-simple-code-snippet.md %}
