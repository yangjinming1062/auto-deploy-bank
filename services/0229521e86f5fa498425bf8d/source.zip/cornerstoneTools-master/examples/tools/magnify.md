---
layout: tool-simple
title: Magnify Tool
toolName: Magnify
toolType: general
---

{% include tool-simple-code-snippet.md %}
