---
layout: tool-simple
title: WWWC Region Tool
toolName: WwwcRegion
toolType: general
---

{% include tool-simple-code-snippet.md %}
