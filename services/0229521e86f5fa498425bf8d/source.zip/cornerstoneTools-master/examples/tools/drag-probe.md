---
layout: tool-simple
title: Drag Probe Tool
toolName: DragProbe
toolType: general
---

{% include tool-simple-code-snippet.md %}
