---
layout: tool-simple
title: Pan Tool
toolName: Pan
toolType: general
---

{% include tool-simple-code-snippet.md %}
