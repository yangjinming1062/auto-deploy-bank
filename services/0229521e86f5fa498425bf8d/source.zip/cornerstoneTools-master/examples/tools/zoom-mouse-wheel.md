---
layout: needs-example
title: Zoom MouseWheel Tool
toolName: ZoomMouseWheel
toolType: general
---

{% include tool-simple-code-snippet.md %}
