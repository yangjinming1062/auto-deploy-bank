---
layout: tool-simple
title: Cobb Angle Tool
toolName: CobbAngle
toolType: annotation
---

{% include tool-simple-code-snippet.md %}
