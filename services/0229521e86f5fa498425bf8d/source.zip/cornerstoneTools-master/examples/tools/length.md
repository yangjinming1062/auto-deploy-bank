---
layout: tool-simple
title: Length Tool
toolName: Length
toolType: annotation
---

{% include tool-simple-code-snippet.md %}
