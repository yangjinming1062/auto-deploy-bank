## Interaction Types {#interaction-types}

_This section needs content_
