# Anatomy of a Tool

{% include "./modes.md" %}
{% include "./configuration.md" %}
{% include "./interaction-types.md" %}
{% include "./strategies.md" %}
{% include "./mixins.md" %}
{% include "./measurement-data.md" %}
