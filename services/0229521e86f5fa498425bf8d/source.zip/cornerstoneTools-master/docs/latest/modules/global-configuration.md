## Global Configuration {#global-configuration}

TODO! Feel free to contribute.
