# 3 Summary and outlook

Through the learning of previous courses, you have gained an in-depth understanding of the development and improvement process of large language models (LLMs) applications by building and progressively optimizing a Q&A bot. 
Below are several key points:

1. **Easy to launch, hard to improve**: Although it is relatively simple to develop and launch LLM applications, achieving good results requires continuous investment and a deep understanding of the business. Establishing objective evaluation methods and efficient evaluation mechanisms with domain experts is crucial.
   
2. **Step-by-step optimization, continuous iteration**: There are various ways to improve the performance of LLM applications, including prompt optimization, using RAG chatbot, adding tools, and fine-tuning. It is recommended to first try low-cost methods such as prompt optimization or RAG before considering more complex operations like fine-tuning.

3. **Multi-agent collaboration, complementary strengths**: LLMs possess human-like reasoning capabilities, and constructing a multi-agent system may be more efficient and powerful than relying on a single LLM.

4. **Production-oriented, focus on practical results**: Similar to traditional computer systems, during the development process, attention must also be paid to non-functional aspects such as system performance, cost, stability, and security.

Although we started with building a RAG application to learn about LLM applications, the actual use cases of LLMs go far beyond this.  



## 🧑🏻‍💻 1. Hands-on experience: building more complex AI applications

To give you a practical experience of specific AI application scenarios, we highly recommend that you try out the following AI technical solutions. These solutions cover multiple fields, including data extraction, content creation, customer service system construction, and real-time audio-video interaction.

### 1.1 Creative applications with AIGC

Creating compelling visual, audio, and video content has never been easier — all you need is a creative idea and the right tools. With Alibaba Cloud Smart Studio, you can now generate high-quality images, videos, and voice content effortlessly using AI-powered tools tailored for your specific needs.

Whether you're a marketer, content creator, or developer, Smart Studio offers a suite of powerful AIGC (Artificial Intelligence Generated Content) features that allow you to bring your imagination to life in seconds.

🔗 Try it out now at: [https://industrysolutions.alibabacloud.com/demo/smartstudio](https://industrysolutions.alibabacloud.com/demo/smartstudio)

Here are just a few of the creative tools you can explore:

**🖋️ Text-to-Image** 
Turn your ideas into stunning visuals with just a few lines of text. Whether you're designing a product mockup or creating artwork, our AI model generates high-resolution images that match your description — no design skills required!

**🔄 Face swap**
Want to swap faces in a photo or video? Our Face Swap tool makes it easy to replace faces in just one click. Try it out and see how AI can help you create fun and engaging content in no time!


<a href="https://img.alicdn.com/imgextra/i2/O1CN015sEzZe1lVu5lCNZeL_!!6000000004825-1-tps-1722-862.gif" target="_blank">
<img src="https://img.alicdn.com/imgextra/i2/O1CN015sEzZe1lVu5lCNZeL_!!6000000004825-1-tps-1722-862.gif" width="800" style="box-shadow: rgba(99, 99, 99, 0.21) 0px 1px 8px 0px;">
</a>

**🖼️ Image-to-Video**
Turn static images into dynamic videos with AI. Whether it's bringing a product to life or animating a concept, this tool helps you create compelling visual stories effortlessly.


<a href="https://img.alicdn.com/imgextra/i2/O1CN01PsdmGP1uptvZXUB54_!!6000000006087-1-tps-1722-950.gif" target="_blank">
<img src="https://img.alicdn.com/imgextra/i2/O1CN01PsdmGP1uptvZXUB54_!!6000000006087-1-tps-1722-950.gif" width="800" style="box-shadow: rgba(99, 99, 99, 0.21) 0px 1px 8px 0px;">
</a>

**🗣️ Voice copy**

Generate realistic voiceovers in seconds. Whether you're creating a marketing video, podcast, or presentation, our Voice Copy tool can:
- Clone your voice
- Generate speech in multiple languages
- Deliver natural intonation and clarity

---

**💡 Why use smart studio?**

- **Fast & Easy**: No coding or design experience needed—just describe what you want and let AI do the rest.
- **High-Quality Output**: Generate professional-grade content that looks and sounds amazing.
- **All-in-One Platform**: Access a full suite of AIGC tools in one place—including images, video, and voice generation.
- **Customizable**: Fine-tune your prompts and inputs to match your brand, style, or personal preferences.



### 1.2 Build an AI-Powered assistant in 10 minutes
Whether on a website, in DingTalk groups, WeChat Official Accounts, or Enterprise WeChat, Alibaba Cloud’s [Build an AI-Powered Customer Service in 10 Minutes](https://www.aliyun.com/solution/tech-solution/build-a-chatbot-for-your-website-or-chat-system) solution series enables seamless integration of AI-driven customer service to provide 24/7 support for client inquiries.  

You can visit Alibaba Cloud's **Chat App Message Service Console** to [Deploy Now](https://chatapp.console.aliyun.com/Overview) and create a web-based AI assistant.  


#### Key features  
- **Zero-code configuration**: Associate end applications (such as websites or WhatsApp) with Model Studio AI applications using intuitive settings.
- **Customizable knowledge base**: Train the assistant on private domain data to deliver precise answers.
- **Multi-channel support**: Deploy across platforms like WhatsApp, DingTalk, and WeChat Official Accounts.

#### Deployment workflow  

**1. Activate the chat App message service**  

Ensure the service is enabled in your Alibaba Cloud account before proceeding.  

**2. Create a chatbot workspace**  
- Log in to the [Chat App Message Service Console](https://chatapp.console.aliyun.com/Overview).  
- Navigate to **Ali me Settings** > **Open Chatbot Space**.  
- Select a language and confirm the workspace creation.  

**3. Build and manage chatbots**
- Go to **Ali me Settings** > **Robot Management**.  
- Define chatbot parameters (name, type) and create a new chatbot.  

**4. Bind to channels**
- Link the chatbot to a business number in a WhatsApp channel via **Channel Management** > **Number Management**.  
- Select the workspace and chatbot for binding.  



### 1.3 Real-time audio and video calls with AI

Suppose your customer service center handles thousands of complex customer inquiries every day, and human customer service agents struggle to respond to and resolve each customer's issues in real time. You can consider using the [AI Real-time Audio and Video Interaction](https://www.alibabacloud.com/en/solutions/ai-application/real-time-interaction) solution. Relying on the Video Cloud ARTC network, the entire interaction process is stable, efficient, and has extremely low latency, fully meeting the requirements of commercial scenarios. Below is an illustration of the system's architecture:

<a href="https://img.alicdn.com/imgextra/i1/O1CN01wmjg881zTWcHmgTV8_!!6000000006715-0-tps-7833-3667.jpg" target="_blank">
<img src="https://img.alicdn.com/imgextra/i1/O1CN01wmjg881zTWcHmgTV8_!!6000000006715-0-tps-7833-3667.jpg" width="800">
</a>

For businesses requiring voice-centric interactions, an audio dialogue assistant can be deployed.


<a href="https://img.alicdn.com/imgextra/i3/O1CN01HfdjN31NVOsTfiYFy_!!6000000001575-1-tps-696-544.gif" target="_blank">
<img src="https://img.alicdn.com/imgextra/i3/O1CN01HfdjN31NVOsTfiYFy_!!6000000001575-1-tps-696-544.gif" width="700" style="box-shadow: rgba(99, 99, 99, 0.21) 0px 1px 8px 0px;">
</a>

Now, [deploy an instance](https://www.alibabacloud.com/en/solutions/ai-application/real-time-interaction) and start your journey into the future!  


### 1.4 Pair programming with an AI developer, instantly become a full-stack developer
You may want to quickly add a new feature to your e-commerce system but are struggling with a lack of manpower? The Tongyi Lingma AI Developer is your 24/7 on-call programming partner! It can:
- **One-click generation for the entire process**
From requirement implementation to unit testing, from code fixes to batch modifications, complex code writing is "one-click generated" with full intelligent collaboration from AI.
- **Zero pressure for full-stack requirements**
Front-end and back-end development proceed simultaneously—front-end interface interaction, back-end service logic, AI automatically completes multi-file integration, doubling development efficiency.
- **Liberate your hands to create value**
You focus on architectural design and core logic, while repetitive coding, configuration maintenance, test cases, and other tedious tasks are autonomously handled by AI.


<a href="https://img.alicdn.com/imgextra/i1/O1CN01W0cNh11F81jzWyiXz_!!6000000000441-1-tps-1726-990.gif" target="_blank">
<img src="https://img.alicdn.com/imgextra/i1/O1CN01W0cNh11F81jzWyiXz_!!6000000000441-1-tps-1726-990.gif" width="700" style="box-shadow: rgba(99, 99, 99, 0.21) 0px 1px 8px 0px;">
</a>

For detailed processes, please refer to [Tongyi Lingma AI Developer Pair Programming with Developers](https://developer.aliyun.com/article/1658034). Let the AI Developer become your right-hand assistant now, [Download and experience immediately](https://help.aliyun.com/zh/lingma/user-guide/download-the-installation-guide)!


> If you want to automatically trigger pipelines after submitting code, automatically execute code inspections and unit tests, and manage the entire CI/CD process from development to deployment, Alibaba Cloud also provides [Enterprise Intelligent Coding Solutions](https://www.aliyun.com/solution/tech-solution/intelligent-coding?spm=5176.29677750.J_7uZrZlgl1hzBH9MLq1qLS.d_5_action_0.5f02154aSfWf1n). By combining Tongyi Lingma with Yunxiao, it further enhances your project management capabilities, ensuring timely and high-quality software delivery.


## 🌏 2. AI is impacting thousands of industries

AI and LLMs have already seen successful implementations in many fields. The following cases cover areas such as healthcare, entertainment, education, and more. By understanding these practical application scenarios, you can not only more intuitively feel the powerful capabilities of AI technology but also gain inspiration to find innovative breakthroughs and practical solutions for your own industry.


### 2.1 Healthcare: Assisted diagnosis and health management
In the healthcare field, innovations involving AI and LLMs are emerging one after another. Alibaba Cloud has collaborated with AstraZeneca to integrate vast amounts of medical knowledge literature and healthcare data, enabling the LLM to generate adverse drug reaction reports and improve pharmaceutical R&D efficiency. In 2020, DAMO Academy's healthcare AI team developed a large-scale assisted diagnosis system, which can quickly and accurately diagnose suspected cases of COVID-19 by analyzing patients' CT scans. The diagnosis takes only 20 seconds with an accuracy rate exceeding 96%. Additionally, Alibaba has partnered with multiple hospitals to significantly enhance the screening efficiency of lung diseases using its AI system, reducing the analysis time from several hours to just a few minutes.

<img src="https://img.alicdn.com/imgextra/i3/O1CN01cuDZrW1c52JjViJgE_!!6000000003548-2-tps-3102-1676.png"  width=800>
<img src="https://img.alicdn.com/imgextra/i4/O1CN01AOaBDt1ivbTC5lKw9_!!6000000004475-2-tps-3046-1528.png" width=800>


> Note: AI recommendations and AI prescriptions are only supplementary information. Medical decisions should be made by professional doctors based on the patient’s actual condition.


### 2.2 Entertainment industry: Content creation and virtual idols
The entertainment industry represents a pivotal domain where large language model (LLM) technology is revolutionizing content creation. Li Li, a groundbreaking virtual idol developed through advanced AI integration, exemplifies this transformation. By seamlessly merging with real-world film sets, Li Li demonstrates remarkable realism and human-like qualities, blurring the line between virtual and physical performance.

A standout moment came when Li Li starred in the Chinese-produced live-action series I Am Nobody, captivating audiences with her lifelike presence. Her holographic appearance at the 2023 World Internet Conference Wuzhen Summit—a flagship Chinese tech event—further solidified her status as a cultural phenomenon, drawing enthusiastic responses from attendees.

Beyond entertainment, innovations in digital human technology are reshaping marketing strategies. AI-driven real-time interactions, such as virtual anchors and digital employees, enable brands to craft immersive live-streaming experiences and hyper-targeted campaigns tailored to China’s dynamic market. These advancements highlight how LLM-powered solutions are not only enhancing storytelling but also redefining audience engagement in the Chinese entertainment ecosystem.

<table style='margin-left: 0;'>
    <tr>
        <td height="400" style="border-collapse: collapse;border: none;padding: 0;"><img src="https://img.alicdn.com/imgextra/i2/O1CN01DOzYDY1XFxeJLeuYL_!!6000000002895-2-tps-956-1698.png" style="height:400; box-shadow: rgba(99, 99, 99, 0.21) 0px 1px 8px 0px;">
        </td>
         <td height="400" style="border-collapse: collapse;border: none;padding: 0;"><img src="https://img.alicdn.com/imgextra/i2/O1CN01G7AOmz1RNqmIbhEdd_!!6000000002100-2-tps-864-1437.png" style="height:400; box-shadow: rgba(99, 99, 99, 0.21) 0px 1px 8px 0px;">
        </td>
        <td height="400" style="border-collapse: collapse;border: none;padding: 0;"><img src="https://img.alicdn.com/imgextra/i3/O1CN01PH880m1cG1mojjo6L_!!6000000003572-2-tps-1404-1868.png" style="height:400; box-shadow: rgba(50, 44, 44, 0.21) 0px 1px 8px 0px;">
        </td>
    </tr>
</table>


> Virtual YouTuber (Vtuber) technology spans multiple domains, and with the support of multimodal, Vtubers are becoming part of reality.


### 2.3 Education industry: Personalized learning and intelligent tutoring
LLMs are revolutionizing education through personalized learning systems and adaptive teaching tools. A notable example is **Precision Learning**, a Chinese education technology company that leveraged Alibaba's Tongyi LLM to develop the **Hyperrealistic AI One-on-One Teacher**.

This system creates customized learning plans for students, dynamically adjusting content and difficulty based on real-time progress and knowledge gaps. While currently tailored for China's educational context, its success highlights the transformative potential of LLMs in addressing global educational challenges.

### Key innovations in Precision Learning

- **Voice-Driven interaction**: Unlike text-based models, the system uses end-to-end voice recognition and synthesis to simulate natural teacher-student dialog.
- **Knowledge graph integration**: Combines AI with over six years of curated educational data to build subject-specific learning pathways.
- **Equity-Driven deployment**: Through partnerships with DingTalk and Qwen, Precision Learning aims to provide AI tutoring resources to underserved regions via the **Hyperrealistic One-on-One AI teacher universal plan**.

### Global adaptation considerations

While Precision Learning exemplifies the power of LLMs in education, its application must be localized to fit cultural, curricular, and technological contexts. For example:

- **Cross-Cultural personalization**: Systems like Duolingo (language learning) or Khan Academy's AI Tutor (global math/STEM) demonstrate how LLMs can adapt to diverse educational frameworks.
- **Ethical frameworks**: Countries could adopt AI-driven tutoring with safeguards for:
  - Data privacy (such as GDPR in the EU, COPPA in the US)
  - Bias mitigation in content delivery
  - Compliance with global standards like ISO/IEC 27001

  <img src="https://aliyun-aps-cloud-public.oss-cn-hangzhou.aliyuncs.com/img_946b7422dd46687c5d0c5916e2bc92a5.png?x-oss-process=image/resize,h_400,m_lfit" width="700" style="box-shadow: rgba(99, 99, 99, 0.21) 0px 1px 8px 0px;">

## 🎓 3. Continuous exploration

Technical research and development work always excites technical professionals, as everyone competes with each other, surpassing one another, collectively pushing the boundaries of technology. Today, the application of LLMs is creating wave after wave of technological advancements worldwide. Not long ago, DeepSeek-R2 made a significant appearance on global leaderboards, while the advent of Manus AI has pushed agent research to new heights.

We hope that you will use this course as a starting point to continue exploring the limitless possibilities of LLMs, continuously improving yourself through practice, and creating more applications with both social and commercial value. Together with developers around the world, let’s write a new chapter in artificial intelligence!

### 3.1 Further reading: In-depth thinking model QwQ
QwQ is a powerful reasoning AI model based on the Qwen2.5, available in both commercial and open-source versions. The commercial model (such as qwq-plus) significantly enhances performance in mathematics, coding, and general tasks through reinforcement learning, with core metrics comparable to the full version of DeepSeek-R2, offering both stable and latest snapshot versions. The open-source version (such as qwq-32b) also performs exceptionally well, surpassing similar distilled models. The model supports ultra-long contexts (131,072 tokens) and multi-round conversation, enabling continuous interaction scenarios, but does not support tool calling or structutred output. Its design focuses on reasoning effectiveness, making it suitable for applications requiring deep thinking and high-quality responses.

You can experience the QwQ series models on Model Studio [here](https://bailian.console.aliyun.com/#/efm/model_experience_center/text?currentTab=textChat&modelId=qwq-plus-latest), or refer to the Alibaba Cloud Help Center for [more information](https://help.aliyun.com/zh/model-studio/user-guide/qwq).  



## 🔥 Quiz
[Multiple Choice Question] What is an effective strategy for quickly validating new AI tools in a business environment?

- A. Conduct extensive market research before implementation
- B. Select a small group of representative users for a pilot
- C. Immediately proceed with large-scale deployment
- D. Wait for competitors to test the method first, then follow up

**Reference Answer**: B

**Answer Explanation**: A small-scale pilot effectively controls risks, avoiding project failure due to immature technology or unsuitable business scenarios.
---


## **🎊 Congratulations! You’ve Completed the Large Language Models ACP Certification Course! 👏**

Learning is about persistence. Thank you for sticking with it until now. Next, you can take the certification exam.

To help you smoothly obtain certification, here is a mock exam for the certification test. You can visit the Alibaba Cloud Training Center for the [Large Language Models ACP Certification Mock Exam](https://edu.aliyun.com/clouder/exam/intro/1107) to assess your learning outcomes.

Of course, if you have already mastered the basics of large language models (LLMs) development, you can log in to Alibaba Cloud and register for the [certification exam](https://edu.aliyun.com/certification/acp26). Best of luck on your exam!

<img src="https://aliyun-aps-cloud-public.oss-cn-hangzhou.aliyuncs.com/img_946b7422dd46687c5d0c5916e2bc92a5.png?x-oss-process=image/resize,h_400,m_lfit" width="700" style="box-shadow: rgba(99, 99, 99, 0.21) 0px 1px 8px 0px;">


