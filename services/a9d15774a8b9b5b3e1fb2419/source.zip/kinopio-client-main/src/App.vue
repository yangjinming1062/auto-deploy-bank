<template lang="pug">
  //- router-view is the route component (e.g. Space, Add)
  router-view
</template>

<script setup>
</script>
