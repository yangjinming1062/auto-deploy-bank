We're all friends here, so let's be cool, constructive, and always treat each other with respect.

Long version: https://www.contributor-covenant.org/version/2/0/code_of_conduct/
