# Architecture

```{toctree}
:maxdepth: 1

architecture/architecture_overview.md
architecture/jax_ai_libraries_chosen.md
```
