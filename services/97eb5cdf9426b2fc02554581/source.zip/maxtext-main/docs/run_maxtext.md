# Run MaxText

```{toctree}
:maxdepth: 1

run_maxtext/run_maxtext_localhost.md
run_maxtext/run_maxtext_single_host_gpu.md
run_maxtext/run_maxtext_via_xpk.md
run_maxtext/run_maxtext_via_pathways.md
run_maxtext/decoupled_mode.md

```
