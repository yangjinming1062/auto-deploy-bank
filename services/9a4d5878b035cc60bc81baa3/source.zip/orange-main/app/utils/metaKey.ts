export const metaKey = /Mac/.test(navigator.platform) ? '⌘' : 'Ctrl+'
