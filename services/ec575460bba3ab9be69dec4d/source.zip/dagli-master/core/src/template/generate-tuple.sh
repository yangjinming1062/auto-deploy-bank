#!/usr/bin/env bash

MY_DIR="`dirname \"$0\"`"



wait

javaformat ${MY_DIR}/generated/com/linkedin/dagli/tuple