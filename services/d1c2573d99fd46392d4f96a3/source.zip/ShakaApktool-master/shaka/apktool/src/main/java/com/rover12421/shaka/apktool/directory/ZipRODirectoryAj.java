package com.rover12421.shaka.apktool.directory;

import org.aspectj.lang.annotation.Aspect;

/**
 * Created by rover12421 on 1/29/16.
 */
@Aspect
public class ZipRODirectoryAj {
//    @Around("call(brut.directory.ZipRODirectory.new(..))" +
//            "&& args(zipFileName)")
//    public ZipRODirectory _new(String zipFileName) throws DirectoryException {
//        return new ZipRODirectoryEx(zipFileName);
//    }
//
//    @Around("call(brut.directory.ZipRODirectory.new(..))" +
//            "&& args(zipFile)")
//    public ZipRODirectory _new(File zipFile) throws DirectoryException {
//        return new ZipRODirectoryEx(zipFile);
//    }
//
//    @Around("call(brut.directory.ZipRODirectory.new(..))" +
//            "&& args(zipFile)")
//    public ZipRODirectory ZipRODirectory(ZipFile zipFile) throws DirectoryException {
//        return new ZipRODirectoryEx(zipFile);
//    }
//
//    @Around("call(brut.directory.ZipRODirectory.new(..))" +
//            "&& args(zipFileName, path)")
//    public ZipRODirectory ZipRODirectory(String zipFileName, String path)
//            throws DirectoryException {
//        return new ZipRODirectoryEx(zipFileName, path);
//    }
//
//    @Around("call(brut.directory.ZipRODirectory.new(..))" +
//            "&& args(zipFile, path)")
//    public ZipRODirectory ZipRODirectory(File zipFile, String path) throws DirectoryException {
//        return new ZipRODirectoryEx(zipFile, path);
//    }
//
//    @Around("call(brut.directory.ZipRODirectory.new(..))" +
//            "&& args(zipFile, path)")
//    public ZipRODirectory ZipRODirectory(ZipFile zipFile, String path) throws DirectoryException {
//        return new ZipRODirectoryEx(zipFile, path);
//    }
}
