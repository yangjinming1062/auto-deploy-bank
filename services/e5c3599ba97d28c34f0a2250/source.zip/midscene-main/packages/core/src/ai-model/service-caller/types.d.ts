declare module 'dirty-json';
