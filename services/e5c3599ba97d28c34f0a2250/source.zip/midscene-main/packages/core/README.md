## Documentation

Automate browser actions, extract data, and perform assertions using AI. It offers JavaScript SDK, Chrome extension, and support for scripting in YAML.

See https://midscenejs.com/ for details.

## License

Midscene is MIT licensed.