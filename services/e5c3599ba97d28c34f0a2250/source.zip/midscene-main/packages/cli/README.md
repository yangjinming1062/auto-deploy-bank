## Documentation

An AI-powered automation SDK can control the page, perform assertions, and extract data in JSON format using natural language.

See https://midscenejs.com/ for details.

## License

Midscene is MIT licensed.