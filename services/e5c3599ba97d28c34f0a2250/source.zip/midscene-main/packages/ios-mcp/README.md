# @midscene/ios-mcp

docs: https://midscenejs.com/mcp.html
