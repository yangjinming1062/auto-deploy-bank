/**
 * Windows-specific re-export of @midscene/computer
 * This package provides the same functionality as @midscene/computer
 * but is specifically for Windows platform.
 */
export * from '@midscene/computer';
