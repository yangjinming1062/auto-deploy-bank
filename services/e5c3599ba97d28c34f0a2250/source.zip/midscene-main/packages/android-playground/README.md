## Android playground

Android is driven by adb, so you need install adb first:
- [CLI](https://developer.android.com/tools/adb)

```bash 
npx @midscene/android-playground
```