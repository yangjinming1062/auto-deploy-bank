
### ScreenSpot-v2

```bash
pip install huggingface_hub
```

```bash
npm run download-screenspot-v2
```