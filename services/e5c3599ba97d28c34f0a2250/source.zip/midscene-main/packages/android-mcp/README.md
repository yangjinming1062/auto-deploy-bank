# Midscene MCP

docs: https://midscenejs.com/mcp.html
