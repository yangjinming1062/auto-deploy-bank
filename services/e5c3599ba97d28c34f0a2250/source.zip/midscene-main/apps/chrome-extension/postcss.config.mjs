export default {
  plugins: {
    '@tailwindcss/postcss': {
      preflight: false,
    },
  },
};
