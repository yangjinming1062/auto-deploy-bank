import './App.css';
import { PlaygroundPopup } from './extension/popup';

export default function App() {
  return <PlaygroundPopup />;
}
