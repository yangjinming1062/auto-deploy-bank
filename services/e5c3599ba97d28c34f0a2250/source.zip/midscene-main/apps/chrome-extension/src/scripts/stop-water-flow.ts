if (typeof window.midsceneWaterFlowAnimation !== 'undefined') {
  window.midsceneWaterFlowAnimation.disable();
}
