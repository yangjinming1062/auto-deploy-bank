# Midscene Android Playground

Playground tool for Android cli @midscene/android.

See https://midscenejs.com/ for details.
