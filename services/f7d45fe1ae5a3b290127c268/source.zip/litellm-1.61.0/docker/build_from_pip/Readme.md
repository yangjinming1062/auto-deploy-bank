# Docker to build LiteLLM Proxy from litellm pip package

### When to use this ?

If you need to build LiteLLM Proxy from litellm pip package, you can use this Dockerfile as a reference.

### Why build from pip package ?

- If your company has a strict requirement around security / building images you can follow steps outlined here 