# Troubleshooting 

## Stable Version

If you're running into problems with installation / Usage 
Use the stable version of litellm 

```
pip install litellm==0.1.345
```

