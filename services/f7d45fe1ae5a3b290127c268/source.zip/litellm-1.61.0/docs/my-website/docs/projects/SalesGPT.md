🤖 SalesGPT - Your Context-Aware AI Sales Assistant

Github: https://github.com/filip-michalsky/SalesGPT