# llmcord.py

llmcord.py lets you and your friends chat with LLMs directly in your Discord server. It works with practically any LLM, remote or locally hosted.

Github: https://github.com/jakobdylanc/discord-llm-chatbot
