**A private and secure ChatGPT alternative that knows your business.**

Upload docs, ask questions --> get answers.

Leverage GenAI with your confidential documents to increase efficiency and collaboration.

OSS core, everything can run in your environment. An extensible platform you can build your GenAI strategy on. Support a variety of popular LLMs including embedded for air gap use cases.

[![Static Badge][docs-shield]][docs-url]
[![Static Badge][github-shield]][github-url]
[![X (formerly Twitter) Follow][twitter-shield]][twitter-url]

<!-- MARKDOWN LINKS & IMAGES -->
<!-- https://www.markdownguide.org/basic-syntax/#reference-style-links -->

[docs-shield]: https://img.shields.io/badge/docs-site-black?logo=materialformkdocs
[docs-url]: https://docqai.github.io/docq/
[github-shield]: https://img.shields.io/badge/Github-repo-black?logo=github
[github-url]: https://github.com/docqai/docq/
[twitter-shield]: https://img.shields.io/twitter/follow/docqai?logo=x&style=flat
[twitter-url]: https://twitter.com/docqai
