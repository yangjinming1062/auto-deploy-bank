
# 🤗 Smolagents

`smolagents` is a barebones library for agents. Agents write python code to call tools and orchestrate other agents.

- [Github](https://github.com/huggingface/smolagents)
- [Docs](https://huggingface.co/docs/smolagents/index)
- [Build your agent](https://huggingface.co/docs/smolagents/guided_tour)