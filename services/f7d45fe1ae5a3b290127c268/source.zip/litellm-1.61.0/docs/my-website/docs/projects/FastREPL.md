⚡Fast Run-Eval-Polish Loop for LLM Applications

Core: https://github.com/fastrepl/fastrepl
Proxy: https://github.com/fastrepl/proxy
