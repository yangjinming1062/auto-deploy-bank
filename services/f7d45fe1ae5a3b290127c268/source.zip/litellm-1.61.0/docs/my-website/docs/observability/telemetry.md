# Telemetry 

There is no Telemetry on LiteLLM - no data is stored by us

## What is logged? 

NOTHING - no data is sent to LiteLLM Servers

