# litellm.moderation()
LiteLLM supports the moderation endpoint for OpenAI

## Usage
```python
import os
from litellm import moderation
os.environ['OPENAI_API_KEY'] = ""
response = moderation(input="i'm ishaan cto of litellm")   
```
