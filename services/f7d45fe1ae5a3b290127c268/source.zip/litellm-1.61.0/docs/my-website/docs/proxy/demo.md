# Demo App

Here is a demo of the proxy. To log in pass in:

- Username: admin
- Password: sk-1234


[Demo UI](https://demo.litellm.ai/ui)
