
If you would like to contribute to this User Guide, please refer to the 
[Contributing](../developer-guide/contributing.md) section in the Developer Guide 
as well as the [CONTRIBUTING.md](https://github.com/openboxes/openboxes/blob/develop/CONTRIBUTING.md)
docs in our GitHub repository.

If you would prefer to submit documentation updates as Word docs or collaborate with us
using Google Docs, please share the docs or links with our Support Team [support@openboxes.com](mailto:support@openboxes.com).
