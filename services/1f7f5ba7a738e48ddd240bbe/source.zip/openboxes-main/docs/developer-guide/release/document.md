1. Go to Releases page

       ![List Releases](../../assets/img/jira-list-releases.png "List Releases")

1. View the current release version

       ![View Release Notes](../../assets/img/jira-view-release.png "View Release")

1. Click the Release Notes button

       ![View Release Notes](../../assets/img/jira-view-release-notes.png "View Release Notes")

1. Choose Format: Markdown

1. Choose Layout: Issue key

1. Choose the issue types you want to include
   
1. Click the Regenerate notes button

1. Click the Copy to clipboard button 

       ![Generate Release Notes](../../assets/img/jira-generate-release-notes.png "Generate Release Notes")
