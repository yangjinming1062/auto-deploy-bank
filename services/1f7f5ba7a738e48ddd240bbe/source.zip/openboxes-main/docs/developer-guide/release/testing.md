Once the latest release branch has been deployed to OBNAVSTAGE we can start the QA pass. During 
this process we might add a few Bug tickets, but there should be no new features. Developers 
should either create branches off of release/x.y.z or commit directly to the release branch.

![Execute Tests](../../assets/img/execute-regression-tests.png)
