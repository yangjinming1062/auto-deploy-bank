Finalizing the release involves making the following changes to JIRA and Github.

Once the QA pass has been completed and there are no more bugs, we can start to finalize the 
release. 

1. Close any tickets that have been completed
1. Move remaining tickets to the next sprint / backlog
1. Remove fixVersion for any open tickets with fixVersion = x.y.z 

