* Create JIRA version 
* Create release branch
* Deploy to staging server 
* QA Process
* Finalize Release
* Generate Release Notes
* Publish Release Notes
* Deploy to Production
* Clean up, clean up, everybody, everywhere

## Resources
* <https://semver.org/>
* <https://www.atlassian.com/git/tutorials/comparing-workflows/gitflow-workflow>
* <https://gitversion.readthedocs.io/en/latest/git-branching-strategies/gitflow-examples/>
* <https://gitversion.readthedocs.io/en/latest/git-branching-strategies/gitflow/>
* <https://danielkummer.github.io/git-flow-cheatsheet/>
* <https://medium.com/hard-work/gitflow-release-hotfix-bddee96fc5c3>
* <https://www.fredonism.com/a-practical-take-on-gitflow-and-semantic-versioning>


## Auditing
* Created Thursday 21 March 2019
* Updated Tuesday 23 February 2021
* Updated Wednesday 28 July 2021
