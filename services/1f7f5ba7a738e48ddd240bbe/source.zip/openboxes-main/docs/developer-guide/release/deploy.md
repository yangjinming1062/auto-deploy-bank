1. Run Daily Stable Build plan (automated)

    ![Run Daily Stable Build plan](../../assets/img/bamboo-daily-stable-build-plan.png)
   

1. Download the Latest WAR artifact from Daily Stable Build > Artifacts

    ![Download latest WAR](../../assets/img/bamboo-download-latest-war.png)
