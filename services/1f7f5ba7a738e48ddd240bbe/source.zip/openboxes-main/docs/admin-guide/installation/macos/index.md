# Looking to contribute? 
We would love for you to create a pull request to add installation instructions for the Mac.