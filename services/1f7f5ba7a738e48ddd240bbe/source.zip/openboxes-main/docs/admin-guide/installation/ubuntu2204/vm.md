# Create a Virtual Machine 

## Deployment Methods

* Digital Ocean 
* Amazon Web Services (AWS) > EC2
* Google Compute 

