
## Step 5. Onboarding
1. Authenticate
1. Change admin password
2. Create a product
3. Record stock 
4. 
