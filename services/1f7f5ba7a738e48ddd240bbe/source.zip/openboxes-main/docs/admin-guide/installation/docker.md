# Installing OpenBoxes using Docker

While we do include a docker/ folder in the source code of OpenBoxes, the official Docker files including the 
instructions are maintained in the [OpenBoxes Docker repository](https://github.com/openboxes/openboxes-docker). 
Please see there for instructions on getting up and running with the newest releases of OpenBoxes.