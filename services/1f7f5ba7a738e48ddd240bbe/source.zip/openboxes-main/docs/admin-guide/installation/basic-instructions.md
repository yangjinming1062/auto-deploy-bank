# Basic Instructions
1. Review requirements
2. Provision resources
3. Install dependencies
1. Download latest release
1. Create new database in MySQL
1. Grant permissions to new database user 
1. Configure runtime properties (openboxes-config.properties)
1. Copy WAR file to Tomcat
1. Configure Tomcat
1. Start Tomcat
1. Watch the Tomcat logs during startup
1. Open application using Chrome browser 
