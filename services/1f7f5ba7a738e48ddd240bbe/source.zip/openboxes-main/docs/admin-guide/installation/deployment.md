!!! todo 
        
        Still need to write these docs, but this can probably wait. This part was more difficult
        because it's a higher level decision that needs to be made outside the scope of installing
        the application. Therefore, I need to restructure the documents to pull this out of the
        installation guide; probably into its own directory (i.e. hosting, deployment). Then, 
        the default installation instructions can be integrated into the first option.

# Deployment Options

## Single-Server Deployment (IaaS)

Use this [Installation Guide](index.md).

## Single-Server Deployment with Managed Database (Hybrid IaaS/PaaS)

### Provision managed database
### Provision VPS
### Install dependencies
### Basic configuration
### Deploy application
### Secure Application 
### Advanced configuration


## Distributed Deployment (CaaS)

Using docker, kubernetes, etc.
