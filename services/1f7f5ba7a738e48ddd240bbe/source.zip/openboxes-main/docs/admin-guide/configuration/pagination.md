## Configuration

```yaml

openboxes:
    api:
        pagination:
            enabled: true
```
