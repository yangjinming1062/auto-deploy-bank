

```
2025-01-25 05:01:55,331 INFO  [main] org.quartz.impl.StdSchedulerFactory: Using default implementation for ThreadExecutor
2025-01-25 05:01:55,391 INFO  [main] org.quartz.core.SchedulerSignalerImpl: Initialized Scheduler Signaller of type: class org.quartz.core.SchedulerSignalerImpl
2025-01-25 05:01:55,396 INFO  [main] org.quartz.core.QuartzScheduler: Quartz Scheduler v.2.3.2 created.
2025-01-25 05:01:55,397 INFO  [main] org.quartz.simpl.RAMJobStore: RAMJobStore initialized.
2025-01-25 05:01:55,399 INFO  [main] org.quartz.core.QuartzScheduler: Scheduler meta-data: Quartz Scheduler (v2.3.2) 'quartzScheduler' with instanceId 'NON_CLUSTERED'
  Scheduler class: 'org.quartz.core.QuartzScheduler' - running locally.
  NOT STARTED.
  Currently in standby mode.
  Number of jobs executed: 0
  Using thread pool 'org.quartz.simpl.SimpleThreadPool' - with 10 threads.
  Using job-store 'org.quartz.simpl.RAMJobStore' - which does not support persistence. and is not clustered.

2025-01-25 05:01:55,399 INFO  [main] org.quartz.impl.StdSchedulerFactory: Quartz scheduler 'quartzScheduler' initialized from an externally provided properties instance.
2025-01-25 05:01:55,399 INFO  [main] org.quartz.impl.StdSchedulerFactory: Quartz scheduler version: 2.3.2
2025-01-25 05:01:55,400 INFO  [main] org.quartz.core.QuartzScheduler: JobFactory set to: grails.plugins.quartz.QuartzMonitorJobFactory@7852ff5
2025-01-25 05:01:57,985 INFO  [main] o.s.w.s.m.m.a.RequestMappingHandlerMapping: Mapped "{[/error],produces=[text/html]}" onto public org.springframework.web.servlet.ModelAndView org.springframework.boot.autoconfigure.web.BasicErrorController.errorHtml(javax.servlet.http.HttpServletRequest,javax.servlet.http.HttpServletResponse)
```

