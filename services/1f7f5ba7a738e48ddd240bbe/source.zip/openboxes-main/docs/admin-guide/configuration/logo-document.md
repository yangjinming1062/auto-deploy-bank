

## Configuration
```yaml
openboxes:       
    report:
        logo:
            url: "https://openboxes.com/img/logo_100.png"
```


## Customization
```

```


##
