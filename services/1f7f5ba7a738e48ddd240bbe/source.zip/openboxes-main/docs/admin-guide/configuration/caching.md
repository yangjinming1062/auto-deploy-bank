```shell
2025-01-25 05:01:31,922 INFO  [main] o.s.w.s.v.f.FreeMarkerConfigurer: ClassTemplateLoader for Spring macros added to FreeMarker configuration
2025-01-25 05:01:45,782 DEBUG [main] g.p.c.ehcache.DefaultXmlConfiguration: Attempting to search for ehcache xml configuration at classpath:ehcache.xml
2025-01-25 05:01:45,803 DEBUG [main] g.p.c.ehcache.DefaultXmlConfiguration: Configuration not found
2025-01-25 05:01:45,806 DEBUG [main] g.p.c.ehcache.GrailsEhcacheCacheManager: Using default configuration
2025-01-25 05:01:48,696 DEBUG [main] o.e.core.internal.service.ServiceLocator: Starting 14 Services...
2025-01-25 05:01:48,720 DEBUG [main] o.e.core.internal.service.ServiceLocator: All Services successfully started, 14 Services in 24ms
2025-01-25 05:01:48,723 DEBUG [main] org.ehcache.core.EhcacheManager: Initialize successful.
2025-01-25 05:01:48,726 DEBUG [main] g.p.c.ehcache.GrailsEhcacheCacheManager: Cache names: []
```
