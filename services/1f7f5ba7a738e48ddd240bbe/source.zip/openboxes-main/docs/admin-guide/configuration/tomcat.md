[Include discussion re: /opt/tomcat/bin/setenv.sh]: # 
