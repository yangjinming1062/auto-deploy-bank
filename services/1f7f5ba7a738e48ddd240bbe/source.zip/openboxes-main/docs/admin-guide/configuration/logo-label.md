## Configuration 
```yaml
openboxes.logo.label: "TESTING"
```


## Customization
In order to set a custom label, 
```yaml
openboxes.logo.label: "staging"
```


![img.png](img.png)
