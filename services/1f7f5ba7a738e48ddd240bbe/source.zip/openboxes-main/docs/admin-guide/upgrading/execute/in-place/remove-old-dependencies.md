# 4. Remove Old Dependencies (optional)

Once you've completed the ["validate" phase](../../validate/verifying-upgrade.md) and enough time has passed for you
to feel confident that the upgrade has succeeded, you can remove the old dependency versions that you just upgraded
from (Java, Apache, Tomcat...). This is an optional step, but it will keep your machine in a cleaner state, which
will help reduce risk when performing future upgrades.
