# 7. Deprovision Old Instance (optional)

Now that you're fully running on the new server, you likely want to decommission the old one to save costs or resources.
Once you've completed the ["validate" phase](../../validate/verifying-upgrade.md) and feel confident about the new
installation, you can deprovision the old instance or stop the container or VM.
