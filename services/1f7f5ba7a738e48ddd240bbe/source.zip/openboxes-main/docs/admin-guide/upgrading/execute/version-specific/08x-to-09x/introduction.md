# Upgrading From 0.8.x to 0.9.x

There are two documented strategies for upgrading the application from version 0.8.x to 0.9.x:

* [0.8.x to 0.9.x via parallel upgrade](parallel.md)
* [0.8.x to 0.9.x via in-place upgrade](in-place.md)
