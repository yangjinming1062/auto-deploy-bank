# Version-Specific Upgrades

!!! tip

    If you would like advice or support, please feel free to reach out to us on our
    [Community discussion forum](https://community.openboxes.com).

Some upgrades require more precise instructions for how to perform their upgrades. You can find version-specific
upgrade instructions here.

* [0.8.x to 0.9.x](08x-to-09x/introduction.md)
