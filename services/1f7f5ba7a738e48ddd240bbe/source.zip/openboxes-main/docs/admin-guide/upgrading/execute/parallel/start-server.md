# 4. Start The New Server

With all database data and application dependencies properly configured in the new installation, all we need to do
now is start the server.

{% include 'admin-guide/common/_start_server.md' %}


## Verify App Startup

Once the server is started, you'll want to make sure that it's actually running properly.

{% include 'admin-guide/common/_verify_app_startup.md' %}
