# Parallel Upgrade From 0.8.x to 0.9.x

Because parallel upgrades work from a clean install, there are no version specific instructions for this upgrade.
You can simply follow the [regular parallel upgrade instructions](../../parallel/introduction.md).
