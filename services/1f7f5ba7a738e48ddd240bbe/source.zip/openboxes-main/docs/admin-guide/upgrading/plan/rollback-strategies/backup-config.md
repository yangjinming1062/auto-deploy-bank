It's common for new upgrades to require changes to the application configuration or to the configuration of its
dependencies. If you need to roll back the upgrade for whatever reason, you'll want to make sure that you have a
copy of your pre-migration configuration that you can revert back to.

{% include 'admin-guide/common/_determining_custom_config.md' %}
