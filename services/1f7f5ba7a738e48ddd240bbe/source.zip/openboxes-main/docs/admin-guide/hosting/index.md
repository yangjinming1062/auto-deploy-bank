


# Operating Systems
* Ubuntu 22.04 

# Hosting Options

## Infrastructure as a Service
* Amazon Web Services (AWS) EC2
* Azure 
* Digital Ocean Droplets

## Platform as a service


## Database as a Service
* 

# Deployment Options
* Docker
* Kubernetes
* Bare metal


# Skills Required
* Linux administration 
* 

# Other technologies to consider
* Terraform 
* Ansible 
* Puppet / Chef
* Packer
