=== "Using command line"

    #### 1. Copy the backup into the host machine

        scp openboxes.sql openboxes.server.com

    #### 2. 

!!! todo
