=== "Using command line"

    #### 1. SSH into the server

        ssh <database-server-ip>

    For example:

        ssh app.openboxes.com

    #### 2. Stop Tomcat 
    
        sudo service tomcat stop