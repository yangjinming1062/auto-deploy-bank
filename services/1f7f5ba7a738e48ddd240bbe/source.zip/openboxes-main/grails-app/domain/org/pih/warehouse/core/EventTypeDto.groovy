package org.pih.warehouse.core

class EventTypeDto {

    String name

    EventCode eventCode
}
