package com.hansonwang99.springboot_es_demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootEsDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootEsDemoApplication.class, args);
	}
}
