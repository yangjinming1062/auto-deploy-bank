package cn.codesheep.springbt_security_jwt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @www.codesheep.cn
 * 20190312
 */
@SpringBootApplication
public class SpringbtSecurityJwtApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringbtSecurityJwtApplication.class, args);
    }
}
