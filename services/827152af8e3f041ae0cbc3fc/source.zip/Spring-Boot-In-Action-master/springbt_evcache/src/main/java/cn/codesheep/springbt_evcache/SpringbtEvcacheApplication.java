package cn.codesheep.springbt_evcache;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbtEvcacheApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringbtEvcacheApplication.class, args);
    }
}
