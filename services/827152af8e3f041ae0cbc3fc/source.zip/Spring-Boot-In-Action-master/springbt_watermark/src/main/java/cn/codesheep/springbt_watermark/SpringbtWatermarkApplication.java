package cn.codesheep.springbt_watermark;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbtWatermarkApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringbtWatermarkApplication.class, args);
    }
}
