package cn.codesheep.springbt_vesta;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbtVestaApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringbtVestaApplication.class, args);
    }
}
