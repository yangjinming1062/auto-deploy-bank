package com.github.ltsopensource.cmd;

/**
 * @author Robert HG (254963746@qq.com) on 2/17/16.
 */
public class DefaultHttpCmd extends HttpCmd<HttpCmdResponse> {

}
