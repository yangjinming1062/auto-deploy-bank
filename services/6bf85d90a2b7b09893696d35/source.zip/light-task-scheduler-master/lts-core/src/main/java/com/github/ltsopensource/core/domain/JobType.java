package com.github.ltsopensource.core.domain;

/**
 * @author Robert HG (254963746@qq.com) on 4/7/16.
 */
public enum JobType {

    REAL_TIME,
    TRIGGER_TIME,
    CRON,
    REPEAT

}
