/**
 * 该Logger的封装基于 dubbo 修改，这里做统一说明
 * @author Robert HG (254963746@qq.com) on 5/19/15.
 */
package com.github.ltsopensource.core.logger;