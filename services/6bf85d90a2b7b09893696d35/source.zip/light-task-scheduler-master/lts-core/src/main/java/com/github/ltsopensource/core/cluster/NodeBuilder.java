package com.github.ltsopensource.core.cluster;

/**
 * @author Robert HG (254963746@qq.com) on 4/21/16.
 */
public interface NodeBuilder<T> {

    T build();

}
