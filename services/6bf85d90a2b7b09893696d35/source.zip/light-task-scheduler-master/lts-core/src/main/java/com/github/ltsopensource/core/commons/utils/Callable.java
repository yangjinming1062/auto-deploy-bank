package com.github.ltsopensource.core.commons.utils;

/**
 * @author Robert HG (254963746@qq.com) on 3/14/16.
 */
public interface Callable {
    void call() throws Exception;
}