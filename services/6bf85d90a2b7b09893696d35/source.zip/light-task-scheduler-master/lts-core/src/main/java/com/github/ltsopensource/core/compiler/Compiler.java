package com.github.ltsopensource.core.compiler;

public interface Compiler {

    Class<?> compile(String code);

}

