package com.github.ltsopensource.admin.web.vo;

/**
 * @author Robert HG (254963746@qq.com) on 3/10/16.
 */
public class NodeInfo {

    private String identity;
    private String nodeGroup;

    public String getIdentity() {
        return identity;
    }

    public void setIdentity(String identity) {
        this.identity = identity;
    }

    public String getNodeGroup() {
        return nodeGroup;
    }

    public void setNodeGroup(String nodeGroup) {
        this.nodeGroup = nodeGroup;
    }
}
