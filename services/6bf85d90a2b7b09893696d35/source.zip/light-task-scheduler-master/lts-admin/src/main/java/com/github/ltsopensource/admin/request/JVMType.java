package com.github.ltsopensource.admin.request;

/**
 * @author Robert HG (254963746@qq.com) on 3/13/16.
 */
public enum JVMType {

    GC,
    MEMORY,
    THREAD

}
