declare module "prismjs/components/prism-core";
