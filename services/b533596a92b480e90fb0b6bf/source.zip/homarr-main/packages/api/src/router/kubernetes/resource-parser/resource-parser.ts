export interface ResourceParser {
  parse(value: string): number;
}
