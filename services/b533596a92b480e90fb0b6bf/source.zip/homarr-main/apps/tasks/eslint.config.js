import baseConfig from "@homarr/eslint-config/base";

/** @type {import('typescript-eslint').Config} */
export default [
  {
    ignores: ["tasks.cjs"],
  },
  ...baseConfig,
];
