import definition from "./_definition";

const { layout } = definition;

export default layout;
