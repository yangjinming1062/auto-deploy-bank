import definition from "./_definition";

const { generateMetadataAsync: generateMetadata, page } = definition;

export default page;

export { generateMetadata };
