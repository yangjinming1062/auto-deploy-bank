import { notFound } from "next/navigation";

export default function NotFound() {
  return notFound();
}
