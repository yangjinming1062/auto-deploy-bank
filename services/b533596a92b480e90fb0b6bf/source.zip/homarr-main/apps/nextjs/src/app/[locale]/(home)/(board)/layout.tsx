import definition from "../../boards/(content)/(home)/_definition";

const { layout } = definition;

export default layout;
