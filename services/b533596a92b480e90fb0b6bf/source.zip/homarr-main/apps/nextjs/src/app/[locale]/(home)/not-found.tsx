import HomeBoardNotFoundPage from "../boards/(content)/not-found";

export default HomeBoardNotFoundPage;
