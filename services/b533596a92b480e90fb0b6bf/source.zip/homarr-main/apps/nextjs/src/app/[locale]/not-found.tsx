import { Center } from "@mantine/core";

export default function CommonNotFound() {
  return <Center h="100vh">404</Center>;
}
