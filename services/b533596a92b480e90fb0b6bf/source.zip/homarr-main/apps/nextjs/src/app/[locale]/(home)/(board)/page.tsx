import definition from "../../boards/(content)/(home)/_definition";

const { generateMetadataAsync: generateMetadata, page } = definition;

export default page;

export { generateMetadata };
