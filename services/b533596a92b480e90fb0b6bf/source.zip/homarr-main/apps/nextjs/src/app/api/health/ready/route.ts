export function GET() {
  return new Response(undefined, {
    status: 200,
  });
}
