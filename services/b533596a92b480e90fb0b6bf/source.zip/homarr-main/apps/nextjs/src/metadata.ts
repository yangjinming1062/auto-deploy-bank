export const createMetaTitle = (name: string) => `${name} • Homarr`;
