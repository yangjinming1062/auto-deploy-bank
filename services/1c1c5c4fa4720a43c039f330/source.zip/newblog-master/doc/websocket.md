# WebSocket





```js
var wsUri = "ws://${pageContext.request.serverName}:${pageContext.request.localPort}/wscpu.ws";
```


# 拥抱HTTP2.0