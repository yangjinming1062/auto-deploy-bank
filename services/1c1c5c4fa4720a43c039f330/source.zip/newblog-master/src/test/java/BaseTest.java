//import org.junit.runner.RunWith;
//import org.springframework.test.context.ActiveProfiles;
//import org.springframework.test.context.ContextConfiguration;
//import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
//
///**
// * Created with IntelliJ IDEA.
// * User: Zephery
// * Time: 2018/4/14 0:13
// * Description:
// */
//@ContextConfiguration(locations = {"classpath:testContext.xml"})
//@ActiveProfiles("develop")
//@RunWith(SpringJUnit4ClassRunner.class)
//public abstract class BaseTest {
//}