//import com.myblog.service.IBlogService;
//import lombok.extern.slf4j.Slf4j;
//import org.junit.Test;
//
//import javax.annotation.Resource;
//
///**
// * Created with IntelliJ IDEA.
// * User: Zephery
// * Time: 2018/4/8 23:36
// * Description:
// */
//
//@Slf4j
//public class CacheTest extends BaseTest{
//    @Resource
//    private IBlogService blogService;
//
//    @Test
//    public void test() {
//        blogService.getBlogDetail(615);
//    }
//}