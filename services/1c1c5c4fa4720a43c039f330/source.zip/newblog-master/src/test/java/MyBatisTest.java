//import org.apache.ibatis.io.Resources;
//import org.apache.ibatis.session.SqlSession;
//import org.apache.ibatis.session.SqlSessionFactory;
//import org.apache.ibatis.session.SqlSessionFactoryBuilder;
//import org.junit.Test;
//
///**
// * @author Zephery
// * @since 2018/1/20 15:41
// */
//public class MyBatisTest {
//    @Test
//    public void oneCache() throws Exception {
//        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(Resources.getResourceAsReader("mybatis-config.xml"));
//        SqlSession session = sqlSessionFactory.openSession();
//    }
//}