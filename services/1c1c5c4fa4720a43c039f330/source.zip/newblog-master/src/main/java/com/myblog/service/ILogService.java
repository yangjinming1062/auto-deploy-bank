package com.myblog.service;

/**
 * Created with IntelliJ IDEA.
 * User: Zephery
 * Time: 2018/2/13 16:33
 * Description:
 */
public interface ILogService {
    void record(String key, String value);
}