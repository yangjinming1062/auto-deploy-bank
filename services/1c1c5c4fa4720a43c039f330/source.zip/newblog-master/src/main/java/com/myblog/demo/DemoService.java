package com.myblog.demo;

/**
 * @author Zephery
 * @since 2018/1/3 14:24
 */
public interface DemoService {
    String sayHello(String name);
}