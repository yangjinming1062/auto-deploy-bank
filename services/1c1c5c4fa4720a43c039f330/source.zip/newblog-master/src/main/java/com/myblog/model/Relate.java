package com.myblog.model;

import lombok.Data;

/**
 * Created with IntelliJ IDEA.
 * User: Zephery
 * Time: 2018/5/9 23:06
 * Description:
 */
@Data
public class Relate {
    private String colName;
    private String type;
    private String format;
}