package com.myblog.common;

/**
 * @author Zephery
 * @since 2017/12/13 20:48
 */
public class SSOCommon {
    /**
     * qq 应用
     */
    public static final String qqAppKey = "101323012";
    public static final String qqAppSecret = "8afd8601924d31418ea63a83619b21f8";
    public static final String qqRedirectUri = "http://www.wenzhihuai.com/qqCallback.do";
    /**
     * 微信应用
     */
    public static final String weixinAppKey = "";
    public static final String weixinAppSecret = "";
    public static final String weixinScope = "snsapi_login";
    public static final String weixinRedirectUri = "";
//    public static final String weixinRedirectUri = "http://www.wenzhihuai.com/weixinReturn.do";
}