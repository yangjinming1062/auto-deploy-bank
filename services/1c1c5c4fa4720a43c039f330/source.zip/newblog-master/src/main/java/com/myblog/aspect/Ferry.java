package com.myblog.aspect;

/**
 * @author Zephery
 * @since 2018/1/31 14:01
 */
public class Ferry {
    public static void main(String[] args) {

    }

    private void run() {
    }
}