package com.myblog.service;

import com.myblog.model.Myreading;

import java.util.Set;

/**
 * Created with IntelliJ IDEA.
 * User: Zephery
 * Time: 2017/10/9 16:05
 * Description:
 */
public interface IMyReadingService {

    Set<Myreading> getAllReading();
}
