# Copyright 2023 Iguazio
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import uuid
import warnings
from typing import Union

import pandas as pd
import semver

from mlrun.errors import MLRunIncompatibleVersionError
from mlrun.model_monitoring.application import ModelMonitoringApplicationBase

SUPPORTED_EVIDENTLY_VERSION = semver.Version.parse("0.4.11")


def _check_evidently_version(*, cur: semver.Version, ref: semver.Version) -> None:
    if ref.is_compatible(cur) or (
        cur.major == ref.major == 0 and cur.minor == ref.minor and cur.patch > ref.patch
    ):
        return
    if cur.major == ref.major == 0 and cur.minor > ref.minor:
        warnings.warn(
            f"Evidently version {cur} is not compatible with the tested "
            f"version {ref}, use at your own risk."
        )
    else:
        raise MLRunIncompatibleVersionError(
            f"Evidently version {cur} is not supported, please change to "
            f"{ref} (or another compatible version)."
        )


_HAS_EVIDENTLY = False
try:
    import evidently  # noqa: F401

    _check_evidently_version(
        cur=semver.Version.parse(evidently.__version__),
        ref=SUPPORTED_EVIDENTLY_VERSION,
    )
    _HAS_EVIDENTLY = True
except ModuleNotFoundError:
    pass


if _HAS_EVIDENTLY:
    from evidently.renderers.notebook_utils import determine_template
    from evidently.report.report import Report
    from evidently.suite.base_suite import Suite
    from evidently.ui.type_aliases import STR_UUID
    from evidently.ui.workspace import Workspace
    from evidently.utils.dashboard import TemplateParams


class EvidentlyModelMonitoringApplicationBase(ModelMonitoringApplicationBase):
    def __init__(
        self, evidently_workspace_path: str, evidently_project_id: "STR_UUID"
    ) -> None:
        """
        A class for integrating Evidently for mlrun model monitoring within a monitoring application.
        Note: evidently is not installed by default in the mlrun/mlrun image.
        It must be installed separately to use this class.

        :param evidently_workspace_path:    (str) The path to the Evidently workspace.
        :param evidently_project_id:        (str) The ID of the Evidently project.

        """
        if not _HAS_EVIDENTLY:
            raise ModuleNotFoundError("Evidently is not installed - the app cannot run")
        self.evidently_workspace = Workspace.create(evidently_workspace_path)
        self.evidently_project_id = evidently_project_id
        self.evidently_project = self.evidently_workspace.get_project(
            evidently_project_id
        )

    def log_evidently_object(
        self, evidently_object: Union["Report", "Suite"], artifact_name: str
    ):
        """
         Logs an Evidently report or suite as an artifact.

        :param evidently_object:    (Union[Report, Suite]) The Evidently report or suite object.
        :param artifact_name:       (str) The name for the logged artifact.
        """
        evidently_object_html = evidently_object.get_html()
        self.context.log_artifact(
            artifact_name, body=evidently_object_html.encode("utf-8"), format="html"
        )

    def log_project_dashboard(
        self,
        timestamp_start: pd.Timestamp,
        timestamp_end: pd.Timestamp,
        artifact_name: str = "dashboard",
    ):
        """
        Logs an Evidently project dashboard.

        :param timestamp_start: (pd.Timestamp) The start timestamp for the dashboard data.
        :param timestamp_end:   (pd.Timestamp) The end timestamp for the dashboard data.
        :param artifact_name:   (str) The name for the logged artifact.
        """

        dashboard_info = self.evidently_project.build_dashboard_info(
            timestamp_start, timestamp_end
        )
        template_params = TemplateParams(
            dashboard_id="pd_" + str(uuid.uuid4()).replace("-", ""),
            dashboard_info=dashboard_info,
            additional_graphs={},
        )

        dashboard_html = self._render(determine_template("inline"), template_params)
        self.context.log_artifact(
            artifact_name, body=dashboard_html.encode("utf-8"), format="html"
        )

    @staticmethod
    def _render(temple_func, template_params: "TemplateParams"):
        return temple_func(params=template_params)
