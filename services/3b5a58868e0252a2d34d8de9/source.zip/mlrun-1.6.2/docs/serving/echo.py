def echo_handler(x):
    print(x)
    return x
