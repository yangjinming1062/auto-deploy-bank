mlrun.serving
==============

.. autoclass:: mlrun.serving.states.BaseStep
   :members: to, error_handler
   :private-members:

.. automodule:: mlrun.serving
   :members:
   :show-inheritance:
   :undoc-members:

.. automodule:: mlrun.serving.remote
   :members:
   :special-members: __init__

.. autoclass:: mlrun.serving.utils.StepToDict
   :members:
