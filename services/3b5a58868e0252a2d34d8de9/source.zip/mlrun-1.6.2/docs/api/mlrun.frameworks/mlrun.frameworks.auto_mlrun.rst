mlrun.frameworks.auto_mlrun
===========================

.. automodule:: mlrun.frameworks.auto_mlrun.auto_mlrun
   :members:
   :show-inheritance:
   :undoc-members:
