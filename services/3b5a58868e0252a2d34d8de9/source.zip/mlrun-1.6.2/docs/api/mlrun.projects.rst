mlrun.projects
==============

.. automodule:: mlrun.projects
   :members:
   :show-inheritance:
   :undoc-members:
   