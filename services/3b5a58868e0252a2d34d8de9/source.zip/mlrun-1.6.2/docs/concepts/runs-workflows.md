(workflows)=
# Batch runs and workflows


**In this section**

```{toctree}
:maxdepth: 1

mlrun-execution-context
decorators-and-auto-logging
submitting-tasks-jobs-to-functions
workflow-overview
/runtimes/configuring-job-resources
scheduled-jobs
notifications
```