(model-training-tracking)=
# Model training and tracking

**In this section**

```{toctree}
:maxdepth: 1

../training/create-a-basic-training-job
../training/working-with-data-and-model-artifacts
../concepts/auto-logging-mlops
../training/built-in-training-function
../hyper-params
```

