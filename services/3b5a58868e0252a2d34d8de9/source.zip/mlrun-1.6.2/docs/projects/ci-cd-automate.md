(ci-cd-automate)=
# CI/CD automation with Git

**In this section**

```{toctree}
:maxdepth: 1

automate-project-git-source
load-project-yaml
ci-integration
````