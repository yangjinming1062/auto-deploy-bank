package org.cf.smalivm.context;

import org.cf.smalivm.VirtualMachine;

public class StackTraceBuilder {

    static StackTraceElement[] buildCallStack(VirtualMachine vm, ExecutionContext context) {
        // List<String> callStackList = context.getCallStack();

        // For each MD in list
        // Get filename for class
        // Get line number - NEED NODE OR OP
        return null;
    }

}
