package org.cf.smalivm.context;

public class InstanceState extends BaseState {

    InstanceState(ExecutionContext context) {
        super(context);
    }

}
