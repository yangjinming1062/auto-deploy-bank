package org.cf.smalivm.emulate;

public interface UnknownValuesMethod {

}
