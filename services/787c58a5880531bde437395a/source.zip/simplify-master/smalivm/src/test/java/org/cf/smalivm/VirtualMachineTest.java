package org.cf.smalivm;

import static org.junit.jupiter.api.Assertions.fail;

import org.junit.jupiter.api.BeforeEach;

// These are not the tests you're looking for. *hand waving*
public class VirtualMachineTest {

    @BeforeEach
    public void setUp() throws Exception {
    }

    public void test() {
        // test class static initialization
        // examine instruction graph
        // test some public methods
        fail("Not yet implemented");
    }

}
