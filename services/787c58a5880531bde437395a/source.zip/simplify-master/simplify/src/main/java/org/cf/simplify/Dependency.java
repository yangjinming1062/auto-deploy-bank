package org.cf.simplify;

/*
 * Dependency interface we can mock to get away from statics
 */
public interface Dependency {

}
