import { GeminiClient } from '@google/gemini-cli-core'

// 导出默认实例
// export const service = new GeminiClient()
console.log('GeminiClient11', GeminiClient)
