import os

DEFAULT_PORT = int(os.environ.get('DEFAULT_PORT', 57988))
