# Image generation utilities module
