# Image generation providers
