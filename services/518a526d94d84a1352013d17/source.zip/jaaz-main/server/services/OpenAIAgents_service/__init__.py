# services/OpenAIAgents_service/__init__.py

from .jaaz_magic_agent import create_jaaz_response

__all__ = ['create_jaaz_response']
