(function () {

    'use strict';

    angular
        .module('platformChartModule', [
            'nvd3',
            'platformModuleComponent',
            'platformListGridModule',
            'businessIntelligenceServiceTemplatecache'
        ]);
})();