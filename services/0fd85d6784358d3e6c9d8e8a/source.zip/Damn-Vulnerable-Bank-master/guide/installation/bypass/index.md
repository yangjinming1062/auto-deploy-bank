## Bypass detection checks

There are multiple detection checks enabled everywhere in the application to check the integrity of the user.

* [Bypass GPU detection](gpu-detection.md)
* [Bypass root detection](root-detection.md)
* [Bypass frida detection with ghidra](frida-detection-with-ghidra.md)
