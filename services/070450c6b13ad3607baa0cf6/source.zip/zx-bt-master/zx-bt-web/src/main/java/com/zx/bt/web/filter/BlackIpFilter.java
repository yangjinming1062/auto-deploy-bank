package com.zx.bt.web.filter;

/**
 * author:ZhengXing
 * datetime:2018/3/12 0012 16:34
 * 黑名单ip过滤器
 */
public class BlackIpFilter {
}
