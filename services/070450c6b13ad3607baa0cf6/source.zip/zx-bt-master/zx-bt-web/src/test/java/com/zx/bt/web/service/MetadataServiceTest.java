package com.zx.bt.web.service;

import com.zx.bt.common.service.MetadataService;
import com.zx.bt.web.WebApplicationTests;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * author:ZhengXing
 * datetime:2018-03-11 1:23
 * 测试metadata服务类
 */
public class MetadataServiceTest  extends WebApplicationTests{

    @Autowired
    private MetadataService metadataService;

    @Test
    public void testList() {

    }
}
