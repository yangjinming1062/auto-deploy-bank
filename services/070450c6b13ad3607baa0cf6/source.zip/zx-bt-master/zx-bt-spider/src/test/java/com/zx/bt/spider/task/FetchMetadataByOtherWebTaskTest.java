package com.zx.bt.spider.task;

import com.zx.bt.common.entity.Metadata;
import com.zx.bt.spider.SpiderApplicationTests;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import static org.junit.Assert.*;

/**
 * author:ZhengXing
 * datetime:2018/3/14 0014 13:29
 */
public class FetchMetadataByOtherWebTaskTest extends SpiderApplicationTests {

	@Autowired
	private FetchMetadataByOtherWebTask task;

	@Test
	public void testZhongzisou() {
//		Metadata metadata = task.fetchMetadataByBtrabbit("b01ef8a5ea52c8291a5873e6ce580e05afe7f69c");
	}

}