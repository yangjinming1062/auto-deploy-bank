package com.zx.bt.spider.dto.bt;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * author:ZhengXing
 * datetime:2018-02-14 14:51
 * 通用响应参数
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class CommonResponse extends CommonParam{

}
