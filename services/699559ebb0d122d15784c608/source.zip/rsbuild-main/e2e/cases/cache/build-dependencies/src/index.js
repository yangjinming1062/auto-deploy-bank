import { a } from './a';

console.log('foo', a);
