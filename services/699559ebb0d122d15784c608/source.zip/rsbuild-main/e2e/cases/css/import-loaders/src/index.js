import a from './a.module.less';
import b from './b.module.less';

console.log(a);
console.log(b);
