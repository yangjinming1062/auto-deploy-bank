import style from './foo.css?inline';

export { style };
