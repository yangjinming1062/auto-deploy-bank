export default {
  html: {
    template: './src/index.html',
  },
};
