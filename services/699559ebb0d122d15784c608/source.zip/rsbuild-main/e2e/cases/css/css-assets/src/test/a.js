import styles from './index.module.css';

console.log('s', styles);

export const a = 1;
