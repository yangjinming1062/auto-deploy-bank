import styles from './style.module.css';

window.styles = styles;
