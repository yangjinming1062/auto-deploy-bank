import a from './a.scss';
import b from './b.module.scss';

window.a = a;
window.b = b;
