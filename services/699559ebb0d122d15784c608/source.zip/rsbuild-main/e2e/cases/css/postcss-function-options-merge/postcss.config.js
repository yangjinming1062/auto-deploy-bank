import { postcssPlugin } from './postcssPlugin';

export default {
  plugins: [postcssPlugin],
};
