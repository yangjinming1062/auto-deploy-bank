import styles from './index.module.css';

console.log(styles);
