import styles from './external.module.css';

console.log(styles);
