import './a.css';
import style from './b.module.css';

console.log(style);
