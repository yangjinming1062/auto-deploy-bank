console.log(process.env.REACT_APP_NAME, process.env.NORMAL_NAME);
