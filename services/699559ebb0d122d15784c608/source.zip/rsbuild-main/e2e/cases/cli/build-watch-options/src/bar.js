export const bar = 'bar1';
