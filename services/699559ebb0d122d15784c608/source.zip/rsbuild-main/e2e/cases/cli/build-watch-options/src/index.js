import { bar } from './bar';
import { foo } from './foo';

console.log(foo + bar);
