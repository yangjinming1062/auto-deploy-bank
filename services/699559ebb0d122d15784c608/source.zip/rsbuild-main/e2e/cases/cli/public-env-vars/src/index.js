console.log('process.env', process.env.PUBLIC_NAME, process.env.NORMAL_NAME);
console.log(
  'import.meta.env',
  import.meta.env.PUBLIC_NAME,
  import.meta.env.NORMAL_NAME,
);
