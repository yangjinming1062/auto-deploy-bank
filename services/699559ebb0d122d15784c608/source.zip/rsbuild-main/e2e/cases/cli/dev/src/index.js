const el = document.createElement('div');
el.id = 'test';
el.innerHTML = 'hello';
document.body.appendChild(el);
