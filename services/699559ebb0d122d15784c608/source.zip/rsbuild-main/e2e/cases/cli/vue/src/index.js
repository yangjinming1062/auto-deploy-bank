import { createApp } from 'vue';
import A from './A.vue';

createApp(A).mount('#root');
