const el = document.createElement('div');
el.id = 'test';
el.innerHTML = CONTENT;
document.body.appendChild(el);
