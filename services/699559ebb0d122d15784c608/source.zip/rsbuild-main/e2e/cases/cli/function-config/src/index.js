console.log(DEFINED_VALUE);
