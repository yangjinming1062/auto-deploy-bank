import { test } from '@e2e/helper';

test('should display shortcuts as expected in dev', async ({
  exec,
  logHelper,
}) => {
  const { childProcess } = exec('node ./dev.js');
  const { expectLog, clearLogs } = logHelper;

  // help
  await expectLog('press h + enter to show shortcuts');
  childProcess.stdin?.write('h\n');
  await expectLog('u + enter  show urls');

  // print urls
  clearLogs();
  childProcess.stdin?.write('u\n');
  await expectLog('➜  Local:    http://localhost:');

  // restart server
  clearLogs();
  childProcess.stdin?.write('r\n');
  await expectLog('restarting server');
  await expectLog('➜  Local:    http://localhost:');
});

test('should display shortcuts as expected in preview', async ({
  exec,
  logHelper,
}) => {
  const { childProcess } = exec('node ./preview.js');
  const { expectLog, clearLogs } = logHelper;

  // help
  await expectLog('press h + enter to show shortcuts');
  childProcess.stdin?.write('h\n');
  await expectLog('u + enter  show urls');

  // print urls
  clearLogs();
  childProcess.stdin?.write('u\n');
  await expectLog('➜  Local:    http://localhost:');
});

test('should support custom shortcuts in dev', async ({ exec, logHelper }) => {
  const { childProcess } = exec('node ./devCustom.js');
  const { expectLog, clearLogs } = logHelper;

  await expectLog('press h + enter to show shortcuts');

  clearLogs();
  childProcess.stdin?.write('s\n');
  await expectLog('hello world!');
});

test('should support custom shortcuts in preview', async ({
  exec,
  logHelper,
}) => {
  const { childProcess } = exec('node ./previewCustom.js');
  const { expectLog, clearLogs } = logHelper;

  // help
  await expectLog('press h + enter to show shortcuts');

  clearLogs();
  childProcess.stdin?.write('s\n');
  await expectLog('hello world!');
});
