import img from '@e2e/assets/icon.png';

function App() {
  return (
    <div>
      <div id="test">Hello Rsbuild!</div>
      <img id="test-img" src={img} alt="test" />
    </div>
  );
}

export default App;
