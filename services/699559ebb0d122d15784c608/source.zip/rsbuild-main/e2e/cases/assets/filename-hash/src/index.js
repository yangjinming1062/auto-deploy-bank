import React from 'react';
import ReactDOM from 'react-dom/client';

console.log(React, ReactDOM);
