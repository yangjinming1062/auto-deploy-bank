import small from '@e2e/assets/icon.png?url';

const testJson = new URL('./assets/test.json', import.meta.url).href;

console.log(small);
console.log(testJson);
