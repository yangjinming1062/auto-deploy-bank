import icon from '@e2e/assets/icon.png';
import image from '@e2e/assets/image.png';

console.log(icon, image);
