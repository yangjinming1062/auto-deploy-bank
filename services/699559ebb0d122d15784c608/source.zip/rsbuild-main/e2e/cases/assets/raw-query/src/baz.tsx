export function baz() {
  return <div>baz</div>;
}
