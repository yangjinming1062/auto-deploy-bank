export function bar(): string {
  return 'bar';
}
