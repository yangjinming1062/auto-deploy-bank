export default 'foo';
