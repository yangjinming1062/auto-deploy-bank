import large from './assets/test-temp-large.json5';
import small from './assets/test-temp-small.json5';

console.log(large);
console.log(small);
