import a from './a.json?raw';
import b from './b.json?raw';

window.a = a;
window.b = b;
