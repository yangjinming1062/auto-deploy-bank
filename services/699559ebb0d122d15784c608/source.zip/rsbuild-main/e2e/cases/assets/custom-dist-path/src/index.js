import small from '@e2e/assets/icon.png?url';
import './index.css';

import(/* webpackChunkName: "foo" */ './async');

console.log(small);
