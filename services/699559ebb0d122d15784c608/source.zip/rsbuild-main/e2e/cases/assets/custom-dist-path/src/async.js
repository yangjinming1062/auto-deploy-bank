import './async.css';

console.log('async');
