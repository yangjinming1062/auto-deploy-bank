import data from './data.json';

window.testValue = data.age;
