import { age } from './data.json';

window.testValue = age;
