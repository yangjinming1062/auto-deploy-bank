import data from './data.json' with { type: 'json' };

window.testValue = data.age;
