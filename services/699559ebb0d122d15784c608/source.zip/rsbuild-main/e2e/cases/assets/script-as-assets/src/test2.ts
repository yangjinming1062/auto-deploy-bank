export const test2: string = 'test2';
