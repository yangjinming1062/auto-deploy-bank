window.test1 = new URL('./test1.css', import.meta.url).href;
window.test2 = new URL('./test2.less', import.meta.url).href;
window.test3 = new URL('./test3.scss', import.meta.url).href;
window.test4 = new URL('./test4.styl', import.meta.url).href;
