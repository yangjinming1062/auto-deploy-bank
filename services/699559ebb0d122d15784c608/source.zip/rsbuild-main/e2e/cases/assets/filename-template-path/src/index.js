import small from './assets/icon.png?url';

console.log(small);
