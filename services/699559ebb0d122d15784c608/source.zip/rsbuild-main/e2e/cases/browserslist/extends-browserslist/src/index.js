async function foo() {
  console.log('hello');
}

console.log(foo);
