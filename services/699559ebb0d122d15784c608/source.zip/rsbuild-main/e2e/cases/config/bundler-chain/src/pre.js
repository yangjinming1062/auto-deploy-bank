const testEl = document.createElement('div');
testEl.id = 'test-el';
testEl.innerHTML = 'aaaaa';
document.body.appendChild(testEl);
window.aa = 1;
