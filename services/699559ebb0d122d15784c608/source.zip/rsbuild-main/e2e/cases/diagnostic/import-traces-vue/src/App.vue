<template>
  <div></div>
</template>

<style>
body {
  font-weight: 400
  font-size: 14px;
}
</style>
