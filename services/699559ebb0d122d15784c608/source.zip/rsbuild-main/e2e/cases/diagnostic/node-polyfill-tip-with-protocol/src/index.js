import querystring from 'node:querystring';

querystring.stringify({
  foo: 'bar',
});
