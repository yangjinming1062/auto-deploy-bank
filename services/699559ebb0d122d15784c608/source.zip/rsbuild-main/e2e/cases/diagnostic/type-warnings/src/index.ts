// This is a type error
let num = 1;
num = '2';

console.log(num);
