import 'data:text/javascript,import "un-existing-module"';
