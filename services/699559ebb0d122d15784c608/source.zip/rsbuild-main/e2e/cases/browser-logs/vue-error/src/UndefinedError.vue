<template>
  <p>Username: {{ user.name }}</p>
</template>

<script setup>
const user = undefined;
</script>
