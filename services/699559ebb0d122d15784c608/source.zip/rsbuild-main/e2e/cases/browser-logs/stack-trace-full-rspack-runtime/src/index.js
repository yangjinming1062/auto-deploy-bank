throw new Error('foo');
