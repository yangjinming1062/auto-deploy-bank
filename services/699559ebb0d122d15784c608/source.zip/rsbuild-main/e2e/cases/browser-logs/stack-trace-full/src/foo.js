export function foo() {
  throw new Error('foo');
}
