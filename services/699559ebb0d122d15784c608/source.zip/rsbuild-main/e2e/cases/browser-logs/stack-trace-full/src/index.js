import { foo } from './foo';

foo();
