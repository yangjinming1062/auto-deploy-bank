const App = () => {
  return (
    <button id="button" type="button">
      count: {undefinedValue}
    </button>
  );
};

export default App;
