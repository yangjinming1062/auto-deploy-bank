package web.response

class PageResponse(val count:Long, val page:Int,val data:Any){
    val code:Int=0
}