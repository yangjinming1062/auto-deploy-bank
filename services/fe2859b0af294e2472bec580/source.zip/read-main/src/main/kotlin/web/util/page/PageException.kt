package web.util.page

class PageException(msg: String?) : Exception(msg)