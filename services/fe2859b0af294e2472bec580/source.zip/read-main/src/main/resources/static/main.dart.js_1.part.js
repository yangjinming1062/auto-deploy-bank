((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var J,A,B={
b2Z(){var x=0,w=A.j(y.f)
var $async$b2Z=A.e(function(d,e){if(d===1)return A.f(e,w)
for(;;)switch(x){case 0:x=2
return A.c(A.F4(),$async$b2Z)
case 2:return A.h(null,w)}})
return A.i($async$b2Z,w)},
xB(){var x=0,w=A.j(y.f),v,u
var $async$xB=A.e(function(d,e){if(d===1)return A.f(e,w)
for(;;)switch(x){case 0:u=$
x=2
return A.c(C.aqy(),$async$xB)
case 2:u.aR=e
x=3
return A.c(C.O_(!0),$async$xB)
case 3:x=4
return A.c(A.O0(),$async$xB)
case 4:x=5
return A.c(B.b2Z(),$async$xB)
case 5:v=$.aR
$.DY=A.cU(v==null?null:A.bN(J.w(v.a,"setting:chinesetype")))
x=$.dM()||$.h_()?6:7
break
case 6:x=8
return A.c($.czO().k6(0),$async$xB)
case 8:case 7:x=9
return A.c(B.arD(),$async$xB)
case 9:v=e
$.qY=v
if(J.at(J.vD(v))>1000){J.qP($.qY)
v=y.g
A.O3(A.B(v,v))}x=10
return A.c(A.uV(),$async$xB)
case 10:$.ctS=D.coJ()
return A.h(null,w)}})
return A.i($async$xB,w)},
arD(){var x=0,w=A.j(y.j),v,u=2,t=[],s,r,q,p,o,n,m,l
var $async$arD=A.e(function(d,e){if(d===1){t.push(e)
x=u}for(;;)switch(x){case 0:x=3
return A.c(A.hc("urlchange"),$async$arD)
case 3:o=e
n=y.g
m=A.B(n,n)
x=!J.p(o,"")?4:5
break
case 4:u=7
q=o
if(q==null)q=""
x=10
return A.c(A.jK(B.d0w(),q,null,n,y.i),$async$arD)
case 10:s=e
for(q=J.aK(J.vD(s));q.t();){r=q.gO(q)
J.fa(m,r,A.o(J.w(s,r)))}u=2
x=9
break
case 7:u=6
l=t.pop()
m=A.B(n,n)
x=9
break
case 6:x=2
break
case 9:case 5:v=m
x=1
break
case 1:return A.h(v,w)
case 2:return A.f(t.at(-1),w)}})
return A.i($async$arD,w)},
cdA(d){return B.cOR(d)},
cOR(d){var x=0,w=A.j(y.i),v
var $async$cdA=A.e(function(e,f){if(e===1)return A.f(f,w)
for(;;)switch(x){case 0:v=A.c8Z(d,null)
x=1
break
case 1:return A.h(v,w)}})
return A.i($async$cdA,w)}},C,D
J=c[1]
A=c[0]
B=a.updateHolder(c[20],B)
C=c[24]
D=c[22]
var z=a.updateTypes(["Q<u<m,@>>(m)"]);(function installTearOffs(){var x=a._static_1
x(B,"d0w","cdA",0)})()
var y={j:A.a5("u<m,m>"),i:A.a5("u<m,@>"),g:A.a5("m"),f:A.a5("~")}};
(a=>{a["MV+zmpVuda5YQJY1mNtSgTKC6l4="]=a.current})($__dart_deferred_initializers__);