((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,D,B={bMT:function bMT(){},alS:function alS(d,e,f,g,h){var _=this
_.e=d
_.f=e
_.a=f
_.b=g
_.c=h}},C
A=c[0]
D=c[2]
B=a.updateHolder(c[26],B)
C=c[32]
B.bMT.prototype={
a8S(d,e,f,g,h,i,j,k,l,m,n,o){return new B.alS(f,null,h,n,j)}}
B.alS.prototype={
NR(d,e){},
AK(d){this.aLL(0)
this.l()},
aq(d){this.aLK(0)
this.l()}}
var z=a.updateTypes([]);(function inheritance(){var y=a.inherit
y(B.bMT,A.Fd)
y(B.alS,A.rp)})()
A.m5(b.typeUniverse,JSON.parse('{"alS":{"rp":[],"ro":[]}}'));(function constants(){C.uq=new B.bMT()
C.lH=new A.Z(1,0.17254901960784313,0.17254901960784313,0.17254901960784313,D.p)
C.jT=new A.Z(1,1,0.3215686274509804,0.3215686274509804,D.p)
C.va=new A.aC(0,0,0,1)
C.ve=new A.aC(10,0,10,0)
C.vf=new A.aC(16,16,16,0)
C.vl=new A.aC(6,0,0,0)})()};
(a=>{a["MCpGfD3zAbY70ZG+R4YPB+2J/HU="]=a.current})($__dart_deferred_initializers__);