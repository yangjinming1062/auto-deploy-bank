((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var B,C,A
B=c[0]
C=c[2]
A=c[36]
var z=a.updateTypes([]);(function constants(){A.bgI=new B.au("\u57fa\u672c",null,null,null,null,null,null,null,null,null,null,null,null,null,null,null)
A.Dq=new B.eb(C.G,null,null,A.bgI,null)
A.F3=new B.Z(1,0.5568627450980392,0.5568627450980392,0.5568627450980392,C.p)
A.uz=new B.Z(1,0.2196078431372549,0.2196078431372549,0.2196078431372549,C.p)
A.lI=new B.Z(1,0.1411764705882353,0.1411764705882353,0.1411764705882353,C.p)
A.Gk=new B.aC(6,4,6,4)
A.Hl=new B.cw(C.dr,12,C.d,null,null)
A.a_f=new B.a1(!0,null,null,null,null,null,15,C.af,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null)
A.td=new B.a1(!0,C.av,null,null,null,null,14,C.af,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null)})()};
(a=>{a["F/Pp/tACX5bAaFsZSPgorOb57+o="]=a.current})($__dart_deferred_initializers__);