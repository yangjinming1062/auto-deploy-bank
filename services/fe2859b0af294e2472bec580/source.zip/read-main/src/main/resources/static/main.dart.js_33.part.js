((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,B
A=c[0]
B=c[43]
var z=a.updateTypes([]);(function constants(){B.a_u=new A.au("\u6b63\u6587",null,null,null,null,null,null,null,null,null,null,null,null,null,null,null)})()};
(a=>{a["C6HNMpws6trlIqpDpVmH2jvp0So="]=a.current})($__dart_deferred_initializers__);