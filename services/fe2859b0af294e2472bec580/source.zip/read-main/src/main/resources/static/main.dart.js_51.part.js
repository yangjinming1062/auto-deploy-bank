((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,B,C={
cDk(d){return new C.RG(d,null)},
RG:function RG(d,e){this.c=d
this.a=e},
awp:function awp(){this.d=""
this.c=this.a=null},
bto:function bto(d){this.a=d},
btn:function btn(d,e){this.a=d
this.b=e},
btm:function btm(d){this.a=d},
btl:function btl(d){this.a=d},
bti:function bti(d){this.a=d},
btj:function btj(d){this.a=d},
btk:function btk(d){this.a=d}},D
A=c[0]
B=c[2]
C=a.updateHolder(c[8],C)
D=c[29]
C.RG.prototype={
a6(){return new C.awp()}}
C.awp.prototype={
a8(){this.aJ()
$.ap.k3$.push(new C.bto(this))},
a4T(){var x=0,w=A.j(y.f),v=this,u,t,s
var $async$a4T=A.e(function(d,e){if(d===1)return A.f(e,w)
for(;;)switch(x){case 0:s=v.c
s.toString
u=y.h
if(A.a3(s,null,u).w.a.a*0.8>400)t=400
else{s=v.c
s.toString
t=A.a3(s,null,u).w.a.a*0.8}s=v.c
s.toString
A.dm(!0,new C.btm(t),s,y.b)
return A.h(null,w)}})
return A.i($async$a4T,w)},
I9(d){return this.b6e(d)},
b6e(d){var x=0,w=A.j(y.f)
var $async$I9=A.e(function(e,f){if(e===1)return A.f(f,w)
for(;;)switch(x){case 0:x=5
return A.c(A.aKl(d),$async$I9)
case 5:x=f?2:4
break
case 2:x=6
return A.c(A.a9h(d),$async$I9)
case 6:x=3
break
case 4:throw A.k("\u65e0\u6cd5\u6253\u5f00\u94fe\u63a5: "+d)
case 3:return A.h(null,w)}})
return A.i($async$I9,w)},
aRL(d){var x,w,v,u,t=this,s=null,r=A.A(d)?B.h:B.bA,q=A.A(d)?s:B.aw,p=A.A(d)?s:B.aw,o=t.a.c
if(o)x=A.a([A.bt(s,s,s,A.aM(B.b0,A.A(d)?B.ax:B.au,s,s,s),s,s,new C.bti(d),s,s,s,s)],y.e)
else x=s
q=A.h1(x,!o,p,!0,s,s,q,D.bgo)
p=A.u4("assets/images/logo.png",B.G,s,s,s,80,s,80)
o=A.V("\u8f7b\u9605\u8bfb",s,s,s,s,s,s,A.ag(s,s,A.A(d)?B.d:B.H,s,s,s,s,s,s,s,s,20,s,s,B.W,s,s,!0,s,s,s,s,s,s,s,s),s,s,s)
x=t.d
if(x.length===0)x="\u52a0\u8f7d\u4e2d..."
w=y.e
x=A.al(B.G,A.aD(A.a([p,B.fs,o,B.bE,A.V("\u7248\u672c "+x,s,s,s,s,s,s,A.ag(s,s,A.A(d)?B.br:B.aj,s,s,s,s,s,s,s,s,14,s,s,s,s,s,!0,s,s,s,s,s,s,s,s),s,s,s)],w),B.i,B.j,B.l),B.k,s,s,s,s,s,s,s,B.Gc,s,s,s)
p=A.al(s,A.V("\u4e00\u4e2a\u5168\u79fb\u52a8\u7aef\u53ef\u7528\u7684\u9605\u8bfb\u5e94\u7528\uff0c\u652f\u6301\u591a\u7aef\u540c\u6b65\u9605\u8bfb\u8fdb\u5ea6\uff0c\u9002\u914d\u5404\u79cd\u5c4f\u5e55\u5c3a\u5bf8\u3002",s,s,s,s,s,s,A.ag(s,s,A.A(d)?B.bO:B.bV,s,s,s,s,s,s,s,s,14,s,s,s,s,1.6,!0,s,s,s,s,s,s,s,s),B.bx,s,s),B.k,s,s,s,s,s,s,s,B.acH,s,s,s)
o=A.V("\u9690\u79c1\u58f0\u660e",s,s,s,s,s,s,A.ag(s,s,A.A(d)?B.d:B.H,s,s,s,s,s,s,s,s,16,s,s,s,s,s,!0,s,s,s,s,s,s,s,s),s,s,s)
o=A.e6(s,s,s,!0,!0,s,s,s,new C.btj(t),!1,s,s,o,A.aM(B.ds,A.A(d)?B.br:B.aj,s,s,s),s)
v=A.zs(A.A(d)?B.cn:B.ce,20,1,20,s,s)
u=A.V("\u514d\u8d23\u58f0\u660e",s,s,s,s,s,s,A.ag(s,s,A.A(d)?B.d:B.H,s,s,s,s,s,s,s,s,16,s,s,s,s,s,!0,s,s,s,s,s,s,s,s),s,s,s)
u=A.e6(s,s,s,!0,!0,s,s,s,new C.btk(t),!1,s,s,u,A.aM(B.ds,A.A(d)?B.br:B.aj,s,s,s),s)
p=A.a([x,p,B.cv,A.aD(A.a([o,v,u,A.zs(A.A(d)?B.cn:B.ce,20,1,20,s,s)],w),B.i,B.j,B.l)],w)
$.cJ()
return A.eT(q,r,A.kO(s,p,B.lU,s,s,B.J,!1),s,s)},
J(d){return this.aRL(d)}}
var z=a.updateTypes([])
C.bto.prototype={
$1(d){return this.aEb(d)},
aEb(d){var x=0,w=A.j(y.f),v,u=this,t,s
var $async$$1=A.e(function(e,f){if(e===1)return A.f(f,w)
for(;;)switch(x){case 0:x=3
return A.c(A.XS(),$async$$1)
case 3:t=f
s=u.a
if(s.c==null){x=1
break}s.B(new C.btn(s,t))
case 1:return A.h(v,w)}})
return A.i($async$$1,w)},
$S:17}
C.btn.prototype={
$0(){this.a.d=this.b.c},
$S:0}
C.btm.prototype={
$1(d){var x=null,w=A.A(d)?x:B.d,v=A.aE(A.a([D.bg9,B.en,A.bt(x,B.dG,x,B.fb,x,x,new C.btl(d),B.C,x,x,"\u5173\u95ed")],y.e),B.i,B.j,B.l,0,x),u=this.a
return A.eB(x,w,A.al(x,D.b8u,B.k,x,new A.ay(u,u,0,1/0),x,x,x,x,x,x,x,x,x),x,x,v)},
$S:21}
C.btl.prototype={
$0(){A.am(this.a,!1).aX(null)
return null},
$S:0}
C.bti.prototype={
$0(){A.am(this.a,!1).aX(null)
return null},
$S:0}
C.btj.prototype={
$0(){this.a.I9("http://www.qread.xyz/ys.html")},
$S:0}
C.btk.prototype={
$0(){this.a.a4T()},
$S:0};(function inheritance(){var x=a.inherit,w=a.inheritMany
x(C.RG,A.a9)
x(C.awp,A.ac)
w(A.im,[C.bto,C.btm])
w(A.ke,[C.btn,C.btl,C.bti,C.btj,C.btk])})()
A.m5(b.typeUniverse,JSON.parse('{"RG":{"a9":[],"r":[]},"awp":{"ac":["RG"]}}'))
var y={e:A.a5("G<r>"),h:A.a5("ja"),b:A.a5("@"),f:A.a5("~")};(function constants(){var x=a.makeConstList
D.bgC=new A.au("\u8f7b\u9605\u8bfb\u65f6\u4e00\u6b3e\u672c\u5730\u9605\u8bfb\u5668\uff0c\u652f\u6301\u591a\u79cd\u6587\u672c\u683c\u5f0f\u3002\n\n\u8f7b\u9605\u8bfb\u540e\u7aef\uff08\u4ee5\u4e0b\u7b80\u79f0\u540e\u7aef\uff09\u662f\u57fa\u4e8e\u5f00\u6e90\u9605\u8bfb\u5236\u4f5c\u4e00\u6b3e\u89e3\u6790\u6307\u5b9a\u89c4\u5219\u5e76\u83b7\u53d6\u5185\u5bb9\u7684web\u5de5\u5177\uff0c\u4e3a\u5e7f\u5927\u7f51\u7edc\u6587\u5b66\u7231\u597d\u8005\u63d0\u4f9b\u4e00\u79cd\u65b9\u4fbf\u3001\u5feb\u6377\u8212\u9002\u7684\u8bd5\u8bfb\u4f53\u9a8c\u3002\n\n\u5f53\u60a8\u8fde\u63a5\u5230\u540e\u7aef\u65f6\u53ef\u4ee5\u4f7f\u7528\u540e\u7aef\u7684\u529f\u80fd\u3002\n\n\u5f53\u60a8\u4f7f\u7528\u540e\u7aef\u641c\u7d22\u4e00\u672c\u4e66\u7684\u65f6\u5019\uff0c\u540e\u7aef\u4f1a\u60a8\u6240\u4f7f\u7528\u7684\u89c4\u5219\u5c06\u8be5\u4e66\u7684\u4e66\u540d\u4ee5\u5173\u952e\u8bcd\u7684\u5f62\u5f0f\u63d0\u4ea4\u5230\u5404\u4e2a\u7b2c\u4e09\u65b9\u7f51\u7edc\u6587\u5b66\u7f51\u7ad9\u3002\u5404\u7b2c\u4e09\u65b9\u7f51\u7ad9\u8fd4\u56de\u7684\u5185\u5bb9\u4e0e\u8f7b\u9605\u8bfb\u65e0\u5173\uff0c\u8f7b\u9605\u8bfb\u5bf9\u5176\u6982\u4e0d\u8d1f\u8d23\uff0c\u4ea6\u4e0d\u627f\u62c5\u4efb\u4f55\u6cd5\u5f8b\u8d23\u4efb\u3002\u4efb\u4f55\u901a\u8fc7\u4f7f\u7528\u540e\u7aef\u800c\u94fe\u63a5\u5230\u7684\u7b2c\u4e09\u65b9\u7f51\u9875\u5747\u7cfb\u4ed6\u4eba\u5236\u4f5c\u6216\u63d0\u4f9b\uff0c\u60a8\u53ef\u80fd\u4ece\u7b2c\u4e09\u65b9\u7f51\u9875\u4e0a\u83b7\u5f97\u5176\u4ed6\u670d\u52a1\uff0c\u8f7b\u9605\u8bfb\u5bf9\u5176\u5408\u6cd5\u6027\u6982\u4e0d\u8d1f\u8d23\uff0c\u4ea6\u4e0d\u627f\u62c5\u4efb\u4f55\u6cd5\u5f8b\u8d23\u4efb\u3002\u7b2c\u4e09\u65b9\u641c\u7d22\u5f15\u64ce\u7ed3\u679c\u6839\u636e\u60a8\u63d0\u4ea4\u7684\u4e66\u540d\u81ea\u52a8\u641c\u7d22\u83b7\u5f97\u5e76\u63d0\u4f9b\u8bd5\u8bfb\uff0c\u4e0d\u4ee3\u8868\u8f7b\u9605\u8bfb\u8d5e\u6210\u6216\u88ab\u641c\u7d22\u94fe\u63a5\u5230\u7684\u7b2c\u4e09\u65b9\u7f51\u9875\u4e0a\u7684\u5185\u5bb9\u6216\u7acb\u573a\u3002\u60a8\u5e94\u8be5\u5bf9\u4f7f\u7528\u641c\u7d22\u5f15\u64ce\u7684\u7ed3\u679c\u81ea\u884c\u627f\u62c5\u98ce\u9669\u3002\n\n\u8f7b\u9605\u8bfb\u4e0d\u505a\u4efb\u4f55\u5f62\u5f0f\u7684\u4fdd\u8bc1\uff1a\u4e0d\u4fdd\u8bc1\u7b2c\u4e09\u65b9\u641c\u7d22\u5f15\u64ce\u7684\u641c\u7d22\u7ed3\u679c\u6ee1\u8db3\u60a8\u7684\u8981\u6c42\uff0c\u4e0d\u4fdd\u8bc1\u641c\u7d22\u670d\u52a1\u4e0d\u4e2d\u65ad\uff0c\u4e0d\u4fdd\u8bc1\u641c\u7d22\u7ed3\u679c\u7684\u5b89\u5168\u6027\u3001\u6b63\u786e\u6027\u3001\u53ca\u65f6\u6027\u3001\u5408\u6cd5\u6027\u3002\u56e0\u7f51\u7edc\u72b6\u51b5\u3001\u901a\u8baf\u7ebf\u8def\u3001\u7b2c\u4e09\u65b9\u7f51\u7ad9\u7b49\u4efb\u4f55\u539f\u56e0\u800c\u5bfc\u81f4\u60a8\u4e0d\u80fd\u6b63\u5e38\u4f7f\u7528\u8f7b\u9605\u8bfb\uff0c\u8f7b\u9605\u8bfb\u4e0d\u627f\u62c5\u4efb\u4f55\u6cd5\u5f8b\u8d23\u4efb\u3002\n\n\u8f7b\u9605\u8bfb\u5c0a\u91cd\u5e76\u4fdd\u62a4\u6240\u6709\u4f7f\u7528\u8f7b\u9605\u8bfb\u7528\u6237\u7684\u4e2a\u4eba\u9690\u79c1\u6743\uff0c\u60a8\u6ce8\u518c\u7684\u7528\u6237\u540d\u3001\u7535\u5b50\u90ae\u4ef6\u5730\u5740\u7b49\u4e2a\u4eba\u8d44\u6599\uff0c\u975e\u7ecf\u60a8\u4eb2\u81ea\u8bb8\u53ef\u6216\u6839\u636e\u76f8\u5173\u6cd5\u5f8b\u3001\u6cd5\u89c4\u7684\u5f3a\u5236\u6027\u89c4\u5b9a\uff0c\u8f7b\u9605\u8bfb\u4e0d\u4f1a\u4e3b\u52a8\u5730\u6cc4\u9732\u7ed9\u7b2c\u4e09\u65b9\u3002\n\n\u8f7b\u9605\u8bfb\u81f4\u529b\u4e8e\u6700\u5927\u7a0b\u5ea6\u5730\u51cf\u5c11\u7f51\u7edc\u6587\u5b66\u8f7b\u9605\u8bfb\u8005\u5728\u81ea\u884c\u641c\u5bfb\u8fc7\u7a0b\u4e2d\u7684\u65e0\u610f\u4e49\u7684\u65f6\u95f4\u6d6a\u8d39\uff0c\u901a\u8fc7\u4e13\u4e1a\u641c\u7d22\u5c55\u793a\u4e0d\u540c\u7f51\u7ad9\u4e2d\u7f51\u7edc\u6587\u5b66\u7684\u6700\u65b0\u7ae0\u8282\u3002\u8f7b\u9605\u8bfb\u5728\u4e3a\u5e7f\u5927\u5c0f\u8bf4\u7231\u597d\u8005\u63d0\u4f9b\u65b9\u4fbf\u3001\u5feb\u6377\u8212\u9002\u7684\u8bd5\u8bfb\u4f53\u9a8c\u7684\u540c\u65f6\uff0c\u4e5f\u4f7f\u4f18\u79c0\u7f51\u7edc\u6587\u5b66\u5f97\u4ee5\u8fc5\u901f\u3001\u66f4\u5e7f\u6cdb\u7684\u4f20\u64ad\uff0c\u4ece\u800c\u8fbe\u5230\u4e86\u5728\u4e00\u5b9a\u7a0b\u5ea6\u4fc3\u8fdb\u7f51\u7edc\u6587\u5b66\u5145\u5206\u7e41\u8363\u53d1\u5c55\u4e4b\u76ee\u7684\u3002\u8f7b\u9605\u8bfb\u9f13\u52b1\u5e7f\u5927\u5c0f\u8bf4\u7231\u597d\u8005\u901a\u8fc7\u8f7b\u9605\u8bfb\u53d1\u73b0\u4f18\u79c0\u7f51\u7edc\u5c0f\u8bf4\u53ca\u5176\u63d0\u4f9b\u5546\uff0c\u5e76\u5efa\u8bae\u9605\u8bfb\u6b63\u7248\u56fe\u4e66\u3002\u4efb\u4f55\u5355\u4f4d\u6216\u4e2a\u4eba\u8ba4\u4e3a\u901a\u8fc7\u8f7b\u9605\u8bfb\u641c\u7d22\u94fe\u63a5\u5230\u7684\u7b2c\u4e09\u65b9\u7f51\u9875\u5185\u5bb9\u53ef\u80fd\u6d89\u5acc\u4fb5\u72af\u5176\u4fe1\u606f\u7f51\u7edc\u4f20\u64ad\u6743\uff0c\u5e94\u8be5\u53ca\u65f6\u5411\u8f7b\u9605\u8bfb\u63d0\u51fa\u4e66\u9762\u6743\u529b\u901a\u77e5\uff0c\u5e76\u63d0\u4f9b\u8eab\u4efd\u8bc1\u660e\u3001\u6743\u5c5e\u8bc1\u660e\u53ca\u8be6\u7ec6\u4fb5\u6743\u60c5\u51b5\u8bc1\u660e\u3002\u8f7b\u9605\u8bfb\u5728\u6536\u5230\u4e0a\u8ff0\u6cd5\u5f8b\u6587\u4ef6\u540e\uff0c\u5c06\u4f1a\u4f9d\u6cd5\u5c3d\u5feb\u65ad\u5f00\u76f8\u5173\u94fe\u63a5\u5185\u5bb9\u3002",null,null,null,null,null,null,null,null,null,null,null,null,null,null,null)
D.akK=x([D.bgC],y.e)
D.aa9=new A.JO(B.J,B.j,B.l,B.i,null,B.bp,null,0,D.akK,null)
D.b8u=new A.a_B(B.J,null,null,null,D.aa9,B.u,null)
D.bg9=new A.au("\u514d\u8d23\u58f0\u660e",null,null,null,null,null,null,null,null,null,null,null,null,null,null,null)
D.bgo=new A.au("\u5173\u4e8e\u6211\u4eec",null,null,null,null,null,null,null,null,null,null,null,null,null,null,null)})()};
(a=>{a["kJ6/W5Z98HSkp13SFocosl1TF2U="]=a.current})($__dart_deferred_initializers__);