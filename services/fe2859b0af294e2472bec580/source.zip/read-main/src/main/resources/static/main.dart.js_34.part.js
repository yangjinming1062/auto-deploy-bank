((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var J,A,D,B={aV2:function aV2(d,e){this.a=d
this.b=e},Xh:function Xh(d,e,f){this.c=d
this.d=e
this.a=f},aBJ:function aBJ(){var _=this
_.d=$
_.c=_.a=_.f=_.e=null},bMz:function bMz(d){this.a=d},bMy:function bMy(d,e){this.a=d
this.b=e},aIU:function aIU(){},
cL0(d,e){var x=null
return new B.Xj(250,d,!1,new A.hY(x,x,y.n),new B.Bb(x,d,x,!1,!1,D.S,D.jx,1),$.aw())},
Xj:function Xj(d,e,f,g,h,i){var _=this
_.z=d
_.Q=e
_.ax=f
_.ch=g
_.cy=_.cx=_.CW=null
_.db=!1
_.a=h
_.a1$=0
_.R$=i
_.be$=_.al$=0},
b90:function b90(d){this.a=d},
b91:function b91(d){this.a=d},
b92:function b92(d){this.a=d},
Bb:function Bb(d,e,f,g,h,i,j,k){var _=this
_.a=d
_.b=e
_.c=f
_.d=g
_.e=h
_.f=i
_.r=j
_.w=k},
art:function art(d,e,f,g,h,i,j,k){var _=this
_.a=d
_.b=e
_.c=f
_.d=g
_.e=h
_.f=i
_.r=j
_.w=k},
b93(){return new B.Ba(null)},
Ba:function Ba(d){this.a=d},
a4C:function a4C(d){var _=this
_.d=$
_.e=d
_.f=!1
_.c=_.a=null},
bMw:function bMw(d){this.a=d},
bMx:function bMx(d){this.a=d},
bMv:function bMv(d,e){this.a=d
this.b=e}},C
J=c[1]
A=c[0]
D=c[2]
B=a.updateHolder(c[10],B)
C=c[53]
B.aV2.prototype={
M(){return"DetectionSpeed."+this.b}}
B.Xh.prototype={
a6(){return new B.aBJ()}}
B.aBJ.prototype={
gkq(d){var x,w=this.d
if(w===$){x=this.a.c
this.d=x
w=x}return w},
b7B(d,e){this.a.toString
return},
J(d){return new A.fZ(this.gkq(0),new B.bMz(this),null,null,y.i)},
a8(){var x,w,v=this
v.a.toString
$.ap.cS$.push(v)
x=v.gkq(0)
w=x.ch
v.f=new A.dQ(w,A.z(w).i("dQ<1>")).dO(v.a.d)
x.iF(0)
v.aJ()},
l(){var x,w=this
w.aT()
x=w.f
if(x!=null){x.aq(0)
w.f=null}x=w.gkq(0)
x.cs(0)
x.tj(null)
w.a.toString},
qg(d){this.a.toString
return}}
B.aIU.prototype={}
B.Xj.prototype={
bfy(){var x=this
x.CW=$.yw().gauk().dO(new B.b90(x))
x.cx=$.yw().gaCk().dO(new B.b91(x))
x.cy=$.yw().gaDx().dO(new B.b92(x))},
iF(d){var x=0,w=A.j(y.q),v,u=2,t=[],s=this,r,q,p,o,n,m,l,k,j
var $async$iF=A.e(function(e,f){if(e===1){t.push(f)
x=u}for(;;)switch(x){case 0:if(s.db)throw A.k(C.b03)
n=s.a
m=n.c
if((m==null?null:m.a)===D.za){x=1
break}if(n.e){x=1
break}l=s.Q
r=l
q=new B.art(r,null,C.abd,s.z,C.aqg,!1,!1,!1)
u=4
s.bfy()
x=7
return A.c($.yw().n_(0,q),$async$iF)
case 7:p=f
if(!s.db)s.sm(0,s.a.boP(p.b,r,!0,!0,p.c,p.a))
u=2
x=6
break
case 4:u=3
j=t.pop()
n=A.C(j)
if(n instanceof A.oz){o=n
if(!s.db)s.sm(0,s.a.boR(l,o,!0,!1,D.S,D.jx,1))}else if(!(n instanceof A.Y6))throw j
x=6
break
case 3:x=2
break
case 6:case 1:return A.h(v,w)
case 2:return A.f(t.at(-1),w)}})
return A.i($async$iF,w)},
cs(d){var x=0,w=A.j(y.q),v,u=this,t
var $async$cs=A.e(function(e,f){if(e===1)return A.f(f,w)
for(;;)switch(x){case 0:t=u.a
if(!t.d||!t.e||u.db){x=1
break}t=u.CW
if(t!=null)t.aq(0)
t=u.cx
if(t!=null)t.aq(0)
t=u.cy
if(t!=null)t.aq(0)
u.cy=u.cx=u.CW=null
t=u.a
u.sm(0,t.bot(!1,t.r===D.jx?D.jx:D.a_B))
x=3
return A.c($.yw().cs(0),$async$cs)
case 3:case 1:return A.h(v,w)}})
return A.i($async$cs,w)},
tj(d){return this.bDh(d)},
bDh(d){var x=0,w=A.j(y.q),v,u=this
var $async$tj=A.e(function(e,f){if(e===1)return A.f(f,w)
for(;;)switch(x){case 0:if(u.db||!u.a.d){x=1
break}x=3
return A.c($.yw().tj(d),$async$tj)
case 3:case 1:return A.h(v,w)}})
return A.i($async$tj,w)},
l(){var x=0,w=A.j(y.q),v,u=this
var $async$l=A.e(function(d,e){if(d===1)return A.f(e,w)
for(;;)switch(x){case 0:if(u.db){x=1
break}u.db=!0
u.ch.a3(0)
u.e6()
x=3
return A.c($.yw().l(),$async$l)
case 3:case 1:return A.h(v,w)}})
return A.i($async$l,w)}}
B.Bb.prototype={
M7(d,e,f,g,h,i,j,k){var x=this,w=d==null?x.a:d,v=e==null?x.b:e,u=g==null?x.d:g,t=h==null?x.e:h,s=i==null?x.f:i,r=j==null?x.r:j
return new B.Bb(w,v,f,u,t,s,r,k==null?x.w:k)},
boP(d,e,f,g,h,i){return this.M7(d,e,null,f,g,h,i,null)},
boR(d,e,f,g,h,i,j){return this.M7(null,d,e,f,g,h,i,j)},
bol(d){var x=null
return this.M7(x,x,x,x,x,x,x,d)},
boi(d){var x=null
return this.M7(x,x,x,x,x,x,d,x)},
bot(d,e){var x=null
return this.M7(x,x,x,x,d,x,e,x)}}
B.art.prototype={
T(){var x=A.B(y.w,y.y)
x.p(0,"facing",this.a.c)
x.p(0,"returnImage",!1)
x.p(0,"speed",1)
x.p(0,"timeout",this.d)
x.p(0,"torch",!1)
x.p(0,"useNewCameraSelector",!1)
return x}}
B.Ba.prototype={
a6(){return new B.a4C(A.j9(!1))}}
B.a4C.prototype={
a8(){this.aJ()
this.d=B.cL0(D.a6i,!1)},
l(){var x=this.d
x===$&&A.b()
x.l()
this.aT()},
Kf(){var x=0,w=A.j(y.q),v,u=2,t=[],s=this,r,q,p,o,n,m,l,k,j,i,h
var $async$Kf=A.e(function(d,e){if(d===1){t.push(e)
x=u}for(;;)switch(x){case 0:u=4
x=7
return A.c($.Ah.a_().aAC(!1,D.GP),$async$Kf)
case 7:r=e
x=r!=null&&J.fg(r.a)?8:9
break
case 8:q=J.hx(r.a)
x=q.a!=null?10:11
break
case 10:u=13
s.d===$&&A.b()
k=q.a
k.toString
x=16
return A.c($.yw().Lx(k),$async$Kf)
case 16:p=e
if(A.ky(p)){if(!p)s.c.az(y.v).f.ki(C.b92)
x=1
break}else{o=y.r.a(p)
if(o==null||o.a.length===0){s.c.az(y.v).f.ki(C.b98)
x=1
break}n=D.b.gU(o.a).z
if(n==null){s.c.az(y.v).f.ki(C.b96)
x=1
break}if(!D.c.aB(n,"http")){s.c.az(y.v).f.ki(A.H3(null,null,null,null,null,D.z,null,A.V("\u68c0\u6d4b\u5230\u7684\u4e8c\u7ef4\u7801\u4e0d\u662f\u6709\u6548\u7684URL: "+n,null,null,null,null,null,null,null,null,null,null),null,D.dn,null,null,null,null,null,null,null,null,null,null))
x=1
break}s.anT(n)}u=4
x=15
break
case 13:u=12
i=t.pop()
m=A.C(i)
s.c.az(y.v).f.ki(A.H3(null,null,null,null,null,D.z,null,A.V("\u4e8c\u7ef4\u7801\u89e3\u6790\u5931\u8d25: "+A.o(m),null,null,null,null,null,null,null,null,null,null),null,D.dn,null,null,null,null,null,null,null,null,null,null))
x=15
break
case 12:x=4
break
case 15:case 11:case 9:u=2
x=6
break
case 4:u=3
h=t.pop()
l=A.C(h)
s.c.az(y.v).f.ki(A.H3(null,null,null,null,null,D.z,null,A.V("\u9009\u62e9\u56fe\u7247\u5931\u8d25: "+A.o(l),null,null,null,null,null,null,null,null,null,null),null,D.dn,null,null,null,null,null,null,null,null,null,null))
x=6
break
case 3:x=2
break
case 6:case 1:return A.h(v,w)
case 2:return A.f(t.at(-1),w)}})
return A.i($async$Kf,w)},
J(d){var x,w,v=null,u=y.x,t=400*A.a3(d,v,u).w.gcf().gdQ(),s=A.bt(v,v,v,D.cq,v,v,new B.bMw(d),v,v,v,"\u8fd4\u56de"),r=y.u
s=A.h1(A.a([A.bt(v,v,v,C.afT,v,v,this.gbbq(),v,v,v,"\u9009\u62e9\u56fe\u7247"),D.aB],r),!0,v,!0,0,s,v,C.bgD)
x=this.d
x===$&&A.b()
w=A.a3(d,v,u).w.a.a*0.7>t?t:A.a3(d,v,u).w.a.a*0.7
u=A.a3(d,v,u).w.a.a*0.7>t?t:A.a3(d,v,u).w.a.a*0.7
return A.eT(s,v,new A.e1(D.b5,v,D.aT,D.z,A.a([new B.Xh(x,new B.bMx(this),v),A.dd(A.al(v,v,D.k,v,v,new A.aT(v,v,A.eW(D.d,2),A.aG(12),v,v,v,D.B),v,u,v,v,v,v,v,w),v,v),C.b3t],r),v),v,v)},
anT(d){if(this.f)return
this.e.eA(new B.bMv(this,d),y.F)}}
var z=a.updateTypes(["Q<~>()","r(T,Bb,r?)","u<m,F?>()"])
B.bMz.prototype={
$3(d,e,f){if(!e.d){this.a.a.toString
return C.aa8}if(e.c!=null){this.a.a.toString
return C.aa7}return A.ou(new B.bMy(this.a,e))},
$S:z+1}
B.bMy.prototype={
$2(d,e){var x,w,v=this.a,u=this.b
v.b7B(u,e)
v.a.toString
x=u.f
v=A.a2(1/0,e.a,e.b)
u=A.a2(1/0,e.c,e.d)
w=A.r0(A.rS(A.cl5(D.G,new A.ae(x.a,x.b,$.yw().auu(),null),D.k,D.bi),new A.S(v,u)),D.z,null)
return w},
$S:182}
B.b90.prototype={
$1(d){var x=this.a.ch
if((x.c&4)!==0||d==null)return
x.u(0,d)},
$S:1356}
B.b91.prototype={
$1(d){var x=this.a
if(x.db)return
x.sm(0,x.a.boi(d))},
$S:1357}
B.b92.prototype={
$1(d){var x=this.a
if(x.db)return
x.sm(0,x.a.bol(d))},
$S:27}
B.bMw.prototype={
$0(){A.am(this.a,!1).aX(null)
return null},
$S:0}
B.bMx.prototype={
$1(d){var x,w=d.a
if(w.length!==0){x=D.b.gU(w).z
if(x!=null&&D.c.aB(x,"http"))this.a.anT(x)}},
$S:327}
B.bMv.prototype={
$0(){var x,w=this.a
if(!w.f){x=w.c
x.toString
A.am(x,!1).aX(this.b)
w.f=!0}},
$S:3};(function installTearOffs(){var x=a._instance_0u
x(B.Xj.prototype,"gf7","l",0)
x(B.art.prototype,"gbE","T",2)
x(B.a4C.prototype,"gbbq","Kf",0)})();(function inheritance(){var x=a.mixin,w=a.inherit,v=a.inheritMany
w(B.aV2,A.I1)
v(A.a9,[B.Xh,B.Ba])
v(A.ac,[B.aIU,B.a4C])
w(B.aBJ,B.aIU)
v(A.im,[B.bMz,B.b90,B.b91,B.b92,B.bMx])
w(B.bMy,A.od)
w(B.Xj,A.c5)
v(A.F,[B.Bb,B.art])
v(A.ke,[B.bMw,B.bMv])
x(B.aIU,A.em)})()
A.m5(b.typeUniverse,JSON.parse('{"Xh":{"a9":[],"r":[]},"aBJ":{"ac":["Xh"],"em":[]},"Xj":{"c5":["Bb"],"bO":[],"aN":[]},"Ba":{"a9":[],"r":[]},"a4C":{"ac":["Ba"]}}'))
var y=(function rtii(){var x=A.a5
return{u:x("G<r>"),x:x("ja"),F:x("b9"),w:x("m"),i:x("fZ<Bb>"),n:x("hY<l4>"),v:x("QB"),r:x("l4?"),y:x("F?"),q:x("~")}})();(function constants(){var x=a.makeConstList
C.aeF=new A.bu(57911,"MaterialIcons",!1)
C.afQ=new A.cw(C.aeF,null,D.d,null,null)
C.a6q=new A.hK(D.G,null,null,C.afQ,null)
C.aa7=new A.oe(D.h,C.a6q,null)
C.aa8=new A.oe(D.h,null,null)
C.abd=new B.aV2(1,"normal")
C.aeV=new A.bu(58554,"MaterialIcons",!1)
C.afT=new A.cw(C.aeV,null,null,null,null)
C.aqg=x([],A.a5("G<jQ>"))
C.b_Q=new A.FJ(1,"controllerDisposed")
C.b_V=new A.uq("The MobileScannerController was used after it has been disposed.")
C.b03=new A.oz(C.b_Q,C.b_V)
C.b7E=new A.jh(D.h,D.cM,2)
C.ams=x([C.b7E],A.a5("G<jh>"))
C.bdJ=new A.a1(!0,D.d,null,null,null,null,14,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,C.ams,null,null,null)
C.bfT=new A.au("\u5c06\u4e8c\u7ef4\u7801\u653e\u5165\u6846\u5185\uff0c\u5373\u53ef\u81ea\u52a8\u626b\u63cf",null,C.bdJ,null,D.bx,null,null,null,null,null,null,null,null,null,null,null)
C.b3t=new A.q9(0,null,0,100,null,null,C.bfT,null)
C.bfV=new A.au("\u4e8c\u7ef4\u7801\u89e3\u6790\u5931\u8d25",null,null,null,null,null,null,null,null,null,null,null,null,null,null,null)
C.b92=new A.lY(C.bfV,null,null,null,null,null,null,null,null,null,null,null,null,D.dn,!1,null,null,null,D.z,null)
C.bg0=new A.au("\u4e8c\u7ef4\u7801\u5185\u5bb9\u4e3a\u7a7a",null,null,null,null,null,null,null,null,null,null,null,null,null,null,null)
C.b96=new A.lY(C.bg0,null,null,null,null,null,null,null,null,null,null,null,null,D.dn,!1,null,null,null,D.z,null)
C.beW=new A.au("\u672a\u68c0\u6d4b\u5230\u4e8c\u7ef4\u7801\uff0c\u8bf7\u786e\u4fdd\u56fe\u7247\u4e2d\u5305\u542b\u6e05\u6670\u7684\u4e8c\u7ef4\u7801",null,null,null,null,null,null,null,null,null,null,null,null,null,null,null)
C.b98=new A.lY(C.beW,null,null,null,null,null,null,null,null,null,null,null,null,D.dn,!1,null,null,null,D.z,null)
C.bgD=new A.au("\u626b\u7801",null,null,null,null,null,null,null,null,null,null,null,null,null,null,null)})()};
(a=>{a["IQlL+nmlX4adk6DrARfhvSFZOtU="]=a.current})($__dart_deferred_initializers__);