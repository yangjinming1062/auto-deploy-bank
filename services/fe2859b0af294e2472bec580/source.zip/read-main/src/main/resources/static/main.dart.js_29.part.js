((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,B
A=c[0]
B=c[35]
var z=a.updateTypes([]);(function constants(){B.k6=new A.aC(16,8,16,8)})()};
(a=>{a["s7mJS0D2HNTkMR0R6toMtXUYHLY="]=a.current})($__dart_deferred_initializers__);