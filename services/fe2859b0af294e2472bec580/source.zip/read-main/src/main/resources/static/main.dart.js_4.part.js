((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A={
coJ(){var y=$.aR
y=y==null?null:y.c9(0,"setting:isphone")
return y==="true"}}
A=a.updateHolder(c[22],A)
var z=a.updateTypes([])};
(a=>{a["aERCCiKAWqDsA6/RjvBTRKt23V0="]=a.current})($__dart_deferred_initializers__);