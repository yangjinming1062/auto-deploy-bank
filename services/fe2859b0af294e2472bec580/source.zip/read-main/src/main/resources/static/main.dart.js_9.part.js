((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,C,D,E,B={
c9G(){var x=0,w=A.j(y.b)
var $async$c9G=A.e(function(d,e){if(d===1)return A.f(e,w)
for(;;)switch(x){case 0:x=2
return A.c(A.cQ("back",""),$async$c9G)
case 2:A.dR("back")
E.cDS(new B.c9H())
return A.h(null,w)}})
return A.i($async$c9G,w)},
Ri(){var x=0,w=A.j(y.b)
var $async$Ri=A.e(function(d,e){if(d===1)return A.f(e,w)
for(;;)switch(x){case 0:x=2
return A.c(A.cQ("storage",""),$async$Ri)
case 2:A.dR("storage")
x=3
return A.c(C.xB(),$async$Ri)
case 3:x=4
return A.c(A.cQ("image_cache_manager",""),$async$Ri)
case 4:A.dR("image_cache_manager")
x=5
return A.c(D.b2C(),$async$Ri)
case 5:B.c9G()
return A.h(null,w)}})
return A.i($async$Ri,w)},
c9H:function c9H(){}}
A=c[0]
C=c[20]
D=c[19]
E=c[21]
B=a.updateHolder(c[18],B)
var z=a.updateTypes([])
B.c9H.prototype={
$0(){var x,w=$.Dk(),v=$.ap.ah$.x.h(0,w)
if(v!=null){x=A.ccx(v)
w=x!=null&&x.a7T()}else w=!1
if(w)A.am(v,!1).bX()},
$S:3};(function inheritance(){var x=a.inherit
x(B.c9H,A.ke)})()
var y={b:A.a5("~")}};
(a=>{a["SPXZ9cteJIaQ5AOntJm8SNcBE74="]=a.current})($__dart_deferred_initializers__);