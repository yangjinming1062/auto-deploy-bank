((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,B={
b2C(){var x=0,w=A.j(y.b)
var $async$b2C=A.e(function(d,e){if(d===1)return A.f(e,w)
for(;;)switch(x){case 0:x=2
return A.c(A.KV(),$async$b2C)
case 2:return A.h(null,w)}})
return A.i($async$b2C,w)}}
A=c[0]
B=a.updateHolder(c[19],B)
var z=a.updateTypes([])
var y={b:A.a5("~")}};
(a=>{a["obxdagjkbVDWxdpkkwW6x6Uwxis="]=a.current})($__dart_deferred_initializers__);