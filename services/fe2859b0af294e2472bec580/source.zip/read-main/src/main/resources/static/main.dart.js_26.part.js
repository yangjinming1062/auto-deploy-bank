((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var J,A,B,F,C={
ck3(d,e,f){return new C.TS(f,e,d,null)},
TS:function TS(d,e,f,g){var _=this
_.c=d
_.d=e
_.e=f
_.a=g},
a36:function a36(d){var _=this
_.at=""
_.ax=d
_.ay="\u6d4b\u8bd5"
_.ch="http://xxx.com?page={{page}}"
_.CW=null
_.cx=!1
_.fr=_.dy=_.dx=_.db=_.cy=""
_.d=null
_.e=!1
_.c=_.a=null},
bCj:function bCj(d){this.a=d},
bC9:function bC9(){},
bCa:function bCa(d,e,f){this.a=d
this.b=e
this.c=f},
bC4:function bC4(d){this.a=d},
bC5:function bC5(d){this.a=d},
bC3:function bC3(){},
bC6:function bC6(d){this.a=d},
bC2:function bC2(d){this.a=d},
bC7:function bC7(d){this.a=d},
bC0:function bC0(d,e){this.a=d
this.b=e},
bC1:function bC1(d,e){this.a=d
this.b=e},
bC8:function bC8(d){this.a=d},
bCd:function bCd(d){this.a=d},
bCb:function bCb(d,e){this.a=d
this.b=e},
bCc:function bCc(d,e){this.a=d
this.b=e},
bCf:function bCf(d){this.a=d},
bCe:function bCe(d){this.a=d},
bCi:function bCi(d,e,f){this.a=d
this.b=e
this.c=f},
bCg:function bCg(d,e){this.a=d
this.b=e},
bCh:function bCh(d){this.a=d}},D,G,E,H,I
J=c[1]
A=c[0]
B=c[2]
F=c[50]
C=a.updateHolder(c[14],C)
D=c[51]
G=c[25]
E=c[49]
H=c[37]
I=c[35]
C.TS.prototype={
a6(){return new C.a36(new A.c4(B.ag,$.aw()))}}
C.a36.prototype={
a8(){var x=this
x.aJ()
x.fr=x.a.e
$.ap.k3$.push(new C.bCj(x))},
Jk(d){return this.b03(d)},
b02(){return this.Jk("0")},
b03(d){var x=0,w=A.j(y.H),v=1,u=[],t=[],s=this,r,q,p,o,n,m,l,k,j
var $async$Jk=A.e(function(e,f){if(e===1){u.push(f)
x=v}for(;;)switch(x){case 0:s.bL()
v=3
x=6
return A.c(A.Jg(s.a.c,d),$async$Jk)
case 6:r=f
q=[]
try{q=A.c8Z(r.a,null)}catch(i){}l=J.eq(q,new C.bC9(),y.v)
k=A.J(l,l.$ti.i("as.E"))
p=k
if(J.at(p)!==0)for(o=0;o<J.at(p);++o)if(J.w(p,o).b.length!==0){new C.bCa(s,p,o).$0()
s.c.eG()
break}t.push(5)
x=4
break
case 3:v=2
j=u.pop()
n=A.C(j)
A.K(n)
t.push(5)
x=4
break
case 2:t=[1]
case 4:v=1
s.ab()
x=t.pop()
break
case 5:return A.h(null,w)
case 1:return A.f(u.at(-1),w)}})
return A.i($async$Jk,w)},
J(d){return this.aWO()},
aWO(){var x,w,v,u,t,s,r,q,p,o,n,m,l,k=this,j=null,i=k.c
i.toString
x=A.A(i)
w=x?j:B.aw
v=x?B.d:B.H
u=x?B.cn:H.uQ
i=k.a.d
t=i?j:G.ciX(v)
s=A.aG(20)
r=k.ax
q=A.ag(j,j,v,j,j,j,j,j,j,j,j,j,j,j,j,j,j,!0,j,j,j,j,j,j,j,j)
p=A.ag(j,j,A.af(153,v.n()>>>16&255,v.n()>>>8&255,v.n()&255),j,j,j,j,j,j,j,j,j,j,j,j,j,j,!0,j,j,j,j,j,j,j,j)
o=A.aG(20)
n=A.aM(B.dL,B.aj,j,j,j)
m=r.a.a.length!==0?A.cY(j,A.aM(B.b0,A.af(153,v.n()>>>16&255,v.n()>>>8&255,v.n()&255),j,j,20),B.u,!1,j,j,j,j,j,j,j,j,j,j,j,j,j,j,j,j,j,j,j,j,j,j,new C.bC4(k),j,j,j,j,j,j,!1,B.ai):j
l=y.p
s=A.aE(A.a([A.bx(A.al(j,A.dH(j,B.a_,!1,j,!0,B.z,j,A.di(),r,j,j,j,j,j,2,A.eR(j,new A.ia(4,o,B.w),j,B.f9,j,j,j,j,!0,j,j,j,j,j,j,j,j,j,j,j,j,j,j,j,j,j,j,j,j,j,p,"\u8f93\u5165\u4e66\u540d\u6216\u8005\u53d1\u73b0URL",j,j,j,j,j,j,j,j,j,!0,!0,j,n,j,j,j,j,j,j,m,j,j,j,j,j),B.u,!0,j,!0,j,!1,j,B.at,j,j,j,j,j,j,j,j,1,j,j,!1,"\u2022",j,new C.bC5(k),j,k.gb3B(),j,!1,j,j,!1,j,!0,j,B.aq,j,j,j,j,j,j,j,j,j,j,j,q,!0,B.Q,j,B.az,j,j,j,j),B.k,j,j,new A.aT(u,j,j,s,j,j,j,B.B),j,40,j,j,j,j,j,j),1)],l),B.i,B.j,B.l,0,j)
q=A.a([A.bt(j,j,j,A.aM(B.e6,v,j,j,j),j,j,new C.bC6(k),j,j,j,"\u66f4\u591a")],l)
if(k.a.d)q.push(A.bt(j,j,j,A.aM(B.b0,v,j,j,j),j,j,new C.bC7(k),j,j,j,"\u5173\u95ed"))
i=A.h1(q,!i,w,j,0,t,w,s)
t=k.at
if(t.length===0){t=k.fr
t=A.aE(A.a([k.ajN(t.length===0?"\u6211\u7684":t),B.aB,k.ajN("\u7cfb\u7edf")],l),B.i,B.j,B.l,0,j)
s=k.ay+"::"+k.ch
l=A.dg(new A.aQ(B.bC,A.aD(A.a([D.bgz,B.bE,t,B.P,k.QG("\u8c03\u8bd5\u53d1\u73b0 >> \u8f93\u5165\u53d1\u73b0URL\uff0c\u5982\uff1a",s,s),B.P,k.QG("\u8c03\u8bd5\u8be6\u60c5\u9875 >> \u8f93\u5165\u8be6\u60c5\u9875URL\uff0c\u5982\uff1a","http://xxx.com/book/xxx",""),B.P,k.QG("\u8c03\u8bd5\u76ee\u5f55\u9875 >> \u8f93\u5165\u76ee\u5f55\u9875URL\uff0c\u5982\uff1a","++http://xxx.com/xxx/xxx","++"),B.P,k.QG("\u8c03\u8bd5\u6b63\u6587\u9875 >> \u8f93\u5165\u6b63\u6587\u9875URL\uff0c\u5982\uff1a","--http://xxx.com/xxx/xxx","--")],l),B.ac,B.j,B.l),j),j,B.u,j,j,B.J)
t=l}else t=A.dg(new A.aQ(B.bC,A.Nm(t,j,E.a_c,j),j),j,B.u,j,j,B.J)
return A.eT(i,j,A.fz(!0,t,!0,B.C,!0,!0),j,j)},
ajN(d){var x,w,v,u=null,t=this.c
t.toString
x=A.A(t)
w=x?B.cn:A.af(15,B.h.n()>>>16&255,B.h.n()>>>8&255,B.h.n()&255)
v=x?B.d:B.H
t=A.aG(20)
return A.al(u,A.cY(u,A.V(d,u,u,B.aa,u,u,u,A.ag(u,u,v,u,u,u,u,u,u,u,u,14,u,u,u,u,u,!0,u,u,u,u,u,u,u,u),u,u,u),B.u,!1,u,u,u,u,u,u,u,u,u,u,u,u,u,u,u,u,u,u,u,u,u,u,new C.bC0(this,d),u,u,u,u,u,u,!1,B.ai),B.k,u,D.a3H,new A.aT(w,u,u,t,u,u,u,B.B),u,u,u,u,I.k6,u,u,u)},
QG(d,e,f){var x,w,v,u,t=null,s=this.c
s.toString
x=A.A(s)
w=x?B.cn:A.af(15,B.h.n()>>>16&255,B.h.n()>>>8&255,B.h.n()&255)
v=x?B.d:B.H
s=A.V(d,t,t,t,t,t,t,A.ag(t,t,v,t,t,t,t,t,t,t,t,t,t,t,t,t,t,!0,t,t,t,t,t,t,t,t),t,t,t)
u=A.aG(20)
return A.aD(A.a([s,A.al(t,A.cY(t,A.V(e,t,t,t,t,t,t,A.ag(t,t,v,t,t,t,t,t,t,t,t,14,t,t,t,t,t,!0,t,t,t,t,t,t,t,t),t,t,t),B.u,!1,t,t,t,t,t,t,t,t,t,t,t,t,t,t,t,t,t,t,t,t,t,t,new C.bC1(this,f),t,t,t,t,t,t,!1,B.ai),B.k,t,t,new A.aT(w,t,t,u,t,t,t,B.B),t,t,t,D.acs,B.iG,t,t,1/0)],y.p),B.ac,B.j,B.l)},
l(){var x=this.ax
x.R$=$.aw()
x.a1$=0
this.ij()},
IL(){var x=0,w=A.j(y.H),v=1,u=[],t=[],s=this,r,q,p,o
var $async$IL=A.e(function(d,e){if(d===1){u.push(e)
x=v}for(;;)switch(x){case 0:s.bL()
v=3
x=s.cx?6:7
break
case 6:x=8
return A.c(s.Rf(),$async$IL)
case 8:case 7:s.B(new C.bC8(s))
t.push(5)
x=4
break
case 3:v=2
o=u.pop()
r=A.C(o)
p=s.c
p.toString
A.bH(p,A.aP(r))
t.push(5)
x=4
break
case 2:t=[1]
case 4:v=1
s.ab()
x=t.pop()
break
case 5:return A.h(null,w)
case 1:return A.f(u.at(-1),w)}})
return A.i($async$IL,w)},
Rf(){var x=0,w=A.j(y.H),v=this,u
var $async$Rf=A.e(function(d,e){if(d===1)return A.f(e,w)
for(;;)switch(x){case 0:u=v.CW
u=u==null?null:u.gii().a3(0)
x=2
return A.c(y.c.b(u)?u:A.aF(u,y.z),$async$Rf)
case 2:v.CW=null
v.cx=!1
return A.h(null,w)}})
return A.i($async$Rf,w)},
zM(d){return this.b3C(d)},
b3C(d){var x=0,w=A.j(y.H),v,u=2,t=[],s=[],r=this,q,p,o,n,m,l
var $async$zM=A.e(function(e,f){if(e===1){t.push(f)
x=u}for(;;)switch(x){case 0:if(d.length===0){x=1
break}if(d==="++"||d==="--"){x=1
break}q=A.cdw("debug")
if(q==null){n=r.c
n.toString
A.bH(n,"\u83b7\u53d6ws\u94fe\u63a5\u5931\u8d25")
x=1
break}x=r.cx?3:4
break
case 3:r.bL()
u=5
x=8
return A.c(r.IL(),$async$zM)
case 8:s.push(7)
x=6
break
case 5:s=[2]
case 6:u=2
r.ab()
x=s.pop()
break
case 7:case 4:r.at=""
u=10
n=y.N
p=A.E(["url",r.a.c,"key",d],n,n)
r.cx=!0
n=A.cax(A.abv(A.cW(q,0,null),null))
r.CW=n
n=n.f.a
x=13
return A.c(y.x.b(n)?n:A.aF(n,y.H),$async$zM)
case 13:n=r.CW
if(n!=null)n.gii().a.u(0,B.n.e2(p))
A.K("WebSocket\u8fde\u63a5\u6210\u529f")
n=r.CW.r.b
n===$&&A.b()
n=n.b
n===$&&A.b()
new A.dl(n,A.z(n).i("dl<1>")).fJ(new C.bCd(r),new C.bCe(r),new C.bCf(r))
u=2
x=12
break
case 10:u=9
l=t.pop()
o=A.C(l)
A.K("WebSocket\u8fde\u63a5\u5931\u8d25: "+A.o(o))
n=r.c
n.toString
A.bH(n,"WebSocket\u8fde\u63a5\u5931\u8d25:"+A.aP(o))
r.cx=!1
x=12
break
case 9:x=2
break
case 12:case 1:return A.h(v,w)
case 2:return A.f(t.at(-1),w)}})
return A.i($async$zM,w)},
E4(d,e){return this.b7c(d,e)},
b7c(d,e){var x=0,w=A.j(y.H),v=this,u,t
var $async$E4=A.e(function(f,g){if(f===1)return A.f(g,w)
for(;;)switch(x){case 0:t=v.c
t.toString
t=A.a3(t,null,y.w).w.gcf().gdQ()
u=v.c
u.toString
A.dm(!0,new C.bCi(d,e,400*t),u,y.z)
return A.h(null,w)}})
return A.i($async$E4,w)}}
var z=a.updateTypes(["Q<~>(m)"])
C.bCj.prototype={
$1(d){this.a.b02()},
$S:7}
C.bC9.prototype={
$1(d){return A.ckX(d)},
$S:363}
C.bCa.prototype={
$0(){var x=this.a,w=this.b[this.c]
x.ay=w.a
x.ch=w.b},
$S:0}
C.bC4.prototype={
$0(){var x=this.a
x.ax.ik(0,B.eT)
x.IL()},
$S:0}
C.bC5.prototype={
$1(d){this.a.B(new C.bC3())},
$S:23}
C.bC3.prototype={
$0(){},
$S:0}
C.bC6.prototype={
$0(){var x,w,v,u,t=null,s=this.a,r=s.c
r.toString
x=A.A(r)?t:B.d
w=s.c
w.toString
v=y.w
w=A.a3(w,t,v).w
u=s.c
u.toString
v=A.a3(u,t,v).w
A.ys(B.k,x,t,r,t,t,A.a([D.b2M,D.b3d,D.b3a,D.b2O,E.XA,E.XI,D.b2U,D.b2P],y.g),t,t,new A.lW(w.a.a-100,56,v.a.a,156),t,t,t,t,t,t,!1,y.N).aE(new C.bC2(s),y.P)},
$S:0}
C.bC2.prototype={
$1(d){var x,w,v=this
if(d==="search"){x=v.a
x.E4("\u641c\u7d22\u6e90\u7801",x.cy)}else if(d==="book"){x=v.a
x.E4("\u4e66\u7c4d\u6e90\u7801",x.db)}else if(d==="toc"){x=v.a
x.E4("\u76ee\u5f55\u6e90\u7801",x.dx)}else if(d==="content"){x=v.a
x.E4("\u6b63\u6587\u6e90\u7801",x.dy)}else if(d==="cleancaches"){x=v.a
w=x.c
w.toString
x.xa(w)}else if(d==="clearcookie"){x=v.a
w=x.c
w.toString
x.uq(w)}else if(d==="log")v.a.z8()
else if(d==="explore")v.a.Jk("1")},
$S:134}
C.bC7.prototype={
$0(){var x=this.a.c
x.toString
A.am(x,!1).aX(null)
return null},
$S:0}
C.bC0.prototype={
$0(){var x=this.a,w=this.b
x.ax.sL(0,w)
x.zM(w)},
$S:0}
C.bC1.prototype={
$0(){var x=this.a,w=this.b
x.ax.sL(0,w)
x.zM(w)},
$S:0}
C.bC8.prototype={
$0(){var x=this.a
x.at=x.dy=x.dx=x.db=x.cy=""},
$S:0}
C.bCd.prototype={
$1(d){var x,w,v,u,t,s,r,q,p,o=this
try{x=B.n.e1(0,d,null)
if(J.P(J.w(x,"msg")).length!==0){w=A.o(J.w(x,"msg"))
if(J.dD(w,"\u641c\u7d22\u6e90\u7801Qwq")){v=J.pn(w,"\u641c\u7d22\u6e90\u7801Qwq")
o.a.cy=J.w(v,1)}else if(J.dD(w,"\u53d1\u73b0\u6e90\u7801Qwq")){u=J.pn(w,"\u53d1\u73b0\u6e90\u7801Qwq")
o.a.cy=J.w(u,1)}else if(J.dD(w,"\u4e66\u7c4d\u6e90\u7801Qwq")){t=J.pn(w,"\u4e66\u7c4d\u6e90\u7801Qwq")
o.a.db=J.w(t,1)}else if(J.dD(w,"\u76ee\u5f55\u6e90\u7801Qwq")){s=J.pn(w,"\u76ee\u5f55\u6e90\u7801Qwq")
o.a.dx=J.w(s,1)}else{q=o.a
if(J.dD(w,"\u6b63\u6587\u6e90\u7801Qwq")){r=J.pn(w,"\u6b63\u6587\u6e90\u7801Qwq")
q.dy=J.w(r,1)}else q.B(new C.bCb(q,x))}}}catch(p){q=o.a
q.B(new C.bCc(q,d))}},
$S:35}
C.bCb.prototype={
$0(){var x=this.a,w=x.at
w=w.length===0?"":w+"\n"
x.at=w+A.o(J.w(this.b,"msg"))},
$S:0}
C.bCc.prototype={
$0(){var x=this.a,w=x.at
w=w.length===0?"":w+"\n"
x.at=w+A.o(this.b)},
$S:0}
C.bCf.prototype={
$1(d){var x=this.a,w=x.c
w.toString
A.bH(w,"WebSocket\u8fde\u63a5\u9519\u8bef:"+A.aP(d))
x.cx=!1},
$S:20}
C.bCe.prototype={
$0(){this.a.cx=!1},
$S:0}
C.bCi.prototype={
$1(d){var x=null,w=A.A(d)?x:B.d,v=this.b,u=A.aE(A.a([A.V(this.a,x,x,x,x,x,x,F.a_e,x,x,x),B.en,A.bt(x,x,x,B.wp,x,x,new C.bCg(v,d),x,x,x,"\u590d\u5236"),A.bt(x,x,x,B.fb,x,x,new C.bCh(d),x,x,x,"\u5173\u95ed")],y.p),B.i,B.j,B.l,0,x),t=y.w,s=this.c
t=A.a3(d,x,t).w.a.a*0.9>s?s:A.a3(d,x,t).w.a.a*0.9
return A.eB(x,w,A.al(x,A.dg(A.Nm(v,x,B.he,x),x,B.u,x,x,B.J),B.k,x,new A.ay(0,t,0,300),x,x,x,x,x,x,x,x,17976931348623157e292),B.fQ,x,u)},
$S:21}
C.bCg.prototype={
$0(){A.oc(new A.mk(this.a))
A.cp(this.b,"\u5df2\u590d\u5236\u5230\u526a\u8d34\u677f",B.a2)},
$S:0}
C.bCh.prototype={
$0(){A.am(this.a,!1).aX(null)
return null},
$S:0};(function installTearOffs(){var x=a._instance_1u
x(C.a36.prototype,"gb3B","zM",0)})();(function inheritance(){var x=a.inherit,w=a.inheritMany
x(C.TS,A.a9)
x(C.a36,A.tB)
w(A.im,[C.bCj,C.bC9,C.bC5,C.bC2,C.bCd,C.bCf,C.bCi])
w(A.ke,[C.bCa,C.bC4,C.bC3,C.bC6,C.bC7,C.bC0,C.bC1,C.bC8,C.bCb,C.bCc,C.bCe,C.bCg,C.bCh])})()
A.m5(b.typeUniverse,JSON.parse('{"TS":{"a9":[],"r":[]},"a36":{"ac":["TS"]}}'))
var y=(function rtii(){var x=A.a5
return{v:x("re"),c:x("Q<@>"),x:x("Q<~>"),g:x("G<ci<m>>"),p:x("G<r>"),w:x("ja"),P:x("b9"),_:x("ci<m>"),N:x("m"),z:x("@"),H:x("~")}})();(function constants(){var x=a.makeConstList
D.a3H=new A.ay(0,200,0,1/0)
D.acs=new A.aC(0,8,0,16)
D.bg_=new A.au("\u641c\u7d22\u6e90\u7801",null,null,null,null,null,null,null,null,null,null,null,null,null,null,null)
D.apU=x([D.bg_],y.p)
D.b5V=new A.hr(B.al,B.j,B.l,B.i,null,B.bp,null,0,D.apU,null)
D.b2M=new A.ci("search",null,!0,D.b5V,null,y._)
D.bfG=new A.au("\u76ee\u5f55\u6e90\u7801",null,null,null,null,null,null,null,null,null,null,null,null,null,null,null)
D.ats=x([D.bfG],y.p)
D.b63=new A.hr(B.al,B.j,B.l,B.i,null,B.bp,null,0,D.ats,null)
D.b2O=new A.ci("toc",null,!0,D.b63,null,y._)
D.ak4=x([B.a_v],y.p)
D.b61=new A.hr(B.al,B.j,B.l,B.i,null,B.bp,null,0,D.ak4,null)
D.b2P=new A.ci("clearcookie",null,!0,D.b61,null,y._)
D.apj=x([B.a_x],y.p)
D.b6_=new A.hr(B.al,B.j,B.l,B.i,null,B.bp,null,0,D.apj,null)
D.b2U=new A.ci("cleancaches",null,!0,D.b6_,null,y._)
D.bgY=new A.au("\u5237\u65b0\u53d1\u73b0",null,null,null,null,null,null,null,null,null,null,null,null,null,null,null)
D.amo=x([D.bgY],y.p)
D.b65=new A.hr(B.al,B.j,B.l,B.i,null,B.bp,null,0,D.amo,null)
D.b3a=new A.ci("explore",null,!0,D.b65,null,y._)
D.bha=new A.au("\u4e66\u7c4d\u6e90\u7801",null,null,null,null,null,null,null,null,null,null,null,null,null,null,null)
D.att=x([D.bha],y.p)
D.b5X=new A.hr(B.al,B.j,B.l,B.i,null,B.bp,null,0,D.att,null)
D.b3d=new A.ci("book",null,!0,D.b5X,null,y._)
D.bgz=new A.au("\u8c03\u8bd5\u641c\u7d22 >> \u8f93\u5165\u5173\u952e\u5b57\uff0c\u5982\uff1a",null,null,null,null,null,null,null,null,null,null,null,null,null,null,null)})()};
(a=>{a["cylRozksvx779qLITXMfZAb76Bo="]=a.current})($__dart_deferred_initializers__);