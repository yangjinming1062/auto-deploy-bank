((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var J,A,B,E,C={
ckJ(d,e){return new C.UD(e,d,null)},
UD:function UD(d,e,f){this.c=d
this.d=e
this.a=f},
a3p:function a3p(d,e,f,g,h,i,j,k){var _=this
_.x=d
_.y=e
_.z=f
_.Q=g
_.as=h
_.at=i
_.ax=j
_.ay=k
_.d=null
_.e=!1
_.c=_.a=null},
bEW:function bEW(d){this.a=d},
bEX:function bEX(){},
bEY:function bEY(d){this.a=d},
bq2(d){var x=0,w=A.j(y.g),v,u,t,s,r
var $async$bq2=A.e(function(e,f){if(e===1)return A.f(f,w)
for(;;)switch(x){case 0:s=B.n
r=B.r
x=3
return A.c(A.f9(A.ba("/addtts"),d),$async$bq2)
case 3:u=s.P(0,r.P(0,f))
t=J.N(u)
if(t.h(u,"isSuccess")){v=A.o(t.h(u,"errorMsg"))
x=1
break}else throw A.k(A.aA(A.bs(t.h(u,"errorMsg"))))
case 1:return A.h(v,w)}})
return A.i($async$bq2,w)}},D
J=c[1]
A=c[0]
B=c[2]
E=c[38]
C=a.updateHolder(c[15],C)
D=c[39]
C.UD.prototype={
a6(){var x=$.aw()
return new C.a3p(new A.c4(B.ag,x),new A.c4(B.ag,x),new A.c4(B.ag,x),new A.c4(B.ag,x),new A.c4(B.ag,x),new A.c4(B.ag,x),new A.c4(B.ag,x),new A.c4(B.ag,x))}}
C.a3p.prototype={
a8(){var x,w=this
w.aJ()
x=w.a.c
if(x!=null){w.x.sL(0,x.b)
w.y.sL(0,w.a.c.c)
w.z.sL(0,w.a.c.d)
w.Q.sL(0,w.a.c.e)
w.as.sL(0,w.a.c.f)
w.at.sL(0,w.a.c.r)
w.ax.sL(0,w.a.c.y)
w.ay.sL(0,w.a.c.w)}},
mM(d){return this.bz0(d)},
bz0(d){var x=0,w=A.j(y.f),v=this,u,t,s,r
var $async$mM=A.e(function(e,f){if(e===1)return A.f(f,w)
for(;;)switch(x){case 0:try{u=A.ahl(B.n.e1(0,d,null))
v.x.sL(0,u.b)
v.y.sL(0,u.c)
v.z.sL(0,u.d)
v.Q.sL(0,u.e)
v.as.sL(0,u.f)
v.at.sL(0,u.r)
v.ax.sL(0,u.y)
v.ay.sL(0,u.w)}catch(q){t=A.C(q)
r=v.c
r.toString
A.bH(r,A.aP(t))}return A.h(null,w)}})
return A.i($async$mM,w)},
l(){var x=this,w=x.x,v=w.R$=$.aw()
w.a1$=0
w=x.y
w.R$=v
w.a1$=0
w=x.z
w.R$=v
w.a1$=0
w=x.Q
w.R$=v
w.a1$=0
w=x.as
w.R$=v
w.a1$=0
w=x.at
w.R$=v
w.a1$=0
w=x.ax
w.R$=v
w.a1$=0
w=x.ay
w.R$=v
w.a1$=0
x.ij()},
we(d,e){var x,w=null,v=this.c
v.toString
x=A.V(d,w,w,w,w,w,w,A.ag(w,w,A.A(v)?B.ax:B.au,w,w,w,w,w,w,w,w,14,w,w,w,w,w,!0,w,w,w,w,w,w,w,w),w,w,w)
v=B.c.q(d,"\u6beb\u79d2")?B.ie:B.t8
return A.aD(A.a([x,A.dH(w,B.a_,!1,w,!0,B.z,w,A.di(),e,w,w,w,w,w,2,A.eR(w,w,w,B.f9,w,w,w,w,!0,w,w,w,w,w,w,w,w,w,w,w,w,w,w,w,w,w,w,w,w,w,w,"\u8bf7\u8f93\u5165"+d,w,w,w,w,w,w,w,w,w,!0,!0,w,w,w,w,w,w,w,w,w,w,w,w,w,w),B.u,!0,w,!0,w,!1,w,B.at,w,w,w,w,v,w,w,w,w,1,w,!1,"\u2022",w,w,w,w,w,!1,w,w,!1,w,!0,w,B.aq,w,w,w,w,w,w,w,w,w,w,w,B.ep,!0,B.Q,w,B.az,w,w,w,w)],y.e),B.ac,B.j,B.l)},
J(d){var x=this,w=null,v=A.A(d),u=v?w:B.aw,t=v?w:B.aw,s=x.a.d,r=s?w:A.bt(w,w,w,B.cq,w,w,new C.bEW(d),w,w,w,"\u8fd4\u56de"),q=A.bt(w,w,w,E.Hi,w,w,x.gbdI(),w,w,w,"\u4fdd\u5b58"),p=A.A(d)?w:B.d,o=y.e
p=A.a([q,A.kp(p,w,w,B.eF,w,new C.bEX(),x.gaYz(),B.C,w,w,"\u66f4\u591a",y.g)],o)
if(x.a.d)p.push(A.bt(w,w,w,A.aM(B.b0,A.A(d)?B.ax:B.au,w,w,w),w,w,new C.bEY(d),w,w,w,"\u5173\u95ed"))
return A.eT(A.h1(p,!s,t,w,w,r,u,D.bf4),w,A.dg(A.aD(A.a([x.we("\u540d\u79f0",x.x),B.P,x.we("url",x.y),B.P,x.we("Content-Type",x.z),B.P,x.we("\u5e76\u53d1\u7387(concurrentRate)",x.Q),B.P,x.we("\u767b\u5f55Url(loginUrl)",x.as),B.P,x.we("\u767b\u5f55UI(loginUi)",x.at),B.P,x.we("\u767b\u5f55\u68c0\u6d4bjs(loginCheckJs)",x.ax),B.P,x.we("\u8bf7\u6c42\u5934(header)",x.ay)],o),B.ac,B.j,B.l),w,B.u,B.bC,w,B.J),w,w)},
TN(){var x=0,w=A.j(y.f),v,u=2,t=[],s=this,r,q,p,o,n,m,l,k,j,i,h,g
var $async$TN=A.e(function(d,e){if(d===1){t.push(e)
x=u}for(;;)switch(x){case 0:h=s.x.a.a
if(h.length===0){h=s.c
h.toString
A.aq(h,"\u8bf7\u8f93\u5165\u540d\u79f0",!0)
x=1
break}p=s.y.a.a
if(p.length===0){h=s.c
h.toString
A.aq(h,"\u8bf7\u8f93\u5165url",!0)
x=1
break}o=s.a.c
o=o==null?null:o.a
if(o==null)o=""
n=s.z.a.a
m=s.Q.a.a
l=s.as.a.a
k=s.at.a.a
j=s.ax.a.a
r=new A.iG(o,h,p,n,m,l,k,s.ay.a.a,!1,j)
u=4
s.bL()
x=7
return A.c(C.bq2(B.n.de(r,null)),$async$TN)
case 7:s.ab()
h=s.c
h.toString
A.aq(h,"\u4fdd\u5b58\u6210\u529f",!1)
h=s.c
h.toString
A.am(h,!1).aX(r)
u=2
x=6
break
case 4:u=3
g=t.pop()
q=A.C(g)
s.ab()
h=s.c
h.toString
A.aq(h,"\u4fdd\u5b58\u5931\u8d25\uff1a"+A.aP(q),!0)
x=6
break
case 3:x=2
break
case 6:case 1:return A.h(v,w)
case 2:return A.f(t.at(-1),w)}})
return A.i($async$TN,w)},
DJ(d){return this.b9a(d)},
b9a(d){var x=0,w=A.j(y.f),v=1,u=[],t=this,s,r,q,p,o,n,m,l,k,j,i,h
var $async$DJ=A.e(function(e,f){if(e===1){u.push(f)
x=v}for(;;)switch(x){case 0:case 2:switch(d){case"copy":x=4
break
case"paste":x=5
break
default:x=3
break}break
case 4:q=t.a.c
q=q==null?null:q.a
if(q==null)q=""
p=t.x.a.a
o=t.y.a.a
n=t.z.a.a
m=t.Q.a.a
l=t.as.a.a
k=t.at.a.a
j=t.ax.a.a
x=6
return A.c(A.oc(new A.mk(B.n.de(new A.iG(q,p,o,n,m,l,k,t.ay.a.a,!1,j).Ow(),null))),$async$DJ)
case 6:j=t.c
j.toString
A.cp(j,"\u5f15\u64ce\u5df2\u590d\u5236",B.a2)
x=3
break
case 5:x=7
return A.c(A.E0("text/plain"),$async$DJ)
case 7:s=f
q=s
x=(q==null?null:q.a)!=null?8:10
break
case 8:v=12
x=15
return A.c(t.mM(s.a),$async$DJ)
case 15:v=1
x=14
break
case 12:v=11
h=u.pop()
r=A.C(h)
q=t.c
q.toString
A.aq(q,"\u7c98\u8d34\u5931\u8d25:"+A.aP(r)+"!",!0)
x=14
break
case 11:x=1
break
case 14:x=9
break
case 10:q=t.c
q.toString
A.aq(q,"\u526a\u8d34\u677f\u4e3a\u7a7a!",!0)
case 9:x=3
break
case 3:return A.h(null,w)
case 1:return A.f(u.at(-1),w)}})
return A.i($async$DJ,w)}}
var z=a.updateTypes(["Q<~>()","Q<~>(m)"])
C.bEW.prototype={
$0(){return A.am(this.a,!1).bX()},
$S:0}
C.bEX.prototype={
$1(d){return A.a([D.b3o,D.b2X],y.b)},
$S:41}
C.bEY.prototype={
$0(){A.am(this.a,!1).aX(null)
return null},
$S:0};(function installTearOffs(){var x=a._instance_0u,w=a._instance_1u
var v
x(v=C.a3p.prototype,"gbdI","TN",0)
w(v,"gaYz","DJ",1)})();(function inheritance(){var x=a.inherit,w=a.inheritMany
x(C.UD,A.a9)
x(C.a3p,A.vO)
w(A.ke,[C.bEW,C.bEY])
x(C.bEX,A.im)})()
A.m5(b.typeUniverse,JSON.parse('{"UD":{"a9":[],"r":[]},"a3p":{"ac":["UD"]}}'))
var y={b:A.a5("G<jA<m>>"),e:A.a5("G<r>"),j:A.a5("ci<m>"),g:A.a5("m"),f:A.a5("~")};(function constants(){D.bgN=new A.au("\u7c98\u8d34\u5f15\u64ce",null,null,null,null,null,null,null,null,null,null,null,null,null,null,null)
D.b2X=new A.ci("paste",null,!0,D.bgN,null,y.j)
D.bgH=new A.au("\u62f7\u8d1d\u5f15\u64ce",null,null,null,null,null,null,null,null,null,null,null,null,null,null,null)
D.b3o=new A.ci("copy",null,!0,D.bgH,null,y.j)
D.bf4=new A.au("\u6717\u8bfb\u5f15\u64ce\u7f16\u8f91",null,null,null,null,null,null,null,null,null,null,null,null,null,null,null)})()};
(a=>{a["ayZoo1vTQF6+1SpXsyD4zVSINOc="]=a.current})($__dart_deferred_initializers__);