((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,C,B={BR:function BR(){},
cJ8(d){return new B.VK(d,null)},
VK:function VK(d,e){this.c=d
this.a=e},
a3Y:function a3Y(d,e){var _=this
_.d=d
_.e=!0
_.f=""
_.r=0
_.dc$=e
_.c=_.a=null},
bHZ:function bHZ(d){this.a=d},
bHX:function bHX(d,e){this.a=d
this.b=e},
bHY:function bHY(d){this.a=d},
bHV:function bHV(d){this.a=d},
bHW:function bHW(d){this.a=d},
a8m:function a8m(){},
aIJ:function aIJ(){},
aIK:function aIK(){}},D
A=c[0]
C=c[2]
B=a.updateHolder(c[5],B)
D=c[30]
B.BR.prototype={}
B.VK.prototype={
a6(){return new B.a3Y(A.a([],y.k),null)}}
B.a3Y.prototype={
a8(){var x,w=this
w.aPA()
x=$.aR
x=x==null?null:x.c9(0,"bookimages")
if(x==null)x=""
w.f=x
if(x.length===0)w.f="assets/images/no_cover.jpeg"
$.ap.cS$.push(w)
w.E3()},
l(){$.ap.kd(this)
$.cah().bD5(0,this)
this.aT()},
cA(){var x,w
this.el()
x=$.cah()
w=this.c
w.toString
w=A.Bc(w,null,y.q)
w.toString
x.aKO(0,this,w)},
bpN(){A.b8(C.hs,new B.bHZ(this),y.F)},
qg(d){if(d===C.di)this.E3()},
E3(){var x=0,w=A.j(y.v),v=1,u=[],t=this,s,r,q,p,o
var $async$E3=A.e(function(d,e){if(d===1){u.push(e)
x=v}for(;;)switch(x){case 0:A.K("\u52a0\u8f7d\u5386\u53f2\u8bb0\u5f55")
v=3
x=6
return A.c(A.a0c(),$async$E3)
case 6:s=e
if(t.c!=null)t.B(new B.bHX(t,s))
v=1
x=5
break
case 3:v=2
o=u.pop()
r=A.C(o)
if(t.c!=null){t.B(new B.bHY(t))
p=t.c
p.toString
A.aq(p,"\u52a0\u8f7d\u5386\u53f2\u8bb0\u5f55\u5931\u8d25: "+A.aP(r),!0)}x=5
break
case 2:x=1
break
case 5:return A.h(null,w)
case 1:return A.f(u.at(-1),w)}})
return A.i($async$E3,w)},
amI(){var x,w,v,u,t,s,r=this,q=null,p=r.c
p.toString
p=A.A(p)?C.h:C.bA
x=r.c
x.toString
x=A.A(x)?q:C.aw
w=r.c
w.toString
w=A.A(w)?q:C.aw
v=r.a.c
u=r.c
u.toString
t=y.u
s=A.a([A.bt(q,C.cm,q,A.aM(D.aez,A.A(u)?C.d:C.h,q,q,q),q,q,r.gaVy(r),q,q,q,"\u6e05\u7406\u5386\u53f2\u8bb0\u5f55")],t)
if(r.a.c){u=r.c
u.toString
s.push(A.bt(q,q,q,A.aM(C.b0,A.A(u)?C.ax:C.au,q,q,q),q,q,new B.bHV(r),q,q,q,"\u5173\u95ed"))}x=A.h1(s,!v,w,!0,q,q,x,D.bhp)
w=r.c
w.toString
w=A.A(w)?C.h:C.d
if(r.e)v=C.nH
else if(r.d.length===0){v=r.c
v.toString
u=A.aM(D.aeM,A.A(v)?C.d:C.b2,q,q,64)
v=r.c
v.toString
u=A.dd(A.aD(A.a([u,C.P,A.V("\u6682\u65e0\u6d4f\u89c8\u5386\u53f2",q,q,q,q,q,q,A.ag(q,q,A.A(v)?C.d:C.aj,q,q,q,q,q,q,q,q,16,q,q,q,q,q,!0,q,q,q,q,q,q,q,q),q,q,q)],t),C.i,C.bl,C.l),q,q)
v=u}else v=A.ou(new B.bHW(r))
return A.eT(x,p,A.al(q,v,C.k,w,q,q,q,q,q,q,q,q,q,q),q,q)},
b5b(){var x,w,v,u,t,s=this,r=null
if(s.a.c){x=s.c
x.toString
w=y.x
x=A.a3(x,r,w).w.r.b
v=x===0
if(!v)s.r=x
x=s.c
x.toString
x=A.a3(x,r,w).w
u=v?s.r:0
t=s.c
t.toString
w=A.a3(t,r,w).w
v=v?s.r:0
t=s.c
t.toString
t=A.A(t)?r:C.aw
return A.aD(A.a([A.rS(A.al(r,r,C.k,t,r,r,r,v,r,r,r,r,r,w.a.a),new A.S(x.a.a,u)),A.bx(s.amI(),1)],y.u),C.i,C.j,C.l)}return s.amI()},
IA(d){var x=0,w=A.j(y.v),v=this,u
var $async$IA=A.e(function(e,f){if(e===1)return A.f(f,w)
for(;;)switch(x){case 0:u=v.c
u.toString
x=4
return A.c(A.d6(u,"\u64cd\u4f5c\u786e\u8ba4","\u662f\u5426\u8981\u6e05\u9664\u5386\u53f2\u8bb0\u5f55\uff1f"),$async$IA)
case 4:x=f?2:3
break
case 2:C.b.N(v.d)
x=5
return A.c(A.arU(A.a([],y.k)),$async$IA)
case 5:case 3:return A.h(null,w)}})
return A.i($async$IA,w)},
J(d){this.lK(d)
return this.b5b()},
gjR(){return!0}}
B.a8m.prototype={
a8(){this.aJ()
this.kl()},
eS(){var x=this.dc$
if(x!=null){x.ao()
x.e6()
this.dc$=null}this.iV()}}
B.aIJ.prototype={}
B.aIK.prototype={}
var z=a.updateTypes(["Q<~>()"])
B.bHZ.prototype={
$0(){var x=0,w=A.j(y.F),v=this
var $async$$0=A.e(function(d,e){if(d===1)return A.f(e,w)
for(;;)switch(x){case 0:v.a.E3()
return A.h(null,w)}})
return A.i($async$$0,w)},
$S:10}
B.bHX.prototype={
$0(){var x=this.a,w=x.d
C.b.N(w)
C.b.F(w,this.b)
x.e=!1},
$S:0}
B.bHY.prototype={
$0(){this.a.e=!1},
$S:0}
B.bHV.prototype={
$0(){var x=this.a.c
x.toString
A.am(x,!1).aX(null)
return null},
$S:0}
B.bHW.prototype={
$2(d,e){var x=null,w=this.a,v=w.a.c
return A.DH(x,w.d,w.f,x,!0,!1,v,!1,!1,!0,!0,x,"history_list",x,x,x,x,x)},
$S:182};(function aliases(){var x=B.a8m.prototype
x.aPA=x.a8})();(function installTearOffs(){var x=a._instance_0i
x(B.a3Y.prototype,"gaVy","IA",0)})();(function inheritance(){var x=a.mixinHard,w=a.mixin,v=a.inherit,u=a.inheritMany
v(B.BR,A.F)
v(B.VK,A.a9)
v(B.a8m,A.ac)
v(B.aIJ,B.a8m)
v(B.aIK,B.aIJ)
v(B.a3Y,B.aIK)
u(A.ke,[B.bHZ,B.bHX,B.bHY,B.bHV])
v(B.bHW,A.od)
x(B.a8m,A.j_)
w(B.aIJ,A.em)
w(B.aIK,B.BR)})()
A.m5(b.typeUniverse,JSON.parse('{"VK":{"a9":[],"r":[]},"a3Y":{"ac":["VK"],"em":[],"BR":[]}}'))
var y={k:A.a5("G<fs>"),u:A.a5("G<r>"),x:A.a5("ja"),F:A.a5("b9"),q:A.a5("F?"),v:A.a5("~")};(function constants(){D.aez=new A.bu(57703,"MaterialIcons",!1)
D.aeM=new A.bu(58132,"MaterialIcons",!1)
D.bhp=new A.au("\u6d4f\u89c8\u5386\u53f2",null,null,null,null,null,null,null,null,null,null,null,null,null,null,null)})()};
(a=>{a["Gl0ujJNvLVRY/xq/bep4dRCZQd0="]=a.current})($__dart_deferred_initializers__);