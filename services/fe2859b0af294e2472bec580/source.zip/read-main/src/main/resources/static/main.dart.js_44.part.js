((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,B
A=c[0]
B=c[44]
var z=a.updateTypes([]);(function constants(){B.wj=new A.bu(59069,"MaterialIcons",!1)
B.wk=new A.bu(59070,"MaterialIcons",!1)})()};
(a=>{a["FZs5Cy/XW4F41oYifx2Nlcp03q4="]=a.current})($__dart_deferred_initializers__);