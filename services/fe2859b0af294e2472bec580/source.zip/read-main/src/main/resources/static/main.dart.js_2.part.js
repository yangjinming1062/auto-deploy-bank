((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var J,A,C,B={
co5(d){var x,w=J.hP(d,y.e)
for(x=0;x<d;++x)w[x]=$.czG().y_(256)
return new B.biw(new Uint8Array(A.eo(w)))},
biw:function biw(d){this.a=d},
aqy(){var x=0,w=A.j(y.s),v,u=2,t=[],s,r,q,p,o,n
var $async$aqy=A.e(function(d,e){if(d===1){t.push(e)
x=u}for(;;)switch(x){case 0:x=$.blk==null?3:4
break
case 3:s=new A.b4(new A.aj($.ar,y.p),y.u)
$.blk=s
u=6
x=9
return A.c(B.bll(),$async$aqy)
case 9:r=e
J.cCQ(s,new B.NE(r))
u=2
x=8
break
case 6:u=5
n=t.pop()
q=A.C(n)
s.iJ(q)
p=s.a
$.blk=null
v=p
x=1
break
x=8
break
case 5:x=2
break
case 8:case 4:v=$.blk.a
x=1
break
case 1:return A.h(v,w)
case 2:return A.f(t.at(-1),w)}})
return A.i($async$aqy,w)},
bll(){var x=0,w=A.j(y.x),v,u,t,s,r,q,p,o
var $async$bll=A.e(function(d,e){if(d===1)return A.f(e,w)
for(;;)switch(x){case 0:s=y.w
r=y.E
q=A.B(s,r)
p=J
o=q
x=3
return A.c($.c9X().yB(0),$async$bll)
case 3:p.f2(o,e)
u=A.B(s,r)
for(s=q,s=new A.hz(s,s.r,s.e);s.t();){r=s.d
t=C.c.bP(r,8)
r=J.w(q,r)
r.toString
u.p(0,t,r)}v=u
x=1
break
case 1:return A.h(v,w)}})
return A.i($async$bll,w)},
NE:function NE(d){this.a=d},
O_(d){var x=0,w=A.j(y.v),v,u,t,s,r
var $async$O_=A.e(function(e,f){if(e===1)return A.f(f,w)
for(;;)switch(x){case 0:r=$.aR
x=r==null?2:3
break
case 2:x=4
return A.c(B.aqy(),$async$O_)
case 4:r=f
case 3:if(d){v=r.a
u=J.N(v)
t=A.bN(u.h(v,"encrypt_key"))
s=A.bN(u.h(v,"encrypt_iv"))}else{t=null
s=null}v=t==null||s==null
x=v?5:7
break
case 5:v=B.co5(32).a
u=B.co5(16).a
x=8
return A.c(r.KQ("String","encrypt_key",C.f_.gj2().bb(v)),$async$O_)
case 8:x=9
return A.c(r.KQ("String","encrypt_iv",C.f_.gj2().bb(u)),$async$O_)
case 9:$.cdt.b=new A.aiJ(v)
$.bmP.b=new A.ahE(u)
x=6
break
case 7:$.cdt.b=new A.aiJ(C.f0.bb(t))
$.bmP.b=new A.ahE(C.f0.bb(s))
case 6:$.cds.b=new A.aXV(A.cDj($.cdt.a_(),C.Dk,"PKCS7"))
return A.h(null,w)}})
return A.i($async$O_,w)}}
J=c[1]
A=c[0]
C=c[2]
B=a.updateHolder(c[24],B)
B.biw.prototype={
gD(d){return this.a.length}}
B.NE.prototype={
aGo(){return A.kN(J.vD(this.a),y.w)},
c9(d,e){return A.bN(J.w(this.a,e))},
aD(d,e){return J.qQ(this.a,e)},
bS(d,e){return this.KQ("String",d,e)},
G(d,e){J.ik(this.a,e)
return $.c9X().G(0,"flutter."+e)},
KQ(d,e,f){A.js(f,"value")
J.fa(this.a,e,f)
return $.c9X().z3(d,"flutter."+e,f)}}
var z=a.updateTypes([]);(function inheritance(){var x=a.inheritMany
x(A.F,[B.biw,B.NE])})()
var y={x:A.a5("u<m,F>"),E:A.a5("F"),s:A.a5("NE"),w:A.a5("m"),u:A.a5("b4<NE>"),p:A.a5("aj<NE>"),e:A.a5("n"),v:A.a5("~")};(function staticFields(){$.cdt=A.bz()
$.bmP=A.bz()
$.cds=A.bz()
$.blk=null})();(function lazyInitializers(){var x=a.lazyFinal
x($,"d8a","czG",()=>A.cnw())})()};
(a=>{a["0XkdXMR3XdDRmmk4yAr8xcY+DFQ="]=a.current})($__dart_deferred_initializers__);