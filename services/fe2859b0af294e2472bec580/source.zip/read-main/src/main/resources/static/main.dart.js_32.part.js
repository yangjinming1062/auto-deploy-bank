((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,B
A=c[0]
B=c[33]
var z=a.updateTypes([]);(function constants(){B.wl=new A.bu(62260,"MaterialIcons",!1)})()};
(a=>{a["3/1CkQg9UtE2vqrpTleYSuc23I8="]=a.current})($__dart_deferred_initializers__);