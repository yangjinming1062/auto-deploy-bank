((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,B,C
A=c[0]
B=c[2]
C=c[37]
var z=a.updateTypes([]);(function constants(){C.uQ=new A.Z(1,0.9411764705882353,0.9411764705882353,0.9411764705882353,B.p)})()};
(a=>{a["lefbw89xOTwAdgVioeMvr/ZeY5c="]=a.current})($__dart_deferred_initializers__);