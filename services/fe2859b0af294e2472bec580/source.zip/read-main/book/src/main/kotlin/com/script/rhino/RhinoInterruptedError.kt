package com.script.rhino

class RhinoInterruptError(override val cause: Throwable) : Error()
