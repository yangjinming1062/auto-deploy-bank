package book.model

class Header {
    var headers: Map<String, String> = emptyMap()
}