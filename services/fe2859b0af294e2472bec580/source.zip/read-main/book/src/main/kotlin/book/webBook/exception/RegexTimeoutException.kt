package book.webBook.exception

class RegexTimeoutException(msg: String) : NoStackTraceException(msg)