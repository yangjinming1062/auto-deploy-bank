@file:Suppress("unused")
package book.util


fun Throwable.printOnDebug() {
    printStackTrace()
}
