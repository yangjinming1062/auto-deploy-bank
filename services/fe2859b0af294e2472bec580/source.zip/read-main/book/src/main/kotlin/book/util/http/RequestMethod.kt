package book.util.http

enum class RequestMethod {
    GET, POST
}