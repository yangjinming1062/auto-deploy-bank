package com.script

import org.mozilla.javascript.ContextFactory

open class RhinoContextFactory : ContextFactory() {

}