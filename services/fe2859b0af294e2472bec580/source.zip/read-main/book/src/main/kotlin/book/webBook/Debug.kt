package book.webBook

import org.slf4j.Logger
import org.slf4j.LoggerFactory

private val logger: Logger = LoggerFactory.getLogger(Debug::class.java)

object Debug : DebugLog{
}