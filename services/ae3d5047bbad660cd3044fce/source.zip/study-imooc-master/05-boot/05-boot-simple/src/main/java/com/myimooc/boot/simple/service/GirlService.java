package com.myimooc.boot.simple.service;

/**
 * 服务
 *
 * @author zc 2017-02-18
 */
public interface GirlService {

    /**
     * 保存两个女生信息
     */
    void saveTwo();
}
