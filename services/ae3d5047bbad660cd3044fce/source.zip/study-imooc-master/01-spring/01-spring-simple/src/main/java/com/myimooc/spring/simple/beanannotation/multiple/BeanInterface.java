package com.myimooc.spring.simple.beanannotation.multiple;

/**
 * 接口
 *
 * @author zc 2017-01-18
 */
public interface BeanInterface {

}
