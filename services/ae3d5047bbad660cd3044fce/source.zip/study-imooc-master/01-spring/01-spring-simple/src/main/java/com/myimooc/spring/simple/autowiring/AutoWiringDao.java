package com.myimooc.spring.simple.autowiring;

/**
 * DAO
 *
 * @author zc 2017-01-18
 */
public class AutoWiringDao {

    public void say(String word) {
        System.out.println("AutoWiringDao : " + word);
    }

}
