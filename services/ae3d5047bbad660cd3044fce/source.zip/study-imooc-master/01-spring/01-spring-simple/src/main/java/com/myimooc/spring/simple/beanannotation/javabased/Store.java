package com.myimooc.spring.simple.beanannotation.javabased;

/**
 * 仓库接口
 *
 * @author zc 2017-01-18
 */
public interface Store<T> {

}
