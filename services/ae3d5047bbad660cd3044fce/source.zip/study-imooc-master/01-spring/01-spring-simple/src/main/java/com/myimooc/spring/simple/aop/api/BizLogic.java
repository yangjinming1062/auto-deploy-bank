package com.myimooc.spring.simple.aop.api;

/**
 * 业务逻辑接口
 *
 * @author zc 2017-01-18
 */
public interface BizLogic {

    /**
     * 保存
     *
     * @return 结果
     */
    String save();

}
