package com.myimooc.spring.simple.aop.schema.advice;

/**
 * 接口
 *
 * @author zc 2017-01-18
 */
public interface Fit {

    /**
     * 过滤
     */
    void filter();

}
