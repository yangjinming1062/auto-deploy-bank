package com.myimooc.spring.simple.beanannotation.javabased;

/**
 * 整型仓库
 *
 * @author zc 2017-01-18
 */
public class IntegerStore implements Store<Integer> {

}
