package com.myimooc.spring.simple.ioc.injection.service;

/**
 * 服务接口
 *
 * @author zc 2017-01-18
 */
public interface InjectionService {

    /**
     * 保存
     *
     * @param arg 参数
     */
    void save(String arg);

}
