package com.myimooc.sso.same.father;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * 启动类
 *
 * @author zc 2017-04-02
 */
@SpringBootApplication
public class SameFatherApplication {

    public static void main(String[] args) {
        SpringApplication.run(SameFatherApplication.class, args);
    }
}
