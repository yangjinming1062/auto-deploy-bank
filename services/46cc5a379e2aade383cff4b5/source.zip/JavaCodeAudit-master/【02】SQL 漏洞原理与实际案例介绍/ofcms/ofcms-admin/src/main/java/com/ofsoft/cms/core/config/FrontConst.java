package com.ofsoft.cms.core.config;

public final class FrontConst {


	/** 站点存放到session中 **/
	public static final String  VERSION= "OFCMS";
	public static final String  TEMPLATE_PATE= "/";
	public static final String SITE_SESSION = "site";
    public static final String DIRECTIVE_PREFIX = "of";
	/**  错误页面404 */
	public static String pageError = "/404.html";
}
