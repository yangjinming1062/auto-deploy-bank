"""
Allow running as a module: python -m compare_workflows
"""

from compare_workflows import main

if __name__ == "__main__":
    main()
