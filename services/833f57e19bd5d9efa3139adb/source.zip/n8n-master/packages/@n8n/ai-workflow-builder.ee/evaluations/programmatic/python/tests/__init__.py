"""Tests for n8n workflow comparison"""
