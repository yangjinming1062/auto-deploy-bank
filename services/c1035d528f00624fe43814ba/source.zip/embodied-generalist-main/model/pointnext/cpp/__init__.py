"""
Author: PointNeXt

"""

from .pointnet2_batch import pointnet2_cuda