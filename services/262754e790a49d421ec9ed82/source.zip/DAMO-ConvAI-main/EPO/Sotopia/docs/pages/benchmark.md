# Benchmark your model as a social agent in Sotopia

```
sotopia_benchmark --model=<your_model_name>
```
or

```
python sotopia/benchmark/cli.py --model=<your_model_name>
```
Currently this script would run over 100 simulations on the Sotopia Hard tasks. And the partner model is fixed to be `meta-llama/Llama-3-70b-chat-hf`
