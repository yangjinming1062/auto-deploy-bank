from .benchmark import benchmark

__all__ = ["benchmark"]
