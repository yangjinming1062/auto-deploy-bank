# Initially created by
# Darren Burns <darrenb900@gmail.com>
# https://github.com/darrenburns/rich-pixels

from ._pixel import Pixels

__all__ = [
    "Pixels",
]
