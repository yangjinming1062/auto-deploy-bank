class Logger(object):
    def info(self, msg: str) -> None: ...


logger = Logger()
