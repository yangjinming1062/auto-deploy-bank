def get_first_name() -> str:
    raise NotImplementedError
