Tools in this folder expects `langchain-core>=0.2.16` to use the injected RunnableConfig. Prior to that, you'd use `ensure_config` to collect the config from context.

More information: https://python.langchain.com/docs/how_to/tool_configure/#inferring-by-parameter-type
