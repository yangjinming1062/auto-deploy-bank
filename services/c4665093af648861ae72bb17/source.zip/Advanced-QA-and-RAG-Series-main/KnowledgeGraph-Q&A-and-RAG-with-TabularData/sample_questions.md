Q&A:
 - What was the cast of the Jumanji?
 - What movies did Powers Boothe act in?
 - Which actors have appeared together in more than one movie, and what genres do those movies belong to?
 - What are the most common genres for movies released in 1995?


RAG:
 - What was the cast of the Casino? or What movies did Powers Boothe act in?
 - What movies are about love?
 - What movies are about addventure?
