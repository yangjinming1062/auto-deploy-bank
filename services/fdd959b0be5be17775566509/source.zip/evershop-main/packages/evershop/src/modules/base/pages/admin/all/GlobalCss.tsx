import React from 'react';
import './global.scss';

export default function GlobalCss() {
  return null;
}

export const layout = {
  areaId: 'head',
  sortOrder: 5
};
