import { currencies } from '../../../../../lib/locale/currencies.js';

export default {
  Query: {
    currencies: () => currencies
  }
};
