Installation
#######################################################

You can install DataDreamer via `PyPI <https://pypi.org/project/datadreamer.dev/>`_::

   .. code-block:: bash

      pip3 install datadreamer.dev

..
   This page is redirected via the sphinx_reredirect extension.