# Overview
Loading and prompt-based training ERNIE 1.0 with manual template and manual verbalizer. 

实现加载 ERNIE 1.0 模型进行manual template 与 manual verbalizer 的 prompt learning

# Requirements
paddlepaddle==2.3.1
paddlenlp==2.3.5


## Quick start

Please refer to ``basic.py``.


