#!/bin/sh
rm -rf LAMA
wget --content-disposition https://cloud.tsinghua.edu.cn/f/8e1a4e4e881d4b9eb7f2/?dl=1 
tar -zxvf LAMA.tar.gz
rm -rf LAMA.tar.gz