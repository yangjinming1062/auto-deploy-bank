#!/bin/sh
rm -rf FewGLUE
wget --content-disposition https://cloud.tsinghua.edu.cn/f/018f9c0b63a542f88791/?dl=1
tar -zxvf FewGLUE.tar.gz
rm -rf FewGLUE.tar.gz
