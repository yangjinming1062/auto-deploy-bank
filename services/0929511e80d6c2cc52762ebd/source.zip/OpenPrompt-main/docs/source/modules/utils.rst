Utils Functions
==================================


.. contents:: Contents
    :local:

.. currentmodule:: openprompt.utils


Calibration
---------------------------------

.. automodule:: openprompt.utils.calibrate
   :members:
