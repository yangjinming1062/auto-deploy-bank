openprompt
==================

.. contents:: Contents
    :local:



prompt_base
--------------------

.. currentmodule:: openprompt.prompt_base
.. autosummary::
   :nosignatures:
   {% for cls in openprompt.prompt_base.classes %}
     {{ cls }}
   {% endfor %}


.. automodule:: openprompt.prompt_base
   :members:
   :undoc-members:
   :exclude-members:

.. autoclass:: openprompt.prompt_base.Template
   :members:
   :undoc-members:
   :exclude-members: 

