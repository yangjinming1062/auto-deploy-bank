Data Utils
==================================


Input Example
---------------------------------

.. autoclass:: openprompt.data_utils.data_utils.InputExample
   :members:


Input Features
---------------------------------

.. autoclass:: openprompt.data_utils.data_utils.InputFeatures
   :members:


Fewshot Sampler
---------------------------------

.. autoclass:: openprompt.data_utils.data_sampler.FewShotSampler
   :members: