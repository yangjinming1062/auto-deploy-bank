export * from './Resources.pages';
