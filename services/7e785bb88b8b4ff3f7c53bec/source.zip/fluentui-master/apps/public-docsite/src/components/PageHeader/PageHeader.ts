import * as React from 'react';

export const PageHeader: React.FunctionComponent<any> = () => null;
