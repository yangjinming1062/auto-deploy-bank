import { preset } from '@fluentui/scripts-tasks';

preset();
