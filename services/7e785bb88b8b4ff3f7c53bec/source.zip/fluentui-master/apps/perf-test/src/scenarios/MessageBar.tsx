import * as React from 'react';
import { MessageBar } from '@fluentui/react';

const Scenario = () => <MessageBar />;

export default Scenario;
