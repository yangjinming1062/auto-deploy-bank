import * as React from 'react';
import { Label } from '@fluentui/react';

const Scenario = () => <Label>I'm a Label</Label>;

export default Scenario;
