import * as React from 'react';
import { Stack } from '@fluentui/react';

const Scenario = () => (
  <Stack>
    <p>I am a stack child</p>
    <p>I am a stack child</p>
    <p>I am a stack child</p>
    <p>I am a stack child</p>
    <p>I am a stack child</p>
    <p>I am a stack child</p>
    <p>I am a stack child</p>
    <p>I am a stack child</p>
    <p>I am a stack child</p>
    <p>I am a stack child</p>
  </Stack>
);

export default Scenario;
