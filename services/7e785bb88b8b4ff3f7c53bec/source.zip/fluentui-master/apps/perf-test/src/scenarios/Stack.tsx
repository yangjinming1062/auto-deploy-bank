import * as React from 'react';
import { Stack } from '@fluentui/react';

const Scenario = () => <Stack />;

export default Scenario;
