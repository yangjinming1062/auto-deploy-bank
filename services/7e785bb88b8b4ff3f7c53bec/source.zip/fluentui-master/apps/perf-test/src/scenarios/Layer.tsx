import * as React from 'react';
import { Layer } from '@fluentui/react';

const Scenario = () => <Layer />;

export default Scenario;
