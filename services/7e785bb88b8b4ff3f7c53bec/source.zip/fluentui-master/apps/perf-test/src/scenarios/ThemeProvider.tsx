import * as React from 'react';
import { ThemeProvider } from '@fluentui/react';

const Scenario = () => <ThemeProvider />;

export default Scenario;
