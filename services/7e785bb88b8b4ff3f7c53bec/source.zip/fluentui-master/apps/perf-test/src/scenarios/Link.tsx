import * as React from 'react';
import { Link } from '@fluentui/react';

const Scenario = () => <Link href="https//www.bing.com">Bing</Link>;

export default Scenario;
