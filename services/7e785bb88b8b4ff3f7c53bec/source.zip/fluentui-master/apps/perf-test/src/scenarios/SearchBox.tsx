import * as React from 'react';
import { SearchBox } from '@fluentui/react';

const Scenario = () => <SearchBox placeholder="Search" />;

export default Scenario;
