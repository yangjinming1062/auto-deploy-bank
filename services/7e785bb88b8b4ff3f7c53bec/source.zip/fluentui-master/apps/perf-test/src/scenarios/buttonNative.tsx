import * as React from 'react';

const Scenario = () => <button>I am a button</button>;

export default Scenario;
