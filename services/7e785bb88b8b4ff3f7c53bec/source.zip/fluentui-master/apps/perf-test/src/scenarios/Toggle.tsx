import * as React from 'react';
import { Toggle } from '@fluentui/react';

const Scenario = () => <Toggle checked />;

export default Scenario;
