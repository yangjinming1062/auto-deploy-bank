import * as React from 'react';
import { CheckboxBase } from '@fluentui/react';

const Scenario = () => <CheckboxBase />;

export default Scenario;
