import * as React from 'react';
import { Stack, Text } from '@fluentui/react';

const Scenario = () => (
  <Stack>
    <Text>I am a stack child</Text>
    <Text>I am a stack child</Text>
    <Text>I am a stack child</Text>
    <Text>I am a stack child</Text>
    <Text>I am a stack child</Text>
    <Text>I am a stack child</Text>
    <Text>I am a stack child</Text>
    <Text>I am a stack child</Text>
    <Text>I am a stack child</Text>
    <Text>I am a stack child</Text>
  </Stack>
);

export default Scenario;
