import * as React from 'react';
import { TextField } from '@fluentui/react';

const Scenario = () => <TextField label="With placeholder" placeholder="Please enter text here" />;

export default Scenario;
