import * as React from 'react';
import { Text } from '@fluentui/react';

const Scenario = () => <Text>I am text, hear me roar.</Text>;

export default Scenario;
