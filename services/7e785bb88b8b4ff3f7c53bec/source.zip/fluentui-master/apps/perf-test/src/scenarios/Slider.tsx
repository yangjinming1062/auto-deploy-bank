import * as React from 'react';
import { Slider } from '@fluentui/react';

const Scenario = () => <Slider />;

export default Scenario;
