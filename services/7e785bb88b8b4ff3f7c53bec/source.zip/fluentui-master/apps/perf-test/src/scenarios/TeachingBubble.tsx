import * as React from 'react';
import { TeachingBubble } from '@fluentui/react';

const Scenario = () => <TeachingBubble />;

export default Scenario;
