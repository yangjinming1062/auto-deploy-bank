import * as React from 'react';
import { Rating } from '@fluentui/react';

const Scenario = () => <Rating />;

export default Scenario;
