import type { ScenarioIterations } from '@fluentui/scripts-tasks';
// You don't have to add scenarios to this structure unless you want their iterations to differ from the default.
export const scenarioIterations: ScenarioIterations = {
  MakeStyles: 50000,
  FluentProviderWithTheme: 10,
};
