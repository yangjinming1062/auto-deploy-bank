import type { ScenarioNames } from '@fluentui/scripts-tasks';
// You don't have to add scenarios to this structure unless you want their display name to differ
// from their scenario name.
export const scenarioNames: ScenarioNames = {};
