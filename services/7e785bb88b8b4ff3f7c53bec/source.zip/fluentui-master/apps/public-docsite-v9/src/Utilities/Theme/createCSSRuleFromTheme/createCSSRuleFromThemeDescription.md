This API allows you to create CSS from a theme and apply this CSS, for example, to `<body>`.
