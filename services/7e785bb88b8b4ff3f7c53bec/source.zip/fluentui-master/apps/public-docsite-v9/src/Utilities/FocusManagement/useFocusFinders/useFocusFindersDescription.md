This hook returns utility functions to find focusable elements, which can be useful when creating
a feature that requires specific focus management.
