# Best practices

These examples are intended to document the `positioning` prop used in Fluent UI React, please refer to component specific
documentation for best practices for a specific component.
