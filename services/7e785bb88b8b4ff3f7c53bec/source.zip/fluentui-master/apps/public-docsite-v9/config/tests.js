/** Jest test setup file. */

require('@testing-library/jest-dom');
