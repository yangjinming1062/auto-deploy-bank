# Change Log - @fluentui/pr-deploy-site

This log was last generated on Tue, 03 Aug 2021 07:39:30 GMT and should not be manually modified.

<!-- Start content -->

## [1.0.0](https://github.com/microsoft/fluentui/tree/@fluentui/pr-deploy-site_v1.0.0)

Tue, 03 Aug 2021 07:39:30 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/pr-deploy-site_v1.0.0..@fluentui/pr-deploy-site_v1.0.0)

### Patches

- Bump @fluentui/eslint-plugin to v1.3.3 ([PR #19169](https://github.com/microsoft/fluentui/pull/19169) by behowell@microsoft.com)

## [1.0.0](https://github.com/microsoft/fluentui/tree/@fluentui/pr-deploy-site_v1.0.0)

Fri, 09 Jul 2021 07:39:31 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/pr-deploy-site_v1.0.0..@fluentui/pr-deploy-site_v1.0.0)

### Patches

- Bump @fluentui/eslint-plugin to v1.3.2 ([PR #18808](https://github.com/microsoft/fluentui/pull/18808) by martinhochel@microsoft.com)

## [1.0.0](https://github.com/microsoft/fluentui/tree/@fluentui/pr-deploy-site_v1.0.0)

Mon, 07 Jun 2021 07:38:15 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/pr-deploy-site_v1.0.0..@fluentui/pr-deploy-site_v1.0.0)

### Patches

- Bump @fluentui/eslint-plugin to v1.3.1 ([PR #18437](https://github.com/microsoft/fluentui/pull/18437) by martinhochel@microsoft.com)

## [1.0.0](https://github.com/microsoft/fluentui/tree/@fluentui/pr-deploy-site_v1.0.0)

Thu, 20 May 2021 07:41:54 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/pr-deploy-site_v1.0.0..@fluentui/pr-deploy-site_v1.0.0)

### Patches

- Bump @fluentui/eslint-plugin to v1.3.0 ([PR #18024](https://github.com/microsoft/fluentui/pull/18024) by elcraig@microsoft.com)

## [1.0.0](https://github.com/microsoft/fluentui/tree/@fluentui/pr-deploy-site_v1.0.0)

Fri, 30 Apr 2021 07:42:23 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/pr-deploy-site_v1.0.0..@fluentui/pr-deploy-site_v1.0.0)

### Patches

- Bump @fluentui/eslint-plugin to v1.2.0 ([PR #17932](https://github.com/microsoft/fluentui/pull/17932) by joschect@microsoft.com)

## [1.0.0](https://github.com/microsoft/fluentui/tree/@fluentui/pr-deploy-site_v1.0.0)

Fri, 23 Apr 2021 07:37:10 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/pr-deploy-site_v1.0.0..@fluentui/pr-deploy-site_v1.0.0)

### Patches

- Bump @fluentui/eslint-plugin to v1.1.1 ([PR #17894](https://github.com/microsoft/fluentui/pull/17894) by olfedias@microsoft.com)

## [1.0.0](https://github.com/microsoft/fluentui/tree/@fluentui/pr-deploy-site_v1.0.0)

Wed, 31 Mar 2021 00:53:43 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/pr-deploy-site_v1.0.0..@fluentui/pr-deploy-site_v1.0.0)

### Patches

- Bump @fluentui/eslint-plugin to v1.1.0 ([PR #17568](https://github.com/microsoft/fluentui/pull/17568) by elcraig@microsoft.com)

## [1.0.0](https://github.com/microsoft/fluentui/tree/@fluentui/pr-deploy-site_v1.0.0)

Fri, 26 Feb 2021 01:16:27 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/pr-deploy-site_v1.0.0..@fluentui/pr-deploy-site_v1.0.0)

### Patches

- Bump @fluentui/scripts to v1.0.0 ([PR #17169](https://github.com/microsoft/fluentui/pull/17169) by elcraig@microsoft.com)

## [1.0.0](https://github.com/microsoft/fluentui/tree/@fluentui/pr-deploy-site_v1.0.0)

Thu, 18 Feb 2021 12:27:34 GMT 
[Compare changes](https://github.com/microsoft/fluentui/compare/@fluentui/pr-deploy-site_v1.0.0..@fluentui/pr-deploy-site_v1.0.0)

### Changes

- Bump @fluentui/scripts to v1.0.0 ([PR #16975](https://github.com/microsoft/fluentui/pull/16975) by elcraig@microsoft.com)
