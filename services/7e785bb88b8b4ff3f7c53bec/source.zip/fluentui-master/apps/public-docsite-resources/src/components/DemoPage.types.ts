export { IDocPageProps as IDemoPageProps } from '@fluentui/react/lib/common/DocPage.types';
