// Do not modify this file; it is generated as part of publish.
// The checked in version is a placeholder only and will not be updated.
import { setVersion } from '@fluentui/set-version';
setVersion('@fluentui/public-docsite-resources', '0.0.0');
