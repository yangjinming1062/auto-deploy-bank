repositories {
    google()
    mavenCentral()
}

plugins {
    `kotlin-dsl`
}
