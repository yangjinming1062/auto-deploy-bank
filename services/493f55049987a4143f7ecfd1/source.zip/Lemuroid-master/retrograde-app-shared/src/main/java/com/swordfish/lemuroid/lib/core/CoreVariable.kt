package com.swordfish.lemuroid.lib.core

import java.io.Serializable

data class CoreVariable(val key: String, val value: String) : Serializable
