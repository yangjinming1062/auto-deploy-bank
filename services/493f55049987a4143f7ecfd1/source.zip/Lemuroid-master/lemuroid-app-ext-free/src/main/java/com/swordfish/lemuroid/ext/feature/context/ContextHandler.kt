package com.swordfish.lemuroid.ext.feature.context

import android.content.Context

object ContextHandler {
    fun attachBaseContext(context: Context) {}
}
