package com.swordfish.lemuroid.app.tv.shared

import com.swordfish.lemuroid.app.shared.ImmersiveActivity

abstract class BaseTVActivity : ImmersiveActivity()
