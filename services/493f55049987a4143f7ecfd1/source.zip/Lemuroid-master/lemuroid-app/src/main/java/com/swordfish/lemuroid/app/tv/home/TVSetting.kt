package com.swordfish.lemuroid.app.tv.home

data class TVSetting(val type: TVSettingType, val enabled: Boolean = true)
