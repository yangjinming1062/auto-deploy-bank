# Install

This section is divided in 3 steps: first preparing the database, second configuring the connection parameters of lavagna and third the setup phase.

For installing lavagna, the requirements are:

 - a jre (java runtime) >= 8
 - utf-8 environment (especially for the database)
