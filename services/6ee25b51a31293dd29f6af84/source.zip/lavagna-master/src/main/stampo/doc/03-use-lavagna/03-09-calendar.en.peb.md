## Calendars

The global and project calendar take into consideration all due dates, set either on cards or milestones, and display them in a month by month view.

<img class="pure-img" src="{{relativeRootPath}}/images/en/calendar.png" alt="Calendar view">

Cards will be displayed by their short name and name.

Milestone will be displayed by their name and percentage of closed cards.
