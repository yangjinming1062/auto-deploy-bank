/**
 * Created by dora on 2015/4/8.
 */


module.exports={
    cookieSecret:"doracms",
    db:"doracms",
    host:"localhost"
}