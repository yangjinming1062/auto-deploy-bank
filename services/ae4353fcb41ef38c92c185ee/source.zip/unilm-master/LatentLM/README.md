# [Multimodal Latent Language Modeling with Next-Token Diffusion]

Official PyTorch implementation and pretrained models of LatentLM. 

---


<!-- ## Pretrained models -->

<!-- coming soon -->

## Setup & Usage

Coming soon!

## License
This project is licensed under the license found in the LICENSE file in the root directory of this source tree.

[Microsoft Open Source Code of Conduct](https://opensource.microsoft.com/codeofconduct)

### Contact Information

For help or issues using BEiT models, please submit a GitHub issue.

For other communications, please contact [Li Dong](https://dong.li/) (`lidong1@microsoft.com`), [Furu Wei](http://gitnlp.org/) (`fuwei@microsoft.com`).
