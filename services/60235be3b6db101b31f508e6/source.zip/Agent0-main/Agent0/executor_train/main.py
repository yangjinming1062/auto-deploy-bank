def main():
    print("Hello from verl-tool!")


if __name__ == "__main__":
    main()
