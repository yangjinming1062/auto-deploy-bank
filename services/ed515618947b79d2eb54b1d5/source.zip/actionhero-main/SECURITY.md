# Security Policy

## Reporting a Vulnerability

If you have found a security issue, please email hello [at] actionherojs.com.  Do not post a Github Issue so we can properly patch the issue before disclosing publicly. 
