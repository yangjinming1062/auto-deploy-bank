import { Initializer } from "./initializer";

export interface Initializers {
  [key: string]: Initializer;
}
