import axios, { AxiosError } from "axios";
import { Process, config } from "./../../../src/index";

const actionhero = new Process();
let url: string;

jest.mock("./../../../src/config/web.ts", () => ({
  __esModule: true,
  test: {
    web: () => {
      return {
        compress: true,
        enabled: true,
        secure: false,
        urlPathForActions: "api",
        urlPathForFiles: "public",
        rootEndpointType: "file",
        port: 18080 + parseInt(process.env.JEST_WORKER_ID || "0"),
        matchExtensionMime: true,
        metadataOptions: {
          serverInformation: true,
          requesterInformation: false,
        },
        fingerprintOptions: {
          cookieKey: "sessionID",
        },
      };
    },
  },
}));

describe("Core", () => {
  describe("static file", () => {
    beforeAll(async () => {
      await actionhero.start();
      url =
        "http://localhost:" +
        config.web!.port +
        "/" +
        config.web!.urlPathForFiles;
    });

    afterAll(async () => {
      await actionhero.stop();
    });

    describe("Compression", () => {
      test("should respect accept-encoding header priority with gzip as first in a list of encodings", async () => {
        const response = await axios.get(url + "/simple.html", {
          headers: { "Accept-Encoding": "gzip, deflate, sdch, br" },
          decompress: false,
        });

        expect(response.status).toEqual(200);
        expect(response.headers["content-encoding"]).toEqual("gzip");
      });

      test("should respect accept-encoding header priority with deflate as second in a list of encodings", async () => {
        const response = await axios.get(url + "/simple.html", {
          headers: { "Accept-Encoding": "br, deflate, gzip" },
          decompress: false,
        });

        expect(response.status).toEqual(200);
        expect(response.headers["content-encoding"]).toEqual("deflate"); // br is not a currently supported encoding
      });

      test("should respect accept-encoding header priority with gzip as only option", async () => {
        const response = await axios.get(url + "/simple.html", {
          headers: { "Accept-Encoding": "gzip" },
          decompress: false,
        });

        expect(response.status).toEqual(200);
        expect(response.headers["content-encoding"]).toEqual("gzip");
      });

      test("should not encode content without a valid a supported value in accept-encoding header", async () => {
        const response = await axios.get(url + "/simple.html", {
          headers: { "Accept-Encoding": "sdch, br" },
          decompress: false,
        });

        expect(response.status).toEqual(200);
        expect(response.headers["content-encoding"]).toBeUndefined();
      });

      test("should not encode content without accept-encoding header", async () => {
        const response = await axios.get(url + "/simple.html", {
          headers: { "Accept-Encoding": "" },
          decompress: false,
        });

        expect(response.status).toEqual(200);
        expect(response.headers["content-encoding"]).toBeUndefined();
      });
    });
  });
});
