rm -f bank_veto_bank.xml *.hdf
