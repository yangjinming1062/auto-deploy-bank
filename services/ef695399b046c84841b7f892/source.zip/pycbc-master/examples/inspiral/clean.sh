rm -f H1-INSPIRAL_* output_*pstats inspiral_*log *png DATA_FILE.gwf COMPRESSED_BANK.hdf SMALLER_BANK_FOR_GW150914.hdf
