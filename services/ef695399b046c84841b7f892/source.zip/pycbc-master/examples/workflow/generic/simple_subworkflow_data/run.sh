python simple.py --workflow-name test --config-files simple.ini --submit-now
