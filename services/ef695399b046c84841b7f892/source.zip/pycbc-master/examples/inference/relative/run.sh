pycbc_inference \
--config-file `dirname "$0"`/relative.ini \
--nprocesses=1 \
--output-file relative.hdf \
--seed 0 \
--force \
--verbose
