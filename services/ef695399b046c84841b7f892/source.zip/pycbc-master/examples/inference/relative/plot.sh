pycbc_inference_plot_posterior \
--input-file relative.hdf \
--output-file relative.png \
--z-arg snr
