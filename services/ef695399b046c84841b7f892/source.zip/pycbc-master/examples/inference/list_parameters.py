from pycbc.waveform import parameters
# print base parameters for CBC waveform
print(parameters.fd_waveform_params + parameters.location_params + \
    parameters.calibration_params)
