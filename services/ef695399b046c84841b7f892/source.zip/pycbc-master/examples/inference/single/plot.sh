pycbc_inference_plot_posterior \
--input-file single.hdf \
--output-file single.png \
--z-arg snr
