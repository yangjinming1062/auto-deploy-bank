pycbc_inference \
    --config-files prior.ini \
    --nprocesses 1 \
    --output-file multi_signal.hdf \
    --seed 10 \
    --force \
    --verbose
