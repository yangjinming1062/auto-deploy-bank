pycbc_inference \
--config-file `dirname "$0"`/rel.ini \
--nprocesses=1 \
--output-file rel.hdf \
--seed 0 \
--force \
--verbose
