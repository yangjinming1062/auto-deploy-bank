set -e
export OMP_NUM_THREADS=1
cp ../../examples/inference/lisa_smbhb_inj/injection_smbhb.ini injection_smbhb.ini
sh ../../examples/inference/lisa_smbhb_inj/injection_smbhb.sh
sh ../../examples/inference/lisa_smbhb_inj/run.sh
sh ../../examples/inference/lisa_smbhb_inj/plot.sh
