.. _searches:

=============================================
PyCBC searches
=============================================

Here we collect pages describing various parts of the PyCBC searches

.. toctree::
   :maxdepth: 1

   searches/ranking_statistic.rst
