###################################################
Generating Noise
###################################################

=====================================
Generating time domain Gaussian noise
=====================================

.. plot:: ../examples/noise/timeseries.py
   :include-source:

