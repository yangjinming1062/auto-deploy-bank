This setup only uses relative includes
