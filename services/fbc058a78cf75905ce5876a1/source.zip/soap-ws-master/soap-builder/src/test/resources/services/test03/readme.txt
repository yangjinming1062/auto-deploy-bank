This setup uses only relative imports
