This setup only uses relative includes

onewayop
