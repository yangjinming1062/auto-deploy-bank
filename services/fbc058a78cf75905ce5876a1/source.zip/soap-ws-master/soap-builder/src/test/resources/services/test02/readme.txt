This setup uses relative import to xsds, include from xsds
