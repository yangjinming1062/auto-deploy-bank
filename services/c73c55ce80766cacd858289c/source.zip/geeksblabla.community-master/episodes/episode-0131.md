---
date: 2022-11-06
duration: "1:38:02"
title: "MSS with Adil TOUATI"
tags: ["MSS", "geeksblabla", "Cloud", "DevOPS", "Microsoft"]
category: "mss"
youtube: https://www.youtube.com/watch?v=nDb3hLIMrP0
published: true
featured: false
---

In this Episode of Geeksblabla , We're joined by the amazing Adil Touati who shared with us precious insights from his amazing career in the Software Industry.

## Guests

- [Adil TOUATI](https://www.linkedin.com/in/adiltouati/)

## Notes

0:00:00 - Introduction and welcoming

0:02:00 - Adil's Journey to Microsoft

0:23:00 - How was Adil able to follow tech trends ?

0:34:30 - Adil's relationship with Technology

0:37:00 - The work of a Cloud Solution Architect

0:45:00 - What are the necessary skills to become a Solutions Architect ?

0:53:33 - Where do you see the Cloud going ?

1:14:00 - Adil's Advice for the newer generation of Software Engineers

1:26:00 - QA - Geeksblabla Picks

1:35:00 - Conclusion

## Links

## Prepared and Presented by

- [Otmane FETTAL](https://twitter.com/ofettal)
