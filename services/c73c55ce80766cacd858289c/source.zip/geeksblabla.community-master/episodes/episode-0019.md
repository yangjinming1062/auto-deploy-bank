---
date: 2019-07-31
duration: "1:28:48"
title: "Competitive programming, how to become good at!"
tags: ["competitive programming"]
category: "dev"
youtube: https://www.youtube.com/watch?v=jU12lUQMfSQ
published: true
---

In this episode of GeeksBlabla, Geeksblabla team with the amazing Diaa and Adnan talk about what is Competitive Programing, How to become good at and why you need to be a part of the next competition.

## Guests

## Notes

00:00:00 - Introduction: Welcoming and presenting guests.

00:05:00 - What is Competitive programming and why it's important?

00:16:00 - Types of Competitive programming.

00:24:00 - who can participate and How?

00:40:00 - History behind Competitive programming.

00:50:00 - Competitive programming in Morocco: best scores

01:01:00 - How we can improve our scores

01:10:00 - Q/A

## Links

[MCPC chair](https://www.youtube.com/watch?v=aPOJ0w9Cc0w)

[ACPC](https://www.youtube.com/watch?v=NyI2nYOPjiU&t=4s)

[MCPC](https://www.youtube.com/watch?v=aPOJ0w9Cc0w)

[Competitive Programing Book](https://cpbook.net/)

[SolverToBe](https://www.youtube.com/channel/UC2xOPGjIhLKsgUZEiunlzWQ)

[Arabic Competitive Programming](https://www.youtube.com/user/nobody123497)

## Prepared and Presented by
