---
date: 2020-10-04
duration: "01:08:20"
title: "MSS with Samir Benmakhlouf"
tags: ["MSS"]
category: "mss"
youtube: https://www.youtube.com/watch?v=IPR2auK2vRg
published: true
---

In this episode of GeeksBlabla, we invited Samir Benmakhlouf who is the current CEO of London Academy School and previous Country Manager of Microsoft Morocco

## Guests

- [Samir Benmakhlouf](https://www.linkedin.com/in/samirben/)

## Notes

0:00:00 - Introduction and Welcoming. Reminder to register to blablaconf

0:02:00 - Educational journey + Higher education journey

0:07:00 - Why going to the US instead of France or other countries to pursue your higher education studies ?

0:16:00 - Why pursuing a PHD ? Is PHD something you advise for moroccan students ?

0:18:00 - Advantages and inconvenients of education in USA

0:23:00 - Doing a PHD directly after a bachelor ?

0:33:00 - Role of the guest within Microsoft Morocco + Missions of Microsoft Morocco

0:36:00 - Future plans of Microsoft for Morocco

0:37:00 - Advices for people that want to work within Microsoft

0:38:00 - Few words about Bill Gates and his style of management

0:40:00 - WHy aren't there any big technological lab in Morocco ? (Like Google AI center in Ghana)

0:47:00 - How is Coding teached in london academy ?

0:52:00 - Guest point of view about how computer science in teached in Moroccan universities ?

0:56:00 - How were courses handled in London Academy during the Covid 19 pandemic ?

## Links

- [Microsoft MACH program](https://my.gradconnection.com/employers/microsoft/intern-to-mach/)

## Prepared and Presented by

- [Meriem Zaid](https://twitter.com/_iMeriem)
- [Ismail Tlemcani](https://www.linkedin.com/in/ismailtlemcani)
