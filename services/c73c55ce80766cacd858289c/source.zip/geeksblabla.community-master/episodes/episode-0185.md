---
date: 2024-07-07
duration: "2:16:19"
title: "AMA & Tech News #32"
tags: ["AMA"]
category: "ama"
youtube: https://www.youtube.com/watch?v=QZhKeIXcsKA
published: true
featured: false
---

In this episode, we discuss What's new in the AI , Windows and Nvidia

## Guests

- [Abderrahim Soubai Idriss](https://twitter.com/soub4i)
- [Merouane Zouaid](https://x.com/merouanezouaid)
- [Marwane Chaoui](https://x.com/moghwan)

## Notes

0:00:00 - Introduction and welcoming

0:05:30 - What did we learn in the last month

0:20:00 - Bouyaad App Showcase

0:26:00 - Buildspace Showacase

0:34:30 - Tech News - Apple Intelligence

1:01:30 - Tech News - Nvidia's soaring to all time highs

1:20:30 - Tech News - Windows on ARM

1:30:00 - Q/A

1:43:00 - Conclusion

## Links

- [Bouyad App](​​https://web.bouayad.app/)

- [Bouyad App - Repo](https://github.com/moghwan/web.bouayad.app)

- [Buildspace](https://buildspace.so/)

- [Stocks for the Long Run](https://www.amazon.com/Stocks-Long-Run-Definitive-Investment/dp/0071800514)

## Prepared and Presented by

- [Otmane FETTAL](https://twitter.com/ofettal)
