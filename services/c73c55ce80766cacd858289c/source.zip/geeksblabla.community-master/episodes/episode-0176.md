---
date: 2024-03-31
duration: "1:27:32"
title: "MSS with Mohamed Adnane Abouchadi"
tags: ["career", "dev", "mss", "success", "disability"]
category: "mss"
youtube: https://www.youtube.com/watch?v=HRGLTomaEXE
published: true
featured: false
---

In this Geeksblabla episode, Mohammed Adnane Abouchadi talks about how he became a software engineer despite his disability, and shares with us some inspiring lessons he learned along the journey.

## Guests

- [Mohamed Adnane Abouchadi](https://abouchadi.com/)

## Notes

0:00:00 - Introduction and welcoming

0:02:55 - Why Mohamed Adnane is special

0:05:45 - Adnane's childhood, school time and the start of his passion about computers

0:12:30 - Importance of family and environment

0:16:05 - Orientation between passion and abilities

0:24:15 - Adnane's university journey

0:38:00 - Finding the first job

0:57:30 - Adnane's Entrepreneurial journey

1:06:00 - A day in Adnane's life

1:11:00 - Lessons and Advice to people with disabilities

1:22:00 - A message to companies and recruiters

1:27:00 - Closing and Goodbyes

## Links

## Prepared and Presented by

[Mohammed Daoudi](https://www.linkedin.com/in/iduoad)
