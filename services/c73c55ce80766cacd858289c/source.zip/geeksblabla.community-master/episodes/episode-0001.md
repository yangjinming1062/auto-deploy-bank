---
date: 2018-05-19
duration: "2:00:13"
title: "Devops"
tags: ["devops"]
category: "dev"
youtube: https://www.youtube.com/watch?v=_tizAkqvivM
published: true
---

On this episode of Geeksblabla : Soufian , Mohammed Aboullaite , Mohammed Ezzarghili , Youssouf and Amine talks about DevOps : Definitions , brief history , Work flow , Tools and best practices ..etc.

## Guests

## Notes

00:00:00 - Introduction : Mohammed / Soufian announcing upcoming community events

00:09:00 - Welcoming to the new season

00:10:00 - What is the definition of DevOps ?

00:17:00 - Can we use DevOps on any industry context ?

00:22:00 - Good resource for understanding DevOps ( Book : Effective DevOps)

00:28:00 - What is the principal DevOps process/Workflow/toolchain used in software engineering ?

00:37:00 - Code (Toolchain)

00:47:00 - IDE (Toolchain)

00:52:00 - How automatically deploy angular app ?

00:59:00 - Build (Toolchain)

01:03:00 - Test (Toolchain)

01:19:00 - Packaging (Toolchain)

01:25:00 - Releasing (Toolchain)

01:29:00 - Configuration (Toolchain)

01:37:00 - Monitoring (Toolchain)

01:45:00 - Questions

## Links

- [Effective DevOps](http://shop.oreilly.com/product/0636920039846.do)

## Prepared and Presented by
