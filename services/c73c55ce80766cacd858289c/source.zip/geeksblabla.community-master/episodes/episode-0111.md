---
date: 2022-03-20
duration: "1:29:52"
title: "DigiGirlz x WIT 22"
tags: ["dev", "WIT", "DigiGirlz"]
category: "career"
youtube: https://www.youtube.com/watch?v=G7SIYlXHx7Y
published: true
---

In this special episode, we honor the internation women's month. Our guest from Digigirlz will talk about their experience in such IT programs, and answer all of your questions.

## Guests

- [Chaimae Drissi Ismaili](https://www.linkedin.com/in/chaimae-drissi-smaili-b8993a105/)

- [Afaf Ouardi](https://www.linkedin.com/in/afaf-ouardi-788903212/)

- [Nada Skalli Senhaji](https://www.linkedin.com/in/nada-skali-senhaji-555146119)

## Notes

0:00:00 - Introduction and welcoming guests

0:05:00 - What is the DigiGirlz initiative about?

0:09:32 - How can our girls know about it and participate in it?

0:13:00 - What are the technical and general benefits (impact) of this program?

0:24:00 - How did you start your DigiGirlz journey and how was it?

0:30:00 - Are there any other similar initiatives?

0:36:30 - Initiatives created by our guests in Morocco.

0:39:00 - Is the DigiGirlz initiative the best one? And why?

0:44:00 - Is the low presence of women in tech a problem? if so, why ?

1:07:00 - What do you think about the latest result of stateofdev?

1:18:00 - Geeksblabla Picks.

1:28:00 - Wrap up & Goodbye

## Links

- [DigiGirlz Morocco](https://www.facebook.com/DigiGirlz.ma/)

- [Kid code](https://web.facebook.com/KidCodeMorocco)

- [We STEM](https://www.instagram.com/westem.gi/)

- [We STEM application](https://docs.google.com/forms/d/e/1FAIpQLScmef39izLi60B1ErD9KntojqHeq-yxLyqNQDlbTalz9xq2Zg/viewform?vc=0&c=0&w=1)

- [Yale Young Global Scholars](https://globalscholars.yale.edu/)

- [Orange Digital Center ML workshop](https://www.facebook.com/253109491766621/posts/1312010889209804/?d=w)

- [Youth Zone](https://open.spotify.com/show/10Gu0UmnGmkyC2gq04fh6c?si=5ec9c006a5fc4121)

## Prepared and Presented by

- [Meriem Zaid](https://twitter.com/_iMeriem)
