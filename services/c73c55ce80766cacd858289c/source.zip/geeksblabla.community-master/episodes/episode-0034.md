---
date: 2020-04-08
duration: "01:35:34"
title: "HA: Scaling Systems and Handling Loads"
tags: ["devops", "backend", "software engineering"]
category: "dev"
youtube: https://www.youtube.com/watch?v=CUDS14nbxGU
published: true
featured: false
---

In this episode, Abderrahim share with us some important practices and tips about building Hight Availability systems, scaling web applications and handling high traffic

## Guests

[Abderrahim Ouakki](https://web.facebook.com/abderrahim.ouakki.0)

## Notes

## Links

[Presentation slides](https://docs.google.com/presentation/d/1whJIMjPeOGyfjOuAGwmyPTr-pR5DkkA9McsIzgg0xgo/edit?fbclid=IwAR2kXpLL17bkv83Ehp9Ve-uXUscu7eaPc6OnoLeuDDGy-D2Vn8fDSqIb0Rg)

## Prepared and Presented by

[Mohammed Aboullaite](https://twitter.com/laytoun)
