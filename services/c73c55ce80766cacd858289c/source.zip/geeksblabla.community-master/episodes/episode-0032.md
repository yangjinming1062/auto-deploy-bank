---
date: 2020-03-30
duration: "01:00:57"
title: "Moroccan Makers Efforts to Fight COVID-19"
tags: ["COVID-19"]
category: "career"
youtube: https://www.youtube.com/watch?v=XIiMb2z42Ms
published: true
featured: false
---

In this episode We're welcoming 2 great heroes, Mohamed and Hamid are doing amazing jobs, pushing innovation and making things to save lives in Morocco and beat Covid-19!

## Guests

## Notes

## Links

## Prepared and Presented by

[Mohammed Aboullaite](https://twitter.com/laytoun)

[Meriem Zaid](https://twitter.com/_iMeriem)
