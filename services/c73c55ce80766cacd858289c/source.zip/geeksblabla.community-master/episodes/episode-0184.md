---
date: 2024-06-30
duration: "2:06:08"
title: "Why aren't people ready to buy digital information?"
tags: ["career"]
category: "career"
youtube: https://www.youtube.com/watch?v=cFo1Djq_zOg&ab_
published: true
featured: false
---

In this episode we adress the concern of information economy or "why people don't buy digital informations" from different point of views ad based on our guests experience.

## Guests

- [Mehdi Cheracher](https://twitter.com/Mehdi_Cheracher)

- [Zak Elfassi](https://twitter.com/zakelfassi)

- [Mohammed Aboullaite](https://twitter.com/laytoun)

- [Ayoub Alouane](https://twitter.com/alouane_med)

## Notes

0:00:00 - Introduction and welcoming

0:04:39 - Definition of "information economy" in the context of Morocco?

0:17:02 - How has morocco's digital landscape evolved in recent years

0:37:08 - Comparison to neighboring countries

0:47:31 - How educational system prepare students for the information economy

1:02:40 - Working on infrastructure and mindset / Behavior

1:19:16 - What initiatives could boost digital information consumption

1:24:48 - Q&A / Giveaway

2:06:05 - Conclusion and Goodbye

## Links

## Prepared and Presented by

- [Meriem zaid](https://twitter.com/_iMeriem)
