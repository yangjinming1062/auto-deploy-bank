---
date: 2021-01-03
duration: "1:33:00"
title: "MSS with Aboulfeth Hamza"
tags: ["MSS"]
category: "mss"
youtube: https://www.youtube.com/watch?v=w_oWwCKtVuk
published: true
---

In this episode of GeeksBlabla, we invited Aboulfeth, a tech serial entrepreneur who started his first business at the early age of 17. He dropped out of college at 21, became ICANN accredited at 24, attended the World Economic Forum at 25, and went to Harvard at 26 and Hajj and Burning Man at 27.

## Guests

- [Aboulfeth Hamza](https://www.aboulfeth.com/)

## Notes

0:00:00 - Introduction and welcoming

0:02:00 - Who is Mohamed Hamza?

0:08:00 - Did you drop out of school to work on your project?

0:15:00 - Did you give your project more time at the expense of your study?

0:22:00 - Did you work as an employee earlier?

0:35:00 - Why did you choose to build a startup instead of having a full-time job?

0:41:00 - Are Morocco and Moroccan companies start trust Moroccan hosting/cloud providers?

0:45:00 - Are Morocco and Moroccan companies ready for the cloud?

0:49:00 - Building a cloud company in Morocco! Wasn't that a challenge?

0:51:00 - After Genious, you decided to build a restaurant 2.0! Why this decision?

0:54:00 - Building a tech startup (or a tech company) in Marrakech vs in Casablanca ?

0:57:00 - What are the challenges/difficulties in hiring tech profiles?

1:02:00 - Any advice and recommendations for Moroccan entrepreneurs?

1:09:00 - What are the Obstacles he went through and succeeded in going over them, and What are the reasons that motivated you to write a book?

1:22:00 - how was your experience on the program “Chkoun ghayastatmar f machrou3i” and what is your feedback about it?

1:30:00 - Conclusion

## Links

## Prepared and Presented by

- [Hamza Makraz](https://web.facebook.com/MakrazHamza)

- [Mohammed Aboullaite](https://twitter.com/laytoun)
