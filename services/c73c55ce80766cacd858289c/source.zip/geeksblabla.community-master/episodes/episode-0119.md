---
date: 2022-05-29
duration: "1:44:51"
title: "Tech News & AMA #17"
tags: ["AMA", "geeksblabla"]
category: "ama"
youtube: https://www.youtube.com/watch?v=00Z7mP3IhTI
published: true
featured: false
---

Tech News & AMA #17 with our community members Mohamed, and Abdullah. During this episode, we discuss Oracle labs in morocco, new Abdullah experience joining Microsoft and we answer audience questions.

## Guests

- [Mohamed Ez-zarghili](https://twitter.com/ezzarghili)

- [Abdullah Iraamane](https://www.linkedin.com/in/aairaamane/)

## Notes

0:00:00 - Introduction and welcoming

0:01:30 - Guest Introduction

0:03:00 - Oracle Labs in Morocco

0:26:00 - Abdullah experience joining Microsoft

0:54:00 - Big company Recruitment Freezing?

1:01:00 - Resume Writing advices.

1:04:00 - Is a french an obstacle on acquiring jobs in morocco?

1:10:00 - Finding the first job remotely.

1:13:10 - How to deal when you feel you are not learning new things in your job?

1:21:20 - Freelance vs working in companies.

1:23:30 - PhD programs offered by Oracle labs.

1:28:00 - QA

1:41:30 - Conclusion

## Links

- [Oracle Labs](https://labs.oracle.com/pls/apex/labs/r/labs/intro)
- [StateOfDev.ma](https://stateofdev.ma/)
- [Self-taught developers episode](https://geeksblabla.community/blablas/self-taught-developers)

## Prepared and Presented by

- [Youssouf El Azizi](https://elazizi.com)
