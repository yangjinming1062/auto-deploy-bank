---
date: 2021-12-26
duration: "02:30:00"
title: "The 100th Episode"
tags: ["100", "geeksblabla"]
category: "career"
youtube: https://www.youtube.com/watch?v=1Ds--L9ERf0
published: true
featured: true
---

In this episode of GeeksBlabla, we celebrate the 100th episode, we discussed how the podcast started, how we work as a team behind the scene and some statistics about the podcast.

## Guests

- [Mohammed Aboullaite](https://twitter.com/laytoun)

- [Soubai Abderahim](https://twitter.com/soub4i)

- [Meriem Zaid](https://twitter.com/_iMeriem)

- [Otmane Fettal](https://twitter.com/ofettal)

## Notes

0:00:00 - Introduction

0:04:00 - How the podcast started?

0:23:00 - The secret behind podcast consistency.

0:43:00 - Audience reviews

0:59:00 - Episodes preparation and tools we use

1:10:00 - Statistics quiz

1:19:00 - Geeksblabla funny moments

1:38:00 - Wrap up & Goodbye

## Links

## Prepared and Presented by

- [Youssouf El Azizi](https://elazizi.com)
