---
date: 2022-09-11
duration: "1:30:27"
title: "DevoxxMa Special"
tags: ["Dev"]
category: "dev"
youtube: https://www.youtube.com/watch?v=UaulAxzEvdk
published: true
featured: false
---

In this episode we dicuss DevoxxMA's return this year, news and other details with Badr Elhouari.

## Guests

- [Badr Elhouari](https://twitter.com/badrelhouari)

## Notes

0:00:00 - Introduction and welcoming.

0:01:57 - This year's theme.

0:06:53 - From developers to developers.

0:11:28 - What are the subjects most focused on?

0:16:20 - Bringing back in person events.

0:26:30 - Smart training and workshops yet to be presented by experts

0:29:28 - Talks selections and criterias.

0:40:25 - Conferences culture in Morocco.

0:52:11 - Will there be a recording of sessions this year?

1:15:54 - DevoxxMa culture and other conferences.

1:27:26 - Geeksblabla Giveaway

1:29:00 - Wrap up and Goodbye!

## Links

- [DevoxxMA 2022](https://devoxx.ma/)

## Prepared and Presented by

- [Meriem Zaid](https://twitter.com/_iMeriem)

- [Otmane Fettal](https://twitter.com/ofettal)
