---
date: 2018-10-25
duration: "1:22:38"
title: "Developer Career"
tags: ["dev", "career"]
category: "career"
youtube: https://www.youtube.com/watch?v=1luq94KV-xM
published: true
---

On this episode of Geeksblabla hosted by (Mohammed Aboullaite) : The guests Soufian , Faissal ,Youssouf and Othmane talks about The bounds of "job of developer" from many point of views educational , technical and psychologic ..etc.

## Guests

## Notes

00:00:00 - Introduction : Welcoming and presenting guests

00:03:00 - What is the definition(s) of developer job ?

00:07:00 - How a new developers can choose the best profile for there skills ?

00:20:00 - Is anybody can be developer ?

00:39:00 - Any advice to developers to complete their education ?

00:43:00 - In our context (Moroccan) why we don't have the culture of monitoring junior developer inside companies ?

00:59:00 - What's differences between Junior, and Senior developers ?

01:08:00 - Final thoughts ?

## Links

- [Medium](https://medium.com/)
- [Dev.to](https://dev.to/)
- [Technical Podcasts](https://www.freecodecamp.org/news/here-are-the-most-interesting-developer-podcasts-2019-edition-4e43063bf8a4/)

## Prepared and Presented by
