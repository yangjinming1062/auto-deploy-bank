---
date: 2020-06-21
duration: "02:28:04"
title: "Mobile Development"
tags: ["android", "IOS", "mobile dev", "react native", "flutter"]
category: "dev"
youtube: https://www.youtube.com/watch?v=GFlWbEHmi4Y
published: true
featured: false
---

In this episode of GeeksBlabla, we discuss Mobile development with some Amazing Community folks, How to get started, Native, cross-platform solution, hybrid solutions, PWA, and a lot of topics around it.

## Guests

[Mehdi Sakout](https://twitter.com/MedyO80)

[Raouf Rachiche](https://twitter.com/raoufrahiche)

## Notes

0:00:00 - Introduction and welcoming.

0:08:00 - Mobile Development? History?

0:14:00 - Mobile Development and how it’s different from Web or desktop development (challenges).

0:23:00 - State of Mobile Dev in Morocco and worldwide (jobs, technologies salaries)

0:47:00 - Solution for Mobile Development(Native, Cross-platform, hybrid, PWA)

0:55:00 - Flutter

1:09:00 - Native Development (Android)

1:15:00 - React Native

1:21:00 - Cross Platform issues with upgrade.

1:34:00 - Fuchsia and the future of Android.

1:36:00 - Build and distribute Mobile Apps

1:39:00 - Code Push

1:47:00 - QA.

## Links

[Official android courses](https://developer.android.com/courses)

[Official Apple courses](https://developer.apple.com/library/archive/referencelibrary/GettingStarted/DevelopiOSAppsSwift/)

[React Native](https://reactnative.dev/)

[Flutter](https://flutter.dev/)

[Udacity](https://www.udacity.com/)

[Raouf Rachiche Youtube Channel](https://www.youtube.com/channel/UCal0wCIwkxiKcrYPvBS6RiA)

[Udemy](https://www.udemy.com/topic/android-development/free/)

[AppCenter](http://appcenter.ms/)

## Prepared and Presented by

[Youssouf EL Azizi](https://elazizi.com)
