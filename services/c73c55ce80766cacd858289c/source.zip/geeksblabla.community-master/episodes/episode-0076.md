---
date: 2021-03-28
duration: "01:52:00"
title: "Tech News & AMA #9"
tags: ["AMA"]
category: "ama"
youtube: https://www.youtube.com/watch?v=K9DZ8aRCNzE
published: true
---

Tech News & AMA #9 with our community members Ahmed, Mohamed and Othman. During this episode, we discuss the latest Tech News, **Make it legal** Ahmed's book and we answer audience questions about programming, community, new technologies, and much more.

## Guests

- [Ahmed El Azzabi](https://mylink.fyi/elazzabi)

- [Mohamed Ez-zarghili](https://twitter.com/ezzarghili)

- [Otmane Fettal](https://twitter.com/ofettal)

## Notes

0:00:00 - Introduction.

0:03:00 - NFTs

0:16:00 - 'Make it legal' book.

0:32:00 - Remote work future

0:50:00 - Job satisfaction and How do people end up loving what they do?

1:18:00 - OVH outage

1:30:00 - New Windows updates

1:37:00 - QA

1:51:00 - Wrap up and goodbye.

## Links

- [\$69 Million for a JPEG File - The Wild World of NFT’s](https://www.youtube.com/watch?v=x3nmAX3gAlw)

- [So Good They Can't Ignore You](https://www.amazon.com/Good-They-Cant-Ignore-You/dp/1455509124)

- [Remote.ma](https://remote.ma/)

- [Make it legal](https://makeitlegal.ma/)

- [StateOfDev.ma](https://stateofdev.ma)

## Prepared and Presented by

- [Youssouf El Azizi](https://elazizi.com)
