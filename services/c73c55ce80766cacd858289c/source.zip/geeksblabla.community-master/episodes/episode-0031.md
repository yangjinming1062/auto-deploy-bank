---
date: 2020-03-28
duration: "02:24:36"
title: "AMA With GeeksBlabla Team "
tags: ["DevC", "AMA"]
category: "ama"
youtube: https://www.youtube.com/watch?v=nTA2mTRlTD0
published: true
featured: false
---

This episode is an AMA (Ask Me Anything ) with GeeksBlabla Team ,During this episode we answer audience Questions about programming, community,new technologies and much more.

## Guests

[Soufian El Foukahi](https://twitter.com/soufyanAI)

[Youssouf El Azizi](https://elazizi.com)

[Amine Hakkou](https://www.hakkou.me/)

[Meriem Zaid](https://twitter.com/_iMeriem)

[Mohammed Aboullaite](https://twitter.com/laytoun)

[Oussama Hyad](https://www.facebook.com/heoussama.oussama)

## Notes

## Links

## Prepared and Presented by
