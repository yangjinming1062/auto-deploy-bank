---
date: 2022-01-02
duration: "02:08:27"
title: "Microsoft Azure Ecosystem"
tags: ["101", "Microsoft", "Azure"]
category: "dev"
youtube: https://www.youtube.com/watch?v=U2Kem64cZ_0
published: true
featured: true
---

In this Episode of GeeksBlabla , we discussed The Microsoft Azure Ecosystem , first we started with an overview about the cloud and what did it enable the world of tech to do , then we dived deeper on what sets Microsoft Azure apart and what we can do with the tools and capabilities it offers.

## Guests

- [Adil Touati](https://www.linkedin.com/in/adiltouati)

- [Abdelmajid ANEDDAME](https://www.linkedin.com/in/abdelmajidaneddame)

- [Otmane Fettal](https://twitter.com/ofettal)

## Notes

0:00:00 - Introduction

0:06:00 - Cloud computing Introduction

0:36:00 - Microsoft Azure Capabilities

1:18:00 - Advanced Microsoft Azure services and capabilities

## Links

## Prepared and Presented by

- [Otmane Fettal](https://twitter.com/ofettal)
