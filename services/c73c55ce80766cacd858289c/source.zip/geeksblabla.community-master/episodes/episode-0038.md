---
date: 2020-05-03
duration: "01:12:40"
title: "MSS with Meriam Kharbat and Ouafae Aamer"
tags: ["MSS", "entrepreneurship", "software engineering"]
category: "mss"
youtube: https://www.youtube.com/watch?v=QCCH7r9CB1g
published: true
featured: false
---

In this episode of GeeksBlabla, we discuss the success story for two young women in the IT field in and outside Morocco.

## Guests

[Meriam Kharbat](https://twitter.com/meriamkharbat)

[Ouafae Aamer](https://www.facebook.com/ouafae.aamer)

## Notes

0:00:00 - Introduction and welcoming

0:05:00 - Education path

0:09:00 - tell us what your day job is

0:19:00 - How long have you been working as Product Manager, Developer

0:22:00 - What do you do besides being a software engineer by day

0:31:00 - how did you get where you are today and how did you come to work at (field intelligence inc )

0:38:00 - What was your childhood dream? was it IT related ?

0:41:00 - What influenced you to pursue a career in IT

0:48:00 - What led you to embark on an international career

1:03:00 - What are some challenges you’ve faced ?

1:12:00 - Are there any particular Moroccan women in tech who have inspired you?

## Links

- [EU Blue Card](https://www.make-it-in-germany.com/en/visa/kinds-of-visa/eu-blue-card/)

- [Meriam blog](https://twitter.com/meriamkharbat)

## Prepared and Presented by

- [Mohammed Aboullaite](https://twitter.com/laytoun)

- [Meriem Zaid](https://twitter.com/_iMeriem)
