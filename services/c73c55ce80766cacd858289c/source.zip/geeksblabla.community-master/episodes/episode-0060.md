---
date: 2020-12-06
duration: "03:25:00"
title: "MSS with Mohamed Youssfi"
tags: ["MSS"]
category: "mss"
youtube: https://www.youtube.com/watch?v=I7FwzqXm-uQ
published: true
---

In this episode of GeeksBlabla, we invited Mohamed Youssfi, one of the most famous university school teachers in morocco, we discuss his experience and IT education in morocco.

## Guests

- [Mohamed Youssfi](https://www.facebook.com/mohamed.youssfi.9)

## Notes

0:00:00 - Introduction and welcoming

0:04:00 - Who is Mohamed Youssfi ?

0:13:00 - Did you plan to be a teacher in your childhood?

0:22:00 - What is the secret behind a successful teacher?

0:30:00 - The story behind Mohammed Youssfi successful youtube channel.

0:46:00 - Why most of the tutorials are related to Java and JEE?

1:00:00 - Getting updated about the latest technologies?

1:10:00 - How to deal with the level of disparity between students?

1:16:00 - What do you think about the height of education in Morocco (IT)?

1:35:00 - Is diplomas important in IT?

1:51:00 - French or English for height school education ?

2:10:00 - The problem of researcher professor not working in technology in the market before teaching it.

2:28:00 - The State Of Dev In Morocco 2020.

2:48:00 - what the first thing you will do if you are the minister of education.

3:04:00 - Pieces of Advice to students.

## Links

## Prepared and Presented by

- [Youssouf EL Azizi](https://elazizi.com)

- [Soufian El Foukahi](https://twitter.com/soufyanAI)
