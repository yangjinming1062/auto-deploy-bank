---
date: 2018-12-26
duration: "1:24:32"
title: "MSS with  Mohamed Zakariae El Khdime!"
tags: ["MSS", "cybersecurity", "entrepreneurship", "career"]
category: "mss"
youtube: https://www.youtube.com/watch?v=XVl0Y-7JZxw
published: true
---

In this episode of GeeksBlabla, we discuss with Mohamed Zakariae El Khdime about his success story.

## Guests

[Mohamed Zakariae El Khdime](https://www.facebook.com/infom2z)

## Notes

00:00:00 - Who is Mohamed Zakariae El Khdime?

00:03:00 - What is your academic background?

00:06:00 - did you study in any public high school?

00:20:00 - How did you switch from developement to security?

00:22:00 - What is cybersecurity?

00:25:00 - Why do hackers always wear hoodies? Behind the stereotype?

00:26:00 - What is your first project in entrepreneurship?

00:31:00 - How to start a career in cybersecurity?

00:33:00 - How to found a startup in Dubai?

00:40:00 - Advice for people who want to found a startup.

00:46:00 - What kind of knowledge and amount of capital required for someone to take on entrepreneurship?

00:51:00 - How did you manage to get funds?

00:59:00 - What are your future plans, and what kind of advice could you give to someone who wants to get into cybersecurity?

01:10:00 - Mohammed Aboullaite: Thanking DevC team and launch DevC projects for 2019

01:24:00 - Goodbye!

## Links

## Prepared and Presented by

[Mohammed Aboullaite](https://twitter.com/laytoun)

[Soufian El Foukahi](https://twitter.com/soufyanAI)
