---
date: 2024-07-21
duration: "2:27:01"
title: "Back to basics"
tags: ["dev"]
category: "dev"
youtube: https://www.youtube.com/watch?v=k9jMvSybyYY
published: true
featured: false
---

In this episode, we will discuss the fundamental skills every developer needs to master. These essentials will help you become a stronger and more proficient developer.

## Guests

- [Marouane Gazanayi](https://www.linkedin.com/in/marouanegazanayi/)
- [Abdelziz eroui](https://www.linkedin.com/in/aeroui/)
- [Slimane Akalie](https://www.linkedin.com/in/slimaneakalie/)
- [Mehdi Cheracher](https://twitter.com/Mehdi_Cheracher)

## Notes

0:00:00 - Introduction and welcoming

0:04:52 - What are the fundamental skills every software engineer needs to master?

0:29:05 - How deeply should I delve into the fundamentals?

0:50:30 - The fundamentals that a back-end developer needs?

1:25:00 - How can I effectively manage the difficulty of learning the fundamentals?

2:03:30 - is the main purpose of school to teach findamentls?

2:16:25 - picks of guests.

## Links

## Prepared and Presented by

- [Adnan MERRAKCHI](https://twitter.com/_admerra)
