---
date: 2019-06-02
duration: "1:09:27"
title: "Serverless"
tags: ["serverless", "dev", "software engineering"]
category: "dev"
youtube: https://www.youtube.com/watch?v=EHkP_ycfdUk
published: true
---

On this episode of Geeksblabla, Abderahim ,Mohammed , Amine and Youssouf Talk about Serverless && Faas, A complete introduction, Pros and Cons And why you should start working with Faas.

## Guests

## Notes

0:00:00 - Introduction

0:05:00 - what is Serverless ?

0:09:00 - Pay as you consume 🤔?

0:15:00 - Serverless limitation

0:20:00 - Pros and Cons

0:30:00 - Can we use serverless for any project ?

0:40:00 - Programing languages and serverless

0:55:00 - Serverless best practices

1:04:00 - Should I use serverless in my next Project ?

## Links

- [Serverless Tools](https://serverless.css-tricks.com)
- [Netlify](https://www.netlify.com/)
- [AWS lambda](https://aws.amazon.com/lambda/)

## Prepared and Presented by
