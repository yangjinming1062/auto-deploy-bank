---
date: 2023-05-07
duration: "0:58:46"
title: "Developer Circles Morocco: A farewell"
tags: ["dev", "career"]
category: "career"
youtube: https://www.youtube.com/watch?v=YhAc4go0qTI
published: true
featured: false
---

In this episode we discuss the end of DevC program initiated by Meta, the impact it had on community growth in Morocco and still, leads and the many advantages of it.

## Guests

- [Mohammed Aboullaite](https://twitter.com/laytoun)
- [Hamza Makraz](https://web.facebook.com/MakrazHamza)

## Notes

0:00:00 - Introduction and welcoming

0:02:40 - A bit of DevC pogram History

0:10:01 - The many meetups held by devC Morocco

0:20:50 - Community of DevC

0:40:48 - In person meetups and organisation

0:45:30 - Connexions made through DevC

0:48:00 - Mentorship within DevC in offline meetups

0:54:40 - Giveaway

0:58:46 - Wrap up & Good bye

## Links

## Prepared and Presented by

- [Meriem zaid](https://twitter.com/_iMeriem)
