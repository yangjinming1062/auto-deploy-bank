---
date: 2020-02-29
duration: "01:32:00"
title: "GeeksBlabla Kids"
tags: ["kids"]
category: "career"
featured: true
youtube: https://www.youtube.com/watch?v=gvve_LEqtbI
published: true
---

A Special episode to encourage youth minds in the coding industry,In this episode of GeeksBlabla Ayman and Achraf, 2 boys under 16, share their story with programming and robotics.

## Guests

- [Achraf Mansari](https://www.facebook.com/itsachrafmansari/)

- [Ayman Riad Solh](#)

## Notes

00:00:00 - Introduction & Guests presentation

00:04:00 - When and how they know Programming ?

00:12:00 - Difficulties encountered & thier solutions

00:16:00 - How they improved their skills?

00:20:00 - Have you ever practiced these skills in competition?

00:25:00 - How do you like the field of information technology?

00:29:00 - How did your family and friends react to you when they know you love programming?

00:34:00 - Do you have some plans to explain your IT knowledge in Darija to your friends , your family , and others kids ?

00:41:00 - How did you get the idea for your projects?

00:46:00 - Your workflow creating new projects?

00:56:00 - Are you thinking about new projects in the future?

00:59:00 - Connected devices (Q:Ayman A:Achraf)

01:02:00 - Do you have plans for your studies (the program) ?

01:07:00 - QA

01:17:00 - What do you expect your parents to improve your technical skills?

01:27:00 - What your advice for kids in your age to start programming?

01:31:00 - Final words and goodbye.

## Links

- [Scratch](http://scratch.mit.edu/)

- [Facebook DevC](https://www.facebook.com/groups/DevC.Casablanca/?hc_ref=ARQQY8zH-NAV8646DsgW8RNoO1DNoBuf-43ao4kIFvZZMJCV4jpw7-hSQ2C0DmFkkdI&ref=nf_target)

## Prepared and Presented by

- [Soufian El Foukahi](https://twitter.com/soufyanAI)

- [Meriem Zaid](https://twitter.com/_iMeriem)
