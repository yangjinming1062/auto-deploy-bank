---
date: 2024-01-07
duration: "2:18:30"
title: "7 Pillars to be comfortable in your Professional Life"
tags: ["career"]
category: "career"
youtube: https://www.youtube.com/watch?v=UKXczSzD2mA
published: true
featured: false
---

In this episode, We discuss 7 Pillars that can helps us lead a more comfortable Work life.

## Guests

- [Mehdi Cheracher](https://twitter.com/Mehdi_Cheracher)

- [Djalal](https://twitter.com/enlamp)

- [Marouane Gazanayi](https://www.linkedin.com/in/marouanegazanayi/)

- [Abdelati El Asri](https://twitter.com/kaizendae)

## Notes

0:00:00 - Introduction and welcoming

0:04:36 - You don't need to know a lot of Programing languages.

0:25:48 - Work is not only about coding.

0:46:50 - You won't use the latest tech in work.

1:09:40 - You can't know everything.

1:29:10 - Coding Bootcamps is a great start towards a path of learning.

1:43:55 - You can't avoid Office politics , and don't forget to live.

2:06:30 - Conclusion and Goodbye

## Links

- [Range Book Review](https://www.youtube.com/watch?v=E2ipt93liok)

## Prepared and Presented by

- [Adnan M'RAKCHI](https://twitter.com/_admerra)
- [Otmane FETTAL](https://twitter.com/ofettal)
