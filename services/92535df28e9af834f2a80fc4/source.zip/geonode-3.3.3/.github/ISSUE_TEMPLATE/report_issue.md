---
name: Report a bug
about: Report a bug or regression for this project
title: ''
labels: ''
assignees: ''

---

## Expected Behavior


## Actual Behavior


## Steps to Reproduce the Problem

  1.
  2.
  3.

## Specifications

  - GeoNode version:
  - Installation method (manual, GeoNode Docker, SPCGeoNode Docker):
  - Platform:
  - Additional details:
