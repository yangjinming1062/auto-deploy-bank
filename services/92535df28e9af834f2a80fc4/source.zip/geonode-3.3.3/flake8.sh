#!/bin/bash
set -e

flake8 geonode
