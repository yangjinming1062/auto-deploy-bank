from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('documents', '0031_auto_20180409_1238'),
    ]

    operations = [
        migrations.AlterModelManagers(
            name='document',
            managers=[
            ],
        ),
    ]
