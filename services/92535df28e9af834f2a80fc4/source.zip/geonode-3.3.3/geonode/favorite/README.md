# Favorite App Plugin

This GeoNode contrib module was contributed by the MapStory project.

Function of the module:
Allow user to favorite content in Document, Layer, Map detail pages.
  - If user is not logged in, tell them to log in if want to use favorites.
  - If user is logged in, provide an 'Add Favorite' button, or a 'Delete Favorite' button.
Allow user to view a favorites list page with delete link for each.
Allow user to link to user favorites list page from each detail and user profile page and user modal list.
