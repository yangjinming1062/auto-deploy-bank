=========
Changelog
=========

The complete changelog can be found at
http://docs.oscarcommerce.com/en/latest/releases/
