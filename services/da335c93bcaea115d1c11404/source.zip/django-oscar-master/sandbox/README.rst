============
Sandbox site
============

This site is deployed there:

https://latest.oscarcommerce.com
-------------------------------

This is a vanilla install of Oscar with as little customisation as possible to
get a basic site working.  It's really intended for local development and QA.

It does have a few customisations:

* A profile model with a few fields, designed to test Oscar's account section
  which should automatically allow the profile fields to be edited.

It is deployed automatically to: https://latest.oscarcommerce.com
