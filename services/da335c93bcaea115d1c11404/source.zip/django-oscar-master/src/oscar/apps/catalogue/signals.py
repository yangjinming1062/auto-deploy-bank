import django.dispatch

product_viewed = django.dispatch.Signal()
