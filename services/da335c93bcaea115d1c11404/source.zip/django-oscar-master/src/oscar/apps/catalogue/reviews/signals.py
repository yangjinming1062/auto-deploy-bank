import django.dispatch

review_added = django.dispatch.Signal()
