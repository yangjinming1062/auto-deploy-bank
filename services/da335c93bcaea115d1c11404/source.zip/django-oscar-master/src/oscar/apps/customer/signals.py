from django.dispatch import Signal

user_registered = Signal()
user_logged_in = Signal()
