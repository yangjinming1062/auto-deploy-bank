default_app_config = "oscar.apps.analytics.apps.AnalyticsConfig"
