default_app_config = "oscar.apps.basket.apps.BasketConfig"
