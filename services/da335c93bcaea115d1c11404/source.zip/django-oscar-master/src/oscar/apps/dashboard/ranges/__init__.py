default_app_config = "oscar.apps.dashboard.ranges.apps.RangesDashboardConfig"
