default_app_config = "oscar.apps.dashboard.vouchers.apps.VouchersDashboardConfig"
