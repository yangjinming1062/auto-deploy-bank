default_app_config = "oscar.apps.dashboard.offers.apps.OffersDashboardConfig"
