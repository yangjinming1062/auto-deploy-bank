default_app_config = "oscar.apps.address.apps.AddressConfig"
