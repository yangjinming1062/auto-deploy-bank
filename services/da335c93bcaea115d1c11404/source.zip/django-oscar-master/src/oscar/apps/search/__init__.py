default_app_config = "oscar.apps.search.apps.SearchConfig"
