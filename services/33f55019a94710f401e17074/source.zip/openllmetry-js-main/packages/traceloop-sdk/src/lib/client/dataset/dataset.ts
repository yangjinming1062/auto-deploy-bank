import { TraceloopClient } from "../traceloop-client";
import { BaseDatasetEntity } from "./base-dataset";
import { Row } from "./row";
import { Column } from "./column";
import * as Papa from "papaparse";
import { Attachment, ExternalAttachment, isAnyAttachment } from "./attachment";
import { AttachmentUploader } from "./attachment-uploader";
import {
  DatasetResponse,
  DatasetUpdateOptions,
  ColumnDefinition,
  RowData,
  DatasetPublishOptions,
  CSVImportOptions,
  ColumnResponse,
  RowResponse,
  DatasetVersionsResponse,
  DatasetVersion,
} from "../../interfaces";

export class Dataset extends BaseDatasetEntity {
  private _data: DatasetResponse;
  private _deleted = false;
  private _attachmentUploader: AttachmentUploader;

  constructor(client: TraceloopClient, data: DatasetResponse) {
    super(client);
    this._data = data;
    this._attachmentUploader = new AttachmentUploader(client);
  }

  get id(): string {
    return this._data.id;
  }

  get slug(): string {
    return this._data.slug;
  }

  get name(): string {
    return this._data.name;
  }

  get description(): string | undefined {
    return this._data.description;
  }

  get version(): string | undefined {
    return this._data.version;
  }

  get published(): boolean {
    return this._data.published || false;
  }

  get createdAt(): string {
    return this._data.createdAt || "";
  }

  get updatedAt(): string {
    return this._data.updatedAt || "";
  }

  get deleted(): boolean {
    return this._deleted;
  }

  async update(options: DatasetUpdateOptions): Promise<void> {
    if (this._deleted) {
      throw new Error("Cannot update a deleted dataset");
    }

    if (options.name) {
      this.validateDatasetName(options.name);
    }

    const response = await this.client.put(
      `/v2/datasets/${this.slug}`,
      options,
    );
    await this.handleResponse(response);
  }

  async delete(): Promise<void> {
    if (this._deleted) {
      throw new Error("Dataset is already deleted");
    }

    const response = await this.client.delete(`/v2/datasets/${this.slug}`);
    await this.handleResponse(response);
    this._deleted = true;
  }

  async publish(options: DatasetPublishOptions = {}): Promise<void> {
    if (this._deleted) {
      throw new Error("Cannot publish a deleted dataset");
    }

    const response = await this.client.post(
      `/v2/datasets/${this.slug}/publish`,
      options,
    );
    const data = await this.handleResponse(response);
    this._data = data;
  }

  async addColumn(columns: ColumnDefinition[]): Promise<Column[]> {
    if (this._deleted) {
      throw new Error("Cannot add columns to a deleted dataset");
    }

    if (!Array.isArray(columns) || columns.length === 0) {
      throw new Error("Columns must be a non-empty array");
    }

    const results: Column[] = [];

    for (const column of columns) {
      if (!column.name || typeof column.name !== "string") {
        throw new Error("Column name is required and must be a string");
      }

      const response = await this.client.post(
        `/v2/datasets/${this.slug}/columns`,
        column,
      );
      const data = await this.handleResponse(response);

      if (!data || !data.slug) {
        throw new Error("Failed to create column: Invalid API response");
      }

      const columnResponse: ColumnResponse = {
        slug: data.slug,
        datasetId: this._data.id,
        datasetSlug: this.slug,
        name: data.name,
        type: data.type,
        required: data.required,
        description: data.description,
        createdAt: data.createdAt,
        updatedAt: data.updatedAt,
      };

      results.push(new Column(this.client, columnResponse));
    }

    return results;
  }

  async getColumns(): Promise<Column[]> {
    if (this._deleted) {
      throw new Error("Cannot get columns from a deleted dataset");
    }

    if (!this._data.columns) {
      return [];
    }

    const columns: Column[] = [];
    for (const [columnSlug, columnData] of Object.entries(this._data.columns)) {
      const col = columnData as any;
      const columnResponse: ColumnResponse = {
        slug: columnSlug,
        datasetId: this._data.id,
        datasetSlug: this.slug,
        name: col.name,
        type: col.type,
        required: col.required === true,
        description: col.description,
        createdAt: this._data.createdAt || this.createdAt,
        updatedAt: this._data.updatedAt || this.updatedAt,
      };
      columns.push(new Column(this.client, columnResponse));
    }

    return columns;
  }

  async addRow(rowData: RowData): Promise<Row> {
    if (this._deleted) {
      throw new Error("Cannot add row to a deleted dataset");
    }

    if (!rowData || typeof rowData !== "object") {
      throw new Error("Row data must be a valid object");
    }

    const rows = await this.addRows([rowData]);
    if (rows.length === 0) {
      throw new Error("Failed to add row");
    }
    return rows[0];
  }

  async addRows(rows: RowData[]): Promise<Row[]> {
    if (this._deleted) {
      throw new Error("Cannot add rows to a deleted dataset");
    }

    if (!Array.isArray(rows)) {
      throw new Error("Rows must be an array");
    }

    const columns = await this.getColumns();
    const columnMap = new Map<string, string>();

    columns.forEach((col) => {
      columnMap.set(col.name, col.slug);
    });

    // Phase 1: Extract attachments and prepare clean rows
    const { cleanRows, attachmentMap } = this.extractAttachments(
      rows,
      columnMap,
    );

    // Phase 2: Create rows with regular data (attachments replaced with null)
    const transformedRows = cleanRows.map((row) => {
      const transformedRow: { [key: string]: any } = {};
      Object.keys(row).forEach((columnName) => {
        const columnSlug = columnMap.get(columnName);
        if (columnSlug) {
          transformedRow[columnSlug] = row[columnName];
        }
      });
      return transformedRow;
    });

    const payload = {
      Rows: transformedRows,
    };

    const response = await this.client.post(
      `/v2/datasets/${this.slug}/rows`,
      payload,
    );
    const result = await this.handleResponse(response);

    const createdRows: Row[] = [];
    if (result.rows) {
      for (const row of result.rows) {
        const rowResponse: RowResponse = {
          id: row.id,
          datasetId: this._data.id,
          datasetSlug: this.slug,
          data: this.transformValuesBackToNames(row.values, columnMap),
          createdAt: row.created_at,
          updatedAt: row.updated_at,
        };
        createdRows.push(new Row(this.client, rowResponse));
      }
    }

    // Phase 3: Process attachments for created rows
    if (attachmentMap.size > 0) {
      await this.processAttachments(createdRows, attachmentMap, columnMap);
    }

    return createdRows;
  }

  /**
   * Extracts attachments from rows and returns clean rows with null values
   */
  private extractAttachments(
    rows: RowData[],
    columnMap: Map<string, string>,
  ): {
    cleanRows: RowData[];
    attachmentMap: Map<number, Map<string, Attachment | ExternalAttachment>>;
  } {
    const attachmentMap = new Map<
      number,
      Map<string, Attachment | ExternalAttachment>
    >();
    const cleanRows: RowData[] = [];

    rows.forEach((row, rowIndex) => {
      const cleanRow: RowData = {};
      const rowAttachments = new Map<string, Attachment | ExternalAttachment>();

      Object.keys(row).forEach((columnName) => {
        const value = row[columnName];
        const columnSlug = columnMap.get(columnName);

        if (isAnyAttachment(value) && columnSlug) {
          // Store attachment for later processing
          rowAttachments.set(columnSlug, value);
          // Replace with null in the clean row
          cleanRow[columnName] = null;
        } else {
          cleanRow[columnName] = value;
        }
      });

      cleanRows.push(cleanRow);

      if (rowAttachments.size > 0) {
        attachmentMap.set(rowIndex, rowAttachments);
      }
    });

    return { cleanRows, attachmentMap };
  }

  /**
   * Processes attachments for created rows
   */
  private async processAttachments(
    rows: Row[],
    attachmentMap: Map<number, Map<string, Attachment | ExternalAttachment>>,
    columnMap: Map<string, string>,
  ): Promise<void> {
    // Create reverse map for slug to name lookup
    const reverseColumnMap = new Map<string, string>();
    columnMap.forEach((slug, name) => {
      reverseColumnMap.set(slug, name);
    });

    for (const [rowIndex, rowAttachments] of attachmentMap) {
      const row = rows[rowIndex];
      if (!row) continue;

      for (const [columnSlug, attachment] of rowAttachments) {
        try {
          const reference = await this._attachmentUploader.processAnyAttachment(
            this.slug,
            row.id,
            columnSlug,
            attachment,
          );

          // Update the row's internal data with the attachment reference
          const columnName = reverseColumnMap.get(columnSlug);
          if (columnName) {
            (row as any)._data.data[columnName] = reference.toJSON();
          }
        } catch (error) {
          // Log warning but don't fail the entire operation
          console.warn(
            `Failed to process attachment for row ${row.id}, column ${columnSlug}:`,
            error,
          );
        }
      }
    }
  }

  private transformValuesBackToNames(
    values: { [columnSlug: string]: any },
    columnMap: Map<string, string>,
  ): RowData {
    const result: RowData = {};

    const reverseMap = new Map<string, string>();
    columnMap.forEach((slug, name) => {
      reverseMap.set(slug, name);
    });

    Object.keys(values).forEach((columnSlug) => {
      const columnName = reverseMap.get(columnSlug);
      if (columnName) {
        result[columnName] = values[columnSlug];
      }
    });

    return result;
  }

  async getRows(limit = 100, offset = 0): Promise<Row[]> {
    if (this._deleted) {
      throw new Error("Cannot get rows from a deleted dataset");
    }

    const response = await this.client.get(
      `/v2/datasets/${this.slug}/rows?limit=${limit}&offset=${offset}`,
    );
    const data = await this.handleResponse(response);

    const rows = data.rows || [];
    return rows.map((row: any) => {
      const rowResponse: RowResponse = {
        id: row.id,
        datasetId: this._data.id,
        datasetSlug: this.slug,
        data: row.values || row.data || {},
        createdAt: row.created_at,
        updatedAt: row.updated_at,
      };
      return new Row(this.client, rowResponse);
    });
  }

  async fromCSV(
    csvContent: string,
    options: CSVImportOptions = {},
  ): Promise<void> {
    if (this._deleted) {
      throw new Error("Cannot import CSV to a deleted dataset");
    }

    const { hasHeader = true, delimiter = "," } = options;

    if (!csvContent || typeof csvContent !== "string") {
      throw new Error("CSV content must be a valid string");
    }

    const rows = this.parseCSV(csvContent, delimiter, hasHeader);

    if (rows.length === 0) {
      throw new Error("No data found in CSV");
    }

    const batchSize = 100;
    for (let i = 0; i < rows.length; i += batchSize) {
      const batch = rows.slice(i, i + batchSize);
      await this.addRows(batch);
    }
  }

  async getVersions(): Promise<DatasetVersionsResponse> {
    if (this._deleted) {
      throw new Error("Cannot get versions of a deleted dataset");
    }

    const response = await this.client.get(
      `/v2/datasets/${this.slug}/versions`,
    );
    return await this.handleResponse(response);
  }

  async getVersion(version: string): Promise<DatasetVersion | null> {
    if (this._deleted) {
      throw new Error("Cannot get version of a deleted dataset");
    }

    const versionsData = await this.getVersions();
    return versionsData.versions.find((v) => v.version === version) || null;
  }

  private parseCSV(
    csvContent: string,
    delimiter: string,
    hasHeader: boolean,
  ): RowData[] {
    const parseResult = Papa.parse(csvContent, {
      delimiter,
      header: hasHeader,
      skipEmptyLines: true,
      transformHeader: (header: string) => header.trim(),
      transform: (value: string) => this.parseValue(value.trim()),
    });

    if (parseResult.errors.length > 0) {
      throw new Error(`CSV parsing failed: ${parseResult.errors[0].message}`);
    }

    return parseResult.data as RowData[];
  }

  private parseValue(value: string): string | number | boolean | null {
    if (value === "" || value.toLowerCase() === "null") {
      return null;
    }

    if (value.toLowerCase() === "true") {
      return true;
    }

    if (value.toLowerCase() === "false") {
      return false;
    }

    const numValue = Number(value);
    if (!isNaN(numValue) && isFinite(numValue)) {
      return numValue;
    }

    return value;
  }
}
