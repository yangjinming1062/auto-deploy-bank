export interface TraceloopClientOptions {
  apiKey: string;
  appName: string;
  baseUrl?: string;
  experimentSlug?: string;
}
