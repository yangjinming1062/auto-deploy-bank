# 手势控制音量



硬件：

* windows 11
* macOS 

软件：

* python 3.7
* mediapipe

运行方法

`$ pip3 install -r requirements.txt`

`$ cd codes`

根据需要运行代码，如

Windows: `$ python 6.hand_control_volume.py`

macOS : `python 6.hand_control_volume_mac.py`



### 微信技术交流、问题反馈：

<img src="https://enpei-md.oss-cn-hangzhou.aliyuncs.com/imgIMG_5862.JPG?x-oss-process=style/wp" style="width:200px;" />

