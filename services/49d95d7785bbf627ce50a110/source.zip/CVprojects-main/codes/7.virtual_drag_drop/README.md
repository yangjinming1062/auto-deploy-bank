# 手势虚拟拖拽



硬件：

* windows 11

软件：

* python 3.7
* mediapipe

运行方法

`$ pip3 install -r requirements.txt`

`$ cd codes`

根据需要运行代码，如

 `$ python 7.virtual_drag_drop.py`





### 微信技术交流、问题反馈：

<img src="https://enpei-md.oss-cn-hangzhou.aliyuncs.com/imgIMG_5862.JPG?x-oss-process=style/wp" style="width:200px;" />

