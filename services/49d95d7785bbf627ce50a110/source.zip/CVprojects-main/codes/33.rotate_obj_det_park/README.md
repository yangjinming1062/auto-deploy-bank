# 32.realsense dobot 机械臂视觉抓取

![](https://enpei-md.oss-cn-hangzhou.aliyuncs.com/img202306171012021.png?x-oss-process=style/wp)





## 一、硬件：

* USB camera
* windows or ubuntu

## 二、软件环境安装：

* opencv
* Paddle paddle

## 三、用法：

* 下载权重`33.output_inference_vel.zip`，解压到项目根目录，[下载地址](https://github.com/enpeizhao/CVprojects/releases)
* 运行`demo.py`

### 微信技术交流、问题反馈：

<img src="https://enpei-md.oss-cn-hangzhou.aliyuncs.com/imgIMG_5862.JPG?x-oss-process=style/wp" style="width:200px;" />

