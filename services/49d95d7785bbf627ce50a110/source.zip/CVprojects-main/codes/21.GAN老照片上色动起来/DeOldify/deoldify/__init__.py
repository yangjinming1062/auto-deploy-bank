from deoldify._device import _Device

device = _Device()