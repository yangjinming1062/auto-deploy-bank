# 手势控制电视



硬件：

* MACOS
* jetson xavier NX
* 极米极光投影

软件：

* python 3.7
* mediapipe
* home assistant

运行方法

`$ pip3 install -r requirements.txt`

`$ cd codes`

根据需要运行代码，如

`$ python handRemote.py`





### 微信技术交流、问题反馈：

<img src="https://enpei-md.oss-cn-hangzhou.aliyuncs.com/imgIMG_5862.JPG?x-oss-process=style/wp" style="width:200px;" />

