const message = {
  demo: {
    label: {
      text: "获取到Demo对象",
      edit: "编辑",
    },
  },
};
export default {
  ...message,
};
