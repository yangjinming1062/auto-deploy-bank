export interface DemoObject {
  name?: string;
  value?: string;
}
