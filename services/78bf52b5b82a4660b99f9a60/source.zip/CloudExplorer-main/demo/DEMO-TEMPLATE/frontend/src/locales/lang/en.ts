const message = {
  demo: {
    label: {
      text: "Demo Object",
      edit: "EDIT",
    },
  },
};
export default {
  ...message,
};
