const message = {
  demo: {
    label: {
      text: "獲取到Demo對象",
      edit: "編輯",
    },
  },
};
export default {
  ...message,
};
