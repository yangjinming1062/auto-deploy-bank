package org.openstack4j.api.gbp;

/**
 * This interface defines all methods for the manipulation of service chain
 *
 * @author vinod borole
 */
public interface ServicechainService {

}
