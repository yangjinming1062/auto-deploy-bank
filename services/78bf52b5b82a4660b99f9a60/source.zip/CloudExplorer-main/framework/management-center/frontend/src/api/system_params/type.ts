interface RecycleParams {
  recycleBinEnable: boolean;
  metricLogReservedMonth: number;
  loginLogReservedMonth: number;
  manageLogReservedMonth: number;
  systemLogReservedMonth: number;
}

export type { RecycleParams };
