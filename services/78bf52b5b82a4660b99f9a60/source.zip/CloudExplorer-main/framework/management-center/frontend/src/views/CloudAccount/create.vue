<script setup lang="ts">
import CreateCloudAccount from "@commons/business/cloud-account/CreateCloudAccount.vue";
</script>
<template>
  <el-container style="padding: 24px; height: 100%">
    <CreateCloudAccount :show-aside="false" />
  </el-container>
</template>

<style lang="scss"></style>
