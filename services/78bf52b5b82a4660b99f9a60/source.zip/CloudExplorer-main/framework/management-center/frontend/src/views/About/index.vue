<script setup lang="ts">
import AboutView from "@commons/business/about/AboutView.vue";
</script>
<template>
  <AboutView />
</template>

<style lang="scss" scoped></style>
