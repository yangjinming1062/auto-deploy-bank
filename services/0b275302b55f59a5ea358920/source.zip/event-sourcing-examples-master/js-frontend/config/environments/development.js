export default {
  identityProperty: 'APP_IDENTITY',
}
