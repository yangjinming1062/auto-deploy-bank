/**
 * Created by andrew on 18/03/16.
 */
export const bookmarkAccount = (state = {}, action) => {
  switch (action.type) {
    default:
      return state;
  }
};