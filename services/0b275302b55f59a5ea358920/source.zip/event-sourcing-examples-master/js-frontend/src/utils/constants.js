/**
 * Created by andrew on 26/02/16.
 */
export const INITIAL_CONFIG_KEY = "default";
export const DEFAULT_CONFIG_KEY = "defaultConfigKey";
export const SAVED_CONFIG_KEY   = "currentConfigName";
export const SAVED_CREDS_KEY    = "authHeaders";
export const SAVED_USER_INFO    = "user-info";