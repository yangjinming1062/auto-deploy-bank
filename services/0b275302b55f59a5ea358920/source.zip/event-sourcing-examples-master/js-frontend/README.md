# Money Transfer App - Frontend Client

This..

## Happiness is six lines away

*Prerequisites: node.js and git*

```
cd js-frontend
npm install
npm run build
```

Text..
