@net.chrisrichardson.eventstore.EventEntity(entity="net.chrisrichardson.eventstore.examples.bank.accounts.Account")
package net.chrisrichardson.eventstore.examples.bank.backend.common.accounts;