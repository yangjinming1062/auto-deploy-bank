package net.chrisrichardson.eventstore.examples.bank.web.accounts.controllers

case class CreateAccountRequest(initialBalance : BigDecimal)
