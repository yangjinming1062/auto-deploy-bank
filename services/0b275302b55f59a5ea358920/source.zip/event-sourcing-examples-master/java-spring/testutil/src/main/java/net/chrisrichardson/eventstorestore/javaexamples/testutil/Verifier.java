package net.chrisrichardson.eventstorestore.javaexamples.testutil;

public interface Verifier<T> {
  public void verify(T x);
}
