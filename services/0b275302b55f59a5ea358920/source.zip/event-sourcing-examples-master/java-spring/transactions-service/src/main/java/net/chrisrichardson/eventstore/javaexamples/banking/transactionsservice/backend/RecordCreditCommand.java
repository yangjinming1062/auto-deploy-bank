package net.chrisrichardson.eventstore.javaexamples.banking.transactionsservice.backend;

public class RecordCreditCommand implements MoneyTransferCommand {
}
