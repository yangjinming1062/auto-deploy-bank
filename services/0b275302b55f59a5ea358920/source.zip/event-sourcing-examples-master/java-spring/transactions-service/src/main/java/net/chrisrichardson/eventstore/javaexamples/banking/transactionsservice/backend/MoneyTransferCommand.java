package net.chrisrichardson.eventstore.javaexamples.banking.transactionsservice.backend;

import io.eventuate.Command;

interface MoneyTransferCommand extends Command {
}
