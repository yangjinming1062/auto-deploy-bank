package net.chrisrichardson.eventstore.javaexamples.banking.backend.common.accounts;

public class AccountDeletedEvent extends AccountEvent {
}
