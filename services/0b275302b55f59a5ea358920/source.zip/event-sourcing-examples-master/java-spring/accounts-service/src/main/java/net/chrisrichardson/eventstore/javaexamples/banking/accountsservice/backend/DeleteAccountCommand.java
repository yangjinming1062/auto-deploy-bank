package net.chrisrichardson.eventstore.javaexamples.banking.accountsservice.backend;

public class DeleteAccountCommand implements AccountCommand {
}
