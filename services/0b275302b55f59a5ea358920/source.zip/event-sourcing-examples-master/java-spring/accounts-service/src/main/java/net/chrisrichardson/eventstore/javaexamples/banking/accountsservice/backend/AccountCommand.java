package net.chrisrichardson.eventstore.javaexamples.banking.accountsservice.backend;


import io.eventuate.Command;

interface AccountCommand extends Command {
}
