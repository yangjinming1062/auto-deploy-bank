package net.chrisrichardson.eventstore.javaexamples.banking.customersservice.backend;

import io.eventuate.Command;

interface CustomerCommand extends Command {
}
