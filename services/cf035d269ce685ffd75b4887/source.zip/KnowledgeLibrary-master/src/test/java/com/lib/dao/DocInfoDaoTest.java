package com.lib.dao;

import static org.junit.Assert.*;

import org.junit.Test;

public class DocInfoDaoTest {

	@Test
	public void testInsert() {
		fail("Not yet implemented");
	}

	@Test
	public void testDelete() {
		fail("Not yet implemented");
	}

	@Test
	public void testFindById() {
		fail("Not yet implemented");
	}

	@Test
	public void testFindAllByUserId() {
		fail("Not yet implemented");
	}

}
