---
navigation_title: "Known issues"

---

# Elasticsearch Apache Hadoop known issues [elasticsearch-apache-hadoop-known-issues]

% Use the following template to add entries to this page.

% :::{dropdown} Title of known issue
% **Details** 
% On [Month/Day/Year], a known issue was discovered that [description of known issue].

% **Workaround** 
% Workaround description.

% **Resolved**
% On [Month/Day/Year], this issue was resolved.

:::