---
mapped_pages:
  - https://www.elastic.co/guide/en/elasticsearch/hadoop/current/resources.html
navigation_title: Resources
---
# {{esh-full}} resources

Project home page
:   [GitHub](http://github.com/elasticsearch/elasticsearch-hadoop)

Source repository
:   [GitHub](http://github.com/elasticsearch/elasticsearch-hadoop)

Issue tracker
:   [GitHub](http://github.com/elasticsearch/elasticsearch-hadoop/issues)

Mailing list / forum
:   [Google Groups](https://groups.google.com/forum/?fromgroups#!forum/elasticsearch) - please add `[Hadoop]` prefix to the topic message

Twitter
:   [Elasticsearch](http://twitter.com/elasticsearch), [Costin Leau](http://twitter.com/costinl)

{{es}} community page
:   [community](http://www.elastic.co/community/)

{{es}} resources page
:   [documentation](http://www.elastic.co/learn)

