---
navigation_title: Setup and requirements
mapped_pages:
  - https://www.elastic.co/guide/en/elasticsearch/hadoop/current/doc-sections.html#_setup_requirements
---
# {{esh-full}} setup and requirements

This section provides an overview of the project, its requirements (and supported environment and libraries) plus information on how to easily install elasticsearch-hadoop in your environment.
