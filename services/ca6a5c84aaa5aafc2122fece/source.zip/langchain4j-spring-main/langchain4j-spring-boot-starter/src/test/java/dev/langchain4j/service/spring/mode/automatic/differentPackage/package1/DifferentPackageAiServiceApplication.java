package dev.langchain4j.service.spring.mode.automatic.differentPackage.package1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DifferentPackageAiServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(DifferentPackageAiServiceApplication.class, args);
    }
}