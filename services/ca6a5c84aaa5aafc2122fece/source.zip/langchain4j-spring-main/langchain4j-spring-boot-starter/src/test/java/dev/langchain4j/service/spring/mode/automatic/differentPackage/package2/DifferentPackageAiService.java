package dev.langchain4j.service.spring.mode.automatic.differentPackage.package2;

import dev.langchain4j.service.spring.AiService;

@AiService
public interface DifferentPackageAiService {

    String chat(String userMessage);
}