package dev.langchain4j.service.spring.mode.automatic.withStructuredOutput;

public record Person(String name, int age) {
}
