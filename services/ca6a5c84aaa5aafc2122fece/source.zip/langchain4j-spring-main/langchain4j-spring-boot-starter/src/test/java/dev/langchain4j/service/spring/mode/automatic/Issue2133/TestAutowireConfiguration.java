package dev.langchain4j.service.spring.mode.automatic.Issue2133;

import org.springframework.context.annotation.Configuration;

/**
 * @author: qing
 * @Date: 2024/11/20
 */
@Configuration
class TestAutowireConfiguration {
}
