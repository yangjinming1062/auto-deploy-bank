package dev.langchain4j.service.spring.mode;

public class ApiKeys {

    public static final String OPENAI_API_KEY = System.getenv("OPENAI_API_KEY");

}
