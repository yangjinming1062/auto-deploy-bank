package dev.langchain4j.service.spring.mode.explicit.multiple;

interface BaseAiService {

    String chat(String userMessage);
}
