package dev.langchain4j.rag.spring;

record RetrievalProperties(Integer maxResults, Double minScore) {
}
