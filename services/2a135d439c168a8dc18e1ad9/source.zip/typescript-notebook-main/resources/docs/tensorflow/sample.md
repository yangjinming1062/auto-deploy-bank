# Use tensorflow.js along with [tensorflow visualizations](https://www.npmjs.com/package/@tensorflow/tfjs-vis) within node.js

Use tensorflow.js to train your models and create rich visualizations using [@tensorflow/tfjs-vis](https://www.npmjs.com/package/@tensorflow/tfjs-vis) in node.js environments just as you would in the browser environment.

![mnist](https://raw.githubusercontent.com/DonJayamanne/typescript-notebook/main/resources/docs/tensorflow/mnist.png)
