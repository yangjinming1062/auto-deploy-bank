# Sample notebooks

Use the command [Notebook: Open a sample node.js notebook](command:node.notebook.sample) to select from a number of available sample notebooks.
Sample notebooks cover various features such as:
* Tensorflow.js training
* Tensorflow.js visualizations
* Rich outputs
* Plotly plots
* Danfo.js (dataframes & plots)
* Shell scripts
* Tips n tricks for best experience in notebooks
