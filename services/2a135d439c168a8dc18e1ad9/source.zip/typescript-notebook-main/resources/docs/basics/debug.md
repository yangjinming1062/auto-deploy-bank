# Debugging

Debug javascript and typescript without installing typescript.
Add a breakpoint and then either,
* Click on the `Debug Cell` dropdown menu next to the `Run` icon.
* Or click on the `Debug Notebook` icon found on the top right (Editor toolbar).

**Option 1**
![Option1](https://raw.githubusercontent.com/DonJayamanne/typescript-notebook/main/resources/docs/basics/debugCell.gif)

**Option 2**
![Option2](https://raw.githubusercontent.com/DonJayamanne/typescript-notebook/main/resources/docs/basics/debugToolbar.gif)
