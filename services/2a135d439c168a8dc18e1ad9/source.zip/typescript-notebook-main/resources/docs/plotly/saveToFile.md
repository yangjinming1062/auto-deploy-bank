# Save a plot directly to a file

1. Create a file with the extension `*.nnb` (e.g. `sample.nnb`)
2. Add the following code and run it

![Sample](https://raw.githubusercontent.com/DonJayamanne/typescript-notebook/main/resources/docs/plotly/saveToFile.png)
