`ts-node` is shipped with this extension.
All of `node_modules` is what is required to get `ts-node` up and running.
