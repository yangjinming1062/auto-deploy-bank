export enum CellExecutionState {
    notExecutedEmptyCell = 'notExecutedEmptyCell',
    success = 'success',
    error = 'error'
}
