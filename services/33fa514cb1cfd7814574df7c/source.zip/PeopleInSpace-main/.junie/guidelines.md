# Project Guidelines

## Building the Project
When building this project Junie should use the following Gradle task:
```
:common:compileDebugSources 
```
