accelerate launch train_t2v_lora.py \
only_val=True \
num_only_val_itrs=1 \
val_batch_size=1