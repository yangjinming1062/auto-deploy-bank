# 使用说明：create-branch

本技能用于在 `VChart` 项目中快速创建一个符合命名规范的、干净的开发分支。

## 何时使用

- **开始新任务**: 当你准备开始一个新功能、修复一个 bug 或进行任何需要独立分支的工作时，使用此技能可以确保你从一个与 `develop` 同步的、命名规范的分支开始。

## 示例对话

> **你**: “我想开始一个关于图例性能优化的工作，请帮我创建一个开发分支。”
>
> **Agent**: “好的，请为你的分支提供一个 `topic`。”
>
> **你**: “topic 是 `perf-legend-opt`”
>
> **Agent**: (执行技能) “分支 `chore/trae-perf-legend-opt-20260105-1130` 已创建并切换成功。你现在可以在这个新分支上开始工作了。”

## 关键参数

- `topic`: **(必填)** 分支的主题，将成为分支名的一部分。例如 `feature-new-axis`。
- `baseBranch`: 新分支基于哪个分支创建，默认为 `develop`。
- `branchPrefix`: 分支名的前缀，默认为 `chore/trae`。

## 注意事项

- **干净的工作区**: 建议在执行此技能前，先提交或储藏你的本地变更，因为 `git checkout` 操作可能会覆盖未提交的改动。
- 本技能只负责创建和切换分支，不处理任何代码的提交或合并。

## 命名规范与推送建议

- 推荐前缀：`feat/`、`fix/`、`docs/`、`perf/`、`refactor/`、`chore/trae-<topic>-<YYYYMMDD-HHmm>`
- 建议在创建后立即推送以建立远程跟踪关系：
  ```bash
  git push -u origin <new-branch>
  ```
- 如需调整远程地址或默认分支，使用：
  ```bash
  git remote -v
  git remote set-url origin https://github.com/VisActor/VChart.git
  ```
