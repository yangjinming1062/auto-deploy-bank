# Chart History

## How to Run

1. Run the following commands:

```bash
rush update
rush docs
```

2. Access this URL in a browser: http://localhost:3020/assets/demos/chart-history/index.html
