export const pageKey = '1976';
