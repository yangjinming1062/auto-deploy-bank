export const CONTAINER_WIDTH = 1080;
export const CONTAINER_HEIGHT = 1920;

export const page01YearDuration = 2500;
export const page02TitleDuration = 2000;
export const page02EventDuration = 1500;
