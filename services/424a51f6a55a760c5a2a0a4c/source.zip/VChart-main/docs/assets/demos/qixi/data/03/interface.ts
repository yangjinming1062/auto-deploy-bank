export interface Page03OriginalData {
  [word: string]: number;
}
