import { page01 } from './01/data';
import { page02 } from './02/data';
import { page03 } from './03/data';

export const data = {
  page01,
  page02,
  page03
};
