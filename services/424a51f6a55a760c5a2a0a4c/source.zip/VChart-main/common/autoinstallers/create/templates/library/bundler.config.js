
module.exports = {
  formats: ["cjs", "es", "umd"],
};
