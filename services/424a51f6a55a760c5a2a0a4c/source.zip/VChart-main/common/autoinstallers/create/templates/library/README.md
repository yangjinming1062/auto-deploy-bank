# @{{scope}}/{{projectName}}

## Description

{{description}}

## Usage

```typescript
import { xxx } from '@{{scope}}/{{projectName}}';
```
