---
name: Ecosystem CI Participant issue
about: Used for Quarkus extensions participating in https://github.com/quarkusio/quarkus-ecosystem-ci
title: "[CI] - <participant> - Quarkus <branch>"
labels: triage/ci-participant
assignees: ''

---

This issue will be open and closed dependent on the state of <participant repo url> building against Quarkus main snapshot.

If you have interest in being notified of this subscribe to the issue.
