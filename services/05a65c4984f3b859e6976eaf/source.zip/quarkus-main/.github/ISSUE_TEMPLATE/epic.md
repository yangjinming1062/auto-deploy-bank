---
name: Epic
about: " A large piece of work requiring high-level visibility and planning"
title: ''
labels: kind/epic
assignees: ''

---

### Description

(A high level description of the work)

### Analysis

(links to analysis docs containing architecture design work, requirements gathering, etc)

<!-- task list will be automatically generated from below. 
     Just add issue references, i.e. #23, #458 and it will
     be picked up.
 >
<!-- EPIC:DATA
     
-->
