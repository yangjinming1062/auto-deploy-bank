package io.quarkus.builder;

final class FinalStep implements BuildStep {
    @Override
    public void execute(final BuildContext context) {

    }
}
