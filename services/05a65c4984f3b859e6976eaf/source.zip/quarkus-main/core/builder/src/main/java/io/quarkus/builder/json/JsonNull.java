package io.quarkus.builder.json;

/**
 * @deprecated since 3.31.0 in favor of {@link io.quarkus.bootstrap.json.JsonNull}
 */
@Deprecated(forRemoval = true)
public enum JsonNull implements JsonValue {
    INSTANCE;
}
