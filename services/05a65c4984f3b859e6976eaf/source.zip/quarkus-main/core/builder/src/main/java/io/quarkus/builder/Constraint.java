package io.quarkus.builder;

enum Constraint {
    REAL,
    ORDER_ONLY,
}
