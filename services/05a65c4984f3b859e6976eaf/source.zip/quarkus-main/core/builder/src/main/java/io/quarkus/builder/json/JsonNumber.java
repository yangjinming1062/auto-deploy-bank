package io.quarkus.builder.json;

/**
 * @deprecated since 3.31.0 in favor of {@link io.quarkus.bootstrap.json.JsonNumber}
 */
@Deprecated(forRemoval = true)
public interface JsonNumber extends JsonValue {
}
