package io.quarkus.deployment.index;

public class ConstPoolPredicate {
}
