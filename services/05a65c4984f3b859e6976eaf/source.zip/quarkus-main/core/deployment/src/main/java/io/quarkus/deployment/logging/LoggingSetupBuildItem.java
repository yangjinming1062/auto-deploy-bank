package io.quarkus.deployment.logging;

import io.quarkus.builder.item.SimpleBuildItem;

public final class LoggingSetupBuildItem extends SimpleBuildItem {
}
