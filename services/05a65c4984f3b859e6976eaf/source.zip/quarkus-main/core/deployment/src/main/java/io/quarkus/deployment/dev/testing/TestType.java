package io.quarkus.deployment.dev.testing;

public enum TestType {
    UNIT,
    QUARKUS_TEST,
    ALL
}
