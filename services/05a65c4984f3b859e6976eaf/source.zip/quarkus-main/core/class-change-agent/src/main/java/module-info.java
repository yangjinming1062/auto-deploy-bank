module io.quarkus.changeagent {
    exports io.quarkus.changeagent;

    requires transitive java.instrument;
}