.. role:: hidden
    :class: hidden-section

Experiment and ModelBundle
==========================

.. currentmodule:: poutyne

Experiment function
-------------------

.. function:: Experiment

    Alias of :func:`ModelBundle.from_network() <ModelBundle.from_network()>`.

ModelBundle class
-----------------

.. autoclass:: ModelBundle
    :members:
