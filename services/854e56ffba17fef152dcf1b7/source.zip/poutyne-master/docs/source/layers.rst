.. role:: hidden
    :class: hidden-section

Layers
======

.. currentmodule:: poutyne

Poutyne provides utility layers that can be used with the ``Sequential`` module,
``ModuleList`` module and others.

.. autoclass:: Lambda
