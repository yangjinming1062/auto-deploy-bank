.. role:: hidden
    :class: hidden-section

.. _models:

Model
=====

.. currentmodule:: poutyne

.. autoclass:: Model
    :members:
