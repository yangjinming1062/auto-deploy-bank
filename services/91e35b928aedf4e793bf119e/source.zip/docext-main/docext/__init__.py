from __future__ import annotations

from dotenv import load_dotenv

load_dotenv()
