# Empty file to make docext.app a Python package
from __future__ import annotations
