# Empty file to make docext.core a Python package
from __future__ import annotations
