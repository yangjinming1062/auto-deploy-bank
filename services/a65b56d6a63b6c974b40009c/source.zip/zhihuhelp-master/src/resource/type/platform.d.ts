import * as Platform_Consts from '~/src/resource/const/platform'

export type Type_Platform = typeof Platform_Consts.Const_Platform_知乎
