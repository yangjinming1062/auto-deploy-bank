export const Const_Platform_知乎 = 'zhihu' as const
