export type Record = {
  type: 'question' | string
  id: 32314049 | number
  title: 'Web 前端怎样入门？' | string
  question_type: 'normal' | string
  created: 1437189815 | number
  updated_time: 1528027391 | number
  url: 'https://api.zhihu.com/questions/32314049' | string
  answer_count: 106 | number
  follower_count: 5101 | number
  excerpt: 'css+html5+javascript同时学的模式对吗？' | string
  detail: 'css+html5+javascript同时学的模式对吗？' | string
  relationship: {}
}
