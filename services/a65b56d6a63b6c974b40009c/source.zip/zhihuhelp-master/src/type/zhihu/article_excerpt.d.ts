export type Record = {
  updated: 1549277900 | number
  is_labeled: false | boolean
  excerpt:
    | '<img src="https://pic2.zhimg.com/v2-734508f9fcc73c9dd1c6ad29f73743bd_200x112.jpg" data-caption="------每天晚上 · 一起看趣味科学------" data-size="normal" data-rawwidth="300" data-rawheight="300" data-watermark="" data-original-src="" data-watermark-src="" data-private-watermark-src="" class="origin_image inline-img zh-lightbox-thumb" data-original="https://pic2.zhimg.com/v2-734508f9fcc73c9dd1c6ad29f73743bd_r.jpg">今天是除夕，过了今晚我们就算是真真正正地踏入了2019了。说起来，每年年初国家都会发布新一年的放假安排，而今年放假安排刚下来的时候，网上纷纷讨论起了另一件事：<b>2262年我们有两个春节</b>。 <b>为什么一年里会出现两个春节呢</b>？我们先来看看2262年的日历： 我们…'
    | string
  admin_closed_comment: false | boolean
  id: '56254270' | string
  voteup_count: 41 | number
  title_image: 'https://pic4.zhimg.com/v2-bbe00c929d85902d26b805dd6a0d0cdc_b.jpg' | string
  title: '告诉大家一个好消息，2262年可以过两个春节！' | string
  url: 'https://zhuanlan.zhihu.com/p/56254270' | string
  comment_permission: 'all' | string
  author: {
    is_followed: false | boolean
    avatar_url_template: 'https://pic4.zhimg.com/v2-cba887679509294b7b929970e9038056_{size}.jpg' | string
    uid: '856466662591987712' | string
    user_type: 'people' | string
    is_following: false | boolean
    type: 'people' | string
    url_token: 'kuang-wan-35-41' | string
    id: '5f33ef832172f703f4434ca4e2b7a0b4' | string
    description: '微信公众号：狂丸科学，获取科学学习资源' | string
    name: '狂丸科学' | string
    is_advertiser: false | boolean
    headline: '微信公众号：狂丸科学，获取科学学习资源' | string
    gender: 1 | number
    url: '/people/5f33ef832172f703f4434ca4e2b7a0b4' | string
    avatar_url: 'https://pic4.zhimg.com/v2-cba887679509294b7b929970e9038056_l.jpg' | string
    is_org: false | boolean
    badge: []
  }
  state: 'published' | string
  created: 1549277900 | number
  comment_count: 20 | number
  image_url: 'https://pic4.zhimg.com/v2-bbe00c929d85902d26b805dd6a0d0cdc_b.jpg' | string
  excerpt_title: '' | string
  voting: 0 | number
  type: 'article' | string
}
