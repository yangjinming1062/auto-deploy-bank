// 元素类型
export const Const_Type_Question = 'question' as const
export const Const_Type_Pin = 'pin' as const
export const Const_Type_Article = 'article' as const

// 记录类型
export const Const_Record_Type_Answer = 'answer' as const
export const Const_Record_Type_Pin = 'pin' as const
export const Const_Record_Type_Article = 'article' as const
