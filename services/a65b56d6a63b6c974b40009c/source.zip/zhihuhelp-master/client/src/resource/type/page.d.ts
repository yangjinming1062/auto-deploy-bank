import * as Consts from '../const/page'

export type Type_Page_Url =
  | typeof Consts.Const_Page_任务管理
  | typeof Consts.Const_Page_数据浏览
  | typeof Consts.Const_Page_登录
  | typeof Consts.Const_Page_运行日志
