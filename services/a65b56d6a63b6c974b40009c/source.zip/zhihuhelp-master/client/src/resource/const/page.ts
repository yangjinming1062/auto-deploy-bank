export const Const_Page_任务管理 = 'customer_task' as const
export const Const_Page_运行日志 = 'runtime_log' as const
export const Const_Page_数据浏览 = 'db_explorer' as const
export const Const_Page_登录 = 'login' as const

export const Const_Page_Title = {
  [Const_Page_任务管理]: '任务管理',
  [Const_Page_运行日志]: '运行日志',
  [Const_Page_数据浏览]: '数据浏览',
  [Const_Page_登录]: '登录',
}
