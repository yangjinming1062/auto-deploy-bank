package com.moke.wp.wx_weimai.config.exception;

public class QQMapException extends Exception {

    public QQMapException(String msg){
        super(msg);
    }

}
