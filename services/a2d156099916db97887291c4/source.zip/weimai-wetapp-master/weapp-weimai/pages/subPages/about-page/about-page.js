Page({
  data:{
    info:[
      {
        label:'姓名',
        value:'张致豪'
      },
      {
        label: '职业',
        value: 'web前端'
      },
      {
        label: 'QQ',
        value: '137596665'
      },
      {
        label: '微信',
        value: '18771022533'
      },
      {
        label: 'github',
        value: 'https://github.com/zhangZhiHao1996'
      }
    ]
  }
})