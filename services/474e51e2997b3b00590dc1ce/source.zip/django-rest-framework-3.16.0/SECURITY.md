# Security Policy

## Reporting a Vulnerability

**Please report security issues by emailing security@encode.io**.

The project maintainers will then work with you to resolve any issues where required, prior to any public disclosure.
