package io.kestra.core.models.triggers;

public enum RecoverMissedSchedules {
    LAST,
    NONE,
    ALL
}
