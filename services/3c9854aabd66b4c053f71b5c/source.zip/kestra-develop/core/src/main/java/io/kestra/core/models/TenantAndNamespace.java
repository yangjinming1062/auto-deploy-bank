package io.kestra.core.models;

public record TenantAndNamespace(String tenantId, String namespace) {}
