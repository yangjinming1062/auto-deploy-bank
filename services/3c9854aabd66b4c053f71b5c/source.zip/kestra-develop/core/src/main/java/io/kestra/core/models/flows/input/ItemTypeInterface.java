package io.kestra.core.models.flows.input;

import io.kestra.core.models.flows.Type;

public interface ItemTypeInterface {
    Type getItemType();
}
