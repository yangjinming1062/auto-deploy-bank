package io.kestra.core.models.dashboards;

import io.kestra.core.models.dashboards.charts.LegendOption;

public interface WithLegend {
    LegendOption getLegend();
}
