package io.kestra.core.models;

public interface DeletedInterface {
    boolean isDeleted();
}
