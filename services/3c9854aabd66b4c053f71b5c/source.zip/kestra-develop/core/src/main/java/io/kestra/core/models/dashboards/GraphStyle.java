package io.kestra.core.models.dashboards;

public enum GraphStyle {
    LINES,
    BARS,
    POINTS
}
