package io.kestra.core.models.dashboards;

public enum Order {
    ASC,
    DESC
}
