package io.kestra.core.models.tasks;

public class VoidOutput implements Output {
}
