package io.kestra.core.models.dashboards;

public enum AggregationType {
    AVG,
    MAX,
    MIN,
    SUM,
    COUNT
}
