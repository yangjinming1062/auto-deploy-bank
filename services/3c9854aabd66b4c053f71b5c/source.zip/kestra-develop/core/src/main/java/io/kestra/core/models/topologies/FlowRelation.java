package io.kestra.core.models.topologies;

public enum FlowRelation {
    FLOW_TASK,
    FLOW_TRIGGER,
}
