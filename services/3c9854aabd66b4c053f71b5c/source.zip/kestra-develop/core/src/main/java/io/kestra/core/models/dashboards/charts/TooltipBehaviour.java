package io.kestra.core.models.dashboards.charts;

public enum TooltipBehaviour {
    NONE,
    ALL,
    SINGLE
}
