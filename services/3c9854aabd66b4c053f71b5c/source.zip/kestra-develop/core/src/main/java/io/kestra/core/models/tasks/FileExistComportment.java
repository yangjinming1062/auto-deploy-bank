package io.kestra.core.models.tasks;

public enum FileExistComportment {
    OVERWRITE, FAIL, WARN, IGNORE
}
