package io.kestra.core.models.tasks.runners;

import io.kestra.core.models.tasks.Output;
import lombok.Getter;
import lombok.experimental.SuperBuilder;

@Getter
@SuperBuilder
public class TaskRunnerDetailResult implements Output {
}
