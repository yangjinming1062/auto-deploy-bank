package io.kestra.core.models.flows;

public enum FlowScope {
    USER,
    SYSTEM
}