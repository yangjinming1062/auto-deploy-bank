package io.kestra.core.models;

public enum FetchVersion {
    LATEST,
    OLD,
    ALL
}
