package io.kestra.cli.commands.flows;

import io.micronaut.configuration.picocli.PicocliRunner;
import io.micronaut.context.ApplicationContext;
import io.micronaut.context.env.Environment;
import io.micronaut.runtime.server.EmbeddedServer;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.net.URL;

import static org.assertj.core.api.Assertions.assertThat;

class TemplateValidateCommandTest {
    @Test
    void runLocal()  {
        URL directory = TemplateValidateCommandTest.class.getClassLoader().getResource("invalids/empty.yaml");
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        System.setErr(new PrintStream(out));

        try (ApplicationContext ctx = ApplicationContext.run(Environment.CLI, Environment.TEST)) {
            String[] args = {
                "--local",
                directory.getPath()
            };
            Integer call = PicocliRunner.call(FlowValidateCommand.class, ctx, args);

            assertThat(call).isEqualTo(1);
            assertThat(out.toString()).contains("Unable to parse flow");
            assertThat(out.toString()).contains("must not be empty");
        }
    }

    @Test
    void runServer()  {
        URL directory = TemplateValidateCommandTest.class.getClassLoader().getResource("invalids/empty.yaml");
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        System.setErr(new PrintStream(out));

        try (ApplicationContext ctx = ApplicationContext.run(Environment.CLI, Environment.TEST)) {

            EmbeddedServer embeddedServer = ctx.getBean(EmbeddedServer.class);
            embeddedServer.start();

            String[] args = {
                "--plugins",
                "/tmp", // pass this arg because it can cause failure
                "--server",
                embeddedServer.getURL().toString(),
                "--user",
                "myuser:pass:word",
                directory.getPath()
            };
            Integer call = PicocliRunner.call(FlowValidateCommand.class, ctx, args);

            assertThat(call).isEqualTo(1);
            assertThat(out.toString()).contains("Unable to parse flow");
            assertThat(out.toString()).contains("must not be empty");
        }
    }
}