package io.kestra.cli.commands.templates;

import io.micronaut.configuration.picocli.PicocliRunner;
import io.micronaut.context.ApplicationContext;
import io.micronaut.context.env.Environment;
import io.micronaut.runtime.server.EmbeddedServer;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.net.URL;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;

class TemplateValidateCommandTest {
    @Test
    void runLocal()  {
        URL directory = TemplateValidateCommandTest.class.getClassLoader().getResource("invalidsTemplates/template.yml");
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        System.setErr(new PrintStream(out));

        try (ApplicationContext ctx = ApplicationContext.run(Map.of("kestra.templates.enabled", "true"), Environment.CLI, Environment.TEST)) {
            String[] args = {
                "--local",
                directory.getPath()
            };
            Integer call = PicocliRunner.call(TemplateValidateCommand.class, ctx, args);

            assertThat(call).isEqualTo(1);
            assertThat(out.toString()).contains("Unable to parse template");
            assertThat(out.toString()).contains("must not be empty");
        }
    }

    @Test
    void runServer()  {
        URL directory = TemplateValidateCommandTest.class.getClassLoader().getResource("invalidsTemplates/template.yml");
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        System.setErr(new PrintStream(out));

        try (ApplicationContext ctx = ApplicationContext.run(Map.of("kestra.templates.enabled", "true"), Environment.CLI, Environment.TEST)) {

            EmbeddedServer embeddedServer = ctx.getBean(EmbeddedServer.class);
            embeddedServer.start();

            String[] args = {
                "--server",
                embeddedServer.getURL().toString(),
                "--user",
                "myuser:pass:word",
                directory.getPath()
            };
            Integer call = PicocliRunner.call(TemplateValidateCommand.class, ctx, args);

            assertThat(call).isEqualTo(1);
            assertThat(out.toString()).contains("Unable to parse template");
            assertThat(out.toString()).contains("must not be empty");
        }
    }
}
