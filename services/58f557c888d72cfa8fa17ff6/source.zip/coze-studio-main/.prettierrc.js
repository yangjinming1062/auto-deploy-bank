// Do not modify this file
module.exports = {
  ...require('./frontend/config/eslint-config/.prettierrc.js'),
};
