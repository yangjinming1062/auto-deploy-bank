namespace appMpower.Orm.Data
{
   public enum Dbms
   {
      MySQL = 0,
      PostgreSQL = 1,
      SQLServer = 2,
   }
}