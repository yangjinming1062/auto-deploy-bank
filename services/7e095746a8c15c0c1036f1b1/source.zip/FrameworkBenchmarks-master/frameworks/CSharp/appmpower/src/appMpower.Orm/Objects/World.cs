namespace appMpower.Orm.Objects
{
   public struct World
   {
      public int Id { get; set; }
      public int RandomNumber { get; set; }
   }
}