namespace appMpower.Orm.Data
{
   public enum DbProvider
   {
      ADO = 0,
      ODBC = 1,
   }
}