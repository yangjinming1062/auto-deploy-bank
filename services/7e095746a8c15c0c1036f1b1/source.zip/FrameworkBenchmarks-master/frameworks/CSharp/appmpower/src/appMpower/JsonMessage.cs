namespace appMpower
{
  public struct JsonMessage
  {
      public string Message { get; set; }
  }
}