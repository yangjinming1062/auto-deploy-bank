[![Nginx logo](https://nginx.org/nginx.png)](https://nginx.org)

# Nginx Benchmarking Test

This is the Nginx portion of a [benchmarking test suite](../) comparing a variety of web development platforms.



## Infrastructure Software Version
The tests were run with:

* [nginx mainline version](http://nginx.org/)


## Test URLs
### Plaintext Test

http://localhost/hello
