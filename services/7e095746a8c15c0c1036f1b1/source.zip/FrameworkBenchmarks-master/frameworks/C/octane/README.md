# OCTANE

Benchmarks for the [octane](http://github.com/simongui/octane) library.
