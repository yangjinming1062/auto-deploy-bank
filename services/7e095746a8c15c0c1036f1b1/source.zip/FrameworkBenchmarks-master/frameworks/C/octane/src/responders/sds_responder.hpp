#pragma once

#include <uv.h>
#include "octane.h"

void create_plaintext_response_sds(write_batch* batch);
void create_json_response_sds(write_batch* batch);
