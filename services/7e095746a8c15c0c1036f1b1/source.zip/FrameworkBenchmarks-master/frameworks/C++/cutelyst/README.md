# Cutelyst 

Cutelyst is a C++ Full Stack Web Framework built with Qt.

Inspired on the Perl Catalyst Framework, it integrages with templating
engines such as Grantlee (DJango syntax), ClearSilver. Many
ready to use plugins to send templated emails, validade user input,
CSRF protection, authentication and session increase the productivity
while having very low memory requirements and a very good performance.

Website: https://cutelyst.org
GitHub: https://github.com/cutelyst/cutelyst

