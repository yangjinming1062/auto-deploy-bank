# cinatra Benchmarking Test

cinatra is a high-performance, easy-to-use http framework developed in Modern C++ (C++20) with the goal of making it easy and quick to develop web applications using the C++ programming language, located at https://github.com/qicosmos/cinatra

## Testing Source Code

* [PLAINTEXT](example/benchmark.cpp)

## Test URLs

### PLAINTEXT

http://localhost:8090/plaintext
