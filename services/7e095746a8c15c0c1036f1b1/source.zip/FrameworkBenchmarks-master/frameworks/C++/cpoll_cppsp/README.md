note: this benchmark module has only been tested on ubuntu 12.04, and it requires the following PPA to be installed:

ppa:ubuntu-toolchain-r/test

(run: add-apt-repository ppa:ubuntu-toolchain-r/test)
and the following packages to be installed:

gcc-4.8 g++-4.8

(this will not replace the system default gcc; it adds a "gcc-4.8" and "g++-4.8" command)
gcc/g++ 4.7 should work too.

