#ifndef __HTTP_REGHTTPMETHOD_HPP
#define __HTTP_REGHTTPMETHOD_HPP

#if defined(_MSC_VER) && (_MSC_VER >= 1200)
#pragma once
#endif// defined(_MSC_VER) && (_MSC_VER >= 1200)

#include "httppeer.h"
namespace http
{
void _inithttpmethodregto(std::map<std::string, regmethold_t> &methodcallback)
{
}

}// namespace http
#endif