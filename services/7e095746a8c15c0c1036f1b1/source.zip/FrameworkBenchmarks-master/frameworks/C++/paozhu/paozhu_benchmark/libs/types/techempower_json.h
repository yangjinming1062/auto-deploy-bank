#ifndef LIBS_TYPES_TECHEMPOWER_TYPE_H
#define LIBS_TYPES_TECHEMPOWER_TYPE_H
#include <string>
#include <sstream>

namespace http
{
//@reflect json to_json from_json
struct techempower_outjson_t
{
    std::string message;
};

}// namespace http
#endif
