# [reactor](https://github.com/shaovie/reactor) (c++) Benchmarking Test

This is the go portion of a [benchmarking test suite](https://www.techempower.com/benchmarks/) comparing a variety of web development platforms.

"reactor is a high-performance, lightweight, i/o event-driven network framework in c++."

## Test URLs

    http://localhost:8080/plaintext
