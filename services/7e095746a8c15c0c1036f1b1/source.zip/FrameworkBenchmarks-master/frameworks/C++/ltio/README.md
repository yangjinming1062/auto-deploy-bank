# ltio Benchmarking Test

ltio is a coroutine based io implementations netlib

### Test Type Implementation Source Code

* [JSON](/json)
* [PLAINTEXT](/plaintext)
* [DB](None)
* [QUERY](None)
* [CACHED QUERY](None)
* [UPDATE](None)


## Test URLs
### JSON

http://localhost:5006/json

### PLAINTEXT

http://localhost:5006/plaintext
