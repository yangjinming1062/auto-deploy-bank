# CppCMS framework
All Test are implemented. 


## What is CppCMS
CppCMS is a Free High-Performance Web Development Framework (not a CMS) aimed at Rapid Web Application Development. It differs from most other web development frameworks like Python Django, Java Servlets in the following ways:

- It is designed and tuned to handle extremely high loads.
- It uses modern C++ as the primary development language in order to achieve the first goal.
- It is designed for developing both Web Sites and Web Services.

It is available under open source LGPLv3 license and alternative Commercial License for users who need an alternative license for proprietary software development.
(From homepage)


## Problems/DOTO
- Test 7 CachedWorld uses normal worlds table




## Links
[Homepage](http://cppcms.com/wikipp/en/page/main)
