ex = [
    [
        "四川美食确实以辣闻名，但也有不辣的选择。比如甜水面、赖汤圆、蛋烘糕、叶儿粑等，这些小吃口味温和，甜而不腻，也很受欢迎。",
        0.3,
        0.7,
        20,
        2,
        42,
        True,
    ],
    [
        "What is your favorite english food?",
        0.5,
        0.5,
        10,
        245,
        531,
        True,
    ],
    [
        "chat T T S is a text to speech model designed for dialogue applications. [uv_break]it supports mixed language input [uv_break]and offers multi speaker capabilities with precise control over prosodic elements like [uv_break]laughter[uv_break][laugh], [uv_break]pauses, [uv_break]and intonation. [uv_break]it delivers natural and expressive speech,[uv_break]so please[uv_break] use the project responsibly at your own risk.[uv_break]",
        0.8,
        0.4,
        7,
        70,
        165,
        False,
    ],
]
