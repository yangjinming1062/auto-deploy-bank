## Installation

```bash
npm install
```

## Run

```bash
npm start
```

## Build

Binary files for Windows, Linux and Mac are available in the `release-builds/` folder.

### For Windows

```bash
npm run package-win
```

### For Linux

```bash
npm run package-linux
```

### For Mac

```bash
npm run package-mac
```