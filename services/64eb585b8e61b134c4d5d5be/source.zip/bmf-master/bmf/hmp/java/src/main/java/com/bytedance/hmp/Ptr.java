package com.bytedance.hmp;

public class Ptr {
    protected long ptr = 0;
    protected boolean own = false;

    public long getPtr() { return ptr; }
}
