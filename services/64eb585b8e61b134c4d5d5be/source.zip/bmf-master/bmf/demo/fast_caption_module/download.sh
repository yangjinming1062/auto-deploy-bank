# 3rd party
cd ../../../3rd_party
wget https://github.com/BabitMF/bmf/releases/download/files/bmf_caption_demo_3rd_party.tar.gz
tar -xzf bmf_caption_demo_3rd_party.tar.gz
mv bmf_caption_demo_3rd_party/* .
rm bmf_caption_demo_3rd_party.tar.gz
rm -rf bmf_caption_demo_3rd_party

wget https://github.com/BabitMF/bmf/releases/download/files/table.raw
