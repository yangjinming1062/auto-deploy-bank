#!/usr/bin/env python
# -*- coding: utf-8 -*-

import logging


def get_logger():
    return logging.getLogger('main')
