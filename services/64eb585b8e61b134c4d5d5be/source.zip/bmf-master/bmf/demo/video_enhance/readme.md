## bmf-enhance-demo

This demo implement two bmf modules:

* enhance_module, implemente the inference process of this project [Real-ESRGAN](https://github.com/xinntao/Real-ESRGAN)
* composition_module, overlay the super-resolution results and the original video


you can try it on [![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/BabitMF/bmf/blob/master/bmf/demo/video_enhance/bmf-enhance-demo.ipynb).



