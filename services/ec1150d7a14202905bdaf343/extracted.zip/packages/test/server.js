module.exports = require('./lib/server');
