export const DEFAULT_PAGE = 1;
export const DEFAULT_PER_PAGE = 20;
