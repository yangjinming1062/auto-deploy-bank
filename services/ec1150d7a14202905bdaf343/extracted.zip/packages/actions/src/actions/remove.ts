import { RelationRepositoryActionBuilder } from '../utils';

export const remove = RelationRepositoryActionBuilder('remove');
