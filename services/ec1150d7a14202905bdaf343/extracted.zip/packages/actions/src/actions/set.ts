import { RelationRepositoryActionBuilder } from '../utils';

export const set = RelationRepositoryActionBuilder('set');
