const test = 'hello';

export default { test };
