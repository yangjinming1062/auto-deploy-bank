export const error = (message: Error | string, ...args: any[]) => {
  console.error(message, ...args);
};
