/// <reference types="../core" />
/// <reference types="../json-schema" />
import * as Types from './types';

declare global {
  namespace Formily.React {
    export { Types };
  }
}
