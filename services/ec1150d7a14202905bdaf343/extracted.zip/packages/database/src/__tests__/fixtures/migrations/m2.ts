import { Migration } from '@tachybase/database';

export default class extends Migration {
  async up() {}

  async down() {}
}
