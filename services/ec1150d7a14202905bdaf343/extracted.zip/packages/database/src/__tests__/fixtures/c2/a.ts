import { extend } from '../../../database';

export default {
  name: 'tests',
  fields: [{ type: 'string', name: 'n2' }],
};
