import { extend } from '../../../database';

export default extend({
  name: 'tests',
  fields: [{ type: 'string', name: 'n0' }],
});
