export default {
  name: 'posts',
  fields: [{ type: 'string', name: 'title' }],
};
