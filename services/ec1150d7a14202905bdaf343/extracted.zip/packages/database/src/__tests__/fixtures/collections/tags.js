module.exports = {
  name: 'tags',
  fields: [{ type: 'string', name: 'name' }],
};
