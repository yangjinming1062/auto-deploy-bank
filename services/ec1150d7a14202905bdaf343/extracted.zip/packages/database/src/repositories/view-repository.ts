import { Repository } from '../repository';

export class ViewRepository extends Repository {}
