use peggy to transform pegjs to sql parser
https://github.com/peggyjs/peggy
