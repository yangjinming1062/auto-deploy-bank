export class ZeroColumnTableError extends Error {}
