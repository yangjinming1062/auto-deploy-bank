Convert this python script to a downloadable jupyter notebook. Make comments into text. 

