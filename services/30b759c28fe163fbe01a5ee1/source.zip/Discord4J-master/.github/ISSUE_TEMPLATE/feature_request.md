---
name: Feature Request
about: Suggest an idea for this project
type: "Feature"

---

<!--
YOUR ISSUE MAY BE CLOSED IF YOU DO NOT FOLLOW THIS TEMPLATE

Consider searching for similar issues before submitting yours:
https://github.com/Discord4J/Discord4J/issues?q=is%3Aissue%20state%3Aopen%20type%3AFeature
-->

**Feature Description:** <!-- A description of the feature you are requesting. -->

**Justification:** <!-- Justification for the feature you are requesting. -->
