package cn.lili.modules.im.mapper;

import cn.lili.modules.im.entity.dos.ImMessage;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * Im消息 Dao层
 * @author Chopper
 */
public interface ImMessageMapper extends BaseMapper<ImMessage> {

}