package cn.lili.modules.im.entity.vo;

import lombok.Data;

import java.util.List;

/**
 * ReadMessage
 *
 * @author Chopper
 * @version v1.0
 * 2021-12-31 11:13
 */
@Data
public class ReadMessage {
    private List<String> readMessageList;
}
