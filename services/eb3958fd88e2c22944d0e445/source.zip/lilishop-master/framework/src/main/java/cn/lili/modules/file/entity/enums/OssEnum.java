package cn.lili.modules.file.entity.enums;

/**
 * OssEnum
 *
 * @author Chopper
 * @version v1.0
 * 2022-06-06 11:23
 */
public enum OssEnum {
    /**
     * 上传渠道
     */
    ALI_OSS, MINIO, HUAWEI_OBS, TENCENT_COS;
}
