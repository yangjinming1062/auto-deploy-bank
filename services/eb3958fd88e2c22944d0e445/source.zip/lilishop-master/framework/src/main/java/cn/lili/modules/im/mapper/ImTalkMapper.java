package cn.lili.modules.im.mapper;

import cn.lili.modules.im.entity.dos.ImTalk;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * 聊天 Dao层
 * @author Chopper
 */
public interface ImTalkMapper extends BaseMapper<ImTalk> {

}