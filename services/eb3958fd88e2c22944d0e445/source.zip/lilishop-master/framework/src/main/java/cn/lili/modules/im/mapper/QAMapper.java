package cn.lili.modules.im.mapper;


import cn.lili.modules.im.entity.dos.QA;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * 问答处理层
 *
 * @author pikachu
 * @since 2020-02-18 15:18:56
 */
public interface QAMapper extends BaseMapper<QA> {


}