/**
 * 项目部分参考   JustAuth
 * git地址       https://gitee.com/yadong.zhang/JustAuth
 */
package cn.lili.modules.connect;
