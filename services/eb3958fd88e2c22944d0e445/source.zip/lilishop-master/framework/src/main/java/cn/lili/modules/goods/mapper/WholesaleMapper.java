package cn.lili.modules.goods.mapper;

import cn.lili.modules.goods.entity.dos.Wholesale;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * @author paulG
 * @since 2022/5/24
 **/
public interface WholesaleMapper extends BaseMapper<Wholesale> {
}
