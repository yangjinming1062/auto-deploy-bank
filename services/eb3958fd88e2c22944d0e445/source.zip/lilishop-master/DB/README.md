## PS:数据库位置

点击跳转 https://gitee.com/beijing_hongye_huicheng/docker/tree/master/init/mysql 这里有与tag版本一致的sql，根据tag获取sql，如果使用master代码，则需要在lilishop项目根目录的update-sql目录中，获取对应的升级sql。


使用master分支代码时，可能会无法运行，执行完初始化sql之后需要执行当前目录下'versiontXXXXtoMASTER.sql'。