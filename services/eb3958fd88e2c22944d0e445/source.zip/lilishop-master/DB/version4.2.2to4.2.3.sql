/** 新增店铺客服字段 **/
ALTER TABLE li_store ADD merchant_euid varchar(255) COMMENT '客服标识';