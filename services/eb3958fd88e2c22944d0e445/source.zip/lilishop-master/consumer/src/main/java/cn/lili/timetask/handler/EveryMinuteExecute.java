package cn.lili.timetask.handler;

/**
 * 每分钟任务
 *
 * @author Chopper
 * @since 2020/12/24 11:52
 */
public interface EveryMinuteExecute {

    /**
     * 执行
     */
    void execute();


}
