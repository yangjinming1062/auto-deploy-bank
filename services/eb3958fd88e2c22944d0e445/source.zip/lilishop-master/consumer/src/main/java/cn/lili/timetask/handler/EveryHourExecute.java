package cn.lili.timetask.handler;

/**
 * 每小时任务
 *
 * @author Chopper
 * @since 2020/12/24 11:52
 */
public interface EveryHourExecute {

    /**
     * 执行
     */
    void execute();


}
