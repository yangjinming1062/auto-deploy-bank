from .module import Module
import logging
logger = logging.getLogger(__name__)

class Neuron(Module):
    pass