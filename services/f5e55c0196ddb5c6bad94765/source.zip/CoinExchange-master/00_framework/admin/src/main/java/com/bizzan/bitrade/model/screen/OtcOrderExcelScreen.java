package com.bizzan.bitrade.model.screen;

import lombok.Data;

@Data
public class OtcOrderExcelScreen extends OtcOrderTopScreen{

    private Long memberId ;

    private Long customerId ;
}
