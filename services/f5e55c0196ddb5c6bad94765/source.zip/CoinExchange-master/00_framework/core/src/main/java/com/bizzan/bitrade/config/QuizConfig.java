package com.bizzan.bitrade.config;
// package com.bizzan.bitrade.config;

// import org.springframework.beans.factory.annotation.Value;
// import org.springframework.context.annotation.Configuration;
// import org.springframework.stereotype.Component;

// @Component
// @Configuration
// public class QuizConfig {

// 	@Value("${quiz.quizMemberId}")
// 	private Long quizMemberId;
	
// 	@Value("${quiz.premiumMemberId}")
// 	private Long premiumMemberId;
	
// 	@Value("${quiz.decimalismMemberId}")
// 	private Long decimalismMemberId;
	
// 	@Value("${quiz.handlingMemberId}")
// 	private Long handlingMemberId;

// 	public Long getQuizMemberId() {
// 		return quizMemberId;
// 	}

// 	public void setQuizMemberId(Long quizMemberId) {
// 		this.quizMemberId = quizMemberId;
// 	}

// 	public Long getPremiumMemberId() {
// 		return premiumMemberId;
// 	}

// 	public void setPremiumMemberId(Long premiumMemberId) {
// 		this.premiumMemberId = premiumMemberId;
// 	}

// 	public Long getDecimalismMemberId() {
// 		return decimalismMemberId;
// 	}

// 	public void setDecimalismMemberId(Long decimalismMemberId) {
// 		this.decimalismMemberId = decimalismMemberId;
// 	}

// 	public Long getHandlingMemberId() {
// 		return handlingMemberId;
// 	}

// 	public void setHandlingMemberId(Long handlingMemberId) {
// 		this.handlingMemberId = handlingMemberId;
// 	}
// }
