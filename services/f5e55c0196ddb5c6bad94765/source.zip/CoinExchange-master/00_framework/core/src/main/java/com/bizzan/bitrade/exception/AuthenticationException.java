package com.bizzan.bitrade.exception;

public class AuthenticationException extends Exception {

	public AuthenticationException(String msg) {
		super(msg);
	}

}
