package com.bizzan.bitrade.exception;

/**
 * @author Jammy
 * @date 2020年03月16日
 */
public class GeeTestException extends Exception {
    public GeeTestException(String msg) {
        super(msg);
    }
}
