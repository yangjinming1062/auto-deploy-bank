package com.bizzan.bitrade.dao;

import com.bizzan.bitrade.dao.base.BaseDao;
import com.bizzan.bitrade.entity.MemberSignRecord;

/**
 * @author Jammy
 * @Description:
 * @date 2019/5/410:18
 */
public interface MemberSignRecordDao extends BaseDao<MemberSignRecord> {
}
