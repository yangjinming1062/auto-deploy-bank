package com.bizzan.bitrade.dao;

import com.bizzan.bitrade.dao.base.BaseDao;
import com.bizzan.bitrade.entity.Feedback;

/**
 * @author Jammy
 * @date 2020年03月19日
 */
public interface FeedbackDao extends BaseDao<Feedback> {
}
