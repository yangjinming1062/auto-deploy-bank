package com.bizzan.bitrade.dao;

import com.bizzan.bitrade.dao.base.BaseDao;
import com.bizzan.bitrade.entity.WebsiteInformation;

/**
 * @author Jammy
 * @description
 * @date 2019/1/25 18:22
 */
public interface WebsiteInformationDao extends BaseDao<WebsiteInformation> {
}
