package com.bizzan.bitrade.constant;

/**
 * @author Jammy
 * @Description:
 * @date 2019/5/311:33
 */
public enum SignStatus {
    UNDERWAY, FINISH;
}
