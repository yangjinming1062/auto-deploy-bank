package com.bizzan.bitrade.exception;

/**
 * @author Jammy
 * @date 2020年01月18日
 */
public class InformationExpiredException extends Exception {
    public InformationExpiredException(String msg) {
        super(msg);
    }
}
