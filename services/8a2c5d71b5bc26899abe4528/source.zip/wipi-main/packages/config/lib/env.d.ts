export declare const file: string, config: Record<string, unknown>;
