export declare const messages: Record<string, unknown>, locales: string[], defaultLocale: string;
