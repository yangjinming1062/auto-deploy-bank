Start it, and wait for 2 minutes at least.

Wait the following logs on the console:

```
==> [{"time":"2018-06-05T16:41:00+08:00","tags":{"app":"appName","ip":"10.15...
```

- we also add log4j2 dependency in order to print client logs in home directory.