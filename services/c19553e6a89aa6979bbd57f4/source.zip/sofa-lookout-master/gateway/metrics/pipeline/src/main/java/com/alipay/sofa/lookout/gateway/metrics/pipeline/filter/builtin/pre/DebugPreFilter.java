/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.alipay.sofa.lookout.gateway.metrics.pipeline.filter.builtin.pre;

import com.alibaba.fastjson.JSON;
import com.alipay.sofa.lookout.gateway.core.common.LogUtils;
import com.alipay.sofa.lookout.gateway.core.prototype.filter.AbstractFilter;
import com.alipay.sofa.lookout.gateway.core.prototype.filter.Filter;
import com.alipay.sofa.lookout.gateway.metrics.pipeline.model.RawMetric;

import java.util.Map;

/**
 * @author xiangfeng.xzc
 * @date 2018/11/30
 */
public class DebugPreFilter extends AbstractFilter<RawMetric> {
    @Override
    public String type() {
        return "metric";
    }

    @Override
    public Filter.FilterResult test(RawMetric rm, Map<String, ?> filterContext) {
        String debugId = rm.getHead().getDebugId();
        if (debugId != null) {
            // debug数量很少 简单期间 直接打印成json了
            LogUtils.DEBUG_LOGGER.info("debugId={} rm={}", debugId, JSON.toJSONString(rm));
        }
        return SUCCESS;
    }
}
