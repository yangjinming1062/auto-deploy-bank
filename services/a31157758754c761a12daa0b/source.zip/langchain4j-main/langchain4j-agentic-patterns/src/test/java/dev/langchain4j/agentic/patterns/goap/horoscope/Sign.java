package dev.langchain4j.agentic.patterns.goap.horoscope;

public record Sign(String zodiacSign) { }
