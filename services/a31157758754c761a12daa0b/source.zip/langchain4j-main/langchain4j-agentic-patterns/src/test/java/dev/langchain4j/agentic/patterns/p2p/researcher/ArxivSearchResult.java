package dev.langchain4j.agentic.patterns.p2p.researcher;

public record ArxivSearchResult(String title, String summary, String link, String content) {
}
