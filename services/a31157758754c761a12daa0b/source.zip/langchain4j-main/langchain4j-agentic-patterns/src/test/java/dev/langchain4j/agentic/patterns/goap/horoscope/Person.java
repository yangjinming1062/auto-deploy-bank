package dev.langchain4j.agentic.patterns.goap.horoscope;

public record Person(String name) { }
