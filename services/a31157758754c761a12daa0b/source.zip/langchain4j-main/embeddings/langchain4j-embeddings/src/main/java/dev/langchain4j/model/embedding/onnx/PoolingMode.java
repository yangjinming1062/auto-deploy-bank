package dev.langchain4j.model.embedding.onnx;

public enum PoolingMode {
    CLS,
    MEAN
}
