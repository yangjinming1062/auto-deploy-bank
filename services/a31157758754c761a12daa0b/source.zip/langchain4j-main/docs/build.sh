#!/usr/bin/env bash

npm ci

npm run build