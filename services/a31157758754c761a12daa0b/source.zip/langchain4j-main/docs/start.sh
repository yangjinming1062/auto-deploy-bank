#!/usr/bin/env bash

npm ci

npm run start