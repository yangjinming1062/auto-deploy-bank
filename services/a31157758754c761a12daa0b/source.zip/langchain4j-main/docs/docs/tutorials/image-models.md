---
sidebar_position: 21
---

# Image Models

More info coming soon

## Examples

- [Example of Image generation](https://github.com/langchain4j/langchain4j-examples/blob/main/open-ai-examples/src/main/java/OpenAiImageModelExamples.java)
- [Example of Image as inputs](https://github.com/langchain4j/langchain4j-examples/blob/5c5fc14613101a84fe32b39200e30701fec45194/open-ai-examples/src/main/java/OpenAiChatModelExamples.java#L37)
