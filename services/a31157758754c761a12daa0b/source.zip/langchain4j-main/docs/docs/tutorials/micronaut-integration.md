---
sidebar_position: 24
---

# Micronaut Integration

[Micronaut](https://micronaut.io/) provides a Micronaut module for LangChain4j.

You can find all the necessary documentation [here](https://micronaut-projects.github.io/micronaut-langchain4j/latest/guide/#introduction) and a tutorial [here](https://micronaut-projects.github.io/micronaut-langchain4j/latest/guide/#quickStart).
