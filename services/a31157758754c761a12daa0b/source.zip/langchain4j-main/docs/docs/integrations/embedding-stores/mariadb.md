---
sidebar_position: 18
---

# Mariadb Vector

https://mariadb.com/kb/en/vector-overview


## Maven Dependency

```xml
<dependency>
    <groupId>dev.langchain4j</groupId>
    <artifactId>langchain4j-mariadb</artifactId>
    <version>1.9.1-beta17</version>
</dependency>
```


## APIs

- `MariaDbEmbeddingStore`
