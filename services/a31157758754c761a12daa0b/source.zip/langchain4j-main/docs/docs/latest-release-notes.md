---
sidebar_position: 20
---

# Latest Release Notes
Please find the latest release notes [here](https://github.com/langchain4j/langchain4j/releases).
