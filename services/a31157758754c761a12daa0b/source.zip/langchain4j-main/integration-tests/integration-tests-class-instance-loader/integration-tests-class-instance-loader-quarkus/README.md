Some integration tests for the [`ClassInstanceLoader`](../../../langchain4j-core/src/main/java/dev/langchain4j/classinstance/ClassInstanceLoader.java), implemented with Quarkus.
