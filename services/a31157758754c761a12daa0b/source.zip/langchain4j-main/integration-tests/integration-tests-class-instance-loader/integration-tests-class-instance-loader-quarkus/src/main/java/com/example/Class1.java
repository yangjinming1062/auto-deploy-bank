package com.example;

import jakarta.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class Class1 {}
