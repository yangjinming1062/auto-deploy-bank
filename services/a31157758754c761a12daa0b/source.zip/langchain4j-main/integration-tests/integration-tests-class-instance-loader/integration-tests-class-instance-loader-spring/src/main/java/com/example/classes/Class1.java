package com.example.classes;

import org.springframework.stereotype.Component;

@Component
public class Class1 {}
