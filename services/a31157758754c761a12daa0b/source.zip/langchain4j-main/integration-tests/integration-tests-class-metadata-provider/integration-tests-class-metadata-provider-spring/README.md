Some integration tests for the [`ClassMetadataProvider`](../../../langchain4j-core/src/main/java/dev/langchain4j/classinstance/ClassMetadataProvider.java), implemented with Spring.
