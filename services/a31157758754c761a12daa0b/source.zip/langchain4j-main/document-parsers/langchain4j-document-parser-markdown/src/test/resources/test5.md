My favorite search engine is [Duck Duck Go](https://duckduckgo.com).
