At the command prompt, type `nano`.
