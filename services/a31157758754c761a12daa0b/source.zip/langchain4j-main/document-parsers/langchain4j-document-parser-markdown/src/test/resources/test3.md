I just love **bold text**.
I just love __bold text__.
Italicized text is the *cat's meow*.
Italicized text is the _cat's meow_.
This text is ***really important***.
This text is ___really important___.
