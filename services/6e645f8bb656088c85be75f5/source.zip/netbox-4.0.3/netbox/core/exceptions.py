class SyncError(Exception):
    pass
