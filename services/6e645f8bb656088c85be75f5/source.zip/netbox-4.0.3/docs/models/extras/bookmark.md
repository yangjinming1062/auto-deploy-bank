# Bookmarks

A user can bookmark individual objects for convenient access. Bookmarks are listed under a user's profile and can be displayed using a dashboard widget.

## Fields

### User

The user to whom the bookmark belongs.

### Object

The bookmarked object.
