# Virtual Disks

A virtual disk is used to model discrete virtual hard disks assigned to [virtual machines](./virtualmachine.md).

## Fields

### Name

A human-friendly name that is unique to the assigned virtual machine.

### Size

The allocated disk size, in gigabytes.
