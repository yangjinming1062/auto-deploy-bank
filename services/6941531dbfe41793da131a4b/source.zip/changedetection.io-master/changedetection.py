#!/usr/bin/env python3

# Only exists for direct CLI usage

import changedetectionio

if __name__ == '__main__':
    changedetectionio.main()
