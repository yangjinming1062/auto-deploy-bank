SELECT
    dsj_job_id as jsjobid, dsj_job_name as jsjobname,
    dsj_enabled as jsjobenabled, dsj_comments as jsjobdesc
FROM sys.scheduler_0400_job;
