import builtins
builtins.SERVER_MODE = True

from pgAdmin4 import app
