NAME = 'roxy-wi-config-module'
