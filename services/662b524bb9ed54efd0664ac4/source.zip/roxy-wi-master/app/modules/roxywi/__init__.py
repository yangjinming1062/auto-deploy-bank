NAME = 'roxy-wi-service-modules'
