---
name: 🛎 TODO LIST
about: Use this template to post new development tasks
title: '[Task] Task Title'
labels: 'To Be Claimed'
assignees: ''
---

### Task Description

Briefly describe the goal that this task aims to achieve.

### Specific Task Requirements

- [ ] Requirement 1
- [ ] Requirement 2
- [ ] Requirement 3

### Claiming Process

If you would like to claim this task, please reply with “I want to claim this task” in the comments.

### Task Remarks

Any additional information or remarks about the task.
