import { FC } from 'react';

const Plugins: FC = () => {
  return <div className="p-4 h-full">Plugins</div>;
};

export default Plugins;
