import json
import random

import torch

from PIL import Image
from pycocotools import mask as mask_utils
import copy
import os
import numpy as np
import tqdm

IGNORE_INDEX = -100
IMAGE_TOKEN_INDEX = -200
DEFAULT_IMAGE_TOKEN = "<image>"

class STBench(torch.utils.data.Dataset):
    def __init__(
        self,
        image_folder,
        json_file,
    ):
        self.image_folder = image_folder
        with open(json_file, "r") as f:
            json_data = json.load(f)
        self.json_data = json_data

    def __len__(self):
        return len(self.json_data)

    def __getitem__(self, idx):
        json_data = self.json_data[idx]
        image_path = os.path.join(self.image_folder, json_data["image_name"])
        mcqs = json_data["mcqs"]

        questions = []
        answers = []
        masks = []
        for object_annotation in mcqs:
            mask = mask_utils.decode(object_annotation["object"])
            question = object_annotation["question"]
            answer = object_annotation["answer"]
            questions.append(question)
            answers.append(answer)
            masks.append(mask)

        image = Image.open(image_path).convert('RGB')

        return {
            "image": image, "masks": masks, "questions": questions, "answers": answers
        }

def main():
    image_folder = None
    save_path = "./stbench_mcq/"
    if not os.path.exists(save_path):
        os.mkdir(save_path)

    dataset = STBench(
        image_folder=image_folder,
        json_file="./STBench_MCQ.json"
    )

    _i_sample = 0
    for i in tqdm.tqdm(range(len(dataset))):
        data_item = dataset[i]
        object_masks = data_item["masks"]
        questions = data_item["questions"]
        answers = data_item["answers"]
        image = data_item["image"]

        for object_mask, question, answer in zip(object_masks, questions, answers):
            question_image = show_mask_pred(copy.deepcopy(image), [object_mask])
            _folder_path = os.path.join(save_path, f"{_i_sample}")
            _i_sample += 1
            if not os.path.exists(_folder_path):
                os.mkdir(_folder_path)
            question_image.save(os.path.join(_folder_path, "question.png"))
            with open(os.path.join(_folder_path, "text.txt"), "w") as f:
                f.write("Question:\n" + question + "\nAnswer:\n" + answer)

def show_mask_pred(image, masks):
    from PIL import Image
    import numpy as np

    colors = [
              (255, 255, 0), (255, 0, 255), (0, 255, 255),
              (128, 128, 255),
              (255, 0, 0), (0, 255, 0), (0, 0, 255),
    ]

    _color_prefix = random.randint(0, len(colors) - 1)

    masks = np.stack(masks, axis=0)
    _mask_image = np.zeros((masks.shape[1], masks.shape[2], 3), dtype=np.uint8)
    # print(masks.shape)
    for i, mask in enumerate(masks):
        color = colors[(i + _color_prefix) % len(colors)]
        _mask_image[:, :, 0] = _mask_image[:, :, 0] + mask.astype(np.uint8) * color[0]
        _mask_image[:, :, 1] = _mask_image[:, :, 1] + mask.astype(np.uint8) * color[1]
        _mask_image[:, :, 2] = _mask_image[:, :, 2] + mask.astype(np.uint8) * color[2]

    image = np.array(image)
    image = image * 0.5 + _mask_image * 0.5
    image = image.astype(np.uint8)
    image = Image.fromarray(image)

    return image

if __name__ == '__main__':
    main()



