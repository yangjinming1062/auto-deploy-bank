from .image_resize import DirectResize

__all__ = ['DirectResize']
