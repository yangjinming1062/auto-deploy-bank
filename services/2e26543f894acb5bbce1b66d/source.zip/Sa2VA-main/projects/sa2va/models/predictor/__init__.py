from .sam2_predictor import SAM2VideoPredictor
