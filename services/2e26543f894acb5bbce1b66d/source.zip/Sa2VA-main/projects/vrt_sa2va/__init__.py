# Visual Evidence Reasoning module for Sa2VA
