package com.xiaojukeji.know.streaming.km.common.bean.entity.param.cluster;

import com.xiaojukeji.know.streaming.km.common.bean.entity.param.VersionItemParam;

/**
 * @author wyc
 * @date 2022/11/9
 */
public class ClusterParam extends VersionItemParam {
}
