package com.xiaojukeji.know.streaming.km.common.bean.dto.cluster;

import com.xiaojukeji.know.streaming.km.common.bean.dto.pagination.PaginationBaseDTO;
import lombok.Data;

/**
 * @author wyc
 * @date 2022/9/23
 */
@Data
public class ClusterZookeepersOverviewDTO extends PaginationBaseDTO {

}
