package com.xiaojukeji.know.streaming.km.common.bean.dto.cluster;

import lombok.Data;


/**
 * @author zengqiao
 * @date 22/12/12
 */
@Data
public class ClusterMirrorMakersOverviewDTO extends ClusterConnectorsOverviewDTO {
}
