package com.xiaojukeji.know.streaming.km.common.bean.entity.record;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class RecordHeaderKS {
    private String key;

    private String value;
}
