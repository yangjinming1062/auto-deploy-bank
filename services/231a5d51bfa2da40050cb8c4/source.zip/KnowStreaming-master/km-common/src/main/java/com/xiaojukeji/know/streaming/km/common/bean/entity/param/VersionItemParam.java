package com.xiaojukeji.know.streaming.km.common.bean.entity.param;

public class VersionItemParam {
}
