package com.xiaojukeji.know.streaming.km.common.bean.entity.job.content;

import lombok.Data;

@Data
public class BaseJobCreateContent {
    protected int type;
}
