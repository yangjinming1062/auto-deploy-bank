package com.xiaojukeji.know.streaming.km.common.bean.entity.zookeeper.fourletterword;

import java.io.Serializable;

/**
 * 四字命令结果数据的基础类
 */
public class BaseFourLetterWordCmdData implements Serializable {
}
