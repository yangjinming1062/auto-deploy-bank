package com.xiaojukeji.know.streaming.km.common.component;

/**
 * 基础handle标识, 搭配 BaseExtendFactory 使用
 *
 * @author linyunan
 * @date 2021-04-25
 */
public interface BaseHandle {

}
