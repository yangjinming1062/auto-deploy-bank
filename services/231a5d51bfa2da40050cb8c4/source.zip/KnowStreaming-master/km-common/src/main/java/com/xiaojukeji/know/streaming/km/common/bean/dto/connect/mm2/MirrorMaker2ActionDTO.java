package com.xiaojukeji.know.streaming.km.common.bean.dto.connect.mm2;

import com.xiaojukeji.know.streaming.km.common.bean.dto.connect.connector.ConnectorActionDTO;
import io.swagger.annotations.ApiModel;
import lombok.Data;


/**
 * @author zengqiao
 * @date 2022-12-12
 */
@Data
@ApiModel(description = "操作MM2")
public class MirrorMaker2ActionDTO extends ConnectorActionDTO {
}
