package com.xiaojukeji.know.streaming.km.common.bean.vo;

import lombok.ToString;

import java.io.Serializable;

/**
 * @author d06679
 * @date 2019/3/13
 */
@ToString
public class BaseVO implements Serializable {
}
