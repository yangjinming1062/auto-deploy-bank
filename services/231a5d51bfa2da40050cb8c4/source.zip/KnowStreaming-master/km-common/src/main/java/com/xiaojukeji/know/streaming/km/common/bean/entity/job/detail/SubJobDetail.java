package com.xiaojukeji.know.streaming.km.common.bean.entity.job.detail;

public abstract class SubJobDetail {
}
