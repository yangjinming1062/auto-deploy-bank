package com.xiaojukeji.know.streaming.km.common.bean.entity.param.metric;

import com.xiaojukeji.know.streaming.km.common.bean.entity.param.VersionItemParam;

public class MetricParam extends VersionItemParam {
}
