package com.xiaojukeji.know.streaming.km.common.bean.entity.kafka;

public class KSMemberBaseAssignment {
}
