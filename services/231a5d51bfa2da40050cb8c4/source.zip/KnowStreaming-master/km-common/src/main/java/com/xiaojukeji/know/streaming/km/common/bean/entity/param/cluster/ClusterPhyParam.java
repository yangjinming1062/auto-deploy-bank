package com.xiaojukeji.know.streaming.km.common.bean.entity.param.cluster;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ClusterPhyParam extends ClusterParam {
    protected Long clusterPhyId;
}
