package com.xiaojukeji.know.streaming.km.common.bean.dto;

import java.io.Serializable;

/**
 *
 *
 * @author d06679
 * @date 2019/3/13
 */
public class BaseDTO implements Serializable {
    private static final long serialVersionUID = 7861489615519826338L;
}
