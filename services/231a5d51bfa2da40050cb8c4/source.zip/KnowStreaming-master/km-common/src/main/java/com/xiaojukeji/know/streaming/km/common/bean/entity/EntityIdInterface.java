package com.xiaojukeji.know.streaming.km.common.bean.entity;

/**
 * @author didi
 */
public interface EntityIdInterface {
    /**
     * 获取id
     * @return
     */
    Long getId();
}
