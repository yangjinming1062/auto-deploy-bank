package com.xiaojukeji.know.streaming.km.common.bean.vo.job.sub;

import io.swagger.annotations.ApiModel;

@ApiModel(description = "Job-子任务详情")
public abstract class SubJobVO {
}
