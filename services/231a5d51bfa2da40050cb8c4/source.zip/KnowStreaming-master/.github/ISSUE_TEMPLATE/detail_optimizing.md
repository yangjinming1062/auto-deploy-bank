---
name: 优化建议
about: 相关功能优化建议
title: ''
labels: Optimization Suggestions
assignees: ''

---

- [ ] 我已经在 [issues](https://github.com/didi/KnowStreaming/issues) 搜索过相关问题了,并没有重复的。

 你是否希望来认领这个优化建议。

 「   Y   /   N  」

### 环境信息

* KnowStreaming version :   <font size=4 color =red>   xxx </font>
* Operating System version :  <font size=4 color =red> xxx </font>
* Java version : <font size=4 color =red> xxx </font>

### 需要优化的功能点


### 建议如何优化

