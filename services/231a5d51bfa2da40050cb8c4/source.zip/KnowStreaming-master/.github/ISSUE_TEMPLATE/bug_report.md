---
name: 报告Bug
about: 报告KnowStreaming的相关Bug
title: ''
labels: bug
assignees: ''

---

- [ ] 我已经在 [issues](https://github.com/didi/KnowStreaming/issues) 搜索过相关问题了,并没有重复的。

 你是否希望来认领这个Bug。

 「   Y   /   N  」

### 环境信息

* KnowStreaming version :   <font size=4 color =red>   xxx </font>
* Operating System version :  <font size=4 color =red> xxx </font>
* Java version : <font size=4 color =red> xxx </font>


### 重现该问题的步骤

1. xxx
   


2. xxx
   

3. xxx



### 预期结果

<!-- 写下应该出现的预期结果？-->

### 实际结果

<!-- 实际发生了什么? -->


---

如果有异常，请附上异常Trace:

```
Just put your stack trace here!
```
