package com.ly.ckibana.constants;

/**
 * n9e参数
 *
 * @Author: zl11357
 * @Email: zl11357@ly.com
 * @Date: 2025/3/7
 */
public class N9eConstants {
    public static final String RANGE_LOW_NAME = "from";

    public static final String RANGE_HIGH_NAME = "to";

    public static final String AGGREGATIONS = "aggregations";


}
