# Code of Conduct
The CKibana project follows the [CONTRIBUTOR COVENANT CODE OF CONDUCT V2.1](https://www.contributor-covenant.org/version/2/1/code_of_conduct/).
