# Real-time-stock-market-prediction
In this repository I have developed the server side principal architecture for real time stock market prediction with Machine Learning. I have used Tensorflow.js for constructing ml model architecture, and Kafka for real time data pipelining.
## Technologies used.
 1. Kafka.<img align="left" alt="kafka" width="26px" src="https://github.com/victor369basu/Real-time-stock-market-prediction/issues/1#issue-771533063" />


