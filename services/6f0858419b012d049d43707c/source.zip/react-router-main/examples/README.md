---
title: Examples
order: 6
---

# React Router Examples

Welcome to the examples for React Router.

Here you'll find various examples of using React Router to accomplish certain tasks. Each example is a complete application including a build and even a button to preview a live instance of the app so you can play with it. You'll most often be interested in checking out the code in `src/App.tsx` (or `src/App.js`), but we included the entire source code for the app for completeness.

Also, remember to check out the README!

Enjoy!
