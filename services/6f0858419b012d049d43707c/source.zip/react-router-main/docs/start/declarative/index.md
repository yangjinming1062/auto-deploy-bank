---
title: Declarative Mode
order: 4
---
