---
title: Pending UI
order: 7
---

# Pending UI

Pending UI is the same as Framework Mode, please see the [Pending UI](../framework/pending-ui) guide for more information.

---

Next: [Custom Framework](./custom)
