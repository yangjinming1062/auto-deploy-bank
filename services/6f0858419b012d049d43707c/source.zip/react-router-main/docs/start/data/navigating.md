---
title: Navigating
order: 6
---

# Navigating

Navigating in Data Mode is the same as Framework Mode, please see the [Navigating](../framework/navigating) guide for more information.

---

Next: [Pending UI](./pending-ui)
