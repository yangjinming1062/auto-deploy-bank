---
title: Testing
order: 9
---

# Testing

You can use `createRoutesStub` in data and framework modes. Please refer to the [Testing Guide](../framework/testing).
