---
title: Server vs. Client Code Execution
hidden: true
---
