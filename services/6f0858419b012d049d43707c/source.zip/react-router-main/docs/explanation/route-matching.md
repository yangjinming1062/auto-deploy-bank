---
title: Route Matching
hidden: true
# want to explain how the matching algorithm works with any potential gotchas
---

# Route Matching
