---
title: isSession
---

# isSession

[MODES: framework, data]

## Summary

[Reference Documentation ↗](https://api.reactrouter.com/v7/functions/react-router.isSession.html)

Returns true if an object is a React Router session.
