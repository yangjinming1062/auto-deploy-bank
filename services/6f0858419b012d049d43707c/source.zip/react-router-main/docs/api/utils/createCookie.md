---
title: createCookie
---

# createCookie

[MODES: framework, data]

## Summary

[Reference Documentation ↗](https://api.reactrouter.com/v7/functions/react-router.createCookie.html)

Creates a logical container for managing a browser cookie from the server.
