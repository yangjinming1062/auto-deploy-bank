---
title: parsePath
---

# parsePath

[MODES: framework, data, declarative]

## Summary

[Reference Documentation ↗](https://api.reactrouter.com/v7/functions/react-router.parsePath.html)

Parses a string URL path into its separate pathname, search, and hash components.

## Signature

```tsx
parsePath(path): Partial
```

## Params

### path

[modes: framework, data, declarative]

_No documentation_
