---
title: createRequestHandler
hidden: true
---

# createRequestHandler

[MODES: framework, data, declarative]

## Summary

[Reference Documentation ↗](https://api.reactrouter.com/v7/functions/react-router.createRequestHandler.html)
