---
title: isCookie
---

# isCookie

[MODES: framework, data]

## Summary

[Reference Documentation ↗](https://api.reactrouter.com/v7/functions/react-router.isCookie.html)

Returns true if an object is a Remix cookie container.
