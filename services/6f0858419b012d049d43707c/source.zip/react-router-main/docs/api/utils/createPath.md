---
title: createPath
---

# createPath

[MODES: framework, data, declarative]

## Summary

[Reference Documentation ↗](https://api.reactrouter.com/v7/functions/react-router.createPath.html)

Creates a string URL path from the given pathname, search, and hash components.

## Signature

```tsx
createPath(__namedParameters): string
```

## Params

### \_\_namedParameters

[modes: framework, data, declarative]

_No documentation_
