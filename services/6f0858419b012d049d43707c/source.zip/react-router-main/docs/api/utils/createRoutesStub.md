---
title: createRoutesStub
---

# createRoutesStub

[MODES: framework, data]

## Summary

[Reference Documentation ↗](https://api.reactrouter.com/v7/functions/react-router.createRoutesStub.html)

## Signature

```tsx
createRoutesStub(routes, context): undefined
```

## Params

### routes

[modes: framework, data]

_No documentation_

### context

[modes: framework, data]

_No documentation_
