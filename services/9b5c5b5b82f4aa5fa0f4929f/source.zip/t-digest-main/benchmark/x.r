data = read.csv("bin-fill.csv")
