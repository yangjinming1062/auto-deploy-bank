package com.tdunning.tdigest.quality;

/**
 * Measurement size of t-digests versus data size and compression
 */
public class ScalingTest {
}
