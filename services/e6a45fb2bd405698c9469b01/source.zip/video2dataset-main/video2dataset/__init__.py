"""video2dataset"""

from .main import video2dataset
