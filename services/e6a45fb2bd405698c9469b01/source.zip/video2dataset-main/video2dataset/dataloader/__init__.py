"""
Load the data (videos and metadata) into bytes, tensors, strings etc.
"""

from .dataloader import get_video_dataset
