API Reference
=============
    
- [self.crawl](self.crawl)
- [Response](Response)
- [self.send_message](self.send_message)
- [@every](@every)
- [@catch_status_code_error](@catch_status_code_error)
