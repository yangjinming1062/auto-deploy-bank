package com.bootdo.oa.domain;

public class Message {
	private String name;

	public String getName() {
		return name;
	}
}
