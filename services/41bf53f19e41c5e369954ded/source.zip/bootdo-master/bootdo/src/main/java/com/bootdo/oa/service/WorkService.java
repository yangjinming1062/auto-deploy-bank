package com.bootdo.oa.service;

import java.util.List;

public interface WorkService {
    List listTodoWork();
}
