# Injected

This directory contains helper sources which are injected into the page.

These sources are bundled with the ebuild into `src/generated` as compile-time source constants. See `utils/generate_injected` for details.
