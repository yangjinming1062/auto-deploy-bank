REMOTE_URL="https://github.com/WebKit/WebKit.git"
BASE_BRANCH="main"
BASE_REVISION="482d54b279fd6147a45aaa122242f2ac315f46df"
