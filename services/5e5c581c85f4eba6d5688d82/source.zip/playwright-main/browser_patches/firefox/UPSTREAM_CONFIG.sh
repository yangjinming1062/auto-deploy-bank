REMOTE_URL="https://github.com/mozilla-firefox/firefox"
BASE_BRANCH="release"
BASE_REVISION="d0f4d17d5aefe7ca5aa97afbcafcdc641cbd9f93"
