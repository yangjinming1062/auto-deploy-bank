---
agent: playwright-test-planner
description: Create test plan
---

Create test plan for basic operations of my todo app.

- Seed file: `tests/seed.spec.ts`
- Test plan: `specs/basic-operations.plan.md`
