---
agent: playwright-test-generator
description: Generate test plan
---

Generate tests for the test plan's bullet 1. Todo Creation

Test plan: `specs/basic-operations.plan.md`
