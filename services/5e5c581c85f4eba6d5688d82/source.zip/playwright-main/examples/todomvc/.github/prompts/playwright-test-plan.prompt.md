---
agent: playwright-test-planner
description: Create test plan
---

Create test plan for basic operations of the todo app. Test plan should contain around 20 tests.

- Seed file: `tests/seed.spec.ts`
- Test plan: `specs/basic-operations.plan.md`
