---
agent: playwright-test-generator
description: Generate test plan
---

Generate tests for the test plan's bullet 1. Adding Todos. Generate one test at a time, never in parallel.

Test plan: `specs/basic-operations.plan.md`
