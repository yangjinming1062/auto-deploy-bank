import { test, expect } from './fixtures';

test('seed', async ({ page }) => {
  // This test tells agents how to start recording the test
  // so that the page was already configured.
});
