@NullMarked
package org.springframework.shell.core.command.annotation;

import org.jspecify.annotations.NullMarked;
