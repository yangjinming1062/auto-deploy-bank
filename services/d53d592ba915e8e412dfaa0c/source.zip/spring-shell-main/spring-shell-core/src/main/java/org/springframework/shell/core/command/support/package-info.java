@NullMarked
package org.springframework.shell.core.command.support;

import org.jspecify.annotations.NullMarked;
