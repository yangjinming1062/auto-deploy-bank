@NullMarked
package org.springframework.shell.core.exit;

import org.jspecify.annotations.NullMarked;
