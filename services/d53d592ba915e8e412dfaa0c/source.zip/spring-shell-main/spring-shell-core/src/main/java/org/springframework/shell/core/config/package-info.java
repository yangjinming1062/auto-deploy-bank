@NullMarked
package org.springframework.shell.core.config;

import org.jspecify.annotations.NullMarked;
