@NullMarked
package org.springframework.shell.core.commands.adapter;

import org.jspecify.annotations.NullMarked;
