@NullMarked
package org.springframework.shell.core.command.annotation.support;

import org.jspecify.annotations.NullMarked;
