@NullMarked
package org.springframework.shell.core.completion;

import org.jspecify.annotations.NullMarked;
