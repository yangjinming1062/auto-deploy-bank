/*
 * Copyright 2025-present the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.springframework.shell.core.command;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Default implementation of {@link CommandParser}. Supports options in the form -o=value
 * and --option=value. Options and arguments can be specified in any order. Arguments are
 * 0-based indexed among other arguments. <pre>
 * CommandSyntax  ::= CommandName [SubCommandName]* [Option | Argument]*
 * CommandName    ::= String
 * SubCommandName ::= String
 * Option         ::= ShortOption | LongOption
 * ShortOption    ::= '-' Char ('=' String)?
 * LongOption     ::= '--' String ('=' String)?
 * Argument       ::= String
 *
 * Example: mycommand mysubcommand --option1=value1 arg1 -o2=value2 arg2
 *
 *  If subcommands are used without options, then arguments must be separated using "--" (POSIX style):
 *  CommandSyntax  ::= CommandName [SubCommandName]* '--' [Argument]*
 *
 *  Example: mycommand mysubcommand -- arg1 arg2
 * </pre>
 *
 * @author Mahmoud Ben Hassine
 * @since 4.0.0
 */
public class DefaultCommandParser implements CommandParser {

	private static final Log log = LogFactory.getLog(DefaultCommandParser.class);

	@Override
	public ParsedInput parse(String input) {
		log.debug("Parsing input: " + input);
		// TODO use Utils.sanitizeInput ?
		List<String> words = List.of(input.split(" "));

		// the first word is the command name
		String commandName = words.get(0);
		ParsedInput.Builder parsedInputBuilder = ParsedInput.builder().commandName(commandName);
		if (words.size() == 1) {
			return parsedInputBuilder.build();
		}

		List<String> remainingWords = words.subList(1, words.size());

		// parse sub commands: if no options, then need to use -- to separate sub commands
		// from arguments (POSIX style)
		int subCommandCount = 0;
		for (String word : remainingWords) {
			if (!isOption(word) && !isArgumentSeparator(word)) {
				subCommandCount++;
				parsedInputBuilder.addSubCommand(word);
			}
			else {
				break;
			}
		}
		if (subCommandCount > 0) {
			remainingWords = remainingWords.subList(subCommandCount, remainingWords.size());
		}

		// parse options
		List<String> options = remainingWords.stream().filter(this::isOption).toList();
		for (String option : options) {
			CommandOption commandOption = parseOption(option);
			parsedInputBuilder.addOption(commandOption);
		}
		// parse arguments
		List<String> arguments = remainingWords.stream()
			.filter(word -> !isOption(word) && !isArgumentSeparator(word))
			.toList();
		for (int i = 0; i < arguments.size(); i++) {
			CommandArgument commandArgument = parseArgument(i, arguments.get(i));
			parsedInputBuilder.addArgument(commandArgument);
		}
		ParsedInput parsedInput = parsedInputBuilder.build();
		log.debug("Parsed input: " + parsedInput);
		return parsedInput;
	}

	// Check if the word is the argument separator, ie empty "--" (POSIX style)
	private boolean isArgumentSeparator(String word) {
		return word.equals("--");
	}

	private boolean isOption(String word) {
		return (word.startsWith("-") || word.startsWith("--")) && !isArgumentSeparator(word);
	}

	private CommandOption parseOption(String word) {
		char shortName = ' ';
		String longName = "";
		String value = "";
		if (word.startsWith("--")) {
			word = word.substring(2);
			String[] tokens = word.split("=");
			longName = tokens[0];
			if (tokens.length > 1) {
				value = tokens[1];
			}
		}
		else if (word.startsWith("-")) {
			word = word.substring(1);
			String[] tokens = word.split("=");
			shortName = tokens[0].charAt(0);
			if (tokens.length > 1) {
				value = tokens[1];
			}
		}
		return new CommandOption(shortName, longName, value);
	}

	private CommandArgument parseArgument(int index, String word) {
		return new CommandArgument(index, word);
	}

}
