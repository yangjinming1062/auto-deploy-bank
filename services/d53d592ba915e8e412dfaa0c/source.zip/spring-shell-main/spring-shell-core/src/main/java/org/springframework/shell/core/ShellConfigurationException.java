package org.springframework.shell.core;

public class ShellConfigurationException extends RuntimeException {

	public ShellConfigurationException(String message, Throwable cause) {
		super(message, cause);
	}

}
