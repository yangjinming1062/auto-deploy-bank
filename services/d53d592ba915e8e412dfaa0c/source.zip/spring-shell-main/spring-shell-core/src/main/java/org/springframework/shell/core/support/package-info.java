@NullMarked
package org.springframework.shell.core.support;

import org.jspecify.annotations.NullMarked;
