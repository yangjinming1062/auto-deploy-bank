@NullMarked
package org.springframework.shell.core.command;

import org.jspecify.annotations.NullMarked;
