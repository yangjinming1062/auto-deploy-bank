@NullMarked
package org.springframework.shell.boot.condition;

import org.jspecify.annotations.NullMarked;