@NullMarked
package org.springframework.shell.boot;

import org.jspecify.annotations.NullMarked;