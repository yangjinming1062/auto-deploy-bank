@NullMarked
package org.springframework.shell.jline.tui.style;

import org.jspecify.annotations.NullMarked;
