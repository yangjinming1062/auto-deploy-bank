/*
 * Copyright 2024 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.springframework.shell.jline.tui.component.view.control;

/**
 * {@code Spinner} represents how user is notified that something is happening using a
 * traditional spinner concept. Represented in a console with an array of characters which
 * are looped.
 *
 * @author Janne Valkealahti
 */
public interface Spinner {

	/**
	 * Gets a frame characters. Type is {@link String} to support unicode.
	 * @return a frame characters
	 */
	String[] getFrames();

	/**
	 * Gets an interval which should be used to estimate how often frame should get
	 * changed. This is always an estimate as actual change depends how ofter console gets
	 * redrawn.
	 * @return an interval in milliseconds
	 */
	int getInterval();

	/**
	 * Construct {@link Spinner} from given frames and interval.
	 * @param frames the spinner frames
	 * @param interval the spinner interval
	 * @return a Spinner implementation
	 */
	static Spinner of(String[] frames, int interval) {
		return new Spinner() {

			@Override
			public String[] getFrames() {
				return frames;
			}

			@Override
			public int getInterval() {
				return interval;
			}

		};
	}

	final static String[] LINE1 = new String[] { "-", "\\", "|", "/" };

	final static String[] DOTS1 = new String[] { "⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏" };

	final static String[] DOTS2 = new String[] { "⣾", "⣽", "⣻", "⢿", "⡿", "⣟", "⣯", "⣷" };

	final static String[] DOTS3 = new String[] { "⠋", "⠙", "⠚", "⠞", "⠖", "⠦", "⠴", "⠲", "⠳", "⠓" };

	final static String[] DOTS4 = new String[] { "⠄", "⠆", "⠇", "⠋", "⠙", "⠸", "⠰", "⠠", "⠰", "⠸", "⠙", "⠋", "⠇", "⠆" };

	final static String[] DOTS5 = new String[] { "⠋", "⠙", "⠚", "⠒", "⠂", "⠂", "⠒", "⠲", "⠴", "⠦", "⠖", "⠒", "⠐", "⠐",
			"⠒", "⠓", "⠋" };

	final static String[] DOTS6 = new String[] { "⠁", "⠉", "⠙", "⠚", "⠒", "⠂", "⠂", "⠒", "⠲", "⠴", "⠤", "⠄", "⠄", "⠤",
			"⠴", "⠲", "⠒", "⠂", "⠂", "⠒", "⠚", "⠙", "⠉", "⠁" };

	final static String[] DOTS7 = new String[] { "⠈", "⠉", "⠋", "⠓", "⠒", "⠐", "⠐", "⠒", "⠖", "⠦", "⠤", "⠠", "⠠", "⠤",
			"⠦", "⠖", "⠒", "⠐", "⠐", "⠒", "⠓", "⠋", "⠉", "⠈" };

	final static String[] DOTS8 = new String[] { "⠁", "⠁", "⠉", "⠙", "⠚", "⠒", "⠂", "⠂", "⠒", "⠲", "⠴", "⠤", "⠄", "⠄",
			"⠤", "⠠", "⠠", "⠤", "⠦", "⠖", "⠒", "⠐", "⠐", "⠒", "⠓", "⠋", "⠉", "⠈", "⠈" };

	final static String[] DOTS9 = new String[] { "⢹", "⢺", "⢼", "⣸", "⣇", "⡧", "⡗", "⡏" };

	final static String[] DOTS10 = new String[] { "⢄", "⢂", "⢁", "⡁", "⡈", "⡐", "⡠" };

	final static String[] DOTS11 = new String[] { "⠁", "⠂", "⠄", "⡀", "⢀", "⠠", "⠐", "⠈" };

	final static String[] DOTS12 = new String[] { "⢀⠀", "⡀⠀", "⠄⠀", "⢂⠀", "⡂⠀", "⠅⠀", "⢃⠀", "⡃⠀", "⠍⠀", "⢋⠀", "⡋⠀",
			"⠍⠁", "⢋⠁", "⡋⠁", "⠍⠉", "⠋⠉", "⠋⠉", "⠉⠙", "⠉⠙", "⠉⠩", "⠈⢙", "⠈⡙", "⢈⠩", "⡀⢙", "⠄⡙", "⢂⠩", "⡂⢘", "⠅⡘", "⢃⠨",
			"⡃⢐", "⠍⡐", "⢋⠠", "⡋⢀", "⠍⡁", "⢋⠁", "⡋⠁", "⠍⠉", "⠋⠉", "⠋⠉", "⠉⠙", "⠉⠙", "⠉⠩", "⠈⢙", "⠈⡙", "⠈⠩", "⠀⢙", "⠀⡙",
			"⠀⠩", "⠀⢘", "⠀⡘", "⠀⠨", "⠀⢐", "⠀⡐", "⠀⠠", "⠀⢀", "⠀⡀" };

	final static String[] DOTS13 = new String[] { "⣼", "⣹", "⢻", "⠿", "⡟", "⣏", "⣧", "⣶" };

	final static String[] DOTS14 = new String[] { ".   ", " .  ", "  . ", "   ." };

}
