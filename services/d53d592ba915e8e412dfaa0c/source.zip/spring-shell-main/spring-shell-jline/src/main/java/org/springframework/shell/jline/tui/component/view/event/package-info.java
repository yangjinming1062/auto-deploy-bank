@NullMarked
package org.springframework.shell.jline.tui.component.view.event;

import org.jspecify.annotations.NullMarked;
