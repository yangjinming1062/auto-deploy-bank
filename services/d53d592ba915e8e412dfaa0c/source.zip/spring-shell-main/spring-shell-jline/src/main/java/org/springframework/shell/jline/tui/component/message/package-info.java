@NullMarked
package org.springframework.shell.jline.tui.component.message;

import org.jspecify.annotations.NullMarked;
