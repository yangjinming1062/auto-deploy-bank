@NullMarked
package org.springframework.shell.jline.tui.component.support;

import org.jspecify.annotations.NullMarked;
