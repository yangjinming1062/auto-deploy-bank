@NullMarked
package org.springframework.shell.jline.tui.component.view.control;

import org.jspecify.annotations.NullMarked;
