@NullMarked
package org.springframework.shell.jline.tui.component.flow;

import org.jspecify.annotations.NullMarked;
