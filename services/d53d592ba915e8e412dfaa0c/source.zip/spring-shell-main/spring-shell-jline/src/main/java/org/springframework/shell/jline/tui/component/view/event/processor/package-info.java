@NullMarked
package org.springframework.shell.jline.tui.component.view.event.processor;

import org.jspecify.annotations.NullMarked;
