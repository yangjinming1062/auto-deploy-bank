/*
 * Copyright 2022 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.springframework.shell.jline.tui.component.flow;

import org.springframework.core.Ordered;
import org.springframework.shell.jline.tui.component.flow.ComponentFlow.BaseBuilder;

/**
 * Base impl for specs.
 *
 * @author Janne Valkealahti
 */
public abstract class BaseInput<T extends BaseInputSpec<T>> implements Ordered, BaseInputSpec<T> {

	private final BaseBuilder builder;

	private final String id;

	private int order;

	BaseInput(BaseBuilder builder, String id) {
		this.builder = builder;
		this.id = id;
	}

	@Override
	public int getOrder() {
		return order;
	}

	public void setOrder(int order) {
		this.order = order;
	}

	@Override
	public T order(int order) {
		this.order = order;
		return getThis();
	}

	public BaseBuilder getBuilder() {
		return builder;
	}

	public String getId() {
		return id;
	}

}