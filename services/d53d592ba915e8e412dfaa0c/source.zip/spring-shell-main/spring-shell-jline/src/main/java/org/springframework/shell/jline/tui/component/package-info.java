@NullMarked
package org.springframework.shell.jline.tui.component;

import org.jspecify.annotations.NullMarked;
