@NullMarked
package org.springframework.shell.jline.tui.component.context;

import org.jspecify.annotations.NullMarked;
