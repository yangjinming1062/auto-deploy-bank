@NullMarked
package org.springframework.shell.jline.tui.component.view.screen;

import org.jspecify.annotations.NullMarked;
