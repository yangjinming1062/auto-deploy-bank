@NullMarked
package org.springframework.shell.jline.tui.component.view;

import org.jspecify.annotations.NullMarked;
