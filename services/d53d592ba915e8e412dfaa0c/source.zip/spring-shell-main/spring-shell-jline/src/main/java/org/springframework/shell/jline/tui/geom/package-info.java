@NullMarked
package org.springframework.shell.jline.tui.geom;

import org.jspecify.annotations.NullMarked;
