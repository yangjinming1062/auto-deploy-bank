@NullUnmarked
package org.springframework.shell.test.jediterm;

// Excluded from nullness checking (jediterm forked code).
import org.jspecify.annotations.NullUnmarked;
