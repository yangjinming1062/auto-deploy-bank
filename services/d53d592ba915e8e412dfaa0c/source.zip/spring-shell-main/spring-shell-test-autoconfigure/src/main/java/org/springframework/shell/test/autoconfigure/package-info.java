@NullMarked
package org.springframework.shell.test.autoconfigure;

import org.jspecify.annotations.NullMarked;
