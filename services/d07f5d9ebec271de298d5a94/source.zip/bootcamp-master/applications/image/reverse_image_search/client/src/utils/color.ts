export const baseColor = '#3F9CD1';
