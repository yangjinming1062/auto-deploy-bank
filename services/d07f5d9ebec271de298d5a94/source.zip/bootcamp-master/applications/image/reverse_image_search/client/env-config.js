window._env_ = {
  API_URL: "http://192.168.1.85:5000",
}
