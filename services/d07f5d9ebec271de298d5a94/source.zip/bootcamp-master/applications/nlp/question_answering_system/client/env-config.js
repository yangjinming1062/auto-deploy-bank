window._env_ = {
  API_URL: "http://40.117.75.127:5005",
  LAN: "cn",
};
