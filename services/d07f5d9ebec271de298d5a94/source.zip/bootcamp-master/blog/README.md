Codes & Tutorials used in blogs
