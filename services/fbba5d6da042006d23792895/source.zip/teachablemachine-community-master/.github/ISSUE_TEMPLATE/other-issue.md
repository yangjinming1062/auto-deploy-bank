---
name: Other Issue
about: Use this template for issues that are NOT bugs or feature requests
title: ''
labels: ''
assignees: ''

---

This template is for miscellaneous issues that you believe are not bugs or feature requests.
Please provide as much detail as possible in your question.
