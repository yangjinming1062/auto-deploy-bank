#set( $symbol_pound = '#' )
#set( $symbol_dollar = '$' )
#set( $symbol_escape = '\' )
package ${package};


import org.springframework.ai.tool.annotation.Tool;
import org.springframework.ai.tool.annotation.ToolParam;

import static java.lang.String.format;

public class TestTools {

    @Tool( description="tool for test AI agent executor")
    String execTest(@ToolParam( description = "test message") String message) {
        return format( "test tool ('%s') executed with result 'OK'", message);
    }

    @Tool( description="return current number of system thread allocated by application")
    int threadCount() {
        return Thread.getAllStackTraces().size();
    }

}
