mvn clean archetype:create-from-project \
    -Darchetype.keepParent=false
    