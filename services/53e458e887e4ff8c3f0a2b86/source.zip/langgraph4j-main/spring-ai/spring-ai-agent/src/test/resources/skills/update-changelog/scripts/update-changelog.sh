#!/bin/bash

git-changelog-command-line -of CHANGELOG.md
echo "Successfully updated CHANGELOG.md"