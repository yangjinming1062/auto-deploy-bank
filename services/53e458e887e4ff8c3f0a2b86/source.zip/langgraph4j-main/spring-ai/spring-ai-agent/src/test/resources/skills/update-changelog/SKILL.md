---
name: update-changelog
description: update changelog
---

to update changelog run the command 
```
scripts/update-changelog.sh
```

