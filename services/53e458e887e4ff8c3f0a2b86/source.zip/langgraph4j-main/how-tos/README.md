## JAVA NOTEBOOKS

Idea is to write how-tos using Java Based Notebooks. 
We have evaluate:

* [cyrilou242/jnotebook](https://github.com/cyrilou242/jnotebook)
  > interprets Java JShell files and render them as notebook.
* [JBang](https://github.com/JBangDev/JBang)
  > Lets create, edit and run self-contained source-only Java programs with unprecedented ease.
* [rapaio-jupyter-kernel](https://github.com/padreati/rapaio-jupyter-kernel)
  > Jupyter kernel for Java language based on JShell. It implements Jupyter message specification version 5.4, and it requires Java 22.

The current choice is to use [rapaio-jupyter-kernel](https://github.com/padreati/rapaio-jupyter-kernel) 

