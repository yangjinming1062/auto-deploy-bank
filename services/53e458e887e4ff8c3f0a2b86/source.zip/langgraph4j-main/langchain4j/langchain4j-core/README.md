# Utilities for langchain4j to langgraph4j integration

- [x] Serializer ( Java Stream based )
- [x] Tools
- [x] Streaming 


### Adding dependency 

**Maven**
```xml
<dependency>
    <groupId>org.bsc.langgraph4j</groupId>
    <artifactId>langgraph4j-langchain4j</artifactId>
    <version></version>
</dependency>
```