# Check if an argument was provided via the command line
if [ $# -gt 0 ]; then
    ver="$1"
    git flow release finish "$ver"
else
    echo "no version provided abort overall processing"
fi


