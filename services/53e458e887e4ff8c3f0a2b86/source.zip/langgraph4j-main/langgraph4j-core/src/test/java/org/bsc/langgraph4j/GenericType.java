package org.bsc.langgraph4j;

public class GenericType<T>  {

    T value;
}
