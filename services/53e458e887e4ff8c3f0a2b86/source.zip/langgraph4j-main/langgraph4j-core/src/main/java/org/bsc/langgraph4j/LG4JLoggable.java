package org.bsc.langgraph4j;

public interface LG4JLoggable {

    org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger("org.bsc.langgraph4j");
}
