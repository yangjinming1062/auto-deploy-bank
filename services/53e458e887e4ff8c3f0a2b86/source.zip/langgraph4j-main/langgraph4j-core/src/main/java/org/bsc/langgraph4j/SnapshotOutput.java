package org.bsc.langgraph4j;

public interface SnapshotOutput {

    String next();

    RunnableConfig config();

}
