
# Common Agentic Patterns

## Structured Output

> _TO DO _

## Tool calling

> _TO DO _

## Memory

> _TO DO _

## Human-in-the-loop

> _TO DO _

### Approval

> _TO DO _

### Wait for input

> _TO DO _

### Edit agent actions

> _TO DO _

### Time travel

> _TO DO _

## Multi-agent

> _TO DO _

## Planning

> _TO DO _

## Reflection

> _TO DO _

## ReAct Agent

> _TO DO _
