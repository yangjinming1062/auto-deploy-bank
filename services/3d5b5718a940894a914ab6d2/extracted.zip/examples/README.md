# BentoML Examples 🎨

We provide a comprehensive collection of example projects to help you build and scale AI applications with BentoML for different use cases. Check out the [full list](https://docs.bentoml.com/en/latest/use-cases/index.html).
