if __name__ == "__main__":
    from bentoml_cli.cli import cli

    cli()
