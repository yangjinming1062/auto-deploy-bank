import bentoml


@bentoml.service
class BentoB:
    pass
