import bentoml


@bentoml.service
class SimpleBento:
    pass
