import bentoml


@bentoml.service
class BentoA:
    pass
