import bentoml

svc_i = bentoml.legacy.Service("test-bento-service-in-module-i")
svc_ii = bentoml.legacy.Service("test-bento-service-in-module-ii")
