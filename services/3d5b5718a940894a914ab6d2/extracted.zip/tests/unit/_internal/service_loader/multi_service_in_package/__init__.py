import bentoml

svc_i = bentoml.legacy.Service("test-multi-service-in-package-i")
svc_ii = bentoml.legacy.Service("test-multi-service-in-package-ii")
