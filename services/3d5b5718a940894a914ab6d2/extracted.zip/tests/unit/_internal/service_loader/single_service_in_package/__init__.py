import bentoml

svc = bentoml.legacy.Service("test-bento-service-in-package")
