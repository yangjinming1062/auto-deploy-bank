"""
Example BentoML Service

This is a simple example service that demonstrates BentoML's capabilities.
"""

import bentoml
import numpy as np
from typing import Any

# Define a simple BentoML service
@bentoml.service
class SimpleService:
    """
    A simple BentoML service for demonstration purposes.
    This service performs basic mathematical operations.
    """

    def __init__(self):
        # Initialize any models or resources here
        pass

    @bentoml.api
    def predict(self, data: Any) -> dict:
        """
        Handle prediction requests.

        Args:
            data: Input data containing 'operation' and 'values' fields

        Returns:
            JSON response with the result
        """
        operation = data.get("operation")
        values = data.get("values", [])

        if operation == "sum":
            result = sum(values)
        elif operation == "mean":
            result = float(np.mean(values)) if values else 0
        elif operation == "max":
            result = max(values) if values else 0
        elif operation == "min":
            result = min(values) if values else 0
        else:
            result = {"error": f"Unknown operation: {operation}"}

        return {"result": result, "operation": operation}

    @bentoml.api
    def health(self) -> dict:
        """
        Health check endpoint.
        """
        return {"status": "healthy", "service": "SimpleService"}