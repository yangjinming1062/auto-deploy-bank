====
Flax
====

.. admonition:: About this page

   This is an API reference for FLax in BentoML. Please refer to
   :doc:`/frameworks/flax` for more information about how to use Flax in BentoML.

.. currentmodule:: bentoml.flax

.. autofunction:: bentoml.flax.save_model

.. autofunction:: bentoml.flax.load_model

.. autofunction:: bentoml.flax.get
