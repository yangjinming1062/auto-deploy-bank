===
Ray
===


.. admonition:: About this page

   This is an API reference for deploying BentoML with Ray. Please refer to
   :doc:`BentoRay guide </integrations/ray>` for more information.

.. currentmodule:: bentoml.ray

.. autofunction:: bentoml.ray.deployment
