=====
Types
=====

Miscellaneous types for BentoML APIs

.. autoclass:: bentoml.types.ModelSignature
.. autoclass:: bentoml.types.ModelSignatureDict
