$(document).ready(function () {
    // Always open external links in a new tab
    $('a.external').attr('target', '_blank');
});