===============
Batch inference
===============

Batch inference backends
------------------------


.. autofunction:: bentoml.batch.run_in_spark
