Code for Multivariable logistic regression.

Developed with R 3.6.1 (Authors: P.Johannet, Y.Xia, J.Zhong).

See annotations in the code for usage.

For reference, please see the following paper(s):

"Johannet, Paul, et al. "Using machine learning algorithms to predict immunotherapy response in patients with advanced melanoma." Clinical Cancer Research 27.1 (2021): 131-140."




