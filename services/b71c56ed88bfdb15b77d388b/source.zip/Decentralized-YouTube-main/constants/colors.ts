export const Colors = {
  primary: "#3B84F5",
};
