import {singularize} from './noun';

export {
  singularize
};
