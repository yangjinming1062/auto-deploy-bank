import Chance from "./Chance"

export const generator = new Chance()
