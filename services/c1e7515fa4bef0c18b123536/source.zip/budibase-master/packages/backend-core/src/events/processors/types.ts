export type { EventProcessor } from "@budibase/types"
