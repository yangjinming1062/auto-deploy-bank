import PosthogProcessor from "./PosthogProcessor"

export default PosthogProcessor
