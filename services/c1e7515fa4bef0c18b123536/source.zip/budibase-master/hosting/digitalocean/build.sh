#!/bin/bash
packer build template.json
