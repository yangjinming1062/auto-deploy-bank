---
name: Project
about: A project that contains multiple PRDs/Features
title: "[Project]"
labels: ''
assignees: ''

---

Use this issue type when creating a project that contains multiple PRDs/Features and is tied to a launch
