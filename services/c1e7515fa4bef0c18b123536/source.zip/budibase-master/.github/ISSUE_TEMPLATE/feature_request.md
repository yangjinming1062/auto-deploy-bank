---
name: Feature Request
about: Request a new budibase feature or enhancement
title: ''
labels: enhancement, needs-triage
assignees: ''

---

**Describe the feature request**
A clear and concise description of what the feature request.

**Screenshots**
If applicable, add screenshots to help explain your problem.
