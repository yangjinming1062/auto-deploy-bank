# Security Policy

Currently bazix is in active development. Expect for breaking changes.

## Reporting a Vulnerability

Please email one of the core maintainers privately.
