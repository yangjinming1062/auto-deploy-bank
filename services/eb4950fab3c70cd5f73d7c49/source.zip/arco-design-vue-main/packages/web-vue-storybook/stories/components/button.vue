<template>
  <Button type="primary">Primary Button</Button>
</template>

<script>
import { Button } from '@web-vue/components';

export default {
  components: { Button },
};
</script>
