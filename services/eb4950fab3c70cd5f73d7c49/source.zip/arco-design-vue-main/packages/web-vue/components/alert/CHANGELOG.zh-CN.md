```yaml
changelog: true
```

## 2.47.0

`2023-06-02`

### 🆕 新增功能

- 新增 `center` 属性 ([#2464](https://github.com/arco-design/arco-design-vue/pull/2464))


## 2.41.0

`2022-12-30`

### 🆕 新增功能

- 增加 `normal` 类型 ([#2009](https://github.com/arco-design/arco-design-vue/pull/2009))


## 2.36.0

`2022-09-02`

### 🆕 新增功能

- 支持自定义关闭元素 ([#1544](https://github.com/arco-design/arco-design-vue/pull/1544))


## 2.3.0

`2021-11-12`

### 🆕 新增功能

- 增加 `#action` 插槽 ([#148](https://github.com/arco-design/arco-design-vue/pull/148))

### 🐛 问题修复

- 修复组件导出名字错误的问题 ([#142](https://github.com/arco-design/arco-design-vue/pull/142))

