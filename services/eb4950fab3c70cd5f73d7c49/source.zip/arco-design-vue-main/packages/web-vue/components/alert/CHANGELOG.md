```yaml
changelog: true
```

## 2.47.0

`2023-06-02`

### 🆕 Feature

- add `center` prop ([#2464](https://github.com/arco-design/arco-design-vue/pull/2464))


## 2.41.0

`2022-12-30`

### 🆕 Feature

- Add `normal` type ([#2009](https://github.com/arco-design/arco-design-vue/pull/2009))


## 2.36.0

`2022-09-02`

### 🆕 Feature

- suport custom close element ([#1544](https://github.com/arco-design/arco-design-vue/pull/1544))


## 2.3.0

`2021-11-12`

### 🆕 Feature

- Add `#action` slot ([#148](https://github.com/arco-design/arco-design-vue/pull/148))

### 🐛 BugFix

- Fix the problem of incorrect name export by alert ([#142](https://github.com/arco-design/arco-design-vue/pull/142))

