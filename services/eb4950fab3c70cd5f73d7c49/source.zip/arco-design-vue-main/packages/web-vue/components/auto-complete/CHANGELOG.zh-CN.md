```yaml
changelog: true
```

## 2.52.0

`2023-09-22`

### 🆕 新增功能

- 增加下拉菜单滚动事件 ([#2635](https://github.com/arco-design/arco-design-vue/pull/2635))


## 2.50.0

`2023-08-11`

### 🆕 新增功能

- 添加虚拟列表支持 ([#2596](https://github.com/arco-design/arco-design-vue/pull/2596))


## 2.40.0

`2022-12-09`

### 🆕 新增功能

- 增加 focus 和 blur 方法 ([#1809](https://github.com/arco-design/arco-design-vue/pull/1809))


## 2.34.0

`2022-07-29`

### 🆕 新增功能

- 增加`footer`插槽 ([#1445](https://github.com/arco-design/arco-design-vue/pull/1445))


## 2.23.0

`2022-04-08`

### 🆕 新增功能

- 增加 allow-clear 属性和事件 ([#951](https://github.com/arco-design/arco-design-vue/pull/951))


## 2.13.0

`2021-12-31`

### 🆕 新增功能

- 增加 input 中的插槽和 option 插槽支持 ([#482](https://github.com/arco-design/arco-design-vue/pull/482))


## 2.8.0

`2021-12-01`

### 🐛 问题修复

- 修复 disabled 不可用的问题 ([#310](https://github.com/arco-design/arco-design-vue/pull/310))

