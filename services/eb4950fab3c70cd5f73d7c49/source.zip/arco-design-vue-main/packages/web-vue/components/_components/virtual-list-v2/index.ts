import VirtualList from './virtual-list.vue';

export default VirtualList;
