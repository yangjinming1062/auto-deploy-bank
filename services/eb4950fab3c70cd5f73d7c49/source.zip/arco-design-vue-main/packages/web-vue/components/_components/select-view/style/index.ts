import '../../input-label/style';
import '../../../input-tag/style';
import './index.less';
