```yaml
changelog: true
```

## 2.47.1

`2023-06-09`

### 🐛 BugFix

- Fix the problem that components fail when customizing `prefix-cls` ([#2476](https://github.com/arco-design/arco-design-vue/pull/2476))


## 2.40.1

`2022-12-23`


## 2.12.0

`2021-12-24`

### 💎 Enhancement

- No longer render the logo when count is 0 ([#445](https://github.com/arco-design/arco-design-vue/pull/445))

