```yaml
changelog: true
```

## 2.47.1

`2023-06-09`

### 🐛 问题修复

- 修复组件在自定义 `prefix-cls` 时失效的问题 ([#2476](https://github.com/arco-design/arco-design-vue/pull/2476))


## 2.40.1

`2022-12-23`


## 2.12.0

`2021-12-24`

### 💎 功能优化

- count 为 0 时不再渲染徽标 ([#445](https://github.com/arco-design/arco-design-vue/pull/445))

