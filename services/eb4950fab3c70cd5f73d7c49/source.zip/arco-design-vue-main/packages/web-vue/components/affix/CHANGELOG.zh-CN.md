```yaml
changelog: true
```

## 2.21.1

`2022-03-25`

### 🐛 问题修复

- 修复组件在 SSR 下报错的问题 ([#879](https://github.com/arco-design/arco-design-vue/pull/879))


## 2.12.0

`2021-12-24`

### 🐛 问题修复

- 修复与 anchor 组件组合使用，显示 warning 的问题 ([#448](https://github.com/arco-design/arco-design-vue/pull/448))

