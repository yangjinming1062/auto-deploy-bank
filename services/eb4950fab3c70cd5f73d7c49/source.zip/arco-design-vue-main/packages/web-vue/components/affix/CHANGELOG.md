```yaml
changelog: true
```

## 2.21.1

`2022-03-25`

### 🐛 BugFix

- Fix the problem of component reporting error under SSR ([#879](https://github.com/arco-design/arco-design-vue/pull/879))


## 2.12.0

`2021-12-24`

### 🐛 BugFix

- Fix the problem of displaying warning when used in combination with the anchor component ([#448](https://github.com/arco-design/arco-design-vue/pull/448))

