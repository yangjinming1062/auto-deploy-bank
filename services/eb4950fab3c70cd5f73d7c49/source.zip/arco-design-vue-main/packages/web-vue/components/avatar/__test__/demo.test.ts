import demoTest from '../../../scripts/demo-test';

demoTest('avatar');
