```yaml
changelog: true
```

## 2.11.0

`2021-12-17`

### 🐛 问题修复

- 修复加载后不会定位到 hash 位置的问题 ([#400](https://github.com/arco-design/arco-design-vue/pull/400))

