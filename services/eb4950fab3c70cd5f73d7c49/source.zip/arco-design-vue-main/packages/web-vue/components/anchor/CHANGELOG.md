```yaml
changelog: true
```

## 2.11.0

`2021-12-17`

### 🐛 BugFix

- Fix the problem that the hash position will not be located after loading ([#400](https://github.com/arco-design/arco-design-vue/pull/400))

