import demoTest from '../../../scripts/demo-test';

demoTest('anchor');
