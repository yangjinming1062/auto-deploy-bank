# `@arco-design/arco-vue-site-nav`

WIP: Will be removed in the future

Arco Design Vue Docs Navbar (from React Material)
