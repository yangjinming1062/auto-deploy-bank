import props from './props';
import events from './events';
import methods from './methods';
import slots from './slots';

export default {
  props,
  events,
  methods,
  slots,
};
