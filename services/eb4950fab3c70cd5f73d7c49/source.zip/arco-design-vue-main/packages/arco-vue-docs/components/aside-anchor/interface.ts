export interface AnchorData {
  href: string;
  title: {
    'zh-CN': string;
    'en-US': string;
  };
}
