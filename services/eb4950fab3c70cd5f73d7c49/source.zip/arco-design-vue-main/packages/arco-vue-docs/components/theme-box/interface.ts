export interface ThemeData {
  themeId: number;
  themeName: string;
  cover: string;
  packageName: string;
  unpkgHost: string;
}
