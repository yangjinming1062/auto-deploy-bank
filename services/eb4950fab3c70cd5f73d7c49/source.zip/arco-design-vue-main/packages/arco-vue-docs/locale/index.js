import zhCN from './zh-cn';
import enUS from './en-us';

export default {
  'zh-CN': zhCN,
  'en-US': enUS,
};
