```yaml
meta:
  type: Arco Pro 最佳实践
title: 布局
description: 页面通用布局
```

## 布局

目前提供的布局只有一套，应用到了所有路由页面上，包含侧边菜单栏，顶部通知栏，页脚和内容区域，其中侧边栏和顶部通知栏都是 fixed 的，方便用户在滚动的过程中关注到其他视图。

![](https://p1-arco.byteimg.com/tos-cn-i-uwbnlip3yd/ebd0bd6d4c044c1e945527194384fcaa.png~tplv-uwbnlip3yd-webp.webp)

此外，响应式的侧边栏会在窗口宽度小于 `1200px` 的时候，自动收缩如下：

![](https://p1-arco.byteimg.com/tos-cn-i-uwbnlip3yd/c730fddca82cf8c4cda27cef9ecd6683.png~tplv-uwbnlip3yd-webp.webp)
