import { emitFiles } from './emit-files';

export default {
  repo: 'arco-design/arco-design-vue',
  merged: true,
  emitFiles,
};
