module.exports = {
  tabWidth: 2,
  semi: true,
  printWidth: 80,
  singleQuote: true,
  quoteProps: 'consistent',
  endOfLine: 'auto',
  htmlWhitespaceSensitivity: 'strict',
};
