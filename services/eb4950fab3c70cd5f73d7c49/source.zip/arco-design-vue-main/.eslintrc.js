// Adapt to vscode.
// This file will be found in the root directory of vscode.
// If it cannot be found, it will report an error and cannot run eslint in the editor.
module.exports = {};
