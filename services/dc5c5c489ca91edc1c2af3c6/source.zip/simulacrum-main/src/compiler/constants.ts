export class CompilerConstants {
	static METZ_CONTEXT_VARIABLE = '__90991_metz_context';
}
