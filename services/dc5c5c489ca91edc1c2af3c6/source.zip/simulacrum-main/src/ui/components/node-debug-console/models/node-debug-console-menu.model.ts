export enum NodeDebugConsoleMenuOptions {
	INPUT = 'Input',
	SCOPE = 'Scope',
	OUTPUT = 'Output',
}
