export default `/**
 * This is the script which controls how this story goes.
 * You start by creating a flow, which as the name suggests,
 * represents a synchrnous path your system might take.
 * 
 * You can create as many flows as you want, you can even 
 * make time based ones(after 2 ticks, every 2 ticks).
 * 
 * Use the metz's standard library(std) to do that.
**/
`;
