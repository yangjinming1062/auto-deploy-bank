import React, { memo, ReactNode, useEffect, useState } from 'react';
import { Handle, NodeProps, Position } from 'reactflow';
import './preview-origin.css';

export default memo((props: NodeProps<{ title: string }>) => {
	return (
		<>
			<div></div>
		</>
	);
});
