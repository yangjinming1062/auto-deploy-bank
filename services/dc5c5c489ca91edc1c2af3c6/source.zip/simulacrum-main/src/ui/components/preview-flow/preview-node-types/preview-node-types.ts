import previewClassNode from './preview-class-node/preview-class-node';
import previewMethodNode from './preview-method-node/preview-method-node';

export const previewNodeTypes = {
	previewMethodNode,
	previewClassNode,
};
