export type EdgeData = {
	trueId: string;
	sourceXOffset?: number;
	label?: string;
};
