export type NotesState = {
	content: string;
	updateContent: (content: string) => void;
};
