export const ColorVariantMap = {
	dark: 'rgb(6,6,12)',
	light: '#E5E4E2',
};
