export const Settings = {
	rootPath: 'app',
};
