
export enum MetaRepositoryActionType {
	REPOSITORY = 'REPOSITORY',
	RESOURCE = 'RESOURCE',
}