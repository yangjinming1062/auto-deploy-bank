Angular helper library for ngrx-json-api and crnk:

- Form bindings
- Table bindings
- QueryDSL-like expression API to supercede ngModel
- bulk update support with JSON Patch
- Typescript interfaces for crnk meta model

For more information see http://www.crnk.io/releases/stable/documentation/#_angular_development_with_ngrx.