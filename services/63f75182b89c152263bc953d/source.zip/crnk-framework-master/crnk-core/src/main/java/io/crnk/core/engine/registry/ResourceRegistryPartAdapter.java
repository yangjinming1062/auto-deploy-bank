package io.crnk.core.engine.registry;

public class ResourceRegistryPartAdapter implements ResourceRegistryPartListener {

	@Override
	public void onChanged(ResourceRegistryPartEvent event) {

	}
}
