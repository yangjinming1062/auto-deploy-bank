package io.crnk.core.module.discovery;

public interface ServiceDiscoveryFactory {

	ServiceDiscovery getInstance();
}
