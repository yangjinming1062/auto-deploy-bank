package io.crnk.core.engine.filter;

public enum ResourceRelationshipModificationType {

	ADD, REMOVE, SET
}
