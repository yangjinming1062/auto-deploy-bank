package io.crnk.core.engine.internal.utils;

public interface Predicate<T> {

	boolean test(T t);
}
