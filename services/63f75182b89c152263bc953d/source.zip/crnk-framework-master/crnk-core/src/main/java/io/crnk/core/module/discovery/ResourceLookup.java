package io.crnk.core.module.discovery;

import java.util.Set;

public interface ResourceLookup {

	Set<Class<?>> getResourceClasses();

}
