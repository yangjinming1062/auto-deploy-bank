package io.crnk.core.queryspec;

public enum Direction {
	ASC, DESC
}
