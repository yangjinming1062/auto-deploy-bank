package io.crnk.core.engine.properties;

public interface PropertiesProvider {

	String getProperty(String key);
}
