package io.crnk.core.repository;

public interface MatchedRelationshipRepository extends Repository {

    RelationshipMatcher getMatcher();
}
