package io.crnk.core.engine.information.repository;

/**
 * Holds information about the type of a repository.
 */
public interface RepositoryInformation {


	RepositoryMethodAccess getAccess();
}
