package io.crnk.core.engine.filter;

import io.crnk.core.engine.query.QueryContext;

public interface ResourceFilterContext {

    QueryContext getQueryContext();
}
