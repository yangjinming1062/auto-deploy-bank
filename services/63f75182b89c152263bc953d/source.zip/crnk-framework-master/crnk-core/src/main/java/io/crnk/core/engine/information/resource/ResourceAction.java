package io.crnk.core.engine.information.resource;

import io.crnk.core.engine.information.repository.RepositoryAction;

public interface ResourceAction extends RepositoryAction {

}
