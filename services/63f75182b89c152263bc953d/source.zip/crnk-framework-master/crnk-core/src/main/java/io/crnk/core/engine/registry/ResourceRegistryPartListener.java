package io.crnk.core.engine.registry;

public interface ResourceRegistryPartListener {


	void onChanged(ResourceRegistryPartEvent event);
}
