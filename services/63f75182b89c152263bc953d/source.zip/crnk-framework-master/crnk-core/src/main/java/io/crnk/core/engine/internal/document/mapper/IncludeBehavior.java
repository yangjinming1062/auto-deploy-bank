package io.crnk.core.engine.internal.document.mapper;

import io.crnk.core.boot.CrnkProperties;

/**
 * See {@link CrnkProperties#INCLUDE_BEHAVIOR} for more information.
 */
public enum IncludeBehavior {
	PER_TYPE, PER_ROOT_PATH
}
