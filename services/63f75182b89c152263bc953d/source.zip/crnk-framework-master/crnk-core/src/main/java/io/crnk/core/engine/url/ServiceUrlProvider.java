package io.crnk.core.engine.url;


public interface ServiceUrlProvider {

	String getUrl();

}
