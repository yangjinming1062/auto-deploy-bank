package io.crnk.core.engine.parser;

public interface StringParser<T> {
	T parse(String input);
}
