package io.crnk.core.engine.internal.utils;

public interface Predicate2<T, U> {
	boolean test(T t, U u);
}
