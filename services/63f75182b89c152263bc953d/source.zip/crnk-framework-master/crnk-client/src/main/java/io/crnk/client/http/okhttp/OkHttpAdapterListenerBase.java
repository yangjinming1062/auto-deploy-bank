package io.crnk.client.http.okhttp;

import okhttp3.OkHttpClient.Builder;

public class OkHttpAdapterListenerBase implements OkHttpAdapterListener {

	@Override
	public void onBuild(Builder builder) {
		// nothing to do
	}
}
