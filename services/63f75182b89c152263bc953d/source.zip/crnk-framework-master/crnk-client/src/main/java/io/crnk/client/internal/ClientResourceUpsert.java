package io.crnk.client.internal;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import io.crnk.client.ResponseBodyException;
import io.crnk.client.internal.proxy.ClientProxyFactory;
import io.crnk.core.engine.dispatcher.Response;
import io.crnk.core.engine.document.Document;
import io.crnk.core.engine.document.Relationship;
import io.crnk.core.engine.document.Resource;
import io.crnk.core.engine.document.ResourceIdentifier;
import io.crnk.core.engine.http.HttpMethod;
import io.crnk.core.engine.information.resource.ResourceField;
import io.crnk.core.engine.information.resource.ResourceFieldType;
import io.crnk.core.engine.information.resource.ResourceInformation;
import io.crnk.core.engine.internal.dispatcher.controller.ResourceUpsert;
import io.crnk.core.engine.internal.dispatcher.path.JsonPath;
import io.crnk.core.engine.internal.utils.PreconditionUtil;
import io.crnk.core.engine.internal.utils.SerializerUtil;
import io.crnk.core.engine.query.QueryAdapter;
import io.crnk.core.engine.query.QueryContext;
import io.crnk.core.engine.registry.RegistryEntry;
import io.crnk.core.engine.result.Result;
import io.crnk.core.engine.result.ResultFactory;
import io.crnk.core.queryspec.internal.QuerySpecAdapter;

class ClientResourceUpsert extends ResourceUpsert {

    private ClientProxyFactory proxyFactory;

    private Map<String, Object> resourceMap = new HashMap<>();

    public ClientResourceUpsert(ClientProxyFactory proxyFactory) {
        this.proxyFactory = proxyFactory;
    }

    public String getUID(ResourceIdentifier id) {
        return id.getType() + "#" + id.getId();
    }

    public String getUID(RegistryEntry entry, Serializable id) {
        ResourceInformation resourceInformation = entry.getResourceInformation();
        String idString = resourceInformation.toIdString(id);
        return resourceInformation.getResourceType() + "#" + idString;
    }

    public void setRelations(List<Resource> resources, QueryContext queryContext) {
        for (Resource resource : resources) {
            String uid = getUID(resource);
            Object object = resourceMap.get(uid);

            RegistryEntry registryEntry = context.getResourceRegistry().getEntry(resource.getType());

            // no need for any query parameters when doing POST/PATCH
            QueryAdapter queryAdapter = new QuerySpecAdapter(null, null, queryContext);

            setRelationsAsync(object, registryEntry, resource, queryAdapter, true).get();
        }
    }

    /**
     * Get relations from includes section or create a remote proxy
     */
    @Override
    protected Result<Object> fetchRelated(RegistryEntry entry, Serializable relationId, QueryAdapter queryAdapter) {

        ResultFactory resultFactory = context.getResultFactory();

        String uid = getUID(entry, relationId);
        Object relatedResource = resourceMap.get(uid);
        if (relatedResource != null) {
            return resultFactory.just(relatedResource);
        }
        ResourceInformation resourceInformation = entry.getResourceInformation();
        Class<?> resourceClass = resourceInformation.getResourceClass();
        return resultFactory.just(proxyFactory.createResourceProxy(resourceClass, relationId));
    }

    @Override
    protected boolean decideSetRelationObjectField(RegistryEntry entry, Serializable relationId, ResourceField field) {
        return !field.hasIdField() || resourceMap.containsKey(getUID(entry, relationId));
    }

    @Override
    protected boolean decideSetRelationObjectsField(ResourceField relationshipField) {
        return true;
    }

    public List<Object> allocateResources(List<Resource> resources, QueryContext queryContext) {
        List<Object> objects = new ArrayList<>();
        for (Resource resource : resources) {

            RegistryEntry registryEntry = getRegistryEntry(resource.getType());
            ResourceInformation resourceInformation = registryEntry.getResourceInformation();

            Object object = newEntity(resourceInformation, resource);
            setId(resource, object, resourceInformation);
            setType(resource, object);
            setAttributes(resource, object, resourceInformation, queryContext);
            setLinks(resource, object, resourceInformation);
            setMeta(resource, object, resourceInformation);

            objects.add(object);

            String uid = getUID(resource);
            resourceMap.put(uid, object);
        }
        return objects;
    }

    @Override
    public boolean isAcceptable(JsonPath jsonPath, String method) {
        // no in use on client side, consider refactoring ResourceUpsert to
        // separate from controllers
        throw new UnsupportedOperationException();
    }

    @Override
    public Result<Response> handleAsync(JsonPath jsonPath, QueryAdapter queryAdapter, Document requestDocument) {
        // no in use on client side, consider refactoring ResourceUpsert to
        // separate from controllers
        throw new UnsupportedOperationException();

    }

    @Override
    protected RuntimeException newBodyException(String message, IOException e) {
        throw new ResponseBodyException(message, e);
    }

    @Override
    protected Optional<Result> setRelationsFieldAsync(Object newResource, RegistryEntry registryEntry,
                                                      Map.Entry<String, Relationship> property, QueryAdapter queryAdapter) {

        Relationship relationship = property.getValue();

        if (!relationship.getData().isPresent()) {
            ObjectNode links = relationship.getLinks();
            ObjectNode meta = relationship.getMeta();
            if (links != null) {
                // create proxy to lazy load relations
                String fieldJsonName = property.getKey();
                ResourceInformation resourceInformation = registryEntry.getResourceInformation();
                QueryContext queryContext = queryAdapter.getQueryContext();
                ResourceField field = resourceInformation.findFieldByJsonName(fieldJsonName, queryContext.getRequestVersion());
                PreconditionUtil.verifyEquals(ResourceFieldType.RELATIONSHIP, field.getResourceFieldType(), "expected {} to be a relationship", fieldJsonName);
                Class elementType = field.getElementType();
                Class collectionClass = field.getType();

                JsonNode relatedNode = links.get("related");
                if (relatedNode != null) {
                    String url = null;
                    if (relatedNode.has(SerializerUtil.HREF)) {
                        JsonNode hrefNode = relatedNode.get(SerializerUtil.HREF);
                        if (hrefNode != null) {
                            url = hrefNode.asText().trim();
                        }
                    } else {
                        url = relatedNode.asText().trim();
                    }
                    Object proxy = proxyFactory.createCollectionProxy(elementType, collectionClass, url, links, meta);
                    field.getAccessor().setValue(newResource, proxy);
                }
            }
            return Optional.empty();
        } else {
            // set elements
            return super.setRelationsFieldAsync(newResource, registryEntry, property, queryAdapter);
        }
    }

    @Override
    protected boolean checkAccess() {
        return false;
    }

    @Override
    protected HttpMethod getHttpMethod() {
        throw new UnsupportedOperationException();
    }

    @Override
	protected boolean isClient() {
		return true;
	}
}
