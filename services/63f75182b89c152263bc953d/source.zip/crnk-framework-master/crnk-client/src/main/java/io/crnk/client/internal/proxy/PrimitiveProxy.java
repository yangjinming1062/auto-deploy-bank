package io.crnk.client.internal.proxy;


public interface PrimitiveProxy {

}
