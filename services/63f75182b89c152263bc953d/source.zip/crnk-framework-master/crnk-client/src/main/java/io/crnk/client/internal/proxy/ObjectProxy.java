package io.crnk.client.internal.proxy;

public interface ObjectProxy {

	String getUrl();

	boolean isLoaded();
}
