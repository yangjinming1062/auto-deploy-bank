package io.crnk.client.suite;

import io.crnk.test.suite.RelationIdAccessTestBase;

public class RelationIdClientTest extends RelationIdAccessTestBase {

	public RelationIdClientTest() {
		ClientTestContainer testContainer = new ClientTestContainer();
		this.testContainer = testContainer;
	}
}
