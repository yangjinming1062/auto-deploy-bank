package io.crnk.client;

/**
 * Class uses the regular CrnkClient, i.e. nothing to configure here.<br />
 * All tests have been moved to {@link AbstractProxiedObjectsClientTest}.
 */
public class ProxiedObjectsClientTest extends AbstractProxiedObjectsClientTest {

}
