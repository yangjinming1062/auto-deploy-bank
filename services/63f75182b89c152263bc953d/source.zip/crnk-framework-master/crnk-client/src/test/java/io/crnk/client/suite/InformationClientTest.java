package io.crnk.client.suite;

import io.crnk.test.suite.InformationAccessTestBase;

public class InformationClientTest extends InformationAccessTestBase {

	public InformationClientTest() {
		ClientTestContainer testContainer = new ClientTestContainer();
		this.testContainer = testContainer;
	}

}