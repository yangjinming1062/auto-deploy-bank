<template>
  <div>
    <SendMsg queryType="group"></SendMsg>
  </div>
</template>

<script>
import SendMsg from '../common/SendMsg';
export default {
  components: {SendMsg}
}
</script>

<style scoped>
</style>