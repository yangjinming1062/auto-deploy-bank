<template>
  <div>
    <User queryType="contact"></User>
  </div>
</template>

<script>
import User from '../common/User';
export default {
  components: {User}
}
</script>

<style scoped>
</style>