# @syllepsis/editor

[official website](https://bytedance.github.io/syllepsis/)

middle layer of `syllepsis`.

provide `SylEditorService` and basic module constructor to help `access-layer` to use `syllepsis/adapter` more easily.
