const LIST_ITEM_NAME = 'list_item';

export { LIST_ITEM_NAME };
