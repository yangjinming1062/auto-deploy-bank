# @syllepsis/access-react

[official website](https://bytedance.github.io/syllepsis/)

`react` access of `syllepsis`.

help quickly use `syllepsis editor` in `react`.

implemented the rendering method of `Toolbar` and `Card` in `react`.
