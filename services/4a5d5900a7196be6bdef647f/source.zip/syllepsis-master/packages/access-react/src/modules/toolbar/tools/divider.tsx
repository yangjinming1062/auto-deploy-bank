import React from 'react';

const Divider = () => <span className="syl-toolbar-divider" />;

export { Divider };
