# @syllepsis/adapter

[official website](https://bytedance.github.io/syllepsis/)

core of `syllepsis` editor which base on `prosemirror`.

provide `SylApi`, `SylPlugin`, `Controller`, `Schema`, `Module` to help build a custom rich-text editor.
