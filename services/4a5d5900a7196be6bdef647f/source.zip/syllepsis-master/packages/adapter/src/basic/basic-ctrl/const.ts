import { PluginKey } from 'prosemirror-state';

const BSControlKey = new PluginKey('basicControl');
export { BSControlKey };
