## Placeholder plugins

A plugin to lazy load react-components
