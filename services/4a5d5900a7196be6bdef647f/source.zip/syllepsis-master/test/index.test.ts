require('./case/adapter/index.test');
