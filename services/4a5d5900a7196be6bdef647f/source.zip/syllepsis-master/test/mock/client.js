global.navigator = {};
