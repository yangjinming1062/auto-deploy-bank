# Example

In this chapter, you will study what `Syllepsis` provide through some examples and source code

?> If you have no special **customization** requirements, you can skip this part and directly refer to [React example](/en/chapters/access-react). It provides a code example of how to use **all built-in plugins**.