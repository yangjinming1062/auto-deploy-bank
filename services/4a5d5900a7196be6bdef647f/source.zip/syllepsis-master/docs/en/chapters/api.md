# Call API

In this demo, illustrate how to use the API through examples

For more instructions, please check [API documentation](/en/api)

## Example

[api](https://codesandbox.io/embed/api-en-bek33?hidenavigation=1 ':include :type=iframe width=100% height=500px')