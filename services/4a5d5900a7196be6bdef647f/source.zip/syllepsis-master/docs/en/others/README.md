!> This Chapter is translated by machine. please feedback [Issue](https://github.com/bytedance/syllepsis/issues) if expression unclear.

This chapter will introduce some additional functions