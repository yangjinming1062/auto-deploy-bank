`syllepsis` is packaged based on `prosemirror`, the collaborative editing scheme supported by the `prosemirror` community, and `syllepsis` also supports. There are currently two mainstream schemes:

1. Based on `prosemirror-collab` implementation, [code example](https://github.com/lastnigtic/syllepsis-collab)
2. Based on `yjs` implementation, [code example](https://github.com/lastnigtic/syllepsis-yjs)
