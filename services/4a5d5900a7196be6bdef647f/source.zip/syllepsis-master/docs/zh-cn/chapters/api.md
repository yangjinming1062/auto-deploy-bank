# 调用API

`Syllepsis`根据实际的业务场景，封装了一些常用的Api，通过`editor`句柄即可调用。

此章抽取了几个常用的 Api 进行举例。

更多说明，请查看 [API](/zh-cn/api) 说明文档

## 示例

[api](https://codesandbox.io/embed/api-vd8z5?hidenavigation=1 ':include :type=iframe width=100% height=500px')
