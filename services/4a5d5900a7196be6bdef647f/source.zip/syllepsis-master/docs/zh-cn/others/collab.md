`syllepsis`基于`prosemirror`封装而来，`prosemirror`社区支持的协同编辑方案，`syllepsis`也同样支持，目前有两种比较主流的方案：

1. 基于`prosemirror-collab`实现，[代码例子](https://github.com/lastnigtic/syllepsis-collab)
2. 基于`yjs`实现，[代码例子](https://github.com/lastnigtic/syllepsis-yjs)
