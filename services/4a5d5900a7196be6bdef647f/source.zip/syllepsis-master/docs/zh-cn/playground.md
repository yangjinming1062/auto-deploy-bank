# 例子

一个简单，且包含常见功能的编辑器


[access-react](https://codesandbox.io/embed/plugin-react-tflz3?hidenavigation=1 ':include :type=iframe width=100% height=600px')
