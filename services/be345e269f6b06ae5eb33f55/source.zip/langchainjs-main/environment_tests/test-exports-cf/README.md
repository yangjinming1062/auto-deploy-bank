# test-exports-cf

This package was generated with `wrangler init` with the purpose of testing compatibility with Cloudlfare Workers.
