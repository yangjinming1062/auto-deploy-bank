import { DataSource } from "typeorm";
import { OpenAI } from "@langchain/openai";
import { SqlDatabase } from "@langchain/classic/sql_db";
import { SqlDatabaseChain } from "@langchain/classic/chains/sql_db";

/**
 * This example uses Chinook database, which is a sample database available for SQL Server, Oracle, MySQL, etc.
 * To set it up follow the instructions on https://database.guide/2-sample-databases-sqlite/, placing the .db file
 * in the examples folder.
 */
const datasource = new DataSource({
  type: "sqlite",
  database: "Chinook.db",
});

const db = await SqlDatabase.fromDataSourceParams({
  appDataSource: datasource,
});

const chain = new SqlDatabaseChain({
  llm: new OpenAI({ temperature: 0 }),
  database: db,
  sqlOutputKey: "sql",
});

const res = await chain.invoke({ query: "How many tracks are there?" });
/* Expected result:
 * {
 *   result: ' There are 3503 tracks.',
 *   sql: ' SELECT COUNT(*) FROM "Track";'
 * }
 */
console.log(res);
