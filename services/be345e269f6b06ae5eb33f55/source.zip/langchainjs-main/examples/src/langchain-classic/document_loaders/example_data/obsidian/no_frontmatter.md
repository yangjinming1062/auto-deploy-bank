### Description

#recipes #dessert #cookies

A document with HR elements that might trip up a front matter parser:

---

### Ingredients

- 3/4 cup (170g) **unsalted butter**, slightly softened to room temperature.
- 1 and 1/2 cups (180g) **confectioners’ sugar**

---
