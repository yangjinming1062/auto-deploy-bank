---
tags: journal/entry, obsidian
---

No other content than the frontmatter.
