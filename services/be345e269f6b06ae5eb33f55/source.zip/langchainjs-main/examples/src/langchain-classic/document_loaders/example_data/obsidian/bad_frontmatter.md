---
anArray:
 one
- two
- three
tags: 'onetag', 'twotag' ]
---

A document with frontmatter that isn't valid.
