A markdown document with no additional metadata.
