---
aFloat: 13.12345
anInt: 15
aBool: true
aString: string value
anArray:
  - one
  - two
  - three
aDict:
  dictId1: "58417"
  dictId2: 1500
tags: ["onetag", "twotag"]
---

# Tags

()#notatag
#12345
#read
something #tagWithCases

- #tag-with-dash
  #tag_with_underscore #tag/with/nesting

# Dataview

Here is some data in a [dataview1:: a value] line.
Here is even more data in a (dataview2:: another value) line.
dataview3:: more data
notdataview4: this is not a field
notdataview5: this is not a field

# Text content

https://example.com/blog/#not-a-tag
