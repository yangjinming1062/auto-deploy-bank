import { LunaryHandler } from "@langchain/community/callbacks/handlers/lunary";

const handler = new LunaryHandler({
  appId: "app ID",
  // verbose: true,
  // apiUrl: 'custom self hosting url'
});
