import { awaitAllCallbacks } from "@langchain/core/callbacks/promises";

await awaitAllCallbacks();
