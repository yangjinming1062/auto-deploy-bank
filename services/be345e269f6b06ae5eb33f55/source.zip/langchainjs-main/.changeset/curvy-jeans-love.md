---
"@langchain/anthropic": patch
---

feat(anthropic): support tool search tool
