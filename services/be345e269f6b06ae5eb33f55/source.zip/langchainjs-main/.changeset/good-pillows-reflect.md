---
"@langchain/google-genai": patch
---

safe access around custom content parts
