---
"@langchain/openai": minor
---

feat(openai): support for MCP connector tool
