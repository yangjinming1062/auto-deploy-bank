---
"@langchain/anthropic": patch
---

add named webfetch tool
