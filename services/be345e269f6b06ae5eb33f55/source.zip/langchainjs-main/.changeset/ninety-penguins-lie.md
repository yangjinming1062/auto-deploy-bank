---
"@langchain/core": patch
---

test(core): add test for response_metadata in streamEvents
