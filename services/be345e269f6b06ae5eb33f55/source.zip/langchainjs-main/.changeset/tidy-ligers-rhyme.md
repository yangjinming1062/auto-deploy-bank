---
"@langchain/openai": minor
---

feat(langchain): add support for image generation tool
