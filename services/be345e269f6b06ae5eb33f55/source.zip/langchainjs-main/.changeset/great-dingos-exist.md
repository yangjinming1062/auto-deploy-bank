---
"@langchain/google-genai": patch
---

fix(google-genai): support custom agent names in createAgent
