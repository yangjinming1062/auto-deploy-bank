---
"@langchain/anthropic": patch
---

add named mcp toolset tool
