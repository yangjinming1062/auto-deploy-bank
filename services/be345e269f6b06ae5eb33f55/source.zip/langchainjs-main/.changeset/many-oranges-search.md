---
"@langchain/openai": minor
---

feat(openai): support code interpreter tool
