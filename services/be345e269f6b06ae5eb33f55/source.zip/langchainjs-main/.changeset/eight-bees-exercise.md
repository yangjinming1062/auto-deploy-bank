---
"@langchain/anthropic": minor
---

add named text editor tool
