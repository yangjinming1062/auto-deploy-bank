---
"@langchain/community": patch
---

add elasticsearch hybrid search
