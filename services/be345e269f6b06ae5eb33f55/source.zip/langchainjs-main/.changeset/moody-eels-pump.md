---
"@langchain/openai": minor
---

feat(openai): add support for local shell tool
