---
"@langchain/core": patch
"@langchain/mcp-adapters": patch
---

fix(mcp-adapters): preserve timeout from RunnableConfig in MCP tool calls
