---
"@langchain/openai": minor
---

feat(openai): add support for fileSearch tool
