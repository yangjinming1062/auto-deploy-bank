---
"@langchain/openai": minor
---

feat(openai): add support for apply patch tool
