---
"@langchain/openai": minor
---

add support for computer use tool
