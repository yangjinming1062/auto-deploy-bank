---
"@langchain/openai": patch
---

fixes filename / base64 conversions in openai completions converters (#9512)

