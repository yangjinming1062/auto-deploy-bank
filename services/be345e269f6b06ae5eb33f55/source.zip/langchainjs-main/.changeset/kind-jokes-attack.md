---
"@langchain/openai": minor
---

feat(openai): add support for shell tool
