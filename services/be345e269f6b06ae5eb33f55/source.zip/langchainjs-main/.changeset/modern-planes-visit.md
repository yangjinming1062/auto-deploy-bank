---
"@langchain/anthropic": patch
---

add named computer use tool
