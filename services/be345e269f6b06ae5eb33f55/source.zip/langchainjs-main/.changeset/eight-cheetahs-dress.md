---
"@langchain/openai": minor
---

feat(openai): support web search tool
