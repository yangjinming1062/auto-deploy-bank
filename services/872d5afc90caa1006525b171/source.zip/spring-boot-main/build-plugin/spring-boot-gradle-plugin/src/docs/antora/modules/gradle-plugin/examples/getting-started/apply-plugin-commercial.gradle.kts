plugins {
	id("org.springframework.boot") version "{version-spring-boot}"
}
