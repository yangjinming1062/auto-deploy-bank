plugins {
	id("org.springframework.boot") version "{version-spring-boot}"
	id("org.graalvm.buildtools.native") version "{version-native-build-tools}"
	java
}
