ImputedData Class
=================

.. autoclass:: miceforest.imputed_data.ImputedData
   :members:
   :undoc-members:
   :show-inheritance: