package com.mzt.logapi.beans;

/**
 * @author muzhantong
 * create on 2022/3/31 11:39 PM
 */
public enum CodeVariableType {
    ClassName,
    MethodName,
    ;
}
