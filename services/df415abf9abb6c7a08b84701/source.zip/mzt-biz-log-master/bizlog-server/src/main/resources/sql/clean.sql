DELETE
FROM t_logrecord;