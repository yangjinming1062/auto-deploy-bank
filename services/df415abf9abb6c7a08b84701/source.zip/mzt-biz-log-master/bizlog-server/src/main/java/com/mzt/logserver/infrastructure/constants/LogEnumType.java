package com.mzt.logserver.infrastructure.constants;

/**
 * @author muzhantong
 * create on 2022/3/16 2:09 PM
 */
public enum LogEnumType {

    ORDER;

    public static String getName() {
        return "";
    }
}
