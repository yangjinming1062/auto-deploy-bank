package com.mzt.logserver.infrastructure.constants;

/**
 * @author muzhantong
 * create on 2020/4/30 10:56 上午
 */
public class LogRecordType {

    public static final String ORDER = "ORDER";

    public static final String USER = "USER";

    public static final String SKU = "SKU";
}
