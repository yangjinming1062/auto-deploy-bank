package cn.revoist.lifephoton.plugin.data.json

/**
 * @author 6hisea
 * @date  2025/3/5 14:10
 * @description: None
 */
class JSONArray:ArrayList<Any?>() {
}