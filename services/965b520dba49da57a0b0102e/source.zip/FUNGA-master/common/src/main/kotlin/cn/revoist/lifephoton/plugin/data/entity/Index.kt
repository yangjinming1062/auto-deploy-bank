package cn.revoist.lifephoton.plugin.data.entity

/**
 * @author 6hisea
 * @date  2025/5/25 12:23
 * @description: None
 */
annotation class Index()
