package cn.revoist.lifephoton.plugin.data.json

/**
 * @author 6hisea
 * @date  2025/3/5 14:09
 * @description: None
 */
class JSONObject : HashMap<String,Any?>() {

}