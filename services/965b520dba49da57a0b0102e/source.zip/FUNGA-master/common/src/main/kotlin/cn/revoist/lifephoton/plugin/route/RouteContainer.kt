package cn.revoist.lifephoton.plugin.route

/**
 * @author 6hisea
 * @date  2025/1/22 15:57
 * @description: None
 */
annotation class RouteContainer(
    val pluginId:String,
    val root: String
)
