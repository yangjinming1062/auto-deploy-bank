
import cn.revoist.lifephoton.ktors.startEngine

/**
 * @author 6hisea
 * @date  2025/3/2 22:03
 * @description: None
 */
fun main() {
    //FrontAPIPrinter.generate("C:\\Users\\12232\\Desktop\\test")
    startEngine(arrayOf())
}