package cn.revoist.lifephoton.module.mti.pages

import cn.revoist.lifephoton.module.filemanagement.FileManagementAPI
import cn.revoist.lifephoton.module.mti.MatingTypeImputation
import cn.revoist.lifephoton.module.mti.data.entity.request.ImputationRequest
import cn.revoist.lifephoton.plugin.data.sqltype.gson
import cn.revoist.lifephoton.plugin.requestBody
import cn.revoist.lifephoton.plugin.route.*
import cn.revoist.lifephoton.plugin.route.Route
import cn.revoist.lifephoton.tools.checkNotNull
import io.ktor.server.routing.*
import kotlinx.serialization.json.internal.decodeStringToJsonTree
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader

/**
 * @author 6hisea
 * @date  2025/3/2 20:21
 * @description: None
 */
@RouteContainer("mating-type-imputation","imputation")
object Imputation {
    @Route
    @Api("获取推断结果",
        [
        Param("matingResultMatrixFile","the matrix of mating result"),
        Param("osResultFile","the table result for OS experiment")
        ]
    )
    suspend fun getImputationResult(call: RoutingCall){
        val request = call.requestBody(ImputationRequest::class.java)
        val osResultFile = FileManagementAPI.findFileById(request.osResultFile)
        val matingResultMatrixFile = FileManagementAPI.findFileById(request.matingResultMatrixFile)
        call.checkNotNull(osResultFile, matingResultMatrixFile)

        val process = Runtime.getRuntime().exec(
            "python ${MatingTypeImputation.getConfig("exec","/data/LifePhoton/mating-type-imputation/mating_type_imputation.py")} ${matingResultMatrixFile!!.absolutePath} ${osResultFile!!.absolutePath}"
        )
        process.waitFor()

// Read both standard output and error streams
        val stdInput = BufferedReader(InputStreamReader(process.inputStream))
        val stdError = BufferedReader(InputStreamReader(process.errorStream))

        val outFile = File(matingResultMatrixFile.absolutePath + ".output.json")
        if (outFile.exists() && outFile.length() > 0) {
            call.ok(gson.fromJson(outFile.readText(), Any::class.java))
        } else {
            // Read both streams to get complete error information
            val output = stdInput.readText()
            val error = stdError.readText()

            if (error.isNotBlank()) {
                call.error("Error: $error")
            } else if (output.isNotBlank()) {
                call.error("Error: $output")
            } else {
                call.error("Unknown error occurred during Python script execution")
            }
        }
    }
}