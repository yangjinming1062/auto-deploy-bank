package cn.revoist.lifephoton.module.mti.data.entity.request

/**
 * @author 6hisea
 * @date  2025/3/2 20:42
 * @description: None
 */
open class ImputationRequest {
    lateinit var matingResultMatrixFile:String
    lateinit var osResultFile:String
}