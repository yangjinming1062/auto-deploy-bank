package cn.revoist.lifephoton.module.fungipattern.core.storage.page

import cn.revoist.lifephoton.module.authentication.helper.sqlbase.SqlBase

/**
 * @author 6hisea
 * @date  2025/12/9 21:11
 * @description: None
 */
object CompanyPage{
}