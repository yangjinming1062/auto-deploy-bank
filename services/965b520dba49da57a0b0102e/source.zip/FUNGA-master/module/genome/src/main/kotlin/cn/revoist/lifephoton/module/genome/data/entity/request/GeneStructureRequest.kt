package cn.revoist.lifephoton.module.genome.data.entity.request

/**
 * @author 6hisea
 * @date  2025/1/25 16:50
 * @description: None
 */
class GeneStructureRequest : GeneBasicRequest(){
    val offset = false
}