package cn.revoist.lifephoton.module.genome.data.entity.request

/**
 * @author 6hisea
 * @date  2025/1/25 10:49
 * @description: None
*/
class GeneInfoRequest {
    val type:String = "id"
    val data:HashMap<String,Any> = hashMapOf(
        "gene_id" to "W01Dio0000040.1",
    )
}