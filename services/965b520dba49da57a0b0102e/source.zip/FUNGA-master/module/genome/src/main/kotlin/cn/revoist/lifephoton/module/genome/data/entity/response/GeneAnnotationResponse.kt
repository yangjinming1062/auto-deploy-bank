package cn.revoist.lifephoton.module.genome.data.entity.response

/**
 * @author 6hisea
 * @date  2025/1/25 18:04
 * @description: None
 */
class GeneAnnotationResponse {
    lateinit var type:String
    lateinit var data:List<HashMap<String,Any?>>
}