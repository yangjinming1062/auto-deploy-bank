package cn.revoist.lifephoton.module.funga.core.genephenotype.model

/**
 * @author 6hisea
 * @date  2025/5/27 14:25
 * @description: None
 */
data class PhenotypeReferences(var phenotype:String,var references:List<String>,val summary:String) {
}