package cn.revoist.lifephoton.module.funga.data.table.type

/**
 * @author 6hisea
 * @date  2025/4/13 12:43
 * @description: None
 */
data class Source(val name: String, val link: String)