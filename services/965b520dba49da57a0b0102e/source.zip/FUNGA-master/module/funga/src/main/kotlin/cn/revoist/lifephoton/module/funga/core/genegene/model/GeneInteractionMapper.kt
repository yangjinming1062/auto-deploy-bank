package cn.revoist.lifephoton.module.funga.core.genegene.model

import cn.revoist.lifephoton.plugin.data.entity.Map

/**
 * @author 6hisea
 * @date  2025/4/20 17:38
 * @description: None
 */

class GeneInteractionMapper {
    @Map("gene1")
    lateinit var gene1:String

    @Map("gene2")
    lateinit var gene2:String

}