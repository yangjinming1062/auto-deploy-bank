package cn.revoist.lifephoton.module.funga.core.info.model
/**
 * @author 6hisea
 * @date  2025/11/15 16:30
 * @description: None
 */
class DBInfoMapper{

    val id = -1

    lateinit var name: String

    lateinit var taxonomy: String

    lateinit var description:String

    lateinit var image:String
}