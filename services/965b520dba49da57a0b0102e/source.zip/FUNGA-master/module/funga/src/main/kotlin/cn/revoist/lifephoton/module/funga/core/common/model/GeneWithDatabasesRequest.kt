package cn.revoist.lifephoton.module.funga.core.common.model

/**
 * @author 6hisea
 * @date  2025/4/13 17:33
 * @description: None
 */

class GeneWithDatabasesRequest: WithDatabasesRequest() {
    lateinit var gene:String
}