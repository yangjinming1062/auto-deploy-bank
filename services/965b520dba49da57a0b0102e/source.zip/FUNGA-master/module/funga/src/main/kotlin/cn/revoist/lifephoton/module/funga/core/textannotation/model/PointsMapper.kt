package cn.revoist.lifephoton.module.funga.core.textannotation.model

import cn.revoist.lifephoton.plugin.data.entity.Map

/**
 * @author 6hisea
 * @date  2025/11/10 18:22
 * @description: None
 */
class PointsMapper {
    @Map
    val user_id : Long = -1L
    @Map
    val points : Double = 0.0
}