package cn.revoist.lifephoton.module.aiassistant.impl.memory

/**
 * @author 6hisea
 * @date  2025/11/11 10:44
 * @description: None
 */
class MemoryMapper {
    val id = -1L
    val user_id = -1L
    lateinit var memory_id: String
    var message : String?=null
    lateinit var update_date:String
    val summary : String?=null
}