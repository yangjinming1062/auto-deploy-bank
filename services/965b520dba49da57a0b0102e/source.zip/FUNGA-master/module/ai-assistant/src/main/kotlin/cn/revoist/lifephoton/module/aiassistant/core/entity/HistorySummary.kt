package cn.revoist.lifephoton.module.aiassistant.core.entity

/**
 * @author 6hisea
 * @date  2025/11/13 19:13
 * @description: None
 */
data class HistorySummary(
    val memory_id: String,
    val summary: String,
    val update_date: Long
) {

}