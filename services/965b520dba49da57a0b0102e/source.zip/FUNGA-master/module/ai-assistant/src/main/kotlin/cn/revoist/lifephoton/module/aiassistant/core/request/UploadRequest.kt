package cn.revoist.lifephoton.module.aiassistant.core.request

/**
 * @author 6hisea
 * @date  2025/11/11 17:26
 * @description: None
 */
class UploadRequest {
    val isPublic = true
    val citation = ""
    val sourceName = ""
    val sourceLink = ""
    val file = ""
    val isZip = false
}