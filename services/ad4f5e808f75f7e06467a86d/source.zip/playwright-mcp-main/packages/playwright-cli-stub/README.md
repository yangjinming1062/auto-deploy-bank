# 🎭 Playwright CLI

This package has moved to @playwright/cli.

```sh
$ npm i -g @playwright/cli
```
