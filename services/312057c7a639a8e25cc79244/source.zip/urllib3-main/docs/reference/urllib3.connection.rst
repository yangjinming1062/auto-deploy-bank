Connections
===========

.. automodule:: urllib3.connection

.. autoclass:: urllib3.connection.HTTPConnection
    :members:
    :exclude-members: putrequest
    :show-inheritance:

.. autoclass:: urllib3.connection.HTTPSConnection
    :members:
    :show-inheritance:

.. autoclass:: urllib3.connection.ProxyConfig
    :members:
    :show-inheritance:
