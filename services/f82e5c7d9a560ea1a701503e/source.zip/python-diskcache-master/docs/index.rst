.. include:: ../README.rst

.. toctree::
   :hidden:

   tutorial
   cache-benchmarks
   djangocache-benchmarks
   case-study-web-crawler
   case-study-landing-page-caching
   sf-python-2017-meetup-talk
   api
   development
