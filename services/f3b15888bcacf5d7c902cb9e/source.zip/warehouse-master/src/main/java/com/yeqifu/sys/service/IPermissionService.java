package com.yeqifu.sys.service;

import com.yeqifu.sys.entity.Permission;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * InnoDB free: 9216 kB 服务类
 * </p>
 *
 * @author luoyi-
 * @since 2019-11-22
 */
public interface IPermissionService extends IService<Permission> {

}
