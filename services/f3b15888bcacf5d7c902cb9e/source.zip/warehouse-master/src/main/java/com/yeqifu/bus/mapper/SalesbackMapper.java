package com.yeqifu.bus.mapper;

import com.yeqifu.bus.entity.Salesback;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * InnoDB free: 9216 kB Mapper 接口
 * </p>
 *
 * @author luoyi-
 * @since 2019-12-23
 */
public interface SalesbackMapper extends BaseMapper<Salesback> {

}
