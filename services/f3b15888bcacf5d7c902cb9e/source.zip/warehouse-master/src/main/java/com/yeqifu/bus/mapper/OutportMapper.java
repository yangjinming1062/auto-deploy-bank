package com.yeqifu.bus.mapper;

import com.yeqifu.bus.entity.Outport;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * InnoDB free: 9216 kB Mapper 接口
 * </p>
 *
 * @author luoyi-
 * @since 2019-12-19
 */
public interface OutportMapper extends BaseMapper<Outport> {

}
