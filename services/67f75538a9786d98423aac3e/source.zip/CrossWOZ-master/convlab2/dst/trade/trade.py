from convlab2.dst.dst import DST

class TRADE(DST):
    def update(self, act):
        pass