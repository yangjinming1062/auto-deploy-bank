from convlab2.policy.rule.crosswoz.rule_simulator import Simulator
