module.exports = {
    apps: [
        {
            name: "data_labelling",
            script: "run.py",
            interpreter: "venv/bin/python"
        }
    ]
};
