---
sidebar_position: 4
title: Create Blog Post
---

## Visit the website
After local startup, you can directly access: http://localhost:3001

![QQ_1730649142941.png]( https://api.gaoredu.com/public/uploads/2024-11-03/QQ_1730649142941.png )
## Login page

Before logging in, you need to register an account first. After successful registration, log in to the account:

![QQ_1730649395704.png]( https://api.gaoredu.com/public/uploads/2024-11-03/QQ_1730649395704.png )

![QQ_1730649194674.png]( https://api.gaoredu.com/public/uploads/2024-11-03/QQ_1730649194674.png )

## Enter the backend

You can directly access: http://localhost:3001/admin
![QQ_1730649254076.png]( https://api.gaoredu.com/public/uploads/2024-11-03/QQ_1730649254076.png )

## New Article

You can directly select the "New Article" option through the directory on the left:
![QQ_1730649280585.png]( https://api.gaoredu.com/public/uploads/2024-11-03/QQ_1730649280585.png )
## Publish article

Click the "Publish" button in the upper right corner to complete the content publishing:
![QQ_1730649303524.png]( https://api.gaoredu.com/public/uploads/2024-11-03/QQ_1730649303524.png )
So far, your first article has been created.