import React from 'react';

import { PageEditor } from '@/components/PageEditor';

const Editor = () => {
  return <PageEditor />;
};

export default Editor;
