import React from 'react';

import { Error404 } from './_error';

function Error() {
  return <Error404 />;
}

export default Error;
