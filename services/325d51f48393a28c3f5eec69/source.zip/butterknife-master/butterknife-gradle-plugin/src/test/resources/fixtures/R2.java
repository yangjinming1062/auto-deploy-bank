// Generated code from Butter Knife gradle plugin. Do not modify!
package com.butterknife.example;

import androidx.annotation.AnimRes;
import androidx.annotation.ArrayRes;
import androidx.annotation.AttrRes;
import androidx.annotation.BoolRes;
import androidx.annotation.ColorRes;
import androidx.annotation.DimenRes;
import androidx.annotation.DrawableRes;
import androidx.annotation.IdRes;
import androidx.annotation.IntegerRes;
import androidx.annotation.LayoutRes;
import androidx.annotation.MenuRes;
import androidx.annotation.PluralsRes;
import androidx.annotation.StringRes;
import androidx.annotation.StyleRes;
import androidx.annotation.StyleableRes;

public final class R2 {
  public static final class anim {
    @AnimRes
    public static final int res = 1;
  }

  public static final class array {
    @ArrayRes
    public static final int res = 2;
  }

  public static final class attr {
    @AttrRes
    public static final int res = 3;
  }

  public static final class bool {
    @BoolRes
    public static final int res = 4;
  }

  public static final class color {
    @ColorRes
    public static final int res = 5;
  }

  public static final class dimen {
    @DimenRes
    public static final int res = 6;
  }

  public static final class drawable {
    @DrawableRes
    public static final int res = 7;
  }

  public static final class id {
    @IdRes
    public static final int res = 8;
  }

  public static final class integer {
    @IntegerRes
    public static final int res = 9;
  }

  public static final class layout {
    @LayoutRes
    public static final int res = 10;
  }

  public static final class menu {
    @MenuRes
    public static final int res = 11;
  }

  public static final class plurals {
    @PluralsRes
    public static final int res = 12;
  }

  public static final class string {
    @StringRes
    public static final int res = 13;
  }

  public static final class style {
    @StyleRes
    public static final int res = 14;
  }

  public static final class styleable {
    @StyleableRes
    public static final int resArray_child = 15;

    @StyleableRes
    public static final int resArray_child2 = 16;
  }
}
