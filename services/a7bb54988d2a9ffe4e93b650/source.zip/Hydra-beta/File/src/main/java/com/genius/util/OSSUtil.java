package com.genius.util;

/**
 * @author Genius
 * @date 2023/05/01 16:34
 **/
public class OSSUtil {
}
