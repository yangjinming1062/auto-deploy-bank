package com.genius.pojo;

import org.example.common.ConfigFile;

/**
 * @author Genius
 * @date 2023/04/26 00:12
 **/
public class CommonConfigFile extends ConfigFile {

    public CommonConfigFile(String filePath, String fileName, Object data) {
        super(filePath, fileName, data);
    }
}
