package com.pinecone.hydra.deploy.entity;

import com.pinecone.hydra.deploy.entity.iface.Virtual;

public class GenericVirtual implements Virtual {
}
