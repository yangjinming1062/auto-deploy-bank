package com.pinecone.hydra.deploy.source;

import com.pinecone.framework.system.prototype.Pinenut;

public interface NamespaceManipulator extends Pinenut {
}
