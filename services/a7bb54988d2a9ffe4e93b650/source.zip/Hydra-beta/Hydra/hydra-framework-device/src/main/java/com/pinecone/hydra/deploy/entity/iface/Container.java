package com.pinecone.hydra.deploy.entity.iface;

public interface Container extends Integration{
}
