package com.pinecone.hydra.deploy.entity.iface;

import com.pinecone.framework.system.prototype.Pinenut;

public interface Virtual extends Pinenut {
}
