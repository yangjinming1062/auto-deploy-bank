package com.pinecone.hydra.device;

import com.pinecone.framework.system.prototype.Pinenut;

public interface Disk extends Pinenut {
}
