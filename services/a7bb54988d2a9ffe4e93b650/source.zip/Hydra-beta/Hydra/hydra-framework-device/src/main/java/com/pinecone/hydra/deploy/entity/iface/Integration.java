package com.pinecone.hydra.deploy.entity.iface;

public interface Integration extends Deploy{
}
