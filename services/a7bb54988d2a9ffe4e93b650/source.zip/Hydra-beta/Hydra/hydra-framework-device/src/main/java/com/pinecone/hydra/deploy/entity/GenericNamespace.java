package com.pinecone.hydra.deploy.entity;

import com.pinecone.hydra.deploy.entity.iface.Namespace;

public class GenericNamespace implements Namespace {

}
