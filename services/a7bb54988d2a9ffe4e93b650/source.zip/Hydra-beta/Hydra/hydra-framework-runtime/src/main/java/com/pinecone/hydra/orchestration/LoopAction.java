package com.pinecone.hydra.orchestration;

public class LoopAction extends ArchLoop {
    public LoopAction() {
        super();
    }
}
