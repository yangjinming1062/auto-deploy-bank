package com.pinecone.hydra.atlas.source;

import com.pinecone.hydra.unit.vgraph.source.AtlasMasterManipulator;

public interface RuntimeMasterManipulator extends AtlasMasterManipulator {
}
