package com.pinecone.hydra.task.kom.entity;

public class GenericCommonMeta extends ArchElementNode implements CommonMeta {
    public GenericCommonMeta() {
        super();
    }
}
