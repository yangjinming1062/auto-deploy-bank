package com.pinecone.hydra.auto;

import com.pinecone.framework.system.functions.Executor;

/**
 * Instruction -mation
 */
public interface Instructation extends Executor {
}
