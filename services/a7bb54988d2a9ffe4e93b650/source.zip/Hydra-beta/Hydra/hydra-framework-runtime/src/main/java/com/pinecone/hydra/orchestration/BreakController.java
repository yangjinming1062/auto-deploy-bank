package com.pinecone.hydra.orchestration;

public interface BreakController extends ProcessController {
}
