package com.pinecone.hydra.task.kom;

import com.pinecone.hydra.system.ko.ArchKernelObjectConfig;

public class KernelServiceConfig extends ArchKernelObjectConfig implements ServiceConfig {
}
