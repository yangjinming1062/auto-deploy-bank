package com.pinecone.hydra.task;

public interface Serviciom extends Task {

}
