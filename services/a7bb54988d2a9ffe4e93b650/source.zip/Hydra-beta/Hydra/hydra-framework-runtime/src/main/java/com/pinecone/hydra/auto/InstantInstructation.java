package com.pinecone.hydra.auto;

public interface InstantInstructation extends Instructation {
}
