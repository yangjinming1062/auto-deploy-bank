package com.pinecone.hydra.orchestration;

public interface BooleanCondition extends Condition {
    boolean result();
}
