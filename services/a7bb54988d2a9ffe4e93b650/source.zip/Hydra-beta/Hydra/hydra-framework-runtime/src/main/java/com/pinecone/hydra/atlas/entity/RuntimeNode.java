package com.pinecone.hydra.atlas.entity;

import com.pinecone.hydra.unit.vgraph.entity.GraphNode;

public interface RuntimeNode extends GraphNode {
    void setName( String name );
}
