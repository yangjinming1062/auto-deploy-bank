package com.pinecone.hydra.task.kom;

import com.pinecone.hydra.system.ko.KernelObjectConfig;

public interface ServiceConfig extends KernelObjectConfig {
}
