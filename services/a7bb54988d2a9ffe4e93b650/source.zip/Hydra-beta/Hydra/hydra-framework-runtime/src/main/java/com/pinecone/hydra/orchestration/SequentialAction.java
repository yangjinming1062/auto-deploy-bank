package com.pinecone.hydra.orchestration;

public class SequentialAction extends ArchSequential {
    public SequentialAction() {
        super();
    }

}
