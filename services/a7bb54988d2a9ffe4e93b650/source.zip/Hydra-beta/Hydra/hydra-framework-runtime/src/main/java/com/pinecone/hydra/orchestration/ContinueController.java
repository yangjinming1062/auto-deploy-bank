package com.pinecone.hydra.orchestration;

public interface ContinueController extends ProcessController {
}
