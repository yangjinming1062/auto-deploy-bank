package com.pinecone.hydra.task.kom.entity;

public interface CommonMeta extends ElementNode {
}
