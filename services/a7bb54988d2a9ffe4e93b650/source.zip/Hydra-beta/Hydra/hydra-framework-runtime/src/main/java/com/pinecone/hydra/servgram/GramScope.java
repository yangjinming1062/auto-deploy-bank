package com.pinecone.hydra.servgram;

import com.pinecone.framework.util.lang.ClassScope;

public interface GramScope extends ClassScope {

}
