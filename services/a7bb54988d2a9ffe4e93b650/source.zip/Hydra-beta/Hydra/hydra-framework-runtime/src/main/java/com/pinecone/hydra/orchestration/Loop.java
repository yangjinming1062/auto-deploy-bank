package com.pinecone.hydra.orchestration;

public interface Loop extends Transaction {
}
