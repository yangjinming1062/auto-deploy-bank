package com.pinecone.hydra.orchestration.recorder;

public interface ActionTape {
}
