package com.pinecone.hydra.auto;

public interface ParallelSuggestation extends ParallelInstructation, Suggestation {
}
