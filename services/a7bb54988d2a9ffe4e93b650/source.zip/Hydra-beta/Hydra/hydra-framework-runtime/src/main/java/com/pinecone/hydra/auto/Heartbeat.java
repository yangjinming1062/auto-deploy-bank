package com.pinecone.hydra.auto;

public final class Heartbeat extends ArchInstructation implements InstantInstructation {
    Heartbeat () { }

    @Override
    public void execute() throws Exception {
    }
}
