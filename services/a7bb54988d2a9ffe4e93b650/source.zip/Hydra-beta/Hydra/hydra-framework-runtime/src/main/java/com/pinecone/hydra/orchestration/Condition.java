package com.pinecone.hydra.orchestration;

public interface Condition {
}
