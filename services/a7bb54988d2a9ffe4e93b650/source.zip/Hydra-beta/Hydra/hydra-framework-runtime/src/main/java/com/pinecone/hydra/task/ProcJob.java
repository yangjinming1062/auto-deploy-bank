package com.pinecone.hydra.task;

public interface ProcJob extends Job {
}
