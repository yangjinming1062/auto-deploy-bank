package com.pinecone.hydra.servgram;

public interface Servgramlet extends Servgram {
}
