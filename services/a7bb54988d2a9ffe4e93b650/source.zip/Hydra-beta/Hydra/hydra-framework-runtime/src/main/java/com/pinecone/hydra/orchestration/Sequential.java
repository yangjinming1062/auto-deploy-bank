package com.pinecone.hydra.orchestration;

public interface Sequential extends Transaction {
}
