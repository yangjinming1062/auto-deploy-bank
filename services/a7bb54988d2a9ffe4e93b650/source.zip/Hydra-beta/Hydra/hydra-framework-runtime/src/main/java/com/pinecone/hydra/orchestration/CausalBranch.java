package com.pinecone.hydra.orchestration;

public interface CausalBranch extends Transaction {
}
