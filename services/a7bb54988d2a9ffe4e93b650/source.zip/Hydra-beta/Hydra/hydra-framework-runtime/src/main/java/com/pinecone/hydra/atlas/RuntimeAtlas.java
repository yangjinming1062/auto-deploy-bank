package com.pinecone.hydra.atlas;

import com.pinecone.framework.system.regime.Orchestrator;
import com.pinecone.hydra.unit.vgraph.AtlasInstrument;

/**
 *  Pinecone Ursus For Java RuntimeAtlas
 *  Author: Ken, Harold.E (Dragon King)
 *  Copyright © 2008 - 2028 Bean Nuts Foundation All rights reserved.
 *  *****************************************************************************************
 *  Runtime Orchestration Atlas
 *  统一大规模运行矢量调度云图
 *  *****************************************************************************************
 */
public interface RuntimeAtlas extends AtlasInstrument {
}
