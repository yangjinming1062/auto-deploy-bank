package com.pinecone.hydra.orchestration.regulation;

import com.pinecone.framework.system.prototype.Pinenut;

public interface Regulation extends Pinenut {
}
