package com.pinecone.hydra.task;

public interface TaskJob extends Job {
}
