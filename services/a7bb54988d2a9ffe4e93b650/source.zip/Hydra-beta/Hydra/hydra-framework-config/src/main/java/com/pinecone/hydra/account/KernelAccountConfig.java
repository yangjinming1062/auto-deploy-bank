package com.pinecone.hydra.account;

import com.pinecone.hydra.system.ko.ArchKernelObjectConfig;

public class KernelAccountConfig extends ArchKernelObjectConfig implements AccountConfig {
}
