package com.pinecone.hydra.registry;

import com.pinecone.hydra.system.ko.ArchKernelObjectConfig;

public class KernelRegistryConfig extends ArchKernelObjectConfig implements RegistryConfig {
}
