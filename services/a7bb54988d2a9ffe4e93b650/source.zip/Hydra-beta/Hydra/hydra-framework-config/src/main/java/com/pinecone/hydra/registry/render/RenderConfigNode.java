package com.pinecone.hydra.registry.render;

import com.pinecone.hydra.registry.entity.ConfigNode;

public interface RenderConfigNode extends ConfigNode {
}
