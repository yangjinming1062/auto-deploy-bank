package com.pinecone.hydra.registry.render;

import com.pinecone.hydra.registry.entity.GenericTextValue;

public class GenericRenderTextValue extends GenericTextValue implements RenderTextValue{

}
