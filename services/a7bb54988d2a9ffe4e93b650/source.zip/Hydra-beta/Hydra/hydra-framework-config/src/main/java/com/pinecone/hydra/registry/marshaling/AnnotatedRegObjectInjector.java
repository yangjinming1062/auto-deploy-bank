package com.pinecone.hydra.registry.marshaling;

public class AnnotatedRegObjectInjector {
}
