package com.pinecone.hydra.registry.render;

import com.pinecone.hydra.registry.entity.Property;

public interface RenderProperty extends Property {
}
