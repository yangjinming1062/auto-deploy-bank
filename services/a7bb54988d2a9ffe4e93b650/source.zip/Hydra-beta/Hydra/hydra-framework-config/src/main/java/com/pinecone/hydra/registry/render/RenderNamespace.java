package com.pinecone.hydra.registry.render;

import com.pinecone.hydra.registry.entity.Namespace;

public interface RenderNamespace extends Namespace,RenderRegistryTreeNode {
}
