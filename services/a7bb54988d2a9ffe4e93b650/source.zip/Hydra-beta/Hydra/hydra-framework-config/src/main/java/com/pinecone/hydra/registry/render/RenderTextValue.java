package com.pinecone.hydra.registry.render;

import com.pinecone.hydra.registry.entity.TextValue;

public interface RenderTextValue extends TextValue {
}
