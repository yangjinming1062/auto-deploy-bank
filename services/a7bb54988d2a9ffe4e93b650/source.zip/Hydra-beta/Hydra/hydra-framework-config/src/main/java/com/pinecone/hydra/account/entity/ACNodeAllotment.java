package com.pinecone.hydra.account.entity;

import com.pinecone.framework.system.prototype.Pinenut;

public interface ACNodeAllotment extends Pinenut {
    Domain newDomain();
}
