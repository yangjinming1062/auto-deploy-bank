package com.pinecone.hydra.account.entity;

public interface FileElement extends ElementNode{
}
