package com.pinecone.hydra.registry;

import com.pinecone.hydra.system.ko.KernelObjectConfig;

public interface RegistryConfig extends KernelObjectConfig {

}
