package com.pinecone.hydra.account;

import com.pinecone.hydra.system.ko.KernelObjectConfig;

public interface AccountConfig extends KernelObjectConfig {
}
