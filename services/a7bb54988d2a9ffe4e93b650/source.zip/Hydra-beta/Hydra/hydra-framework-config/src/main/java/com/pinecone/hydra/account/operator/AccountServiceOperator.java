package com.pinecone.hydra.account.operator;

import com.pinecone.hydra.unit.imperium.operator.TreeNodeOperator;

public interface AccountServiceOperator extends TreeNodeOperator {
}
