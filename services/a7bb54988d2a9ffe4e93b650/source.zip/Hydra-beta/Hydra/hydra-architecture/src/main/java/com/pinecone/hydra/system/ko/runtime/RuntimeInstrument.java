package com.pinecone.hydra.system.ko.runtime;

import com.pinecone.hydra.system.ko.kom.KOMInstrument;

public interface RuntimeInstrument extends KOMInstrument {
}
