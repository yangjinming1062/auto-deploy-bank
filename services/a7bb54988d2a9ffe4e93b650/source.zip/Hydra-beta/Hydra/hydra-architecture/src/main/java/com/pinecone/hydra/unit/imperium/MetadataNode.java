package com.pinecone.hydra.unit.imperium;

public interface MetadataNode {
}
