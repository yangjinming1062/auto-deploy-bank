package com.pinecone.hydra.system.ko.handle;

public interface KHandle extends ObjectHandle {
}
