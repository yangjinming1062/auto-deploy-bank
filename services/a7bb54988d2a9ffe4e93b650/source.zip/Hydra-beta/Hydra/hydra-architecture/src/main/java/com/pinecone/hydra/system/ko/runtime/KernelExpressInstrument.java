package com.pinecone.hydra.system.ko.runtime;

public class KernelExpressInstrument extends ArchRuntimeKOMTree implements CentralizedRuntimeInstrument {


}
