package com.pinecone.hydra.ware;

public interface DataWare extends Ware {
}
