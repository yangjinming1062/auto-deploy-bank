package com.pinecone.hydra.system.ko.handle;

import com.pinecone.hydra.unit.imperium.entity.TreeNode;

public interface ObjectHandle extends TreeNode {

}
