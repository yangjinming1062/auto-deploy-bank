package com.pinecone.hydra.unit.vgraph;

import com.pinecone.framework.system.prototype.Pinenut;

public interface VectorDAG extends Pinenut {
}
