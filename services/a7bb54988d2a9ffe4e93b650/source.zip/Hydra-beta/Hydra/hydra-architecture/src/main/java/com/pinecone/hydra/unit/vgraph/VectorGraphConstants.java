package com.pinecone.hydra.unit.vgraph;

public class VectorGraphConstants {
}
