package com.pinecone.hydra.unit.imperium;

public interface UniImperialTree extends ImperialTree {

}
