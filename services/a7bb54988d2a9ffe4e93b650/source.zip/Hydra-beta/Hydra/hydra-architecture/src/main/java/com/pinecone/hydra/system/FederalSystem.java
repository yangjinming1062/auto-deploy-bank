package com.pinecone.hydra.system;

import com.pinecone.framework.system.prototype.Pinenut;

public interface FederalSystem extends Pinenut {
}
