package com.pinecone.hydra.ware;

public interface OLAPWare {
}
