package com.pinecone.hydra.system.imperium.source;

public interface KernelObjectMasterManipulator {
    KernelObjectManipulator         getKernelObjectManipulator();
    KernelObjectMetaManipulator     getKernelObjectMetaManipulator();
}
