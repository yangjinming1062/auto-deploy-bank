package com.pinecone.hydra.system;

public interface HyComponent extends SystemCascadeComponent {
    @Override
    Hydrarum getSystem();
}
