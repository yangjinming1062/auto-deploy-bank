package com.pinecone.hydra.ware;

public interface MessageWare extends Middleware {
}
