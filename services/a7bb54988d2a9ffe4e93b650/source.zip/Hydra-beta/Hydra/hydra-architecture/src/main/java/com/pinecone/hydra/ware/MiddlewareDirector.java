package com.pinecone.hydra.ware;

public interface MiddlewareDirector extends WareDirector {
}
