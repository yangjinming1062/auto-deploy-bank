package com.pinecone.hydra.ware;

public interface Middleware extends Ware {

}
