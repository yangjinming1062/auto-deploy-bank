package com.pinecone.hydra.ware;

public interface MiddlewareManager extends WareManager {
}
