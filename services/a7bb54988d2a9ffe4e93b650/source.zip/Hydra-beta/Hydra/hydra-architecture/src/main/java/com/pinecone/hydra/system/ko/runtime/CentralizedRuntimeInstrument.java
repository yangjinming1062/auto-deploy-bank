package com.pinecone.hydra.system.ko.runtime;

public interface CentralizedRuntimeInstrument extends RuntimeInstrument {
}
