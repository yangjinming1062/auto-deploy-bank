package com.pinecone.hydra.ware;

public interface RDBWare extends Ware {
}
