package com.pinecone.hydra.unit.imperium;

public final class ImperialTreeConstants {
    public static int DefaultShortPathLength  =  330;
}
