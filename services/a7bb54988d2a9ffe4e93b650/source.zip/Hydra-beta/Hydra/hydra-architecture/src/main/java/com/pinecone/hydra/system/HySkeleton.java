package com.pinecone.hydra.system;

public interface HySkeleton extends SystemCascadeComponentManager {
    Hydrarum getSystem();
}
