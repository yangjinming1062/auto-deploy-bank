package com.pinecone.hydra.system.ko;

import com.pinecone.framework.system.prototype.Pinenut;

public interface KernelObject extends Pinenut {
}
