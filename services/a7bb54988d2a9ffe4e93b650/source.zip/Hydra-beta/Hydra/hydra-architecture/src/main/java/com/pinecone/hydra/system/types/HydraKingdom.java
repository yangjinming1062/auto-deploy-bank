package com.pinecone.hydra.system.types;

import com.pinecone.hydra.system.HierarchySystem;
import com.pinecone.hydra.system.Hydrarum;

public interface HydraKingdom extends Hydrarum, HierarchySystem {
}
