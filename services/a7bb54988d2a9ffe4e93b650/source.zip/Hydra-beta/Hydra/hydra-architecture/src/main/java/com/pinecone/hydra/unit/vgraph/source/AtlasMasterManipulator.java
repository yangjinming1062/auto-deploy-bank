package com.pinecone.hydra.unit.vgraph.source;

import com.pinecone.framework.system.prototype.Pinenut;

public interface AtlasMasterManipulator extends Pinenut {
}
