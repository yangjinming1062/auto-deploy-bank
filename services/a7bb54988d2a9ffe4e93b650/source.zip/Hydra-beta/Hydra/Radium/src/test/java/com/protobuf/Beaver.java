package com.protobuf;

import com.pinecone.hydra.umct.stereotype.Iface;

public interface Beaver {
    @Iface
    String cutting( String target );
}
