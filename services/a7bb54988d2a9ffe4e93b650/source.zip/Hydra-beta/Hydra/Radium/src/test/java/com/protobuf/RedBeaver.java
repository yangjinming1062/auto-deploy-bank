package com.protobuf;

public class RedBeaver implements Beaver {
    @Override
    public String cutting( String target ) {
        return "A cute beaver is cutting a " + target;
    }
}
