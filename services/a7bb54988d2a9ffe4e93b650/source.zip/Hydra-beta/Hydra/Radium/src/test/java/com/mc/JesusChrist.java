package com.mc;

import com.pinecone.framework.system.CascadeSystem;
import com.pinecone.radium.Radium;

public class JesusChrist extends Radium {
    public JesusChrist( String[] args, CascadeSystem parent ) {
        this( args, null, parent );
    }

    public JesusChrist( String[] args, String szName, CascadeSystem parent ){
        super( args, szName, parent );
    }

    public void vitalize () throws Exception {

    }
}
