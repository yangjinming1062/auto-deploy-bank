package com.pinecone.radium;

public final class ConfigConstants {
    public static final String KeyMasterOrchestrator = "MasterOrchestrator";


}
