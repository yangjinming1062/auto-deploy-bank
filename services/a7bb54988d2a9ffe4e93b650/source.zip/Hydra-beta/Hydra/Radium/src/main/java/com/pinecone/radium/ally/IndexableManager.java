package com.pinecone.radium.ally;

public class IndexableManager {
}
