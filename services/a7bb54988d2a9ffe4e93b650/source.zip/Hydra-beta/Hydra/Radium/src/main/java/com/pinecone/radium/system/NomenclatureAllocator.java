package com.pinecone.radium.system;

import com.pinecone.framework.system.prototype.Pinenut;

public interface NomenclatureAllocator extends Pinenut {
}
