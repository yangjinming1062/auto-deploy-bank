# Copyright (c) Microsoft Corporation.
# SPDX-License-Identifier: Apache-2.0

# DeepSpeed Team

# Processing method key names
TOP_K_NAME = "TopK"
TOP_P_NAME = "TopP"
TEMP_NAME = "Temp"
SAMPLER_NAME = "Sampler"
STOP_NAME = "Stop"
