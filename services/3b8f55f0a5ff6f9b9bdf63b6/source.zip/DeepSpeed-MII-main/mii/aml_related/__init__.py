# Copyright (c) Microsoft Corporation.
# SPDX-License-Identifier: Apache-2.0

# DeepSpeed Team
from .templates import *
from .utils import get_acr_name, generate_aml_scripts, aml_output_path
