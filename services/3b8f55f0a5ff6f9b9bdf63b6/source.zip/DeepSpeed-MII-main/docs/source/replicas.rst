Model Replicas
==============

DeepSpeed-MII supports creating multiple replicas of a model with
:doc:`deployment`. Please see :ref:`Persistent Deployment Model Replicas
<deployment_model_replicas>`.
