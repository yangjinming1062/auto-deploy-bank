from .base_sampler import BaseSampler


class DummySampler(BaseSampler):
    def sample(self):
        pass
