LearningModule
==============================

.. autoclass:: oscopilot.modules.learner.self_learner.SelfLearner
   :members:
   :undoc-members:
   :show-inheritance:
