Friday Agent
==============================

.. autoclass:: oscopilot.agents.friday_agent.FridayAgent
   :members:
   :undoc-members:
   :show-inheritance: