ExecutionModule
==============================

.. autoclass:: oscopilot.modules.executor.friday_executor.FridayExecutor
   :members:
   :undoc-members:
   :show-inheritance:
