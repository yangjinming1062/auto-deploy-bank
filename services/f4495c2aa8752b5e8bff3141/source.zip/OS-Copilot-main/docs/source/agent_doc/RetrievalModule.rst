RetrievalModule
==============================

.. autoclass:: oscopilot.modules.retriever.vector_retriever.FridayRetriever
   :members:
   :undoc-members:
   :show-inheritance:
