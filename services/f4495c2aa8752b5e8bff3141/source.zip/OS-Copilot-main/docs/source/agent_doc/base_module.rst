Base Module
==============================

.. automodule:: oscopilot.modules.base_module
   :members:
   :undoc-members:
   :show-inheritance:
