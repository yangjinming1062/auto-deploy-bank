Base Agent
==============================

.. automodule:: oscopilot.agents.base_agent
   :members:
   :undoc-members:
   :show-inheritance:
