PlanningModule
==============================

.. autoclass:: oscopilot.modules.planner.friday_planner.FridayPlanner
   :members:
   :undoc-members:
   :show-inheritance:
