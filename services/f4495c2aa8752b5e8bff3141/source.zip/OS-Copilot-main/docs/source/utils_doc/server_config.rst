Server Proxy Config
==============================

.. autoclass:: oscopilot.utils.server_config.ConfigManager
   :members:
   :undoc-members:
   :show-inheritance: