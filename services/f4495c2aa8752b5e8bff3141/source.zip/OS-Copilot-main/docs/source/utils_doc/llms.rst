Large Language Models
==============================

.. autoclass:: oscopilot.utils.llms.OpenAI
   :members:
   :undoc-members:
   :show-inheritance: