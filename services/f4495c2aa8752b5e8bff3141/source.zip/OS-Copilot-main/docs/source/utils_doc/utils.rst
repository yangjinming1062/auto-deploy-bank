Other Utils
==============================

.. autofunction:: oscopilot.utils.utils.send_chat_prompts


.. autofunction:: oscopilot.utils.utils.random_string


.. autofunction:: oscopilot.utils.utils.num_tokens_from_string


.. autofunction:: oscopilot.utils.utils.parse_content


.. autofunction:: oscopilot.utils.utils.clean_string


.. autofunction:: oscopilot.utils.utils.chunks


.. autofunction:: oscopilot.utils.utils.generate_prompt


.. autofunction:: oscopilot.utils.utils.cosine_similarity


.. autofunction:: oscopilot.utils.utils.is_valid_json_string