Basic Tools
==============================

.. autoclass:: oscopilot.tool_repository.basic_tools.text_extractor.TextExtractor
   :members:
   :undoc-members:
   :show-inheritance: