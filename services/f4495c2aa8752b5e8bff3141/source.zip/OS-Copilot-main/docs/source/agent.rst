FridayAgent
=============

.. toctree::
   :maxdepth: 2

   agent_doc/base_agent
   agent_doc/friday_agent
   agent_doc/self_learning
   agent_doc/base_module
   agent_doc/PlanningModule
   agent_doc/RetrievalModule
   agent_doc/ExecutionModule
   agent_doc/LearningModule
   agent_doc/prompts
