Environment
=============

.. toctree::
   :maxdepth: 2

   environment_doc/env
   environment_doc/base_env
   environment_doc/bash_env
   environment_doc/applescript_env
   environment_doc/py_jupyter_env
   environment_doc/subprocess_env      