Bash Environment
==============================

.. automodule:: oscopilot.environments.bash_env
   :members:
   :undoc-members:
   :show-inheritance: