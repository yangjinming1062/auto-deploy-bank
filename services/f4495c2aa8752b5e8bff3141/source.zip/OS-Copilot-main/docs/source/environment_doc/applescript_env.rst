AppleScript Environment
==============================

.. automodule:: oscopilot.environments.applescript_env
   :members:
   :undoc-members:
   :show-inheritance: