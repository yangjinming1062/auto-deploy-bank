---
name: General issue template
about: Describe this issue template's purpose here.
title: "[General]: "
labels: ''
assignees: ''

---

Do you have issues other than bugs and features? Describe what you need
