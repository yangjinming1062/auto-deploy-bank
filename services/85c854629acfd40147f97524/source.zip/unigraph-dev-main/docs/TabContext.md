
  - `TabContext.setTitle`: set the current tab title (browser tab title if out of workspace)
  - `TabContext.viewId`: a number that represents a view in the `window.layoutModel` object for further editing
  - `TabContext.(subscription function)`: use these functions to scope the subscriptions to the current tab - making unigraph more performant