
  - Package: `unigraph-dev-explorer`
    - A user-friendly way to explore Unigraph data and user resources.
  - Important concepts
    - [[end-user programmable interfaces]]
    - [[view_data type isomorphism|view/data type isomorphism]]
  - Components
    - [[Unigraph workspace]]
    - [[AutoDynamicView]]
    - [[DynamicObjectListView]]
    - View Contexts
      - [[TabContext]]
    - [[Unigraph frontend state management]]
```unigraph
      0xe5155
      ```