
  - This is a page for everything in the Unigraph architecture that Sophia considered to be temporary and should be fixed.
  - Also a great list of things to do!