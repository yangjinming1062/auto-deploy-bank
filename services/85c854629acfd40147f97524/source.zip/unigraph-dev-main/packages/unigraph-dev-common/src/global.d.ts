// import * as react from "react"
// import * as react_dom from "react-dom"
//
// declare global {
//    type React = typeof react
//    type ReactDOM = typeof react_dom
// }
