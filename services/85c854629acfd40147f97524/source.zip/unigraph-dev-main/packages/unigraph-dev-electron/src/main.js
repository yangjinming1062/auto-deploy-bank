const { app, BrowserWindow, Menu, Tray, nativeImage, globalShortcut, shell, MenuItem } = require('electron');
const path = require('path');
const os = require('os');
const child_process = require('child_process');

const { spawn } = child_process;
const { fixPathForAsarUnpack } = require('electron-util');
const { ipcMain } = require('electron');
const { autoUpdater } = require('electron-updater');
const log = require('electron-log');

const Store = require('electron-store');
const net = require('net');
const { electron } = require('process');
const { createTrayMenu } = require('./tray');

const addMenu = (mainWindow) => {
    const newMenu = Menu.getApplicationMenu().items.map((it) => {
        let sm;
        if (it.submenu?.items?.some((subIt) => subIt.role === 'close')) {
            console.log('c');

            if (it.submenu?.items?.map)
                sm = it.submenu.items.map((subIt) =>
                    subIt.role === 'close'
                        ? {
                              accelerator: 'CmdOrCtrl+W',
                              click: (_, window) => {
                                  if (window.webContents.getURL().includes('popout_page')) window.close();
                                  else mainWindow.webContents.send('closeTab');
                              },
                              label: 'Close Tab',
                          }
                        : subIt,
                );
            else sm = it.submenu.items;
        }
        return { ...it, ...(sm ? { submenu: sm } : {}) };
    });
    Menu.setApplicationMenu(Menu.buildFromTemplate(newMenu));
};

const store = new Store();

const userData = app.getPath('userData');

const unigraph_trayIcon =
    'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABUAAAAVCAYAAACpF6WWAAADiXRFWHRteGZpbGUAJTNDbXhmaWxlJTIwaG9zdCUzRCUyMmFwcC5kaWFncmFtcy5uZXQlMjIlMjBtb2RpZmllZCUzRCUyMjIwMjEtMDUtMDNUMTclM0EwNiUzQTA5LjUxMlolMjIlMjBhZ2VudCUzRCUyMjUuMCUyMChNYWNpbnRvc2glM0IlMjBJbnRlbCUyME1hYyUyME9TJTIwWCUyMDExXzNfMCklMjBBcHBsZVdlYktpdCUyRjUzNy4zNiUyMChLSFRNTCUyQyUyMGxpa2UlMjBHZWNrbyklMjBDaHJvbWUlMkY4OC4wLjQzMjQuMTUwJTIwU2FmYXJpJTJGNTM3LjM2JTIyJTIwZXRhZyUzRCUyMmFKRldEQUR0MlEzVk5fZVpKd3I0JTIyJTIwdmVyc2lvbiUzRCUyMjE0LjYuOSUyMiUyMHR5cGUlM0QlMjJkZXZpY2UlMjIlM0UlM0NkaWFncmFtJTIwaWQlM0QlMjJCV0JHLVBoeFRTZkFxRlZBOTdhRSUyMiUyMG5hbWUlM0QlMjJQYWdlLTElMjIlM0VqWkxCYm9Nd0RJYWZobU1sS0czSGpvTjEzV1hTcXFyck9TSXVpUnBpRkVLaGUlMkZxWmtaU3lxdEl1eVA1c3glMkJhM2d6Z3J1NDFobGZoQURpcVloN3dMNHRkZ1BuOWVyT2piZzhzQWxxdkZBQW9qJTJCWUNpRWV6a056Z1lPdHBJRHZVazBTSXFLNnNwekZGcnlPMkVNV093bmFZZFVVMjdWcXlBTzdETG1icW5COG10R0dpeURFZiUyQkRySVF2bk1VdWtqSmZMSUR0V0FjMnhzVXI0TTRNNGgyc01vdUE5VnI1M1VaNnQ0ZVJLJTJCREdkRDJQd1d6elZjaW5qNlhNamx2RDlYMnhMcDRQM092bkpscTNBJTJGdjNiVDI0aVd3MEZHRFZOaFNFWWpJckszQkUyU28wQkRScUNrelBVcWwlMkZpQ21aS0hKeldsRUlKNmV3VmhKNHI2NFFDazU3OXVrclpBV2RoWEwlMkI1NHRYUkl4ZzQzbTBFOGZrdWNHcFFlZ2U2aEFkTldWN2hHd0JHc3VsTktPbSUyRlBiRURkTDg0eTVXeW11bGFPY1pEaEZ2VHR1N2pkMmMlMkY3eCUyQmdjJTNEJTNDJTJGZGlhZ3JhbSUzRSUzQyUyRm14ZmlsZSUzRQ4QufQAAACnSURBVDhP7dQxDgFREIDhb1vR6PTEFbiCOARX4ABKxyERdGqJG0hwBAWFREM22WIRu2vZbl/yqjfvn8k/mQkUcIICmEro/60mOe1ixZv3OfYYfSonCdrDooS+KvrJaQcbVHCNNWWN8E7yNKqGE9rYxgBn9DHLAw3/7HDAADcMMUYDx7zQJpZoRYBLlGCaNDJZF0od1ajqe9oMZoWmcZ7eS+hXujIFPwCUDCEWIOzIUgAAAABJRU5ErkJggg==';

const frontendLocation = process.env.FRONTEND_LOCATION || 'localhost';
const logs = [];
let mainWindow = null;
const todayWindow = null;
let omnibar = null;
let tray = null;
let trayMenu = null;
let index = null;
let dontCheck = false;
let shouldStartBackend = true;
let alpha;
let zero;

let mainWasVisible = false;
let mainWasFocused = false;

if (process.env.FRONTEND_LOCATION) shouldStartBackend = false;

function isDev() {
    return process.argv[2] == '--dev';
}

const gotTheLock = app.requestSingleInstanceLock();

if (!gotTheLock) {
    app.quit();
    process.exit(0);
}

log.transports.file.level = 'debug';
autoUpdater.logger = log;

function isUnigraphPortOpen(port) {
    return new Promise((resolve, reject) => {
        const server = net.createServer(function (socket) {
            socket.write('Echo server\r\n');
            socket.pipe(socket);
        });
        server.listen(port, '127.0.0.1');
        server.on('error', function (e) {
            resolve(true);
        });
        server.on('listening', function (e) {
            server.close();
            resolve(false);
        });
    });
}

async function startServer(logHandler) {
    console.log('Starting server - checking is port open?');
    const portopen = await isUnigraphPortOpen(3000);
    console.log(
        portopen,
        fixPathForAsarUnpack(path.join(__dirname, '..', 'dgraph', 'dgraph')),
        path.join(userData, 'w'),
        store.get('startServer') !== false,
    );
    if (store.get('startServer') !== false && (!portopen || !isDev()) && shouldStartBackend) {
        const oldConsoleLog = console.log;
        console.log = (data) => {
            log.log(data);
            if (!Array.isArray(data)) data = [data];
            logs.push(...data);
            if (!dontCheck) checkIfUComplete(...data);
            try {
                logHandler.send('loading_log', logs);
            } catch (e) {
                // Nothing happens
            }
            return oldConsoleLog(...data);
        };
        alpha = spawn(
            fixPathForAsarUnpack(path.join(__dirname, '..', 'dgraph', `dgraph${process.arch === 'arm64' ? '' : ''}`)),
            [
                'alpha',
                '--wal',
                path.join(userData, 'w'),
                '--postings',
                path.join(userData, 'p'),
                '--tmp',
                path.join(userData, 't'),
            ],
        );
        zero = spawn(
            fixPathForAsarUnpack(path.join(__dirname, '..', 'dgraph', `dgraph${process.arch === 'arm64' ? '' : ''}`)),
            ['zero', '--wal', path.join(userData, 'zw')],
        );

        const completedLog = 'Server is ready: OK'; // When this is logged we know it's completed
        const completedULog = 'Unigraph server listening on port';

        function checkIfComplete(str) {
            if (str.includes && str.includes(completedLog)) dgraphLoaded();
        }

        function checkIfUComplete(str) {
            if (str.includes && str.includes(completedULog)) unigraphLoaded();
        }

        function processData(data, header) {
            console.log(`${header}: ${data.toString()}`);
            checkIfComplete(data.toString());
        }

        alpha.stdout.on('data', (data) => processData(data, 'alpha_stdout'));
        alpha.stderr.on('data', (data) => processData(data, 'alpha_stderr'));
        zero.stdout.on('data', (data) => processData(data, 'zero_stdout'));
        zero.stderr.on('data', (data) => processData(data, 'zero_stderr'));
    } else {
        unigraphLoaded();
    }
}

function createMainWindow(props) {
    const win = new BrowserWindow({
        width: 800,
        height: 600,
        webPreferences: {
            preload: path.join(__dirname, '..', 'src', 'preload.js'),
            nativeWindowOpen: true,
            contextIsolation: false,
        },
        ...(props || { titleBarStyle: 'hiddenInset' }),
    });

    // if (mainPage) win.loadFile(path.join(__dirname, '..', 'buildweb', mainPage))

    return win;
}

function createLoadingWindow(props) {
    const win = new BrowserWindow({
        width: 800,
        height: 600,
        webPreferences: {
            preload: path.join(__dirname, '..', 'src', 'preload.js'),
            nativeWindowOpen: true,
            contextIsolation: false,
        },
        ...(props || { titleBarStyle: 'hiddenInset' }),
    });

    win.loadFile(path.join(__dirname, '..', 'buildweb', 'loading_bar.html'));

    return win;
}

const createOmnibar = () =>
    createMainWindow({
        transparent: true,
        frame: false,
        backgroundColor: '#00ffffff',
        skipTaskbar: true,
        useContentSize: true,
        webPreferences: {
            preload: path.join(__dirname, '..', 'src', 'preload_omnibar.js'),
            nativeWindowOpen: true,
            contextIsolation: false,
        },
    });

const createMainWindowNoLoad = () => createMainWindow(null);

function dgraphLoaded() {
    index = require(path.join(__dirname, '..', 'distnode', 'index.js'));
}

function unigraphLoaded() {
    dontCheck = true;
    setTimeout(() => {
        if (mainWindow) {
            if (!isDev()) {
                mainWindow.loadFile(path.join(__dirname, '..', 'buildweb', 'index.html'));
            } else {
                mainWindow.loadURL(`http://${frontendLocation}:5173/`);
            }
        }
        if (todayWindow) {
            //! isDev() ?
            // todayWindow.loadFile(path.join(__dirname, '..', 'buildweb', 'index.html'), { query: { "pageName": "today" } }) :
            // todayWindow.loadURL('http://' + frontendLocation + ':5173/?pageName=today');
            // todayWindow.hide();
        }
        if (omnibar) {
            !isDev()
                ? omnibar.loadFile(path.join(__dirname, '..', 'buildweb', 'index.html'), {
                      query: { pageName: 'omnibar' },
                  })
                : omnibar.loadURL(`http://${frontendLocation}:5173/?pageName=omnibar`);
            omnibar.hide();
        }
    }, 0);
}

let isAppClosing = false;

autoUpdater.on('update-downloaded', async (info) => {
    const choice = await require('electron').dialog.showMessageBox({
        type: 'question',
        buttons: ['OK', 'Quit and update'],
        title: 'New update downloaded',
        message: `New update has been downloaded (version ${info.version}), and will be automatically installed after quit.`,
    });
    if (choice.response === 1) {
        isAppClosing = true;
        autoUpdater.quitAndInstall();
    }
});

app.whenReady().then(() => {
    if (!isDev()) autoUpdater.checkForUpdates();
    tray = new Tray(nativeImage.createFromDataURL(unigraph_trayIcon));
    tray.setToolTip('Unigraph');
    trayMenu = createTrayMenu((newTemplate) => {
        tray.setContextMenu(Menu.buildFromTemplate(newTemplate));
    });
    // globalShortcut.register('Alt+Tab', () => {
    //     if (todayWindow) {
    //         // todayWindow.isVisible() ? todayWindow.hide() : todayWindow.show();
    //     }
    // });

    globalShortcut.register('CommandOrControl+E', () => {
        if (omnibar) {
            omnibar.isVisible() ? closeOmnibar() : showOmnibar();
        }
    });
    setTimeout(() => {
        mainWindow = createLoadingWindow(); // , todayWindow = createTodayWindow()
        omnibar = createOmnibar();
        omnibar.on('blur', () => {
            // console.log("buhf")
            closeOmnibar();
        });
        omnibar.maximize();
        mainWindow.maximize();
        // todayWindow.setVisibleOnAllWorkspaces(true);
        omnibar.setVisibleOnAllWorkspaces(true);
        trayMenu.setMainWindow(mainWindow); // , trayMenu.setTodayWindow(todayWindow)
        trayMenu.setSearchWindow(omnibar);
        startServer(mainWindow.webContents);
        app.on('activate', () => {
            if (BrowserWindow.getAllWindows().length === 0) {
                createMainWindowNoLoad();
            }
            if (mainWindow) {
                mainWindow.show();
            }
        });
        app.on('second-instance', (event, commandLine, workingDirectory) => {
            // Someone tried to run a second instance, we should focus our window.
            if (mainWindow) {
                mainWindow.show();
            }
        });
        const windows = [mainWindow, omnibar];
        windows.map((el) =>
            el.on('close', (event) => {
                if (!isAppClosing) {
                    event.preventDefault();
                    el.hide();
                }
            }),
        );
        addMenu(mainWindow);
        windows.map((el) => el.on('hide', (event) => {}));
        mainWindow.webContents.on('will-navigate', function (e, url) {
            e.preventDefault();
            shell.openExternal(url);
        });
        mainWindow.webContents.setWindowOpenHandler(({ url }) => {
            // open url in a browser and prevent default
            if (!url.includes('popout_page.html')) {
                shell.openExternal(url);
                return { action: 'deny' };
            }
            return { action: 'allow' };
        });
    }, 0);
});

ipcMain.on('favorites_updated', (event, args) => {
    if (trayMenu) trayMenu.setFavorites(args);
});

ipcMain.on('hideWindow', () => {
    mainWindow.hide();
});
// const applescript = require('applescript');

function closeOmnibar() {
    if (!mainWasFocused && process.platform === 'darwin') {
        console.log('hi');
        mainWindow.setFocusable(false);
        // todayWindow.setFocusable(false);
        omnibar.hide();
        mainWindow.setFocusable(true);
        // todayWindow.setFocusable(true);
    } else {
        omnibar.hide();
    }
}

ipcMain.on('newTabByUrl', (event, args) => {
    mainWindow.webContents.send('newTabByUrl', args);
    mainWindow.show();
});
// const applescript = require('applescript');

function showOmnibar() {
    mainWasFocused = mainWindow.isFocused();
    mainWasVisible = mainWindow.isVisible();
    console.log(mainWasFocused, process.platform);
    omnibar.show();
    omnibar.webContents.send('showOmnibar');
}

ipcMain.on('close_omnibar', closeOmnibar);

app.on('window-all-closed', (e) => {
    // Prevent app quitting, instead runs in background
    e.preventDefault();
});

app.on('quit', () => {
    function killer(ps) {
        if (os.platform() === 'win32') {
            child_process.exec(`taskkill /pid ${ps.pid} /T /F`);
        } else {
            ps.kill();
        }
    }

    if (alpha) killer(alpha);
    if (zero) killer(zero);
});

app.on('before-quit', function () {
    isAppClosing = true;
});
