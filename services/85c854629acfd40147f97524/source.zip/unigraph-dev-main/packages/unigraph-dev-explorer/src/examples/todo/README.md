# Unigraph example TODO list applet

This applet serves as a basic demostration of how to write a custom component.