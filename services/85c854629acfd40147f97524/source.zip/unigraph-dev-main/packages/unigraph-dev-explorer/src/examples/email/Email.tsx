import { Avatar, ListItem as div, ListItemAvatar, ListItemText } from '@mui/material';
import React, { useEffect } from 'react';
import { pkg as emailPackage } from 'unigraph-dev-common/lib/data/unigraph.email.pkg';
import { byUpdatedAt, unpad } from 'unigraph-dev-common/lib/utils/entityUtils';
import Sugar from 'sugar';
import { Link } from '@mui/icons-material';
import { UnigraphObject } from 'unigraph-dev-common/lib/utils/utils';
import { DynamicViewRenderer } from '../../global.d';
import { getComponentFromPage, getOrInitLocalStorage, timeSince } from '../../utils';
import { DynamicObjectListView } from '../../components/ObjectView/DynamicObjectListView';
import { registerDetailedDynamicViews, registerDynamicViews, withUnigraphSubscription } from '../../unigraph-react';
import { AutoDynamicView } from '../../components/ObjectView/AutoDynamicView';
import { AutoDynamicViewDetailed } from '../../components/ObjectView/AutoDynamicViewDetailed';
import { shouldMirrorEmailInbox } from './EmailSettings';

type AEmail = {
    name: string;
    message_id: string;
    message: {
        date_received: string;
        sender: string[];
        recipient: string[];
    };
    content: {
        text: string;
        abstract: string;
    };
};

const EmailListBody: React.FC<{ data: any[] }> = ({ data }) => (
    <DynamicObjectListView
        items={data}
        context={null}
        compact
        subscribeOptions={{
            queryAsType: '$/schema/email_message',
        }}
    />
);

const EmailMessageDetailed: DynamicViewRenderer = ({ data, callbacks }) => {
    useEffect(() => {
        if (shouldMirrorEmailInbox()) {
            window.unigraph.runExecutable('$/executable/modify-emails-labels', {
                uids: [data.uid],
                removeLabelIds: ['UNREAD'],
                addLabelIds: [],
            });
        }
    }, []);
    return (
        <AutoDynamicViewDetailed
            callbacks={{ ...callbacks, context: data }}
            object={data?.get('content/text')?._value?._value}
            context={data}
        />
    );
};

const EmailMessage: DynamicViewRenderer = ({ data, callbacks }) => {
    const unpadded: AEmail = unpad(data);
    const fromPerson = new UnigraphObject(data.get('message/sender')['_value['][0]?._value?.person?._value?._value);
    const ider = data.get('message/sender')['_value['][0]?._value?.identifier?.['_value.%'];
    return (
        <div
            style={{ display: 'contents' }}
            onClick={(ev) => {
                ev.stopPropagation();
                ev.preventDefault();
                window.newTab(
                    getComponentFromPage('/library/object', {
                        uid: data.uid,
                        type: data?.type?.['unigraph.id'],
                    }),
                );
                if (callbacks?.removeFromContext && callbacks?.removeOnEnter) callbacks.removeFromContext();
            }}
        >
            <Avatar
                src={fromPerson?.get('profile_image')?.as('primitive') || ''}
                sx={{ width: 32, height: 32 }}
                onClick={(ev) => {
                    ev.stopPropagation();
                    window.open(data._externalUrl, '_blank');
                }}
            >
                {data.get('message/sender')['_value['][0]?._value?.identifier?.['_value.%']?.[0]?.toUpperCase?.()}
            </Avatar>
            <div className="flex flex-col ml-4">
                <div>
                    <span className="text-[15px] font-medium mr-4 mt-1">{data?.get('name')?.as('primitive')}</span>
                    <span className="text-[15px] font-medium text-slate-600 mr-4 ">
                        <AutoDynamicView
                            object={fromPerson}
                            callbacks={{ identifier: ider }}
                            options={{ inline: true }}
                        />
                    </span>
                    <span className="text-[15px] text-slate-500">
                        {timeSince(new Date(unpadded?.message?.date_received))}
                    </span>
                </div>

                <div style={{ display: 'flex', alignItems: 'center' }} className="text-sm text-slate-600 mb-1">
                    {`${unpadded.content?.abstract}...`}
                </div>
            </div>
        </div>
    );
};

const coupleStateAndLocalStorageObj = (
    stateName: string,
    localStorageAreaName: string,
    localStorageName: string,
    defaultVal: any,
) => {
    // TODO: abstract this better. explorer/src/init.tsx uses this pattern too
    // localStorageAreaName is the name of an JSON object in localStorage,
    // localStorageName is an attribute of that object
    const state = window.unigraph.addState(stateName, defaultVal);
    state.subscribe((val: boolean) => {
        window.localStorage.setItem(
            localStorageAreaName,
            JSON.stringify({
                ...JSON.parse(window.localStorage.getItem(localStorageAreaName)!),
                [localStorageName]: val,
            }),
        );
    });
};

const defaultEmailSettings = { mirrorEmailInbox: true, removeEmailOnRead: false };
export const init = () => {
    const emailSettings = getOrInitLocalStorage('emailSettings', defaultEmailSettings);

    coupleStateAndLocalStorageObj(
        'settings/email/mirrorEmailInbox',
        'emailSettings',
        'mirrorEmailInbox',
        emailSettings.mirrorEmailInbox ?? true,
    );
    coupleStateAndLocalStorageObj(
        'settings/email/removeEmailOnRead',
        'emailSettings',
        'removeEmailOnRead',
        emailSettings.removeEmailOnRead ?? false,
    );

    registerDynamicViews({ '$/schema/email_message': EmailMessage });
    registerDetailedDynamicViews({
        '$/schema/email_message': EmailMessageDetailed,
    });
};

export const EmailList = withUnigraphSubscription(
    EmailListBody,
    { schemas: [], defaultData: [], packages: [emailPackage] },
    {
        afterSchemasLoaded: (subsId: number, tabContext: any, data: any, setData: any) => {
            tabContext.subscribeToType(
                '$/schema/email_message',
                (result: any[]) => {
                    setData(result.sort(byUpdatedAt).reverse());
                },
                subsId,
                { metadataOnly: true },
            );
        },
    },
);
