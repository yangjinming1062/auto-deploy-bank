import { Focus } from '../../components/UnigraphCore/Focus';

export function WidgetFocus() {
    return <Focus />;
}
