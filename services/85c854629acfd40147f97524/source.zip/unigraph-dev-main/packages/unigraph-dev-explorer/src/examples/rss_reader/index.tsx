import { RSSFeeds } from './RSSFeeds';

export default RSSFeeds;
