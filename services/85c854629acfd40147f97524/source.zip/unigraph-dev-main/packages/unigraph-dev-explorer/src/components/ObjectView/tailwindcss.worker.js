import 'monaco-tailwindcss/tailwindcss.worker.js';
