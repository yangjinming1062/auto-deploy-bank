# The Unigraph Webapp

This is the web frontend for Unigraph which can be either served by a standard web server or packaged into an electron app.

Most commands are included in global `yarn` commands, so please refer to the monorepo documentation for more information.