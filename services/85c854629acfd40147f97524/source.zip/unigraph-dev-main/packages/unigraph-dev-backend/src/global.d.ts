/* eslint-disable import/prefer-default-export */
declare module '*.pkg' {
    const pkg: any;
    export { pkg };
}
