# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [0.2.10](https://github.com/unigraph-dev/unigraph-dev/compare/v0.2.9...v0.2.10) (2022-04-20)


### Features

* **search:** add title matching for search capabilities ([d5ba291](https://github.com/unigraph-dev/unigraph-dev/commit/d5ba29139b4561292c199f6f7fc9dbb2d5a5d268))
* **search:** enhanced search flow ([1dc69ef](https://github.com/unigraph-dev/unigraph-dev/commit/1dc69efe80ef78e258549c154a168650267a5a91))
