# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [0.2.9](https://github.com/unigraph-dev/unigraph-dev/compare/v0.2.8...v0.2.9) (2022-04-14)


### Features

* **commands:** helper scripts to make new commands and handlers ([8ee1388](https://github.com/unigraph-dev/unigraph-dev/commit/8ee138858e717ae1ab67ab650b05932ef035abb1))
