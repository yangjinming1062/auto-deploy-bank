console.log('closeTabCondition', { context });
return true;
