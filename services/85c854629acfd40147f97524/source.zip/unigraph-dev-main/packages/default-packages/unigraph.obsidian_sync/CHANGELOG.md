# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [0.2.8](https://github.com/unigraph-dev/unigraph-dev/compare/v0.2.7...v0.2.8) (2022-04-05)


### Bug Fixes

* **obsidian:** add obsidian sync settings page ([09c46a8](https://github.com/unigraph-dev/unigraph-dev/commit/09c46a803a2d14a05a3ae18baf490a376e080d38))





## [0.2.6](https://github.com/unigraph-dev/unigraph-dev/compare/v0.2.5...v0.2.6) (2022-03-19)


### Features

* **obsidian_sync:** obsidian sync first pass ([fcfe7ba](https://github.com/unigraph-dev/unigraph-dev/commit/fcfe7bac67cf80f859861eb74a2ab1e4fbc44cf9))
