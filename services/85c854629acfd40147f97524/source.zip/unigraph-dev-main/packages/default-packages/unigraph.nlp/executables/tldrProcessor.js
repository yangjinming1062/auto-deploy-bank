{
    result: context.params.result,
}
