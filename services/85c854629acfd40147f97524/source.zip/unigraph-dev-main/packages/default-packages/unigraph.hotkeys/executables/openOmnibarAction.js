unigraph.getState('global/omnibarSummoner').setValue({
    show: !unigraph.getState('global/omnibarSummoner').value?.show,
    tooltip: '',
    defaultValue: '',
});
