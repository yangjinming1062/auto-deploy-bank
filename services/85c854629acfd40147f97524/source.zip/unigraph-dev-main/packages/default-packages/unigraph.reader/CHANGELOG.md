# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [0.2.5](https://github.com/unigraph-dev/unigraph-dev/compare/v0.2.4...v0.2.5) (2022-03-13)

**Note:** Version bump only for package unigraph.reader





## [0.2.4](https://github.com/unigraph-dev/unigraph-dev/compare/v0.2.3...v0.2.4) (2022-03-13)

**Note:** Version bump only for package unigraph.reader





## [0.2.3](https://github.com/unigraph-dev/unigraph-dev/compare/v0.2.2...v0.2.3) (2022-03-11)

**Note:** Version bump only for package unigraph.reader





## [0.2.2](https://github.com/unigraph-dev/unigraph-dev/compare/v0.2.1...v0.2.2) (2022-03-09)


### Bug Fixes

* **packages:** package declaration now independent from unigraph versioning ([141bd18](https://github.com/unigraph-dev/unigraph-dev/commit/141bd18adb1734db6b3d0280e0bd1104feca1adf))





## [0.2.1](https://github.com/unigraph-dev/unigraph-dev/compare/v0.2.0...v0.2.1) (2022-03-09)

**Note:** Version bump only for package unigraph.reader





# [0.2.0](https://github.com/unigraph-dev/unigraph-dev/compare/v0.1.0...v0.2.0) (2022-03-07)

**Note:** Version bump only for package unigraph.reader





# [0.1.0](https://github.com/unigraph-dev/unigraph-dev/compare/v0.1.10...v0.1.0) (2022-02-21)


### Bug Fixes

* **ux:** various ux and usability fixes ([5bfe822](https://github.com/unigraph-dev/unigraph-dev/commit/5bfe82223030037df4ff2d6bcfdd5959b28978b7))


### Features

* **subscriptions:** auto hibernate subscriptions based on visibility ([4f59e0e](https://github.com/unigraph-dev/unigraph-dev/commit/4f59e0e20c28c457b94c6a8076e4f84e9fae0443))


### Reverts

* Revert "docs: changelogs initialized properly" ([e5b8921](https://github.com/unigraph-dev/unigraph-dev/commit/e5b89215d19fb7478cd76898e6473544f21c773e))
