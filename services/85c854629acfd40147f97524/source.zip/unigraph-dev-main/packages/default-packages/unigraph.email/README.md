# Unigraph Email

Add your emails to Unigraph directly from your favorite email client.

## Clients supported

- Thunderbird (works with all major email accounts - you might need to check with your IT for organization accounts)

## Clients planned

- Microsoft Outlook (low priority)
- Headless thunderbird (low priority)

## Availability

This app is available for both local setups and knowledge servers, although the latter is a bit harder to configure.