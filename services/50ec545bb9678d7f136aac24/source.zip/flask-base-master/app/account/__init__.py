from app.account.views import account # noqa
