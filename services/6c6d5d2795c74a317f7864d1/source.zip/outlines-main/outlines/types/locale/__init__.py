"""Locale-specific regex patterns."""

from . import us

__all__ = [
    "us",
]
