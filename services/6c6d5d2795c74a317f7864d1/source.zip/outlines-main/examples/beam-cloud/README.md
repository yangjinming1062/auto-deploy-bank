## Deploy Outlines on Beam

1. Create an account [here](https://beam.cloud) and install the Beam SDK
2. Download the `app.py` file to your computer
3. Deploy it as a serverless API by running: `beam deploy app.py:predict`
