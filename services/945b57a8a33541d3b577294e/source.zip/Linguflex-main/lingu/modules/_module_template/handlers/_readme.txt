Place your business logic handlers in this folder.
Ensure that these files are independent of and not linked to Linguflex.
Each file should be structured to allow for standalone testing, separate from Linguflex.