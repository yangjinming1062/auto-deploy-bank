# User Guide

This section contains architectural details and configuration references for the Landing Zone Accelerator solution.

!!! info "Subpages"
    - [Services, Features, and Configuration References](./config.md)
    - [Centralized Logging](./logging.md)
    - [Security Hub Findings](./securityhub-findings.md)
    - [Replacement Variables](./replacement-variables.md)
    - [Configuration File Includes](./configuration-include.md)
    - [CloudFormation Stack Policy Protection](./stack-policy.md)
    - [V2 Network Stack Usage](./v2-stacks.md)

!!! note "See also"
    - [Implementation Guide - Architecture Details](https://docs.aws.amazon.com/solutions/latest/landing-zone-accelerator-on-aws/architecture-details.html)
    - [Implementation Guide - Use the solution](https://docs.aws.amazon.com/solutions/latest/landing-zone-accelerator-on-aws/use-the-solution.html)