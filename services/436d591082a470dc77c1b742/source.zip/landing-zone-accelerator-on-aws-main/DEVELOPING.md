# Developing

Details for contributing to the development of the solution have been moved to the [Developer Guide](https://awslabs.github.io/landing-zone-accelerator-on-aws/latest/developer-guide) section of our [GitHub Pages website](https://awslabs.github.io/landing-zone-accelerator-on-aws).
