# TCN
* Code: [https://github.com/locuslab/TCN](https://github.com/locuslab/TCN)
* Paper: [An Empirical Evaluation of Generic Convolutional and Recurrent Networks for Sequence Modeling](https://arxiv.org/abs/1803.01271).

