export type Surface = 'top' | 'bottom' | 'left' | 'right' | 'front' | 'back'
export const SURFACES: Surface[] = ['top', 'bottom', 'left', 'right', 'front', 'back']
