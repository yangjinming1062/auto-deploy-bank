# Contribution Guidelines

Please check out the guidelines on https://vikunja.io/docs/development/
