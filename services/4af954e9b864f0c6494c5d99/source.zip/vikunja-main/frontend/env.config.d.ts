declare module 'postcss-easing-gradients'
declare module 'vite-plugin-sentry/client'
declare module 'virtual:vite-plugin-sentry/sentry-config'
