export function isEditorContentEmpty(content: string): boolean {
	return content === '' || content === '<p></p>'
}
