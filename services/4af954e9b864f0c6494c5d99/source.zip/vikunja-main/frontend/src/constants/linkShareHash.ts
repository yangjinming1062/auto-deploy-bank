export const LINK_SHARE_HASH_PREFIX = '#share-auth-token='
