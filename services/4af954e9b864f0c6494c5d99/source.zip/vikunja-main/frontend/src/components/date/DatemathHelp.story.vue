<script setup lang="ts">
import DatemathHelp from './DatemathHelp.vue'
</script>

<template>
	<Story>
		<Variant title="Default">
			<DatemathHelp />
		</Variant>
	</Story>
</template>
