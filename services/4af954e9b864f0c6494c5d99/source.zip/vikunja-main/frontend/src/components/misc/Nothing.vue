<template>
	<p class="has-text-centered has-text-grey is-italic p-4 mbe-4">
		<slot />
	</p>
</template>
