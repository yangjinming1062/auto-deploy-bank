# Quickstart Guide for LangChain

Mostly taken from the official website: [Quickstart Guide](https://python.langchain.com/docs/get_started/quickstart)