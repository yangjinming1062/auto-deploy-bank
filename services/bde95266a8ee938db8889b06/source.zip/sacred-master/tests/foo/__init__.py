#!/usr/bin/env python
# coding=utf-8
"""
A local package used to test the gathering of sources by test_dependencies.
"""
