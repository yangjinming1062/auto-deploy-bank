#!/usr/bin/env python
# coding=utf-8
"""
This source should not be gathered. It is a regression test for an
exception that happened if a custom pybind11 extension was present.
"""


__file__ = None
