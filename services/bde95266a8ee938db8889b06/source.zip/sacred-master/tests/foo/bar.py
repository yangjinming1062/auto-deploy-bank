#!/usr/bin/env python
# coding=utf-8
"""
A local imported module for the dependency example. Used to test the gathering
of sources.
"""


def test_func():
    pass
