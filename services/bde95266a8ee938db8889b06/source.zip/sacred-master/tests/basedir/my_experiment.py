#!/usr/bin/env python
# coding=utf-8
"""
A file for testing the gathering of sources when a custom base directory is set.
"""

from tests.foo import bar


def some_func():
    pass
