# @pnpm/cache.api

> API for controlling the cache

[![npm version](https://img.shields.io/npm/v/@pnpm/cache.api.svg)](https://www.npmjs.com/package/@pnpm/cache.api)

## Installation

```sh
pnpm add @pnpm/cache.api
```

## License

MIT
