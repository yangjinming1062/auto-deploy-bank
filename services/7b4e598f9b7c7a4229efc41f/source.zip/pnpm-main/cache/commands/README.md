# @pnpm/cache.commands

> Commands for controlling the cache

[![npm version](https://img.shields.io/npm/v/@pnpm/cache.commands.svg)](https://www.npmjs.com/package/@pnpm/cache.commands)

## Installation

```sh
pnpm add @pnpm/cache.commands
```

## License

MIT
