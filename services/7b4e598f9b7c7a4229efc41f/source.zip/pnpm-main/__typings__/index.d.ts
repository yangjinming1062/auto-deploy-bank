/// <reference path="local.d.ts" />
/// <reference path="typed.d.ts" />
