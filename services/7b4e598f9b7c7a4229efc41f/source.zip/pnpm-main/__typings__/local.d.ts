/* eslint-disable @typescript-eslint/no-explicit-any */
declare module 'bole' {
  const anything: any
  export = anything
}

declare module 'split2' {
  const anything: any
  export = anything
}

declare module 'hyperdrive-schemas' {
  const anything: any
  export = anything
}

declare module 'fuse-native' {
  const anything: any
  export = anything
}

declare module '@zkochan/libnpx/index' {
  const anything: any
  export = anything
}

declare module '@pnpm/npm-conf' {
  const anything: any
  export = anything
}

declare module '@pnpm/npm-conf/lib/util.js' {
  export function parseField (types: any, field: string, value: any): unknown
}

declare module '@pnpm/npm-conf/lib/conf' {
  const anything: any
  export = anything
}

declare module '@pnpm/npm-lifecycle' {
  const anything: any
  export = anything
}

declare module '@pnpm/npm-package-arg' {
  const anything: any
  export = anything
}

declare module '@pnpm/which' {
  const anything: any
  export = anything
}

declare module 'anonymous-npm-registry-client' {
  const anything: any
  export = anything
}

declare module 'ansi-diff' {
  const anything: any
  export = anything
}

declare module 'better-path-resolve' {
  const anything: any
  export = anything
}

// cspell:disable-next-line
declare module '@zkochan/diable' {
  const anything: any
  export = anything
}

declare module 'dint' {
  const anything: any
  export = anything
}

declare module 'exists-link' {
  const anything: any
  export = anything
}

declare module 'graceful-git' {
  const anything: any
  export = anything
}

declare module 'is-inner-link' {
  const anything: any
  export = anything
}

declare module 'read-package-json' {
  const anything: any
  export = anything
}

declare module 'split-cmd/index.modern.mjs' {
  export function split (command: string): string[]
}

declare module 'stacktracey' {
  const anything: any
  export = anything
}

declare module 'yaml-tag' {
  const anything: any
  export = anything
}

declare module '@pnpm/patch-package/dist/applyPatches.js' {
  export function applyPatch (opts: any): boolean
}

declare module 'ramda/src/map' {
  function map <K extends string | number | symbol, V, U> (fn: (x: V) => U, obj: Record<K, V>): Record<K, U>
  export = map
}

declare module '@yarnpkg/core/semverUtils'
declare module '@yarnpkg/core/structUtils'

// These are needed for transitive type dependencies that can't be resolved
// from within the pnpm store
declare module 'picomatch' {
  const anything: any
  export = anything
}
