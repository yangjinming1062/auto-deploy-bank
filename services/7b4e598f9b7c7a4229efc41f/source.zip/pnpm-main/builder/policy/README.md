# @pnpm/builder.policy

> Create a function for filtering out dependencies that are not allowed to be built

## Install

```
pnpm add @pnpm/builder.policy
```

## License

[MIT](LICENSE)
