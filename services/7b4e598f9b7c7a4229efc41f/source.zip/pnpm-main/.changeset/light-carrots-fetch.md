---
"@pnpm/prepare-package": major
"@pnpm/git-fetcher": patch
"@pnpm/tarball-fetcher": patch
"@pnpm/core": patch
"@pnpm/headless": patch
"@pnpm/fetcher-base": minor
"@pnpm/package-requester": minor
"@pnpm/resolve-dependencies": minor
"@pnpm/store-controller-types": minor
"pnpm": patch
---

Block git-hosted dependencies from running prepare scripts unless explicitly allowed in onlyBuiltDependencies [#10288](https://github.com/pnpm/pnpm/pull/10288).
