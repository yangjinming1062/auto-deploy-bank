---
"@pnpm/plugin-commands-config": major
"@pnpm/config": major
"pnpm": major
---

`pnpm config get` and `pnpm config list` no longer load non camelCase options from the workspace manifest (`pnpm-workspace.yaml`).
