---
"@pnpm/yaml.document-sync": major
---

Initial version.
