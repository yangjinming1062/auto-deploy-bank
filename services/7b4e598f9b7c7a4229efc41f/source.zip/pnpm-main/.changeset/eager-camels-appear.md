---
"@pnpm/plugin-commands-config": major
"pnpm": major
---

`pnpm config list` and `pnpm config get` (without argument) now hide auth-related settings.
