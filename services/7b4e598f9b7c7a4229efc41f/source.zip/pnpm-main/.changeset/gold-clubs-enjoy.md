---
"pnpm": major
---

Removed the `pnpm server` command [#10463](https://github.com/pnpm/pnpm/pull/10463).
