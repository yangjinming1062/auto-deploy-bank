---
"@pnpm/config": major
"pnpm": major
---

`strictDepBuilds` is `true` by default.
