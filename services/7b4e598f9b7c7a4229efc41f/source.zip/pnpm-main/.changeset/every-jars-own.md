---
"@pnpm/manifest-utils": minor
---

Added convertEnginesRuntimeToDependencies.
