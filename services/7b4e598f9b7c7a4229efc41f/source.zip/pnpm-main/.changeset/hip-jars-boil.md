---
"@pnpm/calc-dep-state": major
"pnpm": minor
---

**Semi-breaking.** Changed the location of unscoped packages in the virtual global store. They will now be stored under a directory named `@` to maintain a uniform 4-level directory depth.
