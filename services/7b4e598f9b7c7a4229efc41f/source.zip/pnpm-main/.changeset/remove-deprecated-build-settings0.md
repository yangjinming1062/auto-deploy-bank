---
"@pnpm/types": major
"@pnpm/config": major
"@pnpm/core": major
"@pnpm/headless": major
"@pnpm/builder.policy": major
"@pnpm/exec.build-commands": major
"@pnpm/plugin-commands-installation": major
"@pnpm/plugin-commands-rebuild": major
"@pnpm/workspace.manifest-writer": major
---

Remove deprecated build dependency settings: `onlyBuiltDependencies`, `onlyBuiltDependenciesFile`, `neverBuiltDependencies`, and `ignoredBuiltDependencies`.
