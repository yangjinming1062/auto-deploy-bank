---
"@pnpm/plugin-commands-audit": patch
"pnpm": patch
---

Fixed `pnpm audit --json` to respect the `--audit-level` setting for both exit code and output filtering [#10540](https://github.com/pnpm/pnpm/issues/10540).
