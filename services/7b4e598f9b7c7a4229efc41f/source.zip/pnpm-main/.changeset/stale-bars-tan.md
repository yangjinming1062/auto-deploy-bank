---
"@pnpm/dependency-path": patch
"@pnpm/calc-dep-state": patch
---

Fix dependency graph hash calculation for runtime dependencies (like Node.js, Deno).
