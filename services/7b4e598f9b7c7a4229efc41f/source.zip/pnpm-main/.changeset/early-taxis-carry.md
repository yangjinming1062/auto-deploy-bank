---
"@pnpm/exportable-manifest": minor
"pnpm": minor
---

Add support for a hook called `beforePacking` that can be used to customize the `package.json` contents at publish time [#3816](https://github.com/pnpm/pnpm/issues/3816).
