---
"@pnpm/npm-resolver": patch
---

Update parse-npm-tarball-url to fix deprecation warnings on Node.js 24.
