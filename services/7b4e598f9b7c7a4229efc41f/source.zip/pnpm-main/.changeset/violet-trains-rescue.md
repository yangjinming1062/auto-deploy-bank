---
"@pnpm/manifest-utils": major
---

Added `@pnpm/logger` to peer dependencies.
