---
"@pnpm/plugin-commands-installation": patch
"pnpm": patch
---

The parameter set by the `--allow-build` flag is written to `allowBuilds`.
