---
"@pnpm/common-cli-options-help": minor
"@pnpm/core": minor
"@pnpm/config": minor
"pnpm": minor
---

A new `--yes` flag can be passed to pnpm to automatically confirm prompts. This is useful when running pnpm in non-interactive script.
