---
"@pnpm/package-bins": patch
"pnpm": patch
---

Security fix: prevent path traversal in `directories.bin` field.
