---
"@pnpm/plugin-commands-completion": patch
"pnpm": patch
---

Fixed the documentation URL shown in `pnpm completion --help` to point to the correct page at https://pnpm.io/completion [#10281](https://github.com/pnpm/pnpm/issues/10281).
