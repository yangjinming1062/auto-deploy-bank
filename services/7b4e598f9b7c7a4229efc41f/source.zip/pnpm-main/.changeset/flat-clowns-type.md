---
"@pnpm/npm-resolver": major
---

Changed the error code for no matching version that satisfies the maturity configuration.
