---
"@pnpm/package-store": patch
"pnpm": patch
---

`pnpm store prune` should not fail if the store contains Node.js packages [#10131](https://github.com/pnpm/pnpm/issues/10131).
