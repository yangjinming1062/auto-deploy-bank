---
"@pnpm/plugin-commands-config": minor
"@pnpm/config": minor
"pnpm": minor
---

Added support for `pnpm config get globalconfig` to retrieve the global config file path [#9977](https://github.com/pnpm/pnpm/issues/9977).
