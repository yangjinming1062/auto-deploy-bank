---
"pnpm": patch
---

patched @isaacs/brace-expansion vulnerability https://github.com/advisories/GHSA-7h2j-956f-4vf2
