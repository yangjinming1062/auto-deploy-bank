---
"@pnpm/cafs-types": minor
"@pnpm/store.cafs": minor
---

Export a new function to add a new file to the CAFS.
