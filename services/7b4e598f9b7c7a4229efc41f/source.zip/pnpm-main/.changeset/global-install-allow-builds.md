---
"@pnpm/config": minor
"pnpm": minor
---

Support reading `allowBuilds` from `pnpm-workspace.yaml` in the global package directory for global installs.
