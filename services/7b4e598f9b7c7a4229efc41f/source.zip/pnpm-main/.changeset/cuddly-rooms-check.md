---
"@pnpm/tarball-fetcher": patch
"@pnpm/git-fetcher": patch
---

`@pnpm/fs.packlist` should be linked from the workspace.
