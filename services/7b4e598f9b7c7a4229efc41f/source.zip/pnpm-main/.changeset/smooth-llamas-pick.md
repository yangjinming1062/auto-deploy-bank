---
"@pnpm/plugin-commands-installation": minor
"@pnpm/plugin-commands-script-runners": minor
"@pnpm/resolve-dependencies": minor
"@pnpm/store-connection-manager": minor
"@pnpm/package-requester": minor
"@pnpm/store-controller-types": minor
"@pnpm/resolver-base": minor
"@pnpm/npm-resolver": minor
"@pnpm/core": minor
"@pnpm/types": minor
"@pnpm/registry.types": minor
"@pnpm/config": minor
---

Added a new setting: `trustPolicy`.
