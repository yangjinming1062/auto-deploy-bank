---
"@pnpm/plugin-commands-config": major
"pnpm": major
---

`pnpm config list` now prints a JSON object instead of INI formatted text.
