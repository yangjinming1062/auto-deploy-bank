---
"@pnpm/types": major
---

DevEngineDependency renamed to EngineDependency.
