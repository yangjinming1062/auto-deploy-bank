---
"@pnpm/modules-yaml": minor
---

Save node_modules/.modules.yaml in JSON format.
