---
"@pnpm/npm-resolver": patch
"pnpm": patch
---

`trustPolicy` should ignore the trust evidences of prerelease versions, when installing a non-prerelease version.
