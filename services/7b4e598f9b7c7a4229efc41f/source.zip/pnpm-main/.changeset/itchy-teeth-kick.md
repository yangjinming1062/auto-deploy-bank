---
"pnpm": patch
---

update tar to version 7.5.7 to fix security issue

Updating the version of dependency tar to 7.5.7 because the previous one have a security vulnerability reported here: <a href="https://github.com/advisories/GHSA-34x7-hfp2-rc4v">CVE-2026-24842</a>
