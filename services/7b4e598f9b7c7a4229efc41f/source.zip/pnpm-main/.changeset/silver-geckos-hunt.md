---
"@pnpm/node.resolver": patch
"pnpm": patch
---

Don't add an extra slash to the Node.js mirror URL [#10204](https://github.com/pnpm/pnpm/pull/10204).
