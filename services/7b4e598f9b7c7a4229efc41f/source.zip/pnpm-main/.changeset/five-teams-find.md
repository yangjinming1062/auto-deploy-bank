---
"@pnpm/plugin-commands-publishing": minor
"pnpm": minor
---

Added support for `--dry-run` to the `pack` command [#10301](https://github.com/pnpm/pnpm/issues/10301).
