---
"@pnpm/plugin-commands-script-runners": patch
"@pnpm/config": patch
"pnpm": patch
---

It should be possible to declare the `requiredScripts` setting in `pnpm-workspace.yaml` [#10261](https://github.com/pnpm/pnpm/issues/10261).
