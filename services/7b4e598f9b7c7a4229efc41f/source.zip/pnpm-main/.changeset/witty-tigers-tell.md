---
"@pnpm/config": patch
"pnpm": patch
---

Setting `gitBranchLockfile` and related settings via `pnpm-workspace.yaml` should work [#9651](https://github.com/pnpm/pnpm/issues/9651).
