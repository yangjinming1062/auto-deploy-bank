---
"@pnpm/naming-cases": major
---

Initial Release.
