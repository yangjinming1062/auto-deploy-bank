---
"pnpm": patch
---

`pnpm help` should correctly report if the currently running pnpm CLI is bundled with Node.js [#10561](https://github.com/pnpm/pnpm/issues/10561).
