---
"pnpm": patch
---

Improved reporting of ignored dependency scripts [#10276](https://github.com/pnpm/pnpm/pull/10276).
