---
"@pnpm/workspace.manifest-writer": minor
"@pnpm/config.config-writer": minor
---

New option added: updatedOverrides.
