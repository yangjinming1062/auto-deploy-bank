---
"@pnpm/fetching.binary-fetcher": patch
---

Runtime dependencies (node, bun, deno) are now added to the store with a package.json file.
