---
"@pnpm/headless": patch
---

Failed to install dependency packages under absolute paths on different disk paths.
