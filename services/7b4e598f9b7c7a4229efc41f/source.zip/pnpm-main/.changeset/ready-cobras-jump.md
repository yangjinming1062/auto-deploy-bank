---
"@pnpm/plugin-commands-config": major
"pnpm": major
---

`pnpm config get <array>` now prints a JSON array.
