---
"@pnpm/plugin-commands-outdated": patch
"pnpm": patch
---

Show deprecation in table/list formats when latest version is deprecated [#8658](https://github.com/pnpm/pnpm/issues/8658).
