---
"@pnpm/package-requester": minor
"@pnpm/store-controller-types": minor
"@pnpm/fetcher-base": minor
"@pnpm/worker": minor
"pnpm": minor
---

Compute integrity hash for HTTP tarball dependencies when fetching, storing it in the lockfile to prevent servers from serving altered content on subsequent installs [#10287](https://github.com/pnpm/pnpm/pull/10287).
