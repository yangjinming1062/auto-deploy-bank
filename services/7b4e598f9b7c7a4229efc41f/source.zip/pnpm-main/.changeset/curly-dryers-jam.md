---
"@pnpm/plugin-commands-script-runners": minor
pnpm: minor
---

The `pnpm dlx` / `pnpx` command now supports the `catalog:` protocol. Example: `pnpm dlx shx@catalog:`.
