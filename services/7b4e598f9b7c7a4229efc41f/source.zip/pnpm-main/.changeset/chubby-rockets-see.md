---
"@pnpm/plugin-commands-script-runners": patch
"pnpm": patch
---

Fixed `minimumReleaseAgeExclude` not being respected by `pnpm dlx` [#10338](https://github.com/pnpm/pnpm/issues/10338).
