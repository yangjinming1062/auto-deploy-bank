---
"@pnpm/types": minor
---

Add type for IgnoredBuilds.
