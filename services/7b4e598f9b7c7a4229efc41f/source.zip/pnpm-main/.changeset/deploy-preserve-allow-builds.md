---
"@pnpm/plugin-commands-deploy": minor
---

Preserve `allowBuilds` settings when deploying a project. The `allowBuilds` configuration is now written to `pnpm-workspace.yaml` in the deploy directory.
