---
"@pnpm/patching.apply-patch": patch
---

Import `@pnpm/patch-package/dist/applyPatches` using `.js` extension for ESM compatibility. This fixes an `ERR_MODULE_NOT_FOUND` error.
