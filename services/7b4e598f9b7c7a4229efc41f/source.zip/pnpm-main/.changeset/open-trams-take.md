---
"@pnpm/plugin-commands-listing": minor
"@pnpm/reviewing.dependencies-hierarchy": minor
"@pnpm/list": minor
---

Added `--lockfile-only` option to `pnpm list` [#10020](https://github.com/pnpm/pnpm/issues/10020).
