---
"@pnpm/crypto.integrity": major
---

Initial release.
