---
"@pnpm/plugin-commands-audit": minor
"@pnpm/config": minor
"pnpm": minor
---

Support configuring `auditLevel` in the `pnpm-workspace.yaml` file [#10540](https://github.com/pnpm/pnpm/issues/10540).
