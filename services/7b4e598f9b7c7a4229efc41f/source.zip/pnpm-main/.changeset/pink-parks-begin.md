---
"@pnpm/plugin-commands-deploy": patch
"pnpm": patch
---

Remove the `injectWorkspacePackages` setting from the lockfile on the `deploy` command [#10294](https://github.com/pnpm/pnpm/pull/10294).
