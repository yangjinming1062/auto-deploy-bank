---
"@pnpm/tarball-fetcher": minor
"@pnpm/fetcher-base": minor
"@pnpm/worker": minor
"@pnpm/crypto.object-hasher": minor
---

Added a way to append a manifest to a package with no package.json file.
