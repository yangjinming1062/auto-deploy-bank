---
"@pnpm/builder.policy": minor
"pnpm": patch
---

Git dependencies with build scripts should respect the `dangerouslyAllowAllBuilds` settings [#10376](https://github.com/pnpm/pnpm/issues/10376).
