---
"@pnpm/plugin-commands-rebuild": major
"@pnpm/modules-yaml": major
"@pnpm/headless": major
"@pnpm/build-modules": major
"@pnpm/core": major
"@pnpm/exec.build-commands": major
---

`ignoreBuilds` is now a set of DepPath.
