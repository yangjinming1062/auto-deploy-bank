---
"@pnpm/workspace.read-manifest": minor
---

The `validateWorkspaceManifest` function is now exported and can be used to validate whether a workspace manifest object's schema is correct.
