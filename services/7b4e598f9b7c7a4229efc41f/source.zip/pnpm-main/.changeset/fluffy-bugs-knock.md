---
"@pnpm/list": patch
"pnpm": patch
---

Revert `pnpm why` dependency pruning to prefer correctness over memory consumption. Reverted PR: [#7122](https://github.com/pnpm/pnpm/pull/7122).
