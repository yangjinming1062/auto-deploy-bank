---
"@pnpm/worker": patch
---

Fix inconsistent store structure due to race condition.
