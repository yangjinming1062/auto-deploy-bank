---
"@pnpm/config": major
"pnpm": major
---

The default value of the `type` field in the `package.json` file of the project initialized by `pnpm init` command has been changed to `module`.
