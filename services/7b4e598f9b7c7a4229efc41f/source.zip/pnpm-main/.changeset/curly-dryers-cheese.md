---
"@pnpm/plugin-commands-script-runners": minor
---

Add timeout & retry options to `pnpm dlx` / `pnpx`
