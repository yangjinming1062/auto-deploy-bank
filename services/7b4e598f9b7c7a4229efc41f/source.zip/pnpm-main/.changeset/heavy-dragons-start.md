---
"pnpm": patch
"@pnpm/git-fetcher": patch
"@pnpm/git-resolver": patch
---

Always resolve git references to full commits and ensure `HEAD` points to the commit after checkout [#10310](https://github.com/pnpm/pnpm/pull/10310).
