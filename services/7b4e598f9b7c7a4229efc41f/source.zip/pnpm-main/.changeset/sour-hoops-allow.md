---
"@pnpm/pick-fetcher": major
"@pnpm/resolve-dependencies": minor
"@pnpm/plugin-commands-deploy": minor
"@pnpm/store-connection-manager": minor
"@pnpm/default-resolver": minor
"@pnpm/license-scanner": minor
"@pnpm/calc-dep-state": minor
"@pnpm/resolver-base": minor
"@pnpm/package-store": minor
"@pnpm/client": minor
"@pnpm/core": minor
"@pnpm/pnpmfile": minor
"@pnpm/lockfile.types": minor
"@pnpm/hooks.types": minor
"@pnpm/package-requester": patch
"@pnpm/tarball-fetcher": patch
"@pnpm/deps.graph-builder": patch
"@pnpm/lockfile.utils": patch
---

Support for custom resolvers and fetchers.
