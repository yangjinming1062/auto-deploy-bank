---
"@pnpm/headless": minor
---

Export extendProjectsWithTargetDirs.
