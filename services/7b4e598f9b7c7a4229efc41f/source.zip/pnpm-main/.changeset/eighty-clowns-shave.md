---
"@pnpm/plugin-commands-config": patch
---

Fix phantom keys in `pnpm config get <key>` [#10296](https://github.com/pnpm/pnpm/issues/10296).
