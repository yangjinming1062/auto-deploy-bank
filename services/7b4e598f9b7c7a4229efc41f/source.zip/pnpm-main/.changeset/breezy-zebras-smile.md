---
"@pnpm/reviewing.dependencies-hierarchy": patch
"pnpm": patch
---

Fixed `pnpm list --json` returning incorrect paths when using global virtual store [#10187](https://github.com/pnpm/pnpm/issues/10187).
