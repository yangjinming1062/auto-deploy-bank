---
"@pnpm/modules-yaml": major
---

Remove options from writeModulesManifest.
