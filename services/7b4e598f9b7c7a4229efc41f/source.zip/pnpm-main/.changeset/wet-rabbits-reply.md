---
"@pnpm/workspace.manifest-writer": minor
pnpm: minor
---

When pnpm updates the `pnpm-workspace.yaml`, comments, string formatting, and whitespace will be preserved.
