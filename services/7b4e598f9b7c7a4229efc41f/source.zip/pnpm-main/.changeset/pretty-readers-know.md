---
"@pnpm/run-npm": minor
"@pnpm/plugin-commands-config": patch
"pnpm": patch
---

Explicitly tell `npm` the path to the global `rc` config file.
