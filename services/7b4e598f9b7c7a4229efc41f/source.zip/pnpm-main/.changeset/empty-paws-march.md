---
"@pnpm/plugin-commands-publishing": patch
"pnpm": patch
---

`pnpm publish -r --force` should allow to run publish over already existing versions in the registry [#10272](https://github.com/pnpm/pnpm/issues/10272).
