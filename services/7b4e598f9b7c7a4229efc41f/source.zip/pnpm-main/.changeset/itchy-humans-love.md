---
"@pnpm/config": major
"@pnpm/plugin-commands-config": major
"pnpm": major
---

pnpm no longer loads non-auth and non-registry settings from rc files. Other settings must be defined in `pnpm-workspace.yaml`.
