---
"@pnpm/worker": patch
---

`WMIC` has been deprecated and replaced by PowerShell commands.
