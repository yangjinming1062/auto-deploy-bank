---
"@pnpm/exportable-manifest": minor
"pnpm": minor
---

Allow to override the `engines` field on publish by the `publishConfig.engines` field.
