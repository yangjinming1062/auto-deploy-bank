---
"pnpm": patch
---

Fixed `pnpm run -r` failing with "No projects matched the filters" when an empty `pnpm-workspace.yaml` exists [#10497](https://github.com/pnpm/pnpm/issues/10497).
