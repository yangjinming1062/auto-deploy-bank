---
"@pnpm/config": patch
"pnpm": patch
---

Correctly read auth tokens for URLs that contain underscores [#17](https://github.com/pnpm/npm-conf/pull/17).
