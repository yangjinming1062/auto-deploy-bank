---
"@pnpm/resolve-dependencies": major
"@pnpm/dependency-path": major
"@pnpm/calc-dep-state": major
"@pnpm/headless": major
"@pnpm/deps.graph-builder": major
"@pnpm/core": major
"pnpm": major
---

Runtime dependencies are always linked from the global virtual store [#10233](https://github.com/pnpm/pnpm/pull/10233).
