---
"@pnpm/constants": major
"pnpm": major
---

Store version bumped to v11.
