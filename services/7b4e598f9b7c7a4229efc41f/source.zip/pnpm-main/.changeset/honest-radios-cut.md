---
"@pnpm/find-workspace-dir": patch
---

Throw an error message if a `.pnpm-workspace.yaml` or `.pnpm-workspace.yml` file is found instead of a `pnpm-workspace.yaml`.
