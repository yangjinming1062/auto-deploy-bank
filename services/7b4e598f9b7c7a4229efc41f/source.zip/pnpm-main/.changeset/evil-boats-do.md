---
"@pnpm/config": major
"pnpm": major
---

`blockExoticSubdeps` is `true` by default.
