---
"@pnpm/config": minor
"pnpm": minor
---

Load environment variables whose names start with `pnpm_config_` into config. These environment variables override settings from `pnpm-workspace.yaml` but not the CLI arguments.
