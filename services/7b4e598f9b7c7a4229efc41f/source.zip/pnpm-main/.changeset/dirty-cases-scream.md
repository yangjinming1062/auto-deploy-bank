---
"@pnpm/resolve-dependencies": patch
"pnpm": patch
---

Don't fail on `pnpm add`, when `blockExoticSubdeps` is set to `true` [#10324](https://github.com/pnpm/pnpm/issues/10324).
