---
"@pnpm/config": patch
"pnpm": patch
---

Throw an error if the value of the `tokenHelper` or `<url>:tokenHelper` setting contains an environment variable.
