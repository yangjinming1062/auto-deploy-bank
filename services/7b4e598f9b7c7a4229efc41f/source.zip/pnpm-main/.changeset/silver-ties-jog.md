---
"pnpm": major
---

The standalone exe version of pnpm requires at least glibc 2.27.
