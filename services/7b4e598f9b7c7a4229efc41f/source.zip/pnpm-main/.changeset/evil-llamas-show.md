---
"@pnpm/build-modules": major
---

Replaced fetchingBundledManifest with fetching.
