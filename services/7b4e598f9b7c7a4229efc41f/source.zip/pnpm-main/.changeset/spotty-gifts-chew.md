---
"@pnpm/lockfile.utils": major
---

Remove extendProjectsWithTargetDirs.
