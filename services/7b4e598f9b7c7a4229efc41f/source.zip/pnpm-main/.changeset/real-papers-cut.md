---
"@pnpm/pnpmfile": minor
"pnpm": minor
---

Added support for pnpmfiles written in ESM. They should have the `.mjs` extension: `.pnpmfile.mjs` [#9730](https://github.com/pnpm/pnpm/pull/9730).
