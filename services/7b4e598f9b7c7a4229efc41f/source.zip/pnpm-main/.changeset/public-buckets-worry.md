---
"@pnpm/config": patch
---

Fix `_password` decoding.
