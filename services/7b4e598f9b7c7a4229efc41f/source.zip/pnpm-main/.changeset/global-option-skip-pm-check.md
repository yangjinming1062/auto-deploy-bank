---
"pnpm": patch
---

Skip the package manager check when running with --global and a project packageManager is configured, and warn that the check is skipped.
