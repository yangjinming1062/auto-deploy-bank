---
"@pnpm/plugin-commands-init": minor
"pnpm": minor
---

Added a new flag called `--bare` to `pnpm init` for creating a package.json with the bare minimum of required fields [#10226](https://github.com/pnpm/pnpm/issues/10226).
