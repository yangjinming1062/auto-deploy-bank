---
"@pnpm/npm-resolver": patch
---

Improve the error messages related to `trustPolicy` mismatch.
