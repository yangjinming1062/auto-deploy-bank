---
"@pnpm/npm-resolver": patch
pnpm: patch
---

Revert Try to avoid making network calls with preferOffline [#10334](https://github.com/pnpm/pnpm/pull/10334).
