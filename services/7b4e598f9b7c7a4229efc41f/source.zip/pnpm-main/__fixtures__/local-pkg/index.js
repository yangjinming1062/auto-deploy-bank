module.exports = () => require('./package.json').name
