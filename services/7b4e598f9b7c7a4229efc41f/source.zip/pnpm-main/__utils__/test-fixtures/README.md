# @pnpm/test-fixtures

> Test fixtures

## Installation

```
pnpm add -D @pnpm/test-fixtures
```

## License

MIT
