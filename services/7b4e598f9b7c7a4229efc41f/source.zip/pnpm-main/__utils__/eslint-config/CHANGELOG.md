# @pnpm/eslint-config

## 1.1.0

### Minor Changes

- e9aa6f682: Update @typescript-eslint dependencies to v6. Version specifiers were changed from `^5.62.0` to `6.5.0`.
- e9aa6f682: Update `eslint-config-standard-with-typescript` dependency minimum version from 37.0.0 to 39.0.0.

## 1.0.1

### Patch Changes

- 39c040127: upgrade various dependencies
