import fs from 'fs'
import * as execa from 'execa'
import path from 'path'
import makeEmptyDir from 'make-empty-dir'
import stream from 'stream'
import * as tar from 'tar'
import { glob } from 'tinyglobby'

const repoRoot = path.join(import.meta.dirname, '../../..')
const dest = path.join(repoRoot, 'dist')
const artifactsDir = path.join(repoRoot, 'pnpm/artifacts')

;(async () => {
  await makeEmptyDir(dest)
  if (!fs.existsSync(path.join(artifactsDir, 'linux-x64/pnpm'))) {
    execa.sync('pnpm', ['--filter=@pnpm/exe', 'run', 'prepublishOnly'], {
      cwd: repoRoot,
      stdio: 'inherit',
    })
  }
  copyArtifact('linux-x64/pnpm', 'pnpm-linux-x64')
  copyArtifact('linuxstatic-x64/pnpm', 'pnpm-linuxstatic-x64')
  copyArtifact('linuxstatic-arm64/pnpm', 'pnpm-linuxstatic-arm64')
  copyArtifact('linux-arm64/pnpm', 'pnpm-linux-arm64')
  copyArtifact('macos-x64/pnpm', 'pnpm-macos-x64')
  copyArtifact('macos-arm64/pnpm', 'pnpm-macos-arm64')
  copyArtifact('win-x64/pnpm.exe', 'pnpm-win-x64.exe')
  copyArtifact('win-arm64/pnpm.exe', 'pnpm-win-arm64.exe')
  await createSourceMapsArchive()
})()

function copyArtifact (srcName: string, destName: string): void {
  try {
    fs.copyFileSync(path.join(artifactsDir, srcName), path.join(dest, destName))
  } catch (err) {
    console.log(err)
  }
}

async function createSourceMapsArchive () {
  const pnpmDistDir = path.join(repoRoot, 'pnpm/dist')

  // The tar.create function can accept a filter callback function, but this
  // approach ends up adding empty directories to the archive. Using tinyglobby
  // instead.
  const mapFiles = await glob('**/*.map', { cwd: pnpmDistDir })

  await stream.promises.pipeline(
    tar.create({ gzip: true, cwd: pnpmDistDir }, mapFiles),
    fs.createWriteStream(path.join(dest, 'source-maps.tgz'))
  )
}
