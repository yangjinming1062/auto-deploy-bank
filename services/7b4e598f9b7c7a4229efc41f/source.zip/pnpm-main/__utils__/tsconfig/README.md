# @pnpm/tsconfig

> pnpm's TypeScript configuration

## Installation

```
pnpm add -D @pnpm/tsconfig typescript
```

## Usage

Create the following `tsconfig.json` file:

```json
{
  "extends": "@pnpm/tsconfig"
}
```

## License

MIT
