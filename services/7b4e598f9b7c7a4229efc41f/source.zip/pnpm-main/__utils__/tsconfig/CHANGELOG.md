# @pnpm/tsconfig

## 2.0.1

### Patch Changes

- 86e0016: Improve the way the error message displays mismatched specifiers. Show differences instead of 2 whole objects [#9598](https://github.com/pnpm/pnpm/pull/9598).

## 2.0.0

### Major Changes

- 542014839: Node.js 12 is not supported.
