# @pnpm/assert-store

## 1000.0.3

### Patch Changes

- @pnpm/store.cafs@1000.0.19

## 1000.0.2

### Patch Changes

- Updated dependencies [9b9faa5]
  - @pnpm/store.cafs@1000.0.18

## 1000.0.1

### Patch Changes

- @pnpm/store.cafs@1000.0.17

## 2.0.16

### Patch Changes

- @pnpm/store.cafs@1000.0.16

## 2.0.15

### Patch Changes

- @pnpm/store.cafs@1000.0.15

## 2.0.14

### Patch Changes

- @pnpm/store.cafs@1000.0.14

## 2.0.13

### Patch Changes

- @pnpm/store.cafs@1000.0.13

## 2.0.12

### Patch Changes

- @pnpm/store.cafs@1000.0.12

## 2.0.11

### Patch Changes

- @pnpm/store.cafs@1000.0.11

## 2.0.10

### Patch Changes

- @pnpm/store.cafs@1000.0.10

## 2.0.9

### Patch Changes

- @pnpm/store.cafs@1000.0.9

## 2.0.8

### Patch Changes

- @pnpm/store.cafs@1000.0.8

## 2.0.7

### Patch Changes

- @pnpm/store.cafs@1000.0.7

## 2.0.6

### Patch Changes

- @pnpm/store.cafs@1000.0.6

## 2.0.5

### Patch Changes

- @pnpm/store.cafs@1000.0.5

## 2.0.4

### Patch Changes

- @pnpm/store.cafs@1000.0.4

## 2.0.3

### Patch Changes

- @pnpm/store.cafs@1000.0.3

## 2.0.2

### Patch Changes

- @pnpm/store.cafs@1000.0.2

## 2.0.1

### Patch Changes

- @pnpm/store.cafs@1000.0.1

## 2.0.0

### Major Changes

- d433cb9: Some registries allow identical content to be published under different package names or versions. To accommodate this, index files in the store are now stored using both the content hash and package identifier.

  This approach ensures that we can:

  1. Validate that the integrity in the lockfile corresponds to the correct package,
     which might not be the case after a poorly resolved Git conflict.
  2. Allow the same content to be referenced by different packages or different versions of the same package.

  Related PR: [#8510](https://github.com/pnpm/pnpm/pull/8510)
  Related issue: [#8204](https://github.com/pnpm/pnpm/issues/8204)

### Patch Changes

- Updated dependencies [d433cb9]
- Updated dependencies [099e6af]
  - @pnpm/store.cafs@5.0.0

## 1.0.92

### Patch Changes

- Updated dependencies [a1f4df2]
  - @pnpm/store.cafs@4.0.2

## 1.0.91

### Patch Changes

- Updated dependencies [db7ff76]
  - @pnpm/store.cafs@4.0.1

## 1.0.90

### Patch Changes

- Updated dependencies [db420ab]
  - @pnpm/store.cafs@4.0.0

## 1.0.89

### Patch Changes

- @pnpm/store.cafs@3.0.8

## 1.0.88

### Patch Changes

- @pnpm/store.cafs@3.0.7

## 1.0.87

### Patch Changes

- @pnpm/store.cafs@3.0.6

## 1.0.86

### Patch Changes

- Updated dependencies [afe520d]
- Updated dependencies [afe520d]
  - @pnpm/store.cafs@3.0.5

## 1.0.85

### Patch Changes

- @pnpm/store.cafs@3.0.4

## 1.0.84

### Patch Changes

- @pnpm/store.cafs@3.0.3

## 1.0.83

### Patch Changes

- @pnpm/store.cafs@3.0.2

## 1.0.82

### Patch Changes

- @pnpm/store.cafs@3.0.1

## 1.0.81

### Patch Changes

- Updated dependencies [43cdd87]
- Updated dependencies [6cdbf11]
- Updated dependencies [36dcaa0]
- Updated dependencies [730929e]
  - @pnpm/store.cafs@3.0.0

## 1.0.80

### Patch Changes

- @pnpm/store.cafs@2.0.12

## 1.0.79

### Patch Changes

- Updated dependencies [33313d2fd]
  - @pnpm/store.cafs@2.0.11

## 1.0.78

### Patch Changes

- @pnpm/store.cafs@2.0.10

## 1.0.77

### Patch Changes

- @pnpm/store.cafs@2.0.9

## 1.0.76

### Patch Changes

- @pnpm/store.cafs@2.0.8

## 1.0.75

### Patch Changes

- @pnpm/store.cafs@2.0.7

## 1.0.74

### Patch Changes

- Updated dependencies [01bc58e2c]
  - @pnpm/store.cafs@2.0.6

## 1.0.73

### Patch Changes

- @pnpm/store.cafs@2.0.5

## 1.0.72

### Patch Changes

- @pnpm/store.cafs@2.0.4

## 1.0.71

### Patch Changes

- @pnpm/store.cafs@2.0.3

## 1.0.70

### Patch Changes

- Updated dependencies [b3947185c]
  - @pnpm/store.cafs@2.0.2

## 1.0.69

### Patch Changes

- Updated dependencies [b548f2f43]
  - @pnpm/store.cafs@2.0.1

## 1.0.68

### Patch Changes

- Updated dependencies [0fd9e6a6c]
- Updated dependencies [083bbf590]
  - @pnpm/store.cafs@2.0.0

## 1.0.67

### Patch Changes

- Updated dependencies [73f2b6826]
  - @pnpm/store.cafs@1.0.2

## 1.0.66

### Patch Changes

- Updated dependencies [fe1c5f48d]
  - @pnpm/store.cafs@1.0.1

## 1.0.65

### Patch Changes

- Updated dependencies [4bbf482d1]
  - @pnpm/store.cafs@1.0.0

## 1.0.64

### Patch Changes

- Updated dependencies [250f7e9fe]
- Updated dependencies [e958707b2]
  - @pnpm/cafs@7.0.5

## 1.0.63

### Patch Changes

- Updated dependencies [b81cefdcd]
  - @pnpm/cafs@7.0.4

## 1.0.62

### Patch Changes

- Updated dependencies [e57e2d340]
  - @pnpm/cafs@7.0.3

## 1.0.61

### Patch Changes

- Updated dependencies [d55b41a8b]
- Updated dependencies [614d5bd72]
  - @pnpm/cafs@7.0.2

## 1.0.60

### Patch Changes

- @pnpm/cafs@7.0.1

## 1.0.59

### Patch Changes

- Updated dependencies [eceaa8b8b]
  - @pnpm/cafs@7.0.0

## 1.0.58

### Patch Changes

- @pnpm/cafs@6.0.2

## 1.0.57

### Patch Changes

- @pnpm/cafs@6.0.1

## 1.0.56

### Patch Changes

- Updated dependencies [98d6603f3]
- Updated dependencies [98d6603f3]
  - @pnpm/cafs@6.0.0

## 1.0.55

### Patch Changes

- Updated dependencies [1e6de89b6]
  - @pnpm/cafs@5.0.6

## 1.0.54

### Patch Changes

- @pnpm/cafs@5.0.5

## 1.0.53

### Patch Changes

- @pnpm/cafs@5.0.4

## 1.0.52

### Patch Changes

- Updated dependencies [a9d59d8bc]
  - @pnpm/cafs@5.0.3

## 1.0.51

### Patch Changes

- @pnpm/cafs@5.0.2

## 1.0.50

### Patch Changes

- @pnpm/cafs@5.0.1

## 1.0.49

### Patch Changes

- Updated dependencies [043d988fc]
- Updated dependencies [f884689e0]
  - @pnpm/cafs@5.0.0

## 1.0.48

### Patch Changes

- @pnpm/cafs@4.3.2

## 1.0.47

### Patch Changes

- @pnpm/cafs@4.3.1

## 1.0.46

### Patch Changes

- Updated dependencies [745143e79]
  - @pnpm/cafs@4.3.0

## 1.0.45

### Patch Changes

- Updated dependencies [dbac0ca01]
  - @pnpm/cafs@4.2.1

## 1.0.44

### Patch Changes

- Updated dependencies [32915f0e4]
  - @pnpm/cafs@4.2.0

## 1.0.43

### Patch Changes

- Updated dependencies [c191ca7bf]
  - @pnpm/cafs@4.1.0

## 1.0.42

### Patch Changes

- Updated dependencies [39c040127]
  - @pnpm/cafs@4.0.9

## 1.0.41

### Patch Changes

- @pnpm/cafs@4.0.8

## 1.0.40

### Patch Changes

- @pnpm/cafs@4.0.7

## 1.0.39

### Patch Changes

- @pnpm/cafs@4.0.6

## 1.0.38

### Patch Changes

- @pnpm/cafs@4.0.5

## 1.0.37

### Patch Changes

- @pnpm/cafs@4.0.4

## 1.0.36

### Patch Changes

- Updated dependencies [6756c2b02]
  - @pnpm/cafs@4.0.3

## 1.0.35

### Patch Changes

- Updated dependencies [cadefe5b6]
  - @pnpm/cafs@4.0.2

## 1.0.34

### Patch Changes

- @pnpm/cafs@4.0.1

## 1.0.33

### Patch Changes

- Updated dependencies [542014839]
  - @pnpm/cafs@4.0.0

## 1.0.32

### Patch Changes

- @pnpm/cafs@3.0.15

## 1.0.31

### Patch Changes

- @pnpm/cafs@3.0.14

## 1.0.30

### Patch Changes

- @pnpm/cafs@3.0.13

## 1.0.29

### Patch Changes

- @pnpm/cafs@3.0.12

## 1.0.28

### Patch Changes

- @pnpm/cafs@3.0.11

## 1.0.27

### Patch Changes

- @pnpm/cafs@3.0.10

## 1.0.26

### Patch Changes

- @pnpm/cafs@3.0.9

## 1.0.25

### Patch Changes

- @pnpm/cafs@3.0.8

## 1.0.24

### Patch Changes

- @pnpm/cafs@3.0.7

## 1.0.23

### Patch Changes

- @pnpm/cafs@3.0.6

## 1.0.22

### Patch Changes

- @pnpm/cafs@3.0.5

## 1.0.21

### Patch Changes

- Updated dependencies [ef0ca24be]
  - @pnpm/cafs@3.0.4

## 1.0.20

### Patch Changes

- @pnpm/cafs@3.0.3

## 1.0.19

### Patch Changes

- @pnpm/cafs@3.0.2

## 1.0.18

### Patch Changes

- Updated dependencies [6f198457d]
  - @pnpm/cafs@3.0.1

## 1.0.17

### Patch Changes

- Updated dependencies [97b986fbc]
- Updated dependencies [83645c8ed]
  - @pnpm/cafs@3.0.0

## 1.0.16

### Patch Changes

- Updated dependencies [8d1dfa89c]
  - @pnpm/cafs@2.1.0

## 1.0.15

### Patch Changes

- @pnpm/cafs@2.0.5

## 1.0.14

### Patch Changes

- @pnpm/cafs@2.0.4

## 1.0.13

### Patch Changes

- Updated dependencies [b3059f4f8]
  - @pnpm/cafs@2.0.3

## 1.0.12

### Patch Changes

- @pnpm/cafs@2.0.2

## 1.0.11

### Patch Changes

- @pnpm/cafs@2.0.1

## 1.0.10

### Patch Changes

- Updated dependencies [0a6544043]
- Updated dependencies [0a6544043]
  - @pnpm/cafs@2.0.0

## 1.0.9

### Patch Changes

- @pnpm/cafs@1.0.8

## 1.0.8

### Patch Changes

- Updated dependencies [1525fff4c]
  - @pnpm/cafs@1.0.7

## 1.0.7

### Patch Changes

- Updated dependencies [a2ef8084f]
  - @pnpm/cafs@1.0.6

## 1.0.6

### Patch Changes

- @pnpm/cafs@1.0.5

## 1.0.5

### Patch Changes

- @pnpm/cafs@1.0.4

## 1.0.4

### Patch Changes

- Updated dependencies [492805ee3]
  - @pnpm/cafs@1.0.3

## 1.0.3

### Patch Changes

- Updated dependencies [d3ddd023c]
  - @pnpm/cafs@1.0.2

## 1.0.2

### Patch Changes

- @pnpm/cafs@1.0.1

## 1.0.1

### Patch Changes

- Updated dependencies [9596774f2]
- Updated dependencies [f516d266c]
- Updated dependencies [7852deea3]
- Updated dependencies [b6a82072e]
- Updated dependencies [b6a82072e]
- Updated dependencies [a5febb913]
- Updated dependencies [c207d994f]
- Updated dependencies [471149e66]
- Updated dependencies [42e6490d1]
  - @pnpm/cafs@1.0.0

## 1.0.1-alpha.2

### Patch Changes

- Updated dependencies [a5febb913]
  - @pnpm/cafs@1.0.0-alpha.5

## 1.0.1-alpha.1

### Patch Changes

- Updated dependencies [471149e6]
  - @pnpm/cafs@1.0.0-alpha.4

## 1.0.1-alpha.0

### Patch Changes

- Updated dependencies [9596774f2]
- Updated dependencies [7852deea3]
  - @pnpm/cafs@1.0.0-alpha.3
