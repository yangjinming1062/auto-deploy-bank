export default () => {
  return global.killServer?.()
}
