import baseConfig from './config.js'

export default baseConfig
