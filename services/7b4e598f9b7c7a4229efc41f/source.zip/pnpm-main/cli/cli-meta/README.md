# @pnpm/cli-meta

> Reads the meta info of the currently running pnpm instance

[![npm version](https://img.shields.io/npm/v/@pnpm/cli-meta.svg)](https://www.npmjs.com/package/@pnpm/cli-meta)

## Installation

```sh
pnpm add @pnpm/cli-meta
```

## License

MIT
