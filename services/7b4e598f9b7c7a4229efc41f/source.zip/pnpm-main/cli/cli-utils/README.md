# @pnpm/cli-utils

> Utils for pnpm commands

[![npm version](https://img.shields.io/npm/v/@pnpm/cli-utils.svg)](https://www.npmjs.com/package/@pnpm/cli-utils)

## Installation

```sh
pnpm add @pnpm/cli-utils
```

## License

MIT
