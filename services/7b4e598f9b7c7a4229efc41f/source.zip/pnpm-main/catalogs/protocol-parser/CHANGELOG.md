# @pnpm/catalogs.protocol-parser

## 1001.0.0

### Major Changes

- 8a9f3a4: `pref` renamed to `bareSpecifier`.

## 0.1.0

Initial release
