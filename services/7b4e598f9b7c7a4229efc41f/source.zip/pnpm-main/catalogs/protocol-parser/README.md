# @pnpm/catalogs.protocol-parser

> Parse catalog protocol specifiers and return the catalog name.
