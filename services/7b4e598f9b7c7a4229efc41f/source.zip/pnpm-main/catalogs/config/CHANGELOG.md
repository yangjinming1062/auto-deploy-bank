# @pnpm/catalogs.config

## 1000.0.5

### Patch Changes

- @pnpm/error@1000.0.5

## 1000.0.4

### Patch Changes

- @pnpm/error@1000.0.4

## 1000.0.3

### Patch Changes

- @pnpm/error@1000.0.3

## 1000.0.2

### Patch Changes

- @pnpm/error@1000.0.2

## 1000.0.1

### Patch Changes

- @pnpm/error@1000.0.1

## 0.1.2

### Patch Changes

- @pnpm/error@6.0.3

## 0.1.1

### Patch Changes

- @pnpm/error@6.0.2

## 0.1.0

Initial release
