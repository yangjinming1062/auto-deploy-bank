export { getCatalogsFromWorkspaceManifest } from './getCatalogsFromWorkspaceManifest.js'
