# @pnpm/catalogs.types

> Types related to the pnpm catalogs feature.
