import updater from './lib/index.js'

export default updater
