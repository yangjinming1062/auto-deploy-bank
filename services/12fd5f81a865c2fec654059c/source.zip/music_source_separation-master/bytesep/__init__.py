from bytesep.models.lightning_modules import get_model_class
from bytesep.separator import Separator

__version__ = "0.1.1"
