#!/bin/bash
python3 -m black bytesep
