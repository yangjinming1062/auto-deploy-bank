#!/bin/sh
latexmk -pdf h2oGPT-TR.tex
