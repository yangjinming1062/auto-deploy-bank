#!/usr/bin/env python3
"""
Script to create user accounts for h2oGPT.

This script allows administrators to create user accounts in the h2oGPT authentication system.
Users can be created in the auth.db file (SQLite) which is the default authentication backend.

Usage:
    python scripts/create_user.py --username <username> --password <password> [--auth-file auth.db] [--admin]

Environment Variables:
    ADMIN_PASS - Admin password for authentication
    AUTH_FILENAME - Path to auth database (default: auth.db)
"""

import argparse
import os
import sys
import json
import sqlite3
import uuid
from pathlib import Path

# Add src to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from db_utils import fetch_user, upsert_user, create_table


def create_user_account(username, password, auth_filename="auth.db", admin=False, verbose=False):
    """
    Create a new user account in the h2oGPT auth system.

    Args:
        username: Username for the new account
        password: Password for the new account
        auth_filename: Path to auth database file (default: auth.db)
        admin: Whether this user should have admin privileges
        verbose: Enable verbose output

    Returns:
        bool: True if user was created successfully, False otherwise
    """
    # Create the auth database table if it doesn't exist
    if not os.path.exists(auth_filename):
        create_table(auth_filename)
        if verbose:
            print(f"Created new auth database: {auth_filename}")

    # Generate a unique user ID
    user_id = str(uuid.uuid4())

    # Prepare user details
    user_details = {
        "password": password,
        "userid": user_id,
        "role": "admin" if admin else "user",
        "selection_docs_state": {},
        "uploaded_files": [],
        "chat_history": []
    }

    # Check if user already exists
    existing_user = fetch_user(auth_filename, username, verbose=verbose)
    if existing_user and username in existing_user:
        print(f"Error: User '{username}' already exists in {auth_filename}")
        return False

    # Create the user
    try:
        upsert_user(auth_filename, username, user_details, verbose=verbose)
        print(f"Successfully created user '{username}' with role '{user_details['role']}'")
        print(f"User ID: {user_id}")
        print(f"Auth file: {os.path.abspath(auth_filename)}")
        return True
    except Exception as e:
        print(f"Error creating user: {e}")
        return False


def list_users(auth_filename="auth.db", verbose=False):
    """List all users in the auth database."""
    if not os.path.exists(auth_filename):
        print(f"Auth file not found: {auth_filename}")
        return

    conn = sqlite3.connect(auth_filename)
    cursor = conn.cursor()

    try:
        cursor.execute("SELECT username, data FROM Users")
        users = cursor.fetchall()

        if not users:
            print("No users found in auth database.")
            return

        print(f"\nUsers in {auth_filename}:")
        print("-" * 60)

        for username, data_json in users:
            try:
                data = json.loads(data_json)
                role = data.get('role', 'unknown')
                userid = data.get('userid', 'N/A')
                print(f"  Username: {username}")
                print(f"  Role: {role}")
                print(f"  User ID: {userid}")
                print("-" * 60)
            except json.JSONDecodeError:
                print(f"  Username: {username} (invalid data)")
                print("-" * 60)
    finally:
        conn.close()


def delete_user(username, auth_filename="auth.db", verbose=False):
    """Delete a user from the auth database."""
    if not os.path.exists(auth_filename):
        print(f"Auth file not found: {auth_filename}")
        return False

    # Check if user exists
    existing_user = fetch_user(auth_filename, username, verbose=verbose)
    if not existing_user or username not in existing_user:
        print(f"Error: User '{username}' not found in {auth_filename}")
        return False

    conn = sqlite3.connect(auth_filename)
    cursor = conn.cursor()

    try:
        cursor.execute("DELETE FROM Users WHERE username = ?", (username,))
        conn.commit()
        print(f"Successfully deleted user '{username}'")
        return True
    except Exception as e:
        print(f"Error deleting user: {e}")
        return False
    finally:
        conn.close()


def main():
    parser = argparse.ArgumentParser(
        description="Create, list, or delete h2oGPT user accounts",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Create a regular user
  python scripts/create_user.py --username john --password secret123

  # Create an admin user
  python scripts/create_user.py --username admin --password admin123 --admin

  # Use custom auth file
  python scripts/create_user.py --username jane --password pass456 --auth-file /path/to/auth.db

  # List all users
  python scripts/create_user.py --list

  # Delete a user
  python scripts/create_user.py --delete --username john
        """
    )

    parser.add_argument("--username", "-u", help="Username for the new account")
    parser.add_argument("--password", "-p", help="Password for the new account")
    parser.add_argument("--auth-file", default="auth.db",
                       help="Path to auth database file (default: auth.db)")
    parser.add_argument("--admin", action="store_true",
                       help="Give the user admin privileges")
    parser.add_argument("--list", action="store_true",
                       help="List all users in the auth database")
    parser.add_argument("--delete", action="store_true",
                       help="Delete the specified user")
    parser.add_argument("--verbose", "-v", action="store_true",
                       help="Enable verbose output")

    args = parser.parse_args()

    # Check if auth file exists, if not create it
    auth_file = args.auth_file
    if not os.path.exists(auth_file):
        if args.verbose:
            print(f"Auth file not found, will create: {auth_file}")
        create_table(auth_file)

    # List users
    if args.list:
        list_users(auth_file, args.verbose)
        return

    # Delete user
    if args.delete:
        if not args.username:
            print("Error: --username is required for deletion")
            sys.exit(1)
        success = delete_user(args.username, auth_file, args.verbose)
        sys.exit(0 if success else 1)

    # Create user
    if not args.username or not args.password:
        print("Error: Both --username and --password are required for creating a user")
        parser.print_help()
        sys.exit(1)

    # Verify admin pass if set
    admin_pass = os.getenv("ADMIN_PASS")
    if admin_pass:
        import getpass
        entered_pass = getpass.getpass("Enter admin password: ")
        if entered_pass != admin_pass:
            print("Error: Incorrect admin password")
            sys.exit(1)

    # Create the user
    success = create_user_account(
        args.username,
        args.password,
        auth_file,
        args.admin,
        args.verbose
    )

    sys.exit(0 if success else 1)


if __name__ == "__main__":
    main()