#!/bin/bash
# h2oGPT User Account Creation Script
# This script creates user accounts for h2oGPT authentication system

set -e

# Configuration
AUTH_FILE="${AUTH_FILE:-auth.db}"
ADMIN_PASS="${ADMIN_PASS:-}"

# Function to print usage
usage() {
    echo "Usage: $0 --username USERNAME --password PASSWORD [--auth-file AUTH_FILE] [--admin] [--delete] [--list]"
    echo ""
    echo "Options:"
    echo "  --username USERNAME    Username for the account"
    echo "  --password PASSWORD    Password for the account"
    echo "  --auth-file FILE       Auth file path (.db or .json). Default: auth.db"
    echo "  --admin                Give the user admin privileges"
    echo "  --delete USERNAME      Delete the specified user"
    echo "  --list                 List all users in the auth file"
    echo "  --verbose              Enable verbose output"
    echo ""
    echo "Environment Variables:"
    echo "  ADMIN_PASS             Admin password for authentication (optional)"
    echo "  AUTH_FILE              Default auth file path (default: auth.db)"
    exit 1
}

# Parse arguments
USERNAME=""
PASSWORD=""
ADMIN=""
DELETE=""
LIST=""
VERBOSE=""

while [[ $# -gt 0 ]]; do
    case $1 in
        --username)
            USERNAME="$2"
            shift 2
            ;;
        --password)
            PASSWORD="$2"
            shift 2
            ;;
        --auth-file)
            AUTH_FILE="$2"
            shift 2
            ;;
        --admin)
            ADMIN="1"
            shift
            ;;
        --delete)
            DELETE="$2"
            shift 2
            ;;
        --list)
            LIST="1"
            shift
            ;;
        --verbose)
            VERBOSE="1"
            shift
            ;;
        *)
            echo "Unknown option: $1"
            usage
            ;;
    esac
done

# List users
if [[ "$LIST" == "1" ]]; then
    if [[ ! -f "$AUTH_FILE" ]]; then
        echo "Auth file not found: $AUTH_FILE"
        exit 1
    fi
    
    if [[ "$AUTH_FILE" == *.db ]]; then
        echo "Users in $AUTH_FILE:"
        sqlite3 "$AUTH_FILE" "SELECT username FROM Users;" | while read user; do
            echo "  - $user"
        done
    elif [[ "$AUTH_FILE" == *.json ]]; then
        echo "Users in $AUTH_FILE:"
        python3 -c "import json; data=json.load(open('$AUTH_FILE')); [print(f'  - {u}') for u in data.keys()]"
    fi
    exit 0
fi

# Delete user
if [[ -n "$DELETE" ]]; then
    if [[ ! -f "$AUTH_FILE" ]]; then
        echo "Auth file not found: $AUTH_FILE"
        exit 1
    fi
    
    if [[ "$AUTH_FILE" == *.db ]]; then
        sqlite3 "$AUTH_FILE" "DELETE FROM Users WHERE username='$DELETE';"
    elif [[ "$AUTH_FILE" == *.json ]]; then
        python3 -c "import json; data=json.load(open('$AUTH_FILE')); data.pop('$DELETE', None); json.dump(data, open('$AUTH_FILE', 'w'))"
    fi
    echo "User '$DELETE' deleted from $AUTH_FILE"
    exit 0
fi

# Create user
if [[ -z "$USERNAME" ]] || [[ -z "$PASSWORD" ]]; then
    echo "Error: Both --username and --password are required"
    usage
fi

# Verify admin password if set
if [[ -n "$ADMIN_PASS" ]]; then
    read -s -p "Enter admin password: " entered_pass
    echo
    if [[ "$entered_pass" != "$ADMIN_PASS" ]]; then
        echo "Error: Incorrect admin password"
        exit 1
    fi
fi

# Use Python script to create user
SCRIPT_DIR="$(dirname "$0")"
if [[ -f "$SCRIPT_DIR/scripts/create_user.py" ]]; then
    ARGS="--username $USERNAME --password $PASSWORD --auth-file $AUTH_FILE"
    [[ -n "$ADMIN" ]] && ARGS="$ARGS --admin"
    [[ -n "$VERBOSE" ]] && ARGS="$ARGS --verbose"
    python3 "$SCRIPT_DIR/scripts/create_user.py" $ARGS
elif [[ -f "$SCRIPT_DIR/create_user_account.py" ]]; then
    ARGS="--username $USERNAME --password $PASSWORD --auth-file $AUTH_FILE"
    [[ -n "$VERBOSE" ]] && ARGS="$ARGS --verbose"
    python3 "$SCRIPT_DIR/create_user_account.py" $ARGS
else
    echo "Error: User creation script not found"
    exit 1
fi
