#!/usr/bin/env python3
"""
h2oGPT User Account Creation Script

This script creates user accounts for h2oGPT authentication system.
Users can authenticate via:
1. Direct username/password pairs (--auth parameter)
2. SQLite database file (auth.db)
3. JSON file (auth.json)

Usage:
    python create_user_account.py --username testuser --password testpass [--auth-file auth.db]
    python create_user_account.py --username admin --password admin123 --auth-file auth.json
"""

import argparse
import json
import os
import sqlite3
import uuid
import sys
import shutil
from datetime import datetime


def create_auth_db(db_filename, username, password, verbose=False):
    """
    Create or update user in SQLite database
    """
    if not os.path.exists(db_filename):
        # Create new database
        conn = sqlite3.connect(db_filename)
        cursor = conn.cursor()
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS Users (
            username VARCHAR(255) PRIMARY KEY,
            data TEXT
        );
        """)
        conn.commit()
        conn.close()
        if verbose:
            print(f"Created new database: {db_filename}")

    # Insert or update user
    conn = sqlite3.connect(db_filename)
    cursor = conn.cursor()

    user_data = {
        'password': password,
        'userid': str(uuid.uuid4()),
        'updated': datetime.now().isoformat()
    }

    data_string = json.dumps(user_data)

    sql_command = """
    INSERT INTO Users (username, data)
    VALUES (?, ?)
    ON CONFLICT(username)
    DO UPDATE SET data = excluded.data;
    """

    cursor.execute(sql_command, (username, data_string))
    conn.commit()
    conn.close()

    if verbose:
        print(f"User '{username}' created/updated in {db_filename}")


def create_auth_json(json_filename, username, password, verbose=False):
    """
    Create or update user in JSON file
    """
    auth_dict = {}

    if os.path.exists(json_filename):
        with open(json_filename, 'rt') as f:
            try:
                auth_dict = json.load(f)
            except json.JSONDecodeError:
                if verbose:
                    print(f"Warning: {json_filename} is corrupted, creating new file")
                auth_dict = {}

    auth_dict[username] = {
        'password': password,
        'userid': str(uuid.uuid4()),
        'updated': datetime.now().isoformat()
    }

    with open(json_filename, 'wt') as f:
        json.dump(auth_dict, f, indent=2)

    if verbose:
        print(f"User '{username}' created/updated in {json_filename}")


def list_users(auth_filename, verbose=False):
    """
    List all users in auth file
    """
    if auth_filename.endswith('.db'):
        if not os.path.exists(auth_filename):
            print(f"Database {auth_filename} does not exist")
            return

        conn = sqlite3.connect(auth_filename)
        cursor = conn.cursor()
        cursor.execute("SELECT username FROM Users")
        users = [row[0] for row in cursor.fetchall()]
        conn.close()

        print(f"Users in {auth_filename}:")
        for user in users:
            print(f"  - {user}")
    elif auth_filename.endswith('.json'):
        if not os.path.exists(auth_filename):
            print(f"JSON file {auth_filename} does not exist")
            return

        with open(auth_filename, 'rt') as f:
            auth_dict = json.load(f)

        print(f"Users in {auth_filename}:")
        for user in auth_dict.keys():
            print(f"  - {user}")
    else:
        print(f"Unknown file format: {auth_filename}")


def delete_user(auth_filename, username, verbose=False):
    """
    Delete user from auth file
    """
    if auth_filename.endswith('.db'):
        if not os.path.exists(auth_filename):
            print(f"Database {auth_filename} does not exist")
            return

        conn = sqlite3.connect(auth_filename)
        cursor = conn.cursor()
        cursor.execute("DELETE FROM Users WHERE username = ?", (username,))
        conn.commit()
        conn.close()

        if verbose:
            print(f"User '{username}' deleted from {auth_filename}")
    elif auth_filename.endswith('.json'):
        if not os.path.exists(auth_filename):
            print(f"JSON file {auth_filename} does not exist")
            return

        with open(auth_filename, 'rt') as f:
            auth_dict = json.load(f)

        if username in auth_dict:
            del auth_dict[username]
            with open(auth_filename, 'wt') as f:
                json.dump(auth_dict, f, indent=2)
            if verbose:
                print(f"User '{username}' deleted from {auth_filename}")
        else:
            print(f"User '{username}' not found in {auth_filename}")


def main():
    parser = argparse.ArgumentParser(description='Create and manage h2oGPT user accounts')
    parser.add_argument('--username', type=str, help='Username for the account')
    parser.add_argument('--password', type=str, help='Password for the account')
    parser.add_argument('--auth-file', type=str, default='auth.db',
                        help='Auth file path (.db or .json). Default: auth.db')
    parser.add_argument('--list', action='store_true',
                        help='List all users in the auth file')
    parser.add_argument('--delete', type=str, metavar='USERNAME',
                        help='Delete specified user')
    parser.add_argument('--verbose', action='store_true',
                        help='Verbose output')

    args = parser.parse_args()

    # Handle list users
    if args.list:
        list_users(args.auth_file, args.verbose)
        return

    # Handle delete user
    if args.delete:
        delete_user(args.auth_file, args.delete, args.verbose)
        return

    # Create or update user
    if not args.username or not args.password:
        parser.error("Username and password are required for creating/updating users")

    if not args.auth_file:
        parser.error("Auth file path is required")

    # Ensure auth file has proper extension
    if not args.auth_file.endswith(('.db', '.json')):
        print("Warning: Auth file should have .db or .json extension")
        if not args.auth_file.endswith('.db'):
            args.auth_file += '.db'

    if args.verbose:
        print(f"Creating user '{args.username}' in {args.auth_file}")

    if args.auth_file.endswith('.db'):
        create_auth_db(args.auth_file, args.username, args.password, args.verbose)
    elif args.auth_file.endswith('.json'):
        create_auth_json(args.auth_file, args.username, args.password, args.verbose)
    else:
        print(f"Error: Unsupported file format: {args.auth_file}")
        sys.exit(1)

    print(f"User account created successfully")
    print(f"\nTo use this auth file with h2oGPT, run:")
    print(f"  python generate.py --auth={args.auth_file}")
    print(f"\nOr with Gradio:")
    print(f"  python generate.py --auth={args.auth_file} --gradio=True")


if __name__ == '__main__':
    main()