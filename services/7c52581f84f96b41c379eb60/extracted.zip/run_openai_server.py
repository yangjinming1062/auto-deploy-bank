#!/usr/bin/env python3
import sys
import os
import multiprocessing
import time

# Ensure workspace is in the path
sys.path.insert(0, '/workspace')
sys.path.insert(0, '/workspace/openai_server')

def run_gradio():
    """Run the Gradio server"""
    os.system('python generate.py --base_model=h2oai/h2ogpt-4096-llama2-7b-chat --use_safetensors=True --prompt_type=llama2 --save_dir=/workspace/save/ --use_gpu_id=False --score_model=None --max_max_new_tokens=2048 --max_new_tokens=1024 --gradio=True --share=False --server_name=0.0.0.0 --server_port=7860')

if __name__ == '__main__':
    # Start Gradio server in a separate process
    print("Starting Gradio server in background...", flush=True)
    gradio_process = multiprocessing.Process(target=run_gradio, daemon=True)
    gradio_process.start()

    print("Waiting for Gradio server to initialize...", flush=True)
    time.sleep(45)  # Give Gradio time to start and load the model

    print("Starting OpenAI server on port 5000...", flush=True)

    # Import the FastAPI app
    from openai_server.server import app

    # Run the OpenAI server
    import uvicorn
    uvicorn.run(app, host='0.0.0.0', port=5000, log_level='info')