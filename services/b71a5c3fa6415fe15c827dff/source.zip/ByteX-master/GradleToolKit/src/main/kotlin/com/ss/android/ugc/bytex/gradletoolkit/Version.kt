package com.ss.android.ugc.bytex.gradletoolkit

import com.android.builder.model.Version
import com.android.repository.Revision

internal val ANDROID_GRADLE_PLUGIN_VERSION = Revision.parseRevision(Version.ANDROID_GRADLE_PLUGIN_VERSION)