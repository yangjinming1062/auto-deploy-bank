package com.ss.android.ugc.bytex.access_inline.visitor;

import com.ss.android.ugc.bytex.common.graph.FieldEntity;
import com.ss.android.ugc.bytex.common.graph.RefMemberEntity;

public class RefFieldEntity extends RefMemberEntity<FieldEntity> {

    public RefFieldEntity(FieldEntity entity) {
        super(entity);
    }
}
