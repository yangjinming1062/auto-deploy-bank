package com.ss.android.ugc.bytex.access_inline.visitor;

import com.ss.android.ugc.bytex.common.graph.MethodEntity;
import com.ss.android.ugc.bytex.common.graph.RefMemberEntity;

public class RefMethodEntity extends RefMemberEntity<MethodEntity> {
    public RefMethodEntity(MethodEntity entity) {
        super(entity);
    }
}
