package com.ss.android.ugc.bytex.common.exception;

/**
 * Created by tanlehua on 2019/4/22.
 */
public class DuplicateClassException extends ByteXException {
    public DuplicateClassException(String msg) {
        super(msg);
    }
}
