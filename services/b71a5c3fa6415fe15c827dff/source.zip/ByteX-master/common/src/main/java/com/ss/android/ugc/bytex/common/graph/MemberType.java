package com.ss.android.ugc.bytex.common.graph;

public enum MemberType {
    METHOD, FIELD
}
