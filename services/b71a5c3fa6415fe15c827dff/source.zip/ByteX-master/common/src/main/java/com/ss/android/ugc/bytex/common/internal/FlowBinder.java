package com.ss.android.ugc.bytex.common.internal;

import com.ss.android.ugc.bytex.common.flow.TransformFlow;

public interface FlowBinder {
    TransformFlow bind(final TransformFlowerManager manager);
}
