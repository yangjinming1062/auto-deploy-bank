package com.ss.android.ugc.bytex.common.exception;

/**
 * Created by tanlehua on 2019/4/14.
 */
public class ByteXException extends RuntimeException {
    public ByteXException(String msg) {
        super(msg);
    }
}
