package com.ss.android.ugc.bytex.common.flow.main;

public enum Process {
    TRAVERSE_INCREMENTAL,
    TRAVERSE,
    TRAVERSE_ANDROID,
    TRANSFORM
}
