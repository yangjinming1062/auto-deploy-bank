package analyse.util;

public class LogUtil {
    public static void log(String msg) {
//        System.out.println("CoverageLog : " + msg);
    }
}
