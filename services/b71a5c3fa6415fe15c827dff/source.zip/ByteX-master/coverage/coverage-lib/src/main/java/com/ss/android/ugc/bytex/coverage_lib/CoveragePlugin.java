package com.ss.android.ugc.bytex.coverage_lib;


/**
 * Created by jiangzilai on 2019-08-27.
 */
public interface CoveragePlugin {
    void addData(int data);
}
