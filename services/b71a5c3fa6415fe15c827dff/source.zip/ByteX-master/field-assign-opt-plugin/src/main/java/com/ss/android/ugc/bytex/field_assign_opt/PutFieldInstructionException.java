package com.ss.android.ugc.bytex.field_assign_opt;

public class PutFieldInstructionException extends RuntimeException {
    public PutFieldInstructionException(String msg) {
        super(msg);
    }
}
