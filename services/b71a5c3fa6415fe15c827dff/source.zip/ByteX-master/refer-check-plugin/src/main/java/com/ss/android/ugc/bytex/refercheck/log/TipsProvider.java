package com.ss.android.ugc.bytex.refercheck.log;

public interface TipsProvider {
    String provideFilePathInfo(String fileName);
}
