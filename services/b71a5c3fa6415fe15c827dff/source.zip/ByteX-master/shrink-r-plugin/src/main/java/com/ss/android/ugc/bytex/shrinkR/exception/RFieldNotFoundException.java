package com.ss.android.ugc.bytex.shrinkR.exception;

/**
 * Created by tanlehua on 2019/4/18.
 */
public class RFieldNotFoundException extends RuntimeException {
}
