package com.ss.android.ugc.bytex.shrinkR.res_check;

public interface Substance {
    String getName();

    boolean canReach();

    void refer();

    void define(String path);

    String toString();
}
