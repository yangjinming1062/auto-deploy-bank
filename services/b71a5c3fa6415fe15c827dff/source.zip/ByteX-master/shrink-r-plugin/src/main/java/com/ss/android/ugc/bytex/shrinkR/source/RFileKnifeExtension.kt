package com.ss.android.ugc.bytex.shrinkR.source

/**
 * Created by yangzhiqian on 2020-02-12<br/>
 */
open class RFileKnifeExtension {
    var limitSize = LIMITS
    var assignType = "value"
    var verifyParse = false
    var packageNames = HashSet<String>()
    var whiteList = HashSet<String>()
}