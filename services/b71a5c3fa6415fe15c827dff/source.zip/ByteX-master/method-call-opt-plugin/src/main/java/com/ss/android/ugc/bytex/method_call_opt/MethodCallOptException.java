package com.ss.android.ugc.bytex.method_call_opt;

/**
 * Created by yangzhiqian on 2019/3/16<br/>
 */
public class MethodCallOptException extends Exception {
    public MethodCallOptException(String message) {
        super(message);
    }
}
