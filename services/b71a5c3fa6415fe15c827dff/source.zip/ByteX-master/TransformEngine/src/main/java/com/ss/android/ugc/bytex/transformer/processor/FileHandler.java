package com.ss.android.ugc.bytex.transformer.processor;

import com.ss.android.ugc.bytex.transformer.cache.FileData;

/**
 * Created by tlh on 2018/8/22.
 */

public interface FileHandler {
    void handle(FileData fileData);
}
