package com.ss.android.ugc.bytex.example.getter_setter.parent;

/**
 * Created by yangzhiqian on 2020-04-07<br/>
 * Desc:
 */
public abstract class Parent {
    protected String mTableName = "";

    public void setmTableName(String name) {
        this.mTableName = name;
    }
}
