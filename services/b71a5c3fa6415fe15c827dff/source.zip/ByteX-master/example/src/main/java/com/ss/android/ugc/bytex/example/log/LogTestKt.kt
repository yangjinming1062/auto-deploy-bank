package com.ss.android.ugc.bytex.example.log

import android.view.View

class LogTestKt{
     fun exceptionTest(e: Exception?) {
        e?.printStackTrace()
    }
}