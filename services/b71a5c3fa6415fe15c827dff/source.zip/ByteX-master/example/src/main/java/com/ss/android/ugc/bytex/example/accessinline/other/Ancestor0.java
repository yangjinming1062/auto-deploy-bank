package com.ss.android.ugc.bytex.example.accessinline.other;

public class Ancestor0 {
    public static final String TAG = Ancestor0.class.getSimpleName();

    protected String call() {
        return TAG;
    }
}
