package com.ss.android.ugc.bytex.example;

public @interface CalledByNative {
}