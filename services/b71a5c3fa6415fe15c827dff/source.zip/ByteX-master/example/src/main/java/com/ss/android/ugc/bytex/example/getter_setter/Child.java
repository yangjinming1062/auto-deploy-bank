package com.ss.android.ugc.bytex.example.getter_setter;

import com.ss.android.ugc.bytex.example.getter_setter.parent.Parent;

/**
 * Created by yangzhiqian on 2020-04-07<br/>
 * Desc:
 */
public class Child extends Parent {
    public String getName() {
        return this.mTableName;
    }

    public void setmTableName(String name) {
    }
}
