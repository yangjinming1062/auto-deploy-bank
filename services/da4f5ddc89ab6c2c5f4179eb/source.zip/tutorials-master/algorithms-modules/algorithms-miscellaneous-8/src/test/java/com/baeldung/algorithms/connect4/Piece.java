package com.baeldung.algorithms.connect4;

public enum Piece {
    PLAYER_1,
    PLAYER_2
}
