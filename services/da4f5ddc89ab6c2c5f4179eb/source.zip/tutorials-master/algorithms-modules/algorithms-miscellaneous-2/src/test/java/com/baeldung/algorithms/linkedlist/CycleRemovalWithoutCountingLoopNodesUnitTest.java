package com.baeldung.algorithms.linkedlist;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;


class CycleRemovalWithoutCountingLoopNodesUnitTest extends CycleDetectionTestBase {

    @ParameterizedTest
    @MethodSource("getLists")
    void givenList_ifLoopExists_thenDetectAndRemoveLoop(Node<Integer> head, boolean cycleExists) {
        assertEquals(cycleExists, CycleRemovalWithoutCountingLoopNodes.detectAndRemoveCycle(head));
        assertFalse(CycleDetectionByFastAndSlowIterators.detectCycle(head).cycleExists);
    }
}