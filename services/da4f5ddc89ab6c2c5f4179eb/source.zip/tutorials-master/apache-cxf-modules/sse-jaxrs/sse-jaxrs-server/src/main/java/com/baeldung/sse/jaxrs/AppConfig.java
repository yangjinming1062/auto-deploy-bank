package com.baeldung.sse.jaxrs;

import jakarta.ws.rs.ApplicationPath;
import jakarta.ws.rs.core.Application;

@ApplicationPath("sse")
public class AppConfig extends Application {
}
