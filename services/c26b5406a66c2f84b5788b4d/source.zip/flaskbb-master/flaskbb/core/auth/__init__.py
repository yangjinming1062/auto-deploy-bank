"""
flaskbb.core.auth
~~~~~~~~~~~~~~~~~

:copyright: 2014-2018 (c) the FlaskBB Team.
:license: BSD, see LICENSE for more details
"""
