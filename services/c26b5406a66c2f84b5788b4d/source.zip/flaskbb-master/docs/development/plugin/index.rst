.. _plugin_development:

Plugin Development
==================

.. toctree::
   :maxdepth: 1

   developing
   hooks
   manager
