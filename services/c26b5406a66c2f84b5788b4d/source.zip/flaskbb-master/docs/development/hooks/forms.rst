.. _hooks_form:

.. currentmodule:: flaskbb.plugins.spec

FlaskBB Form Hooks
==================

.. autofunction:: flaskbb_form_post
.. autofunction:: flaskbb_form_post_save
.. autofunction:: flaskbb_form_topic
.. autofunction:: flaskbb_form_topic_save
.. autofunction:: flaskbb_form_registration

