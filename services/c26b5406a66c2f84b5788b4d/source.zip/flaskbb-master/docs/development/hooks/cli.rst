.. _cli_hooks:

.. currentmodule:: flaskbb.plugins.spec

FlaskBB CLI Hooks
=================

These hooks are only invoked when using the ``flaskbb``
CLI.

.. autofunction:: flaskbb_cli
.. autofunction:: flaskbb_shell_context

