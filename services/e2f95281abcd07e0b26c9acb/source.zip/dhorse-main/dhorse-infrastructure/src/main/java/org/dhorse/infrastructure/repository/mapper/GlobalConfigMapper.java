package org.dhorse.infrastructure.repository.mapper;

import org.dhorse.infrastructure.repository.po.GlobalConfigPO;

public interface GlobalConfigMapper extends CustomizedBaseMapper<GlobalConfigPO> {
	
}