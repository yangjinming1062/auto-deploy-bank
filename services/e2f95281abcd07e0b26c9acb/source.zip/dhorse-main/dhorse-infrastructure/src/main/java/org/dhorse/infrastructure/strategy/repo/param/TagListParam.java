package org.dhorse.infrastructure.strategy.repo.param;

public class TagListParam {

	private String appIdOrPath;

	private String tagName;

	public String getAppIdOrPath() {
		return appIdOrPath;
	}

	public void setAppIdOrPath(String appIdOrPath) {
		this.appIdOrPath = appIdOrPath;
	}

	public String getTagName() {
		return tagName;
	}

	public void setTagName(String tagName) {
		this.tagName = tagName;
	}

}
