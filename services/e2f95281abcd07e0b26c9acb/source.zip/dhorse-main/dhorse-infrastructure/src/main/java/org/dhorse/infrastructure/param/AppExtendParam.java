package org.dhorse.infrastructure.param;

import java.io.Serializable;

public class AppExtendParam implements Serializable{

	private static final long serialVersionUID = 1L;

}