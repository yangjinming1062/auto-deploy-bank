package org.dhorse.infrastructure.repository.mapper;

import org.dhorse.infrastructure.repository.po.DeploymentVersionPO;

public interface DeploymentVersionMapper extends CustomizedBaseMapper<DeploymentVersionPO> {
	
}