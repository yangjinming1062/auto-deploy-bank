package org.dhorse.infrastructure.repository.mapper;

import org.dhorse.infrastructure.repository.po.MetricsPO;

public interface MetricsMapper extends CustomizedBaseMapper<MetricsPO> {
	
}