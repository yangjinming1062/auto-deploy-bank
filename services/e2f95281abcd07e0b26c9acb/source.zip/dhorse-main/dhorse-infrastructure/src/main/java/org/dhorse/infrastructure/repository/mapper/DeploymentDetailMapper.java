package org.dhorse.infrastructure.repository.mapper;

import org.dhorse.infrastructure.repository.po.DeploymentDetailPO;

public interface DeploymentDetailMapper extends CustomizedBaseMapper<DeploymentDetailPO> {
	
}