package org.dhorse.infrastructure.repository.mapper;

import org.dhorse.infrastructure.repository.po.AffinityTolerationPO;

public interface AffinityTolerationMapper extends CustomizedBaseMapper<AffinityTolerationPO> {
	
}