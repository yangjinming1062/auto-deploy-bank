package org.dhorse.infrastructure.repository.mapper;

import org.dhorse.infrastructure.repository.po.LogRecordPO;

public interface LogRecordMapper extends CustomizedBaseMapper<LogRecordPO> {
	
}