package org.dhorse.infrastructure.repository.po;

public abstract class AppExtendPO extends BaseAppPO {

	private static final long serialVersionUID = 1L;

}