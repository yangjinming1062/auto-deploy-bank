package org.dhorse.infrastructure.repository.mapper;

import org.dhorse.infrastructure.repository.po.ClusterPO;

public interface ClusterMapper extends CustomizedBaseMapper<ClusterPO> {
	
}