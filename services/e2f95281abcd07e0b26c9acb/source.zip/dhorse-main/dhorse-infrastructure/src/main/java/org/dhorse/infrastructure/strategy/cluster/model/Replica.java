package org.dhorse.infrastructure.strategy.cluster.model;

public class Replica {

	/**
	 * 镜像名称
	 */
	private String imageName;

	public String getImageName() {
		return imageName;
	}

	public void setImageName(String imageName) {
		this.imageName = imageName;
	}

}
