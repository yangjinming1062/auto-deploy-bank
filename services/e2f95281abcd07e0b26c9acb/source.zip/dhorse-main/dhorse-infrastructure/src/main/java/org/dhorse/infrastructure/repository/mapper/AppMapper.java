package org.dhorse.infrastructure.repository.mapper;

import org.dhorse.infrastructure.repository.po.AppPO;

public interface AppMapper extends CustomizedBaseMapper<AppPO> {
	
}