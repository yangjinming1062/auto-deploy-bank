package org.dhorse.infrastructure.repository.mapper;

import org.dhorse.infrastructure.repository.po.EnvExtPO;

public interface EnvExtMapper extends CustomizedBaseMapper<EnvExtPO> {
	
}