package org.dhorse.api.param.app.branch;

/**
 * 删除应用分支
 * 
 * @author Dahai
 */
public class AppBranchDeletionParam extends AppBranchCreationParam {

	private static final long serialVersionUID = 1L;

}