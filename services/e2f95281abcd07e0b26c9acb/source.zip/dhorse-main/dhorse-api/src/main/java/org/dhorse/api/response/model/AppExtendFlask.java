package org.dhorse.api.response.model;

public class AppExtendFlask extends AppExtendPython {

	private static final long serialVersionUID = 1L;
	
}