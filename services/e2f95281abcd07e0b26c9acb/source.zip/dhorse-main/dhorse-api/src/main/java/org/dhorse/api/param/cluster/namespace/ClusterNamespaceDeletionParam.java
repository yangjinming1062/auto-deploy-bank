package org.dhorse.api.param.cluster.namespace;

/**
 * 删除集群命名空间
 * 
 * @author Dahai 2021-11-24
 */
public class ClusterNamespaceDeletionParam extends ClusterNamespaceCreationParam {

	private static final long serialVersionUID = 1L;

}