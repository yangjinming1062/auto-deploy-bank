package org.dhorse.api.param.app.tag;

/**
 * 删除应用标签
 * 
 * @author 无双
 */
public class AppTagDeletionParam extends AppTagCreationParam {

	private static final long serialVersionUID = 1L;

}