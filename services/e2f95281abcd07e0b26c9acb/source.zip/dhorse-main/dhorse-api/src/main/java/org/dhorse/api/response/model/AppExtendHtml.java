package org.dhorse.api.response.model;

import org.dhorse.api.response.model.App.AppExtend;

public class AppExtendHtml extends AppExtend {

	private static final long serialVersionUID = 1L;

}