package org.dhorse.api.response;

import java.io.Serializable;

public interface Response extends Serializable {

}
