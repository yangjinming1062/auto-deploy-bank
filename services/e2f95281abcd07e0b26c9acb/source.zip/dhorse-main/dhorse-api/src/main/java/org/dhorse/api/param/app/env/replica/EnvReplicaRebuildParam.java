package org.dhorse.api.param.app.env.replica;

/**
 * 重建副本参数模型
 * 
 * @author Dahai
 */
public class EnvReplicaRebuildParam extends EnvReplicaParam {

	private static final long serialVersionUID = 1L;

}