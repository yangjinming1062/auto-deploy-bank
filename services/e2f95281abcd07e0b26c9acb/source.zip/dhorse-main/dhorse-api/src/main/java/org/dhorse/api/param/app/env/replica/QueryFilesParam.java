package org.dhorse.api.param.app.env.replica;

/**
 * 查询文件参数模型
 * 
 * @author Dahai
 */
public class QueryFilesParam extends EnvReplicaParam {

	private static final long serialVersionUID = 1L;

}