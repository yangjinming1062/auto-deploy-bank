package org.dhorse.api.param.app.branch.deploy;

/**
 * 删除分支部署记录
 * 
 * @author Dahai
 */
public class DeploymentDetailDeletionParam extends RollbackApprovementParam {

	private static final long serialVersionUID = 1L;

}