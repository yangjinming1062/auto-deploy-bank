package org.dhorse.api.response.model;

public class AppExtendDjango extends AppExtendPython {

	private static final long serialVersionUID = 1L;

}