package org.dhorse.api.param.cluster;

/**
 * 删除节点的参数模型
 * 
 * @author Dahai 2023-11-22
 */
public class NodeDeletionParam extends NodeCreationParam {

	private static final long serialVersionUID = 1L;

}