package org.dhorse.api.param.app.branch.deploy;

/**
 * 提交回滚的参数模型
 * 
 * @author Dahai
 */
public class RollbackApplicationParam extends DeploymentApprovementParam {

	private static final long serialVersionUID = 1L;

}