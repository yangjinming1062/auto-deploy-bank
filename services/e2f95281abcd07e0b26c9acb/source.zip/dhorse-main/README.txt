本软件遵守Apache开源许可协议2.0，
详情见：http://www.apache.org/licenses/LICENSE-2.0