package com.reajason.javaweb.integration.memshell.tomcat;

import com.reajason.javaweb.integration.AbstractContainerTest;
import com.reajason.javaweb.integration.ContainerTestConfig;
import com.reajason.javaweb.memshell.ShellType;
import com.reajason.javaweb.packer.Packers;
import net.bytebuddy.jar.asm.Opcodes;
import org.testcontainers.containers.GenericContainer;
import org.testcontainers.containers.Network;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;

import java.util.List;

/**
 * @author ReaJason
 * @since 2024/12/4
 */
@Testcontainers
public class Tomcat7ContainerTest extends AbstractContainerTest {
    private static final ContainerTestConfig CONFIG = ContainerTestConfig.tomcat("tomcat:7.0.85-jre7")
            .targetJdkVersion(Opcodes.V1_7)
            .probeTargetJdkVersion(Opcodes.V1_6)
            .supportedShellTypes(List.of(
                    ShellType.FILTER,
                    ShellType.SERVLET,
                    ShellType.LISTENER,
                    ShellType.VALVE,
                    ShellType.PROXY_VALVE,
                    ShellType.AGENT_FILTER_CHAIN,
                    ShellType.CATALINA_AGENT_CONTEXT_VALVE
            ))
            .testPackers(List.of(Packers.JSP, Packers.AgentJarWithJREAttacher))
            .probeShellTypes(List.of(
                    ShellType.FILTER,
                    ShellType.SERVLET,
                    ShellType.LISTENER,
                    ShellType.VALVE,
                    ShellType.PROXY_VALVE
            ))
            .build();

    static Network network = newNetwork();
    @Container
    public static final GenericContainer<?> python = buildPythonContainer(network);

    @Container
    public static final GenericContainer<?> container = buildContainer(CONFIG, network);

    @Override
    protected ContainerTestConfig getConfig() {
        return CONFIG;
    }
}
