#!/bin/bash
pgrep -f "jetty.home" | tr -d '\n'