#!/bin/bash
pgrep -f 'WSLauncher|ws-server.jar' | tr -d '\n'