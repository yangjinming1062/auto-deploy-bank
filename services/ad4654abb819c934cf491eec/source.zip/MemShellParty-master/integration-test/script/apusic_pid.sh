#!/bin/bash
pgrep -f 'Main' | tr -d '\n'