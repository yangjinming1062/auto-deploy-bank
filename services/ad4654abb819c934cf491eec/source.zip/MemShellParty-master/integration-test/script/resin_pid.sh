#!/bin/bash
pgrep -f Resin | tr -d '\n'