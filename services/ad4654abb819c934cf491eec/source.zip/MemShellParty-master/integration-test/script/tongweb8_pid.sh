#!/bin/bash
pgrep -f tongweb-bootstrap.jar | tr -d '\n'