#!/bin/bash
pgrep -f Bootstrap | tr -d '\n'