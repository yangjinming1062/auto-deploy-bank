---
name: 内存马生成 UI Bug 上报
about: Create a report to help us improve
title: "[UI BUG] Something Wrong"
labels: bug
assignees: ''

---

### 描述

> A clear and concise description of what the bug is.

描述哪个功能不好使

### 参数截图 OR 报错截图

> If applicable, add screenshots to help explain your problem.

截图一下

### 运行环境

- 浏览器: [e.g. chrome, safari]

### 额外信息

> Add any other context about the problem here.

猜测哪里出了问题
