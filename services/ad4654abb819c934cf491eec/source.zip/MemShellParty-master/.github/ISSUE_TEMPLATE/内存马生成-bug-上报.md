---
name: 内存马生成 Bug 上报
about: Create a report to help us improve
title: "[BUG] Something Wrong"
labels: bug
assignees: ''

---

运行操作系统: [e.g. MacOS，Ubuntu，Debian，Windows]

### 生成参数

- 服务类型: [e.g. Tomcat, Jetty，SpringMVC]
- 挂载类型: [e.g. Filter，Listener]
- 功能类型: [e.g. Command，Godzilla]

### 报错截图 OR 错误代码

```java
Exception
```

### 额外信息

> Add any other context about the problem here.

某些其他可疑的点
