package com.reajason.javaweb.probe.config;

import lombok.Getter;
import lombok.experimental.SuperBuilder;

/**
 * @author ReaJason
 * @since 2025/8/5
 */
@Getter
@SuperBuilder
public class ProbeContentConfig {
}
