package org.eclipse.jetty.server;

/**
 * @author ReaJason
 * @since 2025/11/29
 */
public interface Request {
}
