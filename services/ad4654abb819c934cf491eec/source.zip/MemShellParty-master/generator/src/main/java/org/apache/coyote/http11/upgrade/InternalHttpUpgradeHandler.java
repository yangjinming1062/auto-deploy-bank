package org.apache.coyote.http11.upgrade;

/**
 * @author ReaJason
 * @since 2025/12/6
 */
public interface InternalHttpUpgradeHandler {
}
