package org.eclipse.jetty.server;

/**
 * @author ReaJason
 * @since 2025/12/2
 */
public class Connector {
}
