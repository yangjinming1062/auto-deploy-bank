package org.apache.coyote;

/**
 * @author ReaJason
 * @since 2025/12/6
 */
public interface Adapter {
}
