package com.xxl.job.core.biz.impl;

import com.xxl.job.core.biz.ExecutorBiz;

/**
 * @author ReaJason
 * @since 2025/1/21
 */
public class ExecutorBizImpl extends ExecutorBiz {
}
