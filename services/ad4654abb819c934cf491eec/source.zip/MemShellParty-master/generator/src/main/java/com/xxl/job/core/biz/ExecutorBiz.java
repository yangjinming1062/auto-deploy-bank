package com.xxl.job.core.biz;

/**
 * @author ReaJason
 * @since 2025/1/21
 */
public class ExecutorBiz {
}
