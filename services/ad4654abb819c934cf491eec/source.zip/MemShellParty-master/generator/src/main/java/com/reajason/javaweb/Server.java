package com.reajason.javaweb;

/**
 * @author ReaJason
 * @since 2025/8/11
 */
public class Server {
    public static final String Tomcat = "Tomcat";
    public static final String Jetty = "Jetty";
    public static final String Undertow = "Undertow";
    public static final String JBoss = "JBoss";
    public static final String Resin = "Resin";
    public static final String WebLogic = "WebLogic";
    public static final String WebSphere = "WebSphere";
    public static final String GlassFish = "GlassFish";
    public static final String TongWeb = "TongWeb";
    public static final String BES = "BES";
    public static final String InforSuite = "InforSuite";
    public static final String Apusic = "Apusic";
    public static final String SpringWebMvc = "SpringWebMvc";
    public static final String SpringWebFlux = "SpringWebFlux";
    public static final String XXLJOB = "XXLJOB";
    public static final String Struct2 = "Struct2";
}
