package com.reajason.javaweb.memshell;

/**
 * @author ReaJason
 * @since 2025/8/22
 */
public class ShellTool {
    public static final String Godzilla = "Godzilla";
    public static final String Behinder = "Behinder";
    public static final String Command = "Command";
    public static final String Suo5 = "Suo5";
    public static final String Suo5v2 = "Suo5v2";
    public static final String AntSword = "AntSword";
    public static final String NeoreGeorg = "NeoreGeorg";
    public static final String Proxy = "Proxy";
    public static final String Custom = "Custom";
}
