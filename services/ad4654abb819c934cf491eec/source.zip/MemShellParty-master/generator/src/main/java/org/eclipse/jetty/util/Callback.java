package org.eclipse.jetty.util;

/**
 * @author ReaJason
 * @since 2025/11/29
 */
public interface Callback {
}
