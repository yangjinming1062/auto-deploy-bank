package org.apache.tomcat.util.net;

/**
 * @author ReaJason
 * @since 2025/12/6
 */
public class SocketWrapperBase<E>  {
}
