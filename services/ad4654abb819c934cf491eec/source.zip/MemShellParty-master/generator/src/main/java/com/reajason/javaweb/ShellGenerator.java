package com.reajason.javaweb;

/**
 * @author ReaJason
 * @since 2025/5/27
 */
public interface ShellGenerator {

    byte[] getBytes();
}
