package com.reajason.javaweb.probe.payload;

/**
 * @author ReaJason
 * @since 2025/8/1
 */
public class Hello {
    @Override
    public String toString() {
        return null;
    }
}
