package com.impossibl.postgres.protocol;

public class Field {
	
	public String name;
	public int relationId;
	public short attributeIndex;
	public int typeId;
	public short typeLength;
	public int typeModId;
	public short formatCode;
	
}
