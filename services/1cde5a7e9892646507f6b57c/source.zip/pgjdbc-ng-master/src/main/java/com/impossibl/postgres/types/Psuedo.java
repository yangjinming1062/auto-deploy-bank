package com.impossibl.postgres.types;

public class Psuedo extends Type {

}
