package com.impossibl.postgres.types;

public class Enumeration extends Type {

}
