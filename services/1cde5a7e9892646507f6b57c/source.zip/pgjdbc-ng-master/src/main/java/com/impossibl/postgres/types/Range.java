package com.impossibl.postgres.types;

public class Range extends Type {

}
