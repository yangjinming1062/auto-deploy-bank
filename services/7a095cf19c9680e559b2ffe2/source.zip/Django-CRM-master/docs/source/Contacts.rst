Contacts
********

|  Contacts can be created and can be assigned to Accounts




|  **Fig** Contacts Home Page

|  The above figure shows the contacts view, this page gives details and list view of leads
|  You can filter the results by name, city, assigned user.

|  Create a new Lead using the button on right corner ``+ Add New contact``


|  **Fig** Contacts Create Page

|  **Note:** Fields having ``*`` are mandatory.

|  **Note:** To create a contacts lead is required.