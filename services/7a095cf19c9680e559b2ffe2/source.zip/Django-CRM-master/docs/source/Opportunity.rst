Opportunity
***********

|  New Opportunities can be added and can be assigned to accounts and contacts.



|  **Fig** Opportunity Home Page

|  The above figure shows the Opportunity view, this page gives details and list view of leads
|  They are two types of leads open and closed
|  You can filter the results by name, stage, account, lead source

|  Create a new Lead using the button on right corner ``+ Add New Opportunity``


|  **Fig** Opportunity Create Page

|  **Note:** Fields having ``*`` are mandatory.

|  **Note:** To create a Opportunity lead is required.