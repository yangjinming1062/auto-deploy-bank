# About

This module implements common http clients for servicecomb-service-center, servicecomb-kie and other
3rd-party services.

This module is independent on servicecomb-java-chassis, and can be used in many other projects like
Spring Cloud, Dubbo, etc.

# 关于

这个模块给 servicecomb-service-center, servicecomb-kie 以及其他第三方服务实现通用的 Http Client。

这个模块独立于 servicecomb-java-chassis， 可以用于 Spring Cloud, Dubbo 等项目。
