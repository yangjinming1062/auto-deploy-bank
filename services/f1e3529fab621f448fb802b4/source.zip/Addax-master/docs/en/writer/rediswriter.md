# Redis Writer

Redis Writer plugin is used to write data to Redis database.

## Configuration Example

This plugin provides the ability to write data to Redis database. For detailed configuration and parameters, please refer to the original Redis Writer documentation.

```json
--8<-- "jobs/rediswriter.json"
```

## Parameters

This plugin supports writing various data types to Redis with configurable connection and data format options.