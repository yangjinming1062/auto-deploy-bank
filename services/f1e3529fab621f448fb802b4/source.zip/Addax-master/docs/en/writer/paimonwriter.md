# Paimon Writer

Paimon Writer plugin implements writing data to Apache Paimon.

## Configuration Example

This plugin is used to write data to Paimon tables. For detailed configuration and parameters, please refer to the original Paimon Writer documentation.

```json
--8<-- "jobs/paimonwriter.json"
```

## Parameters

This plugin supports writing data to Paimon with configurable catalog, table, and schema options.