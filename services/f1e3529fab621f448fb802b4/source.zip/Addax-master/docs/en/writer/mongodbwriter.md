# MongoDB Writer

MongoDB Writer plugin implements writing data to MongoDB.

## Configuration Example

This plugin is used to write data to MongoDB database. For detailed configuration and parameters, please refer to the original MongoDB Writer documentation.

```json
--8<-- "jobs/mongodbwriter.json"
```

## Parameters

This plugin provides comprehensive MongoDB writing capabilities with support for various data types and connection options.