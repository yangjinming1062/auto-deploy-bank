# GreenPlum Writer

GreenPlum Writer plugin implements writing data to GreenPlum database.

## Configuration Example

This plugin is used to write data to GreenPlum database. This plugin is based on [RDBMS Writer](../rdbmswriter), so you can refer to all configuration items of RDBMS Writer.

```json
--8<-- "jobs/greenplumwriter.json"
```