# HBase11x SQL Writer

HBase11x SQL Writer plugin implements writing data to HBase 1.x via Phoenix SQL interface.

## Configuration Example

This plugin is used to write data to HBase 1.x via Phoenix. This plugin is based on [RDBMS Writer](../rdbmswriter), so you can refer to all configuration items of RDBMS Writer.

```json
--8<-- "jobs/hbase11xsqlwriter.json"
```