# HBase20x SQL Writer

HBase20x SQL Writer plugin implements writing data to HBase 2.x via Phoenix SQL interface.

## Configuration Example

This plugin is used to write data to HBase 2.x via Phoenix. This plugin is based on [RDBMS Writer](../rdbmswriter), so you can refer to all configuration items of RDBMS Writer.

```json
--8<-- "jobs/hbase20xsqlwriter.json"
```