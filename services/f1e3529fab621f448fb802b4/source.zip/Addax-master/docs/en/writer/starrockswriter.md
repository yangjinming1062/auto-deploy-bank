# StarRocks Writer

StarRocks Writer plugin implements writing data to StarRocks.

## Configuration Example

This plugin is used to write data to StarRocks database. For detailed configuration and parameters, please refer to the original StarRocks Writer documentation.

```json
--8<-- "jobs/starrockswriter.json"
```

## Parameters

This plugin supports writing data to StarRocks with Stream Load capabilities and configurable connection options.