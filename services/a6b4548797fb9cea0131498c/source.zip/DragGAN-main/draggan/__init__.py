from .utils import BASE_DIR

home = BASE_DIR