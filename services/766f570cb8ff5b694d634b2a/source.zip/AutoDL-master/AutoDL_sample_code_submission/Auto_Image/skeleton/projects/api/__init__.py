# -*- coding: utf-8 -*-
# pylint: disable=wildcard-import
from __future__ import absolute_import

from .model import Model
