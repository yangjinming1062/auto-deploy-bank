# -*- coding: utf-8 -*-
# @Date    : 2020/3/4 17:10

class EnsembleManager(object):
    def __init__(self):
        pass

    def single_model_ensemble(self):
        pass

    def multi_model_ensemble(self):
        pass


