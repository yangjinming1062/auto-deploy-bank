export { default as Video } from "./Video.svelte";
