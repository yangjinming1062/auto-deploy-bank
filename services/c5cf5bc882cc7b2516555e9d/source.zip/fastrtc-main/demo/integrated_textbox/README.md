---
title: Integrated Text Box
emoji: 📝
colorFrom: purple
colorTo: red
sdk: gradio
sdk_version: 5.31.0
app_file: app.py
pinned: false
license: mit
short_description: Talk or type to ANY LLM!
tags: [webrtc, websocket, gradio, secret|HF_TOKEN]
---

# Integrated Textbox

Talk or type to ANY LLM!


