---
title: Moonshine Live Transcription
emoji: 🌕
colorFrom: purple
colorTo: red
sdk: gradio
sdk_version: 5.17.0
app_file: app.py
pinned: false
license: mit
short_description: Real-time captions with Moonshine ONNX
tags: [webrtc, websocket, gradio, secret|TWILIO_ACCOUNT_SID, secret|TWILIO_ACCOUNT_SID, secret|TWILIO_AUTH_TOKEN]
models: [onnx-community/moonshine-base-ONNX, UsefulSensors/moonshine-base]
---

Check out the configuration reference at https://huggingface.co/docs/hub/spaces-config-reference