---
title: Qwen Phone Chat
emoji: 📞
colorFrom: pink
colorTo: green
sdk: gradio
sdk_version: 5.25.2
app_file: app.py
pinned: false
license: mit
short_description: Talk with Qwen 2.5 Omni over the Phone
---

Check out the configuration reference at https://huggingface.co/docs/hub/spaces-config-reference