---
title: Voice Text Editor
emoji: 📝
colorFrom: purple
colorTo: red
sdk: gradio
sdk_version: 5.16.0
app_file: app.py
pinned: false
license: mit
short_description: Edit text documents with your voice!
tags: [webrtc, websocket, gradio, secret|HF_TOKEN, secret|SAMBANOVA_API_KEY]
---

# Voice Text Editor

Edit text documents with your voice!


