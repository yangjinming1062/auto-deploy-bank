---
title: Talk to Llama 4
emoji: 🦙
colorFrom: purple
colorTo: red
sdk: gradio
sdk_version: 5.23.3
app_file: app.py
pinned: false
license: mit
short_description: Talk to Llama 4 using Groq + Cloudflare
tags: [webrtc, websocket, gradio, secret|HF_TOKEN, secret|GROQ_API_KEY]
---

Check out the configuration reference at https://huggingface.co/docs/hub/spaces-config-reference