---
title: Gemini Audio Video
emoji: ♊️
colorFrom: purple
colorTo: red
sdk: gradio
sdk_version: 5.25.2
app_file: app.py
pinned: false
license: mit
short_description: Gemini understands audio and video!
tags: [webrtc, websocket, gradio, secret|HF_TOKEN, secret|GEMINI_API_KEY]
---

Check out the configuration reference at https://huggingface.co/docs/hub/spaces-config-reference