import { _ as s } from "./mermaid.core-DBM7LDcW.js";
var t, e = (t = class {
  /**
   * @param init - Function that creates the default state.
   */
  constructor(i) {
    this.init = i, this.records = this.init();
  }
  reset() {
    this.records = this.init();
  }
}, s(t, "ImperativeState"), t);
export {
  e as I
};
