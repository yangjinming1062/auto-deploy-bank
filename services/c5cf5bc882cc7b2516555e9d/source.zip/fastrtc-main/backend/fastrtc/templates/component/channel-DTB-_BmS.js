import { ao as r, ap as n } from "./mermaid.core-DBM7LDcW.js";
const t = (a, o) => r.lang.round(n.parse(a)[o]);
export {
  t as c
};
