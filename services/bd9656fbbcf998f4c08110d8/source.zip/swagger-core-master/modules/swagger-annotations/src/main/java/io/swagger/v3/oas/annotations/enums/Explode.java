package io.swagger.v3.oas.annotations.enums;

public enum Explode {
    DEFAULT, FALSE, TRUE;
}
