package io.swagger.v3.core.resolving.v31.model;

@io.swagger.v3.oas.annotations.media.Schema(
        description = "MultipleSub1Bean"
)
public class MultipleSub1Bean extends MultipleBaseBean {
    public int c;
}
