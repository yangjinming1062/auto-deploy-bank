package io.swagger.v3.core.oas.models;

public class ModelWithPrimitiveArray {
    public int[] intArray;

    private long[] longArray;

    public long[] getLongArray() {
        return longArray;
    }

    public void setLongArray(long[] longArray) {
        this.longArray = longArray;
    }
}
