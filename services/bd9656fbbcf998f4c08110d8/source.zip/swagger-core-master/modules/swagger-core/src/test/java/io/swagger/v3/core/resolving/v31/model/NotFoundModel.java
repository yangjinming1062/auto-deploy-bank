package io.swagger.v3.core.resolving.v31.model;

public class NotFoundModel {
    int code;
    String message;

    public NotFoundModel() {
    }

    public NotFoundModel(int code, String message) {
        this.code = code;
        this.message = message;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
