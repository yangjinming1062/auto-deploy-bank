package io.swagger.v3.core.oas.models;

public class ModelWithEnumField {
    public TestEnum enumValue;
}
