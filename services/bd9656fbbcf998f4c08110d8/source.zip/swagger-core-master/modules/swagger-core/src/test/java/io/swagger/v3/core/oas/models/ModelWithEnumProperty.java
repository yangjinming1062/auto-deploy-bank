package io.swagger.v3.core.oas.models;

public class ModelWithEnumProperty {
    private TestEnum e;

    public TestEnum getEnumValue() {
        return e;
    }

    public void setEnumValue(TestEnum e) {
        this.e = e;
    }
}
