package io.swagger.v3.core.resolving.resources;

import java.util.Map;

public class TestObject2972 {

    public Map<String, String> myField1;
    public Map<String, String> myField2;
}
