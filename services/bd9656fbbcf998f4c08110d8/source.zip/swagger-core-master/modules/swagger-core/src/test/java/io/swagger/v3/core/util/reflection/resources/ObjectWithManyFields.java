package io.swagger.v3.core.util.reflection.resources;

public class ObjectWithManyFields {

    public String a;
    public boolean d;
    public Integer c;
    public Object b;

}
