package io.swagger.v3.core.oas.models;

import io.swagger.v3.oas.annotations.media.Schema;

public class Model1979 {
    @Schema(nullable = true)
    public String id;
}
