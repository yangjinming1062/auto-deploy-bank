package io.swagger.v3.core.filter.resources;

import io.swagger.v3.core.filter.AbstractSpecFilter;

/**
 * Does nothing
 **/
public class NoOpOperationsFilter extends AbstractSpecFilter {
}