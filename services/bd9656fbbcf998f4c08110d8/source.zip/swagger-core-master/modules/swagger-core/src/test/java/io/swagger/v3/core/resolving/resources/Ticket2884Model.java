package io.swagger.v3.core.resolving.resources;

@com.fasterxml.jackson.annotation.JsonTypeInfo(
        use = com.fasterxml.jackson.annotation.JsonTypeInfo.Id.NAME,
        include = com.fasterxml.jackson.annotation.JsonTypeInfo.As.WRAPPER_OBJECT)
public interface Ticket2884Model {}
