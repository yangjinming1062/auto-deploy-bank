package io.swagger.v3.core.util.reflection.resources;

public interface IGrandparent<T extends Number> {
    String parametrizedMethod5(T arg);
}
