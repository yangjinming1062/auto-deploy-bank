package io.swagger.v3.core.resolving.resources;

public enum Ticket2862ModelImpl implements Ticket2862Model {
    VALUE1,
    VALUE2
}
