package io.swagger.v3.core.oas.models;

public class ModelPropertyName {
    public boolean is_persistent() {
        return true;
    }

    public String gettersAndHaters() {
        return null;
    }
}