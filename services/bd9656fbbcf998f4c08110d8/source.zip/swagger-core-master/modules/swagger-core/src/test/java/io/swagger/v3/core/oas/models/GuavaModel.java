package io.swagger.v3.core.oas.models;

import com.google.common.base.Optional;

public class GuavaModel {
    private Optional<String> name;

    public Optional<String> getName() {
        return name;
    }

    public void setName(Optional<String> name) {
        this.name = name;
    }
}
