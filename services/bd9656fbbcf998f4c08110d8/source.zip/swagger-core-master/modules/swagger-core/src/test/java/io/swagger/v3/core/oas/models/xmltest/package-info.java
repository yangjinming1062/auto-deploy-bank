@javax.xml.bind.annotation.XmlSchema(
        namespace = "https://www.openapis.org/test/nested",
        elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED
)
package io.swagger.v3.core.oas.models.xmltest;
