package io.swagger.v3.core.util;

public class Parameter31Deserializer extends ParameterDeserializer {

    public Parameter31Deserializer() {
        this.openapi31 = true;
    }
}
