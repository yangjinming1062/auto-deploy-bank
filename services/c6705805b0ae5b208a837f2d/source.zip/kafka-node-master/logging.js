'use strict';

const logging = require('./lib/logging');

exports.setLoggerProvider = logging.setLoggerProvider;
