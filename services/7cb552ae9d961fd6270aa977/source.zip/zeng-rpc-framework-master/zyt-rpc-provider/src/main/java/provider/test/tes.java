package provider.test;

import org.junit.jupiter.api.Test;

/**
 * @Author 祝英台炸油条
 * @Time : 2022/5/20 16:44
 **/
public class tes {
    @Test
    public void test() {
        String s = null;
        assert s != null;
    }
}
