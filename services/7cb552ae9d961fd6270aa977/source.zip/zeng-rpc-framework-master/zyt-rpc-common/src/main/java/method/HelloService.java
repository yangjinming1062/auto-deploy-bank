package method;

/**
 * @author ףӢ̨ը����
 */
public interface HelloService {
    String sayHello(String saying);
}
