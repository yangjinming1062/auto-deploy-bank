package monitor.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import monitor.RpcMonitor;

/**
 * @Author 祝英台炸油条
 * @Time : 2022/6/3 19:32
 **/

public interface RpcMonitorMapper extends BaseMapper<RpcMonitor> {
}
