package method;

/**
 * @author ףӢ̨ը����
 */
public interface ByeService {
    String sayBye(String saying);
}
