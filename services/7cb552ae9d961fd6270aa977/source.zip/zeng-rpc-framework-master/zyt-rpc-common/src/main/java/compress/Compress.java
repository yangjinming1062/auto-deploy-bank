package compress;

import annotation.CompressFunction;

/**
 * @author 祝英台炸油条
 * 之前的解压缩是否开启注册类  这个现在已经过时了
 */
@Deprecated
@CompressFunction(isOpenFunction = true)
public interface Compress {

}
