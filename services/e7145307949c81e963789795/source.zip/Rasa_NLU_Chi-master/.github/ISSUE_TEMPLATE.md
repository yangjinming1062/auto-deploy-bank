<!-- If you don't know your Rasa NLU version, here is some help: https://goo.gl/g9QQg2. If you are creating a feature request, feel free to remove all the system information stuff. --> 

**Rasa NLU version**:

**Operating system** (windows, osx, ...):

**Content of model configuration file**:
```yml

```

**Issue**:

