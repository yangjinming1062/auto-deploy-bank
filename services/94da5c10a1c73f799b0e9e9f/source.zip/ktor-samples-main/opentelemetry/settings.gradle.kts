rootProject.name = "opentelemetry-ktor-sample"

include(":server")
include(":client")
include(":shared")