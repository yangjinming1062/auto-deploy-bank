# Structured Logging

An application showing how to do structured [logging](https://ktor.io/docs/logging.html).

## Running

Execute this command to run the sample:

```bash
./gradlew run
```

Then, navigate to [http://localhost:8080/](http://localhost:8080/) to see the sample home page.
