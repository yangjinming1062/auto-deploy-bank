rootProject.name = "ktor-native-image-server-with-config"
