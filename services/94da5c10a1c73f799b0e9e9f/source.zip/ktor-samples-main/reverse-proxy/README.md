# Reverse Proxy Application

This sample shows how to write a reverse proxy application.

## Running

Execute this command to run this sample:

```bash
./gradlew run
```
