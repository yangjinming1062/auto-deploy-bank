# SSE

A sample project showing how to use the SSE (Server-Sent Events) specification.

## Running

Execute this command to run the sample:

```bash
./gradlew run
```

Then, navigate to [http://localhost:8080/](http://localhost:8080/) to see the demo.
