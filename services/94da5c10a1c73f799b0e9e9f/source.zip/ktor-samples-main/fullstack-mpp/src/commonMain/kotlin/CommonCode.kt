package io.ktor.samples.fullstack.common

fun getCommonWorldString() = "common-world"