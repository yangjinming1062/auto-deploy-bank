# Kodein-DI

A sample project for [Ktor](https://ktor.io) showing how to use [Kodein DI](https://kodein.org/Kodein-DI/) with Ktor.

## Running

Execute this command to run the sample:

```bash
./gradlew run
```

Then, navigate to [http://localhost:8080/users](http://localhost:8080/users) to see the sample home page.
