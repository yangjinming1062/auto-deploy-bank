# Ktor-client-wasm

A compose wasm-js application using Ktor HttpClient to make requests.

## Running

Execute this command to run the sample:

```bash
./gradlew clean wasmJsBrowserDevelopmentRun
```
 
Then, navigate to [http://localhost:8080/](http://localhost:8080/) to see the sample home page.  
