# RxJava

An application showing how to use RxJava with [Ktor](https://ktor.io).

## Running

Execute this command to run the sample:

```bash
./gradlew run
```

Then, navigate to [http://localhost:8080/](http://localhost:8080/) to see the sample home page.
