# Open API Generation

This sample shows how to use Ktor's OpenAPI tooling.

The build is configured to use the OpenAPI extension from Ktor's Gradle plugin, and there is an endpoint for serving the documentation using the [OpenAPI](https://ktor.io/docs/server-openapi.html) Ktor plugin.
