# Location Header

An application demonstrating how to use the `Location` HTTP headers.

## Running

Execute this command to run this sample:

```bash
./gradlew run
```
 
To work with the demo, you need to make a POST request. If using IntelliJ IDEA, open the [Test.http](Test.http) file to make test requests.

  