# File listing

A sample project for [Ktor](https://ktor.io) showing how to create a file listing support for [static files](https://ktor.io/docs/serving-static-content.html).

## Running

Execute this command to run the sample:

```bash
./gradlew run
```

Then, navigate to [http://localhost:8080/](http://localhost:8080/) to see the sample home page.
