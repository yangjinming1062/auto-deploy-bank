package com.example.model.entity

data class Wishlist(val id :Int,val wish: String)