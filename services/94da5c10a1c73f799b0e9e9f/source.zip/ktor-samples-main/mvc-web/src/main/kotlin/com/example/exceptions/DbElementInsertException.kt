package com.example.exceptions

class DbElementInsertException(message: String? = null, throwable: Throwable? = null) : Throwable(message, throwable)