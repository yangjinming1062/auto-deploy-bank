rootProject.name = "jwt-auth-tests"
