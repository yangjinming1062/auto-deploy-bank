package com.example.exceptions

class DbElementNotFoundException(message: String? = null, throwable: Throwable? = null) : Throwable(message, throwable)