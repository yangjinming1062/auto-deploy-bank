# Reverse Proxy Application

A reverse proxy application written using [WebSockets](https://ktor.io/docs/websocket.html).

## Running

Execute this command to run this sample:

```bash
./gradlew run
```
