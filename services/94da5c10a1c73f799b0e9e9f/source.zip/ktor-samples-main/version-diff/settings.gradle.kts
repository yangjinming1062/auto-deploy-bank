
rootProject.name = "version-diff"

