# Redirect With Exception

This sample shows how to set up a redirect with when the request handling failed with an exception.


## Running

Execute this command to run this sample:

```bash
./gradlew run
```
