package org.ruoyi.common.chat.constant;

/**
 * @author https:www.unfbx.com
 * @since 2023-03-06
 */
public class OpenAIConst {

    public final static String OPENAI_HOST = "https://api.openai.com/";

    public final static String apiUrl = "v1/chat/completions";

    public final static int SUCCEED_CODE = 200;

}
