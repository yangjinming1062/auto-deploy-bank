package org.ruoyi.common.chat.openai.exception;

/**
 * @author https:www.unfbx.com
 * 2023-02-11
 */
public interface IError {
    String msg();

    int code();
}
